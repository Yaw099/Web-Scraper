# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document outlines the High Impact Large Load Generator Assessment (HILLGA) process, a new SPP framework designed to expedite approval of supporting generation for large loads while maintaining transmission system reliability. The HILLGA process allows generation connection studies to run parallel with High Impact Large Load (HILL) registration, enabling dedicated capacity to serve large loads in the interim (up to 5 years) while pursuing full generator interconnection. The process was approved by the Board on 09/03/2025 and filed with FERC on 10/24/2025, with expected FERC acceptance by January 15, 2025. The framework includes a 90-day study timeline and specific submission requirements under Attachment BB.

## 2. Key Topics

- **HILLGA Process Framework**: New expedited approval process for supporting generation dedicated to large loads
- **Load Limited Resource Interconnection Service (LLRIS)**: Interim service model limited to supporting specific HILL loads
- **Study Timeline**: 90-day HILLGA System Impact Study (SIS) requirement
- **Local Interconnection Requirements**: Point of Interconnection must be within two substations of HILL's Local Delivery Facilities
- **Maximum Injection Capability**: Limited to 110% plus seasonal Planning Reserve Margin OR 125% of associated HILL request MW
- **Transition to Full Interconnection**: Path to Network Resource Interconnection Service (NRIS) or Energy Resource Interconnection Service (ERIS) through Consolidated Planning Process
- **Nonjurisdictional Generation (NJG)**: Impact on existing processes per BP7250
- **Technical Analysis Requirements**: Steady-state, transient stability, short circuit ratio, and SCRCCT screening

## 3. Decisions or Actions

**Completed Actions:**
- Board approved HILLGA process on 09/03/2025
- SPP filed final HILLGA proposal on 10/24/2025
- Process available under special contract pending FERC approval

**Required Actions:**
- SPP must acknowledge HILLGA Request within 5 business days
- SPP has 15 calendar days for Review Period
- HILLGA Customer has 10 business days to cure deficiencies if identified
- SPP must complete HILLGA SIS within 90 calendar days
- Transmission Owner must perform Facilities Analysis within same 90 days
- If Re-Study required, SPP must complete within 60 calendar days
- HILLGA Customer must negotiate and execute HILLGIA within 45 business days
- Transmission Owners must notify SPP of interconnection requests for units 5 MW or more
- HILLGA Customers must submit full Interconnection Request in subsequent CPP for uninterrupted service

**Recommendations:**
- Provide PSCAD model at time of submission to avoid delays from EMT studies if SCRCCT screening fails

## 4. Important Dates

- **09/03/2025**: Board Approval of HILLGA process (available under special contract)
- **10/24/2025**: SPP filed final HILLGA proposal with FERC
- **January 15, 2025**: Expected FERC acceptance deadline (Note: This appears to be an error in the source document as it predates the filing date)
- **11/25/2025**: Document published
- **11/26/2025**: Correction published to Submission Requirements

**Process Timelines:**
- 90 calendar days: HILLGA System Impact Study completion
- 60 calendar days: Re-Study completion (if required)
- 45 business days: HILLGIA negotiation and execution
- 5 years: Maximum service term from Commercial Operation Date
- 5 business days: SPP acknowledgment of HILLGA Request
- 15 calendar days: SPP Review Period
- 10 business days: Cure deficiencies period

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)**: Primary regulatory authority administering HILLGA process
- **FERC (Federal Energy Regulatory Commission)**: Regulatory approval authority
- **SPP Board**: Approved HILLGA process
- **Transmission Owners**: Perform Facilities Analysis, notify SPP of interconnection requests
- **Transmission Customers**: Party planning for load with HILLGA Customer
- **HILLGA Customers**: Entities submitting HILLGA requests
- **AFS (Affected System) entities**: Entities requiring coordination for system impact
- **Distribution providers**: May submit generation requests through Transmission Owners

**People Mentioned:**
- None specifically identified

## 6. Links or References

**Tariff Attachments:**
- Attachment BB (Section 3.1.1): Submission requirements
- Attachment AQ: Study agreement specifications
- Attachment AX: Study agreement specifications
- Attachment BA: Study agreement specifications

**Business Practices:**
- BP7250 (Business Practice 7250): Nonjurisdictional generator interconnection procedures (Section 6.3, Section 8)

**Agreements:**
- HILL-Load Connection Study agreement
- HILL-GIA (HILL Generator Interconnection Agreement)
- HILLGIA (HILLGA Generator Interconnection Agreement)
- Affected System Study Agreement

**Related Processes:**
- Consolidated Planning Process (CPP)
- HILL registration process
- Generator Interconnection (GI) processes

**Revision Requests:**
- RR696 (referenced as impacting existing processes)
- RR720 (in development, impacts existing processes)

## 7. Suggested Tags

- HILLGA
- High Impact Large Load
- Generator Interconnection
- Load Limited Resource Interconnection Service (LLRIS)
- SPP OATT
- System Impact Study
- FERC Filing
- Transmission Planning
- Consolidated Planning Process
- Network Resource Interconnection Service (NRIS)
- Energy Resource Interconnection Service (ERIS)
- Attachment BB
- BP7250
- Nonjurisdictional Generation
- Deliverability Area
- Facilities Analysis
- SCRCCT
- Electromagnetic Transient Study
- Planning Reserve Margin

## 8. Items That May Need Follow-Up

**Critical Follow-Up Items:**

1. **Date Discrepancy**: The FERC acceptance deadline (January 15, 2025) appears to predate the filing date (10/24/2025). This needs clarification and correction.

2. **FERC Approval Status**: Monitor FERC acceptance of the HILLGA proposal to confirm the process becomes fully effective beyond special contract basis.

3. **Revision Request Implementation**: Track development and implementation of RR696 and RR720 and their specific impacts on existing processes.

4. **EMT Study Requirements**: Clarify process and timeline when SCRCCT screening fails and Electromagnetic Transient studies are required outside the 90-day timeline.

5. **Expedited Designation Process**: Details of the "expedited designation process" for transition to NRIS are mentioned but not fully explained.

6. **Multi-HILL Support**: Clarify requirements and limitations when "HILL Generating Facility may be supporting multiple HILL's" (5 substations maximum, 2 transmission line segments).

7. **Non-jurisdictional Generation Coordination**: Ensure clear procedures for HILLGA requests interconnecting to non-SPP controlled facilities per Section 6.3 of BP7250.

8. **Deposit Requirements**: Specific deposit amounts for HILLGA Request submission are not detailed in this document.

9. **Deliverability Area Determination**: Process for identifying and confirming the Deliverability Area for Point of Interconnection needs clarification.

10. **Affected System Coordination**: Detailed procedures for coordinating with AFS entities within the 90-day study window.

11. **Re-Study Triggers**: Specific conditions that would require a Re-Study are not detailed.

12. **Service Extension Options**: Process for HILLGA Customers approaching the 5-year service term limit who haven't transitioned to full interconnection.

13. **Document Version Control**: Monitor for additional corrections following the 11/26/2025 update to Submission Requirements.