# Final Combined Report

# Comprehensive Analysis Report: RR696 SPP Comments (All 27 Chunks)

## Executive Summary

This analysis covers RR696, a comprehensive Southwest Power Pool (SPP) tariff revision request submitted on August 27, 2025 (likely 2025 based on context). The revision establishes a framework for integrating High Impact Large Loads (HILL) into SPP's transmission system while maintaining grid reliability. The document underwent multiple stakeholder revision rounds (July 11, July 28, August 15, and August 26, 2025), with significant modifications including removal of Conditional HILL provisions, alignment of resource requirements, and strengthened data requirements following Market Monitoring Unit input.

The full document encompasses:
- HILL integration framework and operational procedures
- Extensive transmission rate schedules across 19 zones
- Day-Ahead Market and Real-Time Balancing Market protocols
- Resource adequacy and must-offer requirements
- Transmission planning and delivery point assessment processes
- Revenue allocation and cost recovery mechanisms

---

## Key Topics (Consolidated)

### 1. High Impact Large Load (HILL) Framework
- Comprehensive assessment and interconnection process
- HILLGA (High Impact Large Generator Associated with Load) provisions
- Study process requirements (90-day vs. 60-day timelines)
- Metering and ramp rate requirements (20 MW)
- Capacity accreditation methodology (shifted from nameplate to projected MW)
- Separation from Non-Conforming Load classification

### 2. Transmission Rate Structures
- Point-To-Point Transmission Service (Firm and Non-Firm)
- Network Integration Transmission Service
- 19 transmission zones with distinct rate schedules
- On-Peak/Off-Peak pricing differentials
- Formula rate methodologies and Annual Transmission Revenue Requirements (ATRR)
- Schedule 1, 1-A, 2, 7, 8, 9, 11, and 12 revenue mechanisms

### 3. Market Operations
- Day-Ahead Market SCUC/SCED algorithms
- Reliability Unit Commitment (Day-Ahead and Intra-Day)
- Real-Time Balancing Market procedures
- Must-offer obligations (90% threshold)
- Manual commitment procedures for reliability issues
- Virtual Energy Offers/Bids integration
- Operating Reserve co-optimization

### 4. Resource and Load Management
- Non-Conforming Load forecasting requirements (≥50 MW)
- Energy Storage Resource treatment
- Multi-Configuration Resource (MCR) operational rules
- Demand Response Programs (controllable vs. non-controllable)
- Behind-The-Meter Generation (<10 MW)
- Resource Day Ahead Must Offer requirements

### 5. Transmission Planning
- SPP Transmission Expansion Plan (STEP) approval processes
- ITP Upgrades, Balanced Portfolios, Sponsored Upgrades
- Generator Interconnection Procedures
- Delivery Point Assessment (Attachments AQ and AX)
- Network Upgrade cost allocation
- Interregional planning coordination

### 6. Cost Recovery and Revenue Allocation
- Zonal vs. Region-wide charge methodology
- Balanced Portfolio Reallocation
- Point-to-Point revenue crediting
- Upgrade Sponsor payments
- Local vs. regional cost recovery for reliability commitments
- JTIQ ATRR Balance allocation

### 7. System Operations and Reliability
- ICCP connectivity requirements (dual-node for TOPs/GOPs)
- Emergency Operating Plans
- Local Reliability Issue procedures
- Transmission Material Modification definitions
- System protection and configuration change reporting

---

## Decisions and Actions (Consolidated)

### Completed Actions (HILL Framework):
1. **Removed CHILL provisions** (Conditional High Impact Large Load)
2. **Modified capacity calculation** from nameplate to projected accreditation MW
3. **Separated HILL from Non-Conforming Load** classification
4. **Updated study timeline** to 90 days (vs. standard 60)
5. **Adjusted capacity percentage** from 100% to 110% (Attachment BB 3.1.1(2))
6. **Strengthened data requirements** based on MMU August 26, 2025 comments
7. **Relocated ramp rate requirements** from tariff to Integrated Marketplace Protocols

### Rate and Revenue Actions:
1. **Reactive Compensation Rate** set at $2.26/MVArh
2. **Power factor dead band** established at 0.95
3. **FERC Assessment Charge Rate** to be calculated and posted annually by March 1
4. **AEP canceled project recovery** of $3,264,402.55 commencing April 1, 2018
5. **Multiple formula rate posting deadlines** established (various dates by entity)

### Market Operations Actions:
1. **90% must-offer compliance threshold** established
2. **SCUC/SCED algorithm priority orders** defined for capacity shortages/surpluses
3. **Manual commitment protocols** requiring Market Monitor verification
4. **VRL (Violation Relaxation Limit)** application procedures in SCED
5. **MCR transition restrictions** (>30 minutes ineligible for certain reserves)

### Planning and Study Actions:
1. **Board approval required** for ITP Upgrades, Balanced Portfolios, high priority upgrades
2. **10-day minimum notice** before Board action on project lists
3. **Quarterly STEP modification posting** requirements
4. **90-day study completion** for Load Connection Studies and PLPS
5. **ICCP dual-node connectivity** required for TOPs and large GOPs (>1500 MW)

---

## Important Dates (Consolidated)

### RR696 Development Timeline:
- **July 11, 2025**: First round SPP comments
- **July 28, 2025**: Second round SPP comments
- **July 2025**: MOPC meeting (Energy Storage Resource Load Assessment approval)
- **August 15, 2025**: Third round SPP comments
- **August 26, 2025**: MMU comments received
- **August 27, 2025**: Fourth round SPP comments submitted

### Annual Recurring Deadlines:
- **March 1**: FERC Assessment Charge Rate effective date
- **September 1**: OG&E and Tri-State formula rate postings
- **October 1**: NPPD, SPS, and multiple other formula rate postings
- **October 15**: Evergy Kansas Central formula rate posting
- **December 15**: NPPD formula calculation results posting
- **January 1**: Effective date for most annual rate updates
- **July 1**: Tri-State rate effective date
- **July 20**: OPPD formula calculation posting
- **August 1**: OPPD rate effective date

### Study and Request Timelines:
- **90 days**: HILL study completion, Load Connection Studies, PLPS
- **60 days**: Standard interconnection study timeline
- **30 days**: LCS/DPNS Agreement execution deadline
- **10 Business Days**: Host Transmission Owner response to study requests
- **5 Business Days**: DPNS Agreement delivery after preliminary assessment

### Market Operation Timeframes:
- **20 minutes**: Final deadline for energy scheduling changes before Operating Hour
- **30 minutes**: Non-Conforming Load forecast update deadline; Non-Firm hourly request window
- **240 seconds**: ICCP node reconnection requirement after failure

### Canceled Project Recovery:
- **April 1, 2018**: AEP recovery commencement ($3,264,402.55)
- **March 1, 2019**: AEP recovery commencement ($414,465)
- **January 1, 2024**: Sunflower recovery commencement ($718,359)
- **12-month period**: Standard recovery timeframe for canceled projects

---

## Organizations and People Mentioned (Consolidated)

### Primary Regulatory Bodies:
- **SPP (Southwest Power Pool)** - Regional Transmission Organization
- **FERC (Federal Energy Regulatory Commission)** - Primary regulatory authority
- **NERC (North American Electric Reliability Corporation)** - Reliability standards
- **Market Monitor/Market Monitoring Unit (MMU)** - Compliance oversight

### SPP Governance:
- **SPP Board of Directors** - Final approval authority
- **Markets and Operations Policy Committee (MOPC)** - Recommendation body
- **Regional State Committee** - Review and consultation
- **Economic Studies Working Group (ESWG)**
- **Transmission Working Group (TWG)**

---

# Partial Chunk Reports

# Chunk 1 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document is a comment form for Revision Request 696 (RR696) submitted by SPP (Southwest Power Pool) on August 27, 2027 (likely 2025 based on timeline context). The RR focuses on establishing a comprehensive framework for integrating High Impact Large Loads (HILL) into SPP's transmission system. The request aims to accelerate large load interconnections while maintaining grid reliability through integrated design, study, registration, and operations processes. Multiple rounds of stakeholder feedback have been incorporated, with significant revisions made in July and August 2025, including removal of Conditional High Impact Large Load (CHILL) provisions, alignment of resource requirements, and strengthening of data requirements following Market Monitoring Unit (MMU) input.

## 2. Key Topics

- **High Impact Large Load (HILL) Integration Framework**: Comprehensive assessment and interconnection process for significant new loads
- **High Impact Large Generator Associated with Load (HILLGA)**: Generation resources associated with large loads, with capacity limits based on accredited capacity rather than nameplate values
- **Study Process Requirements**: Extended timelines (90 days vs. 60 days for standard interconnections) and enhanced data requirements
- **Metering Requirements**: Specific specifications for HILL in the Protocols
- **Resource Day Ahead Must Offer Requirements**: Alignment with existing requirements for resources
- **Ramp Rate Requirements**: 20 MW ramp rate requirement relocated to Integrated Marketplace Protocols
- **Transmission Cost Allocation**: Revenue requirement calculations and demand charges
- **Regulatory Compliance**: Alignment with NERC standards and ensuring transparency

## 3. Decisions or Actions

### Completed Actions:
- **Removed CHILL provisions**: Conditional High Impact Large Load and related Deliverability Area path for generation removed based on stakeholder feedback
- **Modified capacity calculation methodology**: Shifted from generator nameplate value to projected capacity accreditation MW value for HILLGA maximum injection limits
- **Separated HILL from Non-Conforming Load**: Made HILL independent of Non-Conforming Load classification
- **Updated study timeline**: Maintained 90-day timeline for HILL (vs. standard 60-day) in Attachment AQ 3.2
- **Adjusted capacity percentage**: Modified Attachment BB 3.1.1(2) from 100% to 110%
- **Strengthened data requirements**: Modified Attachments BB and BA based on MMU comments (August 26, 2025)
- **Relocated ramp rate requirements**: Moved 20 MW ramp rate requirement from tariff attachments to Integrated Marketplace Protocols

### Pending Actions:
- Approval of Energy Storage Resource Load Assessment language at July 2025 MOPC (Markets and Operations Policy Committee)
- Final approval of all tariff and protocol modifications

## 4. Important Dates

- **July 11, 2025**: First round of SPP comments (highlighted in yellow)
- **July 28, 2025**: Second round of SPP comments (highlighted in teal)
- **July 2025**: MOPC meeting for Energy Storage Resource Load Assessment approval
- **August 15, 2025**: Third round of SPP comments (highlighted in green)
- **August 26, 2025**: MMU comments received
- **August 27, 2025**: Fourth round of SPP comments (highlighted in gray) - submission date
- **Timeline references**: 60 Calendar Days (standard), 90 Calendar Days (HILL cases)

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)**: Primary organization and submitter
- **MOPC (Markets and Operations Policy Committee)**: Approval body
- **MMU (Market Monitoring Unit)**: Provided comments on August 26, 2025
- **Western Area Power Administration Division**: Identified as potential party to certain GIAs
- **NERC (North American Electric Reliability Corporation)**: Standards reference
- **FERC (Federal Energy Regulatory Commission)**: Referenced in context of service agreements
- **Transmission Owners**: American Electric Power, Southwestern Public Service (specifically mentioned)

### People:
- **Caroline Chapman** (cchapman@spp.org): SPP representative and form submitter

## 6. Links or References

### Referenced Documents/Attachments:
- **Attachment AE**: Resource Day Ahead Must Offer requirements
- **Attachment AQ**: Study process requirements (Section 3.2)
- **Attachment AU**: Revenue distribution provisions
- **Attachment AX**: HILL study process clarity
- **Attachment BA**: Data requirements
- **Attachment BB**: Primary HILL provisions (Sections 3, 3.1.1)
  - Appendix 3: HILLGA GIA for Western Area Power Administration Division
- **Attachment H**: Zonal Annual Transmission Revenue Requirement (includes Addendums 1 and 5)
- **Attachment J**: Reallocation provisions
- **Attachment L**: Schedule 7 and 8 revenue distribution
- **Part 1, Common Service Provisions**: Definitions
- **Integrated Marketplace Protocols**: Operational requirements and metering specifications
- **Schedule 1-A**: Tariff Administration Services
- **Schedule 7 and 8**: Revenue schedules

### Source Document:
- **RR696 SPP Comments 20250827.docx.txt** (chunk 1 of 27)

## 7. Suggested Tags

- High Impact Large Load (HILL)
- HILLGA
- Interconnection Studies
- Grid Reliability
- Load Integration
- Transmission Planning
- SPP Tariff Revisions
- RR696
- Capacity Accreditation
- NERC Compliance
- Market Efficiency
- Energy Storage Resources
- Transmission Revenue Requirements
- Stakeholder Process
- Large Load Assessment
- Ramp Rate Requirements
- Generation Interconnection Agreement (GIA)

## 8. Items That May Need Follow-Up

### Immediate Follow-Up Required:
1. **MOPC Approval Status**: Track approval of Energy Storage Resource Load Assessment language at July 2025 MOPC meeting
2. **MMU Comments Resolution**: Verify all August 26, 2025 MMU comments have been adequately addressed in the data requirements modifications
3. **Stakeholder Feedback Validation**: Confirm stakeholder acceptance of CHILL removal and HILL/Non-Conforming Load separation

### Policy/Process Clarifications Needed:
4. **Ramp Rate Specification**: Ensure 20 MW ramp rate requirement is properly documented in Integrated Marketplace Protocols following relocation from tariff attachments
5. **110% Capacity Threshold**: Understand rationale and implications of the change from 100% to 110% in Attachment BB 3.1.1(2)
6. **Western Area Power Administration**: Clarify scope and application of Attachment BB Appendix 3 for GIA cases involving this entity
7. **Metering Requirements**: Verify HILL metering specifications are complete and implementable

### Implementation Concerns:
8. **Timeline Coordination**: Ensure 90-day HILL study timeline is operationally feasible and properly resourced
9. **Cost Recovery Mechanism**: Validate Schedule 1-A rate cap ($0.515) adequacy for HILL administration costs
10. **Affected System Studies**: Review additional detail added to Attachment BB Section 3 to ensure completeness

### Long-Term Monitoring:
11. **Benefits Realization**: Establish metrics to track claimed benefits:
    - Reduction in planning reserve margin requirements
    - Avoidance of transmission upgrades/congestion costs
    - Curtailment reduction quantification
    - Emergency procedure cost savings
    - Study efficiency improvements
12. **Market Entry Speed**: Monitor actual time-to-market for HILL projects under new framework
13. **Regulatory Compliance**: Track FERC response and any required modifications
14. **Load Predictability**: Assess whether HILL framework improves forecasting accuracy as anticipated

### Documentation Completeness:
15. **Remaining Chunks**: This is chunk 1 of 27 - review remaining 26 chunks for additional context, definitions, detailed procedures, and potential conflicts or gaps

---

# Chunk 2 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document is chunk 2 of 27 from SPP (Southwest Power Pool) tariff comments dated August 27, 2025 (RR696). The content focuses on detailed rate schedules and billing methodologies for transmission services, including:

- **Schedule 1-A1**: Network Integration and Point-to-Point Transmission Service billing determinants and rate formulas
- **Schedule 1**: Scheduling, System Control and Dispatch Service rates for through/out transactions and transactions sinking within the Transmission System
- **Schedule 2**: Reactive Supply and Voltage Control compensation rates for Qualifying Generators (QGs)
- **Schedule 11**: Base Plan Zonal Charge and Region-wide Charge assessment methodologies

The document establishes complex rate calculations, billing determinants, on-peak/off-peak definitions, and revenue distribution mechanisms for various transmission services within the SPP Region.

## 2. Key Topics

### Transmission Service Billing
- Network Integration Transmission Service billing determinants based on Network Load
- Point-to-Point Transmission Service billing based on MW hours reserved
- Bundled retail load and Grandfathered Agreements treatment

### Rate Calculation Methodologies
- Schedule 1-A1 annual rate determination process
- Schedule 1 rates computed from revenue requirements and Resident Load
- On-Peak and Off-Peak rate differentials (hourly, daily, weekly, monthly)

### Reactive Power Compensation
- Reactive Compensation Rate (RCR) set at $2.26 per MVArh
- Qualifying Generator (QG) compensation based on Reactive Power Outside the Dead Band (RPOD)
- Power factor maintenance at 0.95 threshold

### Zonal vs. Region-wide Charges
- Multi-owner Zone rate calculations
- Zone-specific Schedule 1 and Schedule 2 charges
- Through and Out transaction treatments
- Western-UGP exemption from Region-wide Charge

### Time-of-Use Definitions
- Off-Peak: Saturdays, Sundays, and NERC holidays
- On-Peak hours: HE 0700 through HE 2200 Central Prevailing Time
- Various rate divisors (260 days for on-peak daily, 365 for off-peak daily, etc.)

## 3. Decisions or Actions

### Established Rate Structures
- Reactive Compensation Rate fixed at **$2.26 per MVArh**
- Power factor dead band established at **0.95**
- Revenue Requirements and Rates File (RRR File) to be posted on SPP website

### Calculation Procedures
- Transmission Provider shall calculate zonal Schedule 1 rates by summing rates of each Transmission Owner in multi-owner Zones
- Monthly RPOD calculations to determine QG compensation
- Revenue adjustments for Point-to-Point transactions already credited

### Billing Procedures
- Monthly charges to be billed in next billing cycle after sufficient RPOD data available
- SPP shall post applicable monthly Schedule 2 charges promptly
- Pro-rata revenue distribution when collected revenues don't match Zone Revenue Credits (ZRC)

### Review Mechanisms
- Transmission Provider may periodically review RCR to ensure it reflects upper end of reasonable cost range
- Annual formula rate updates for certain Transmission Owners

## 4. Important Dates

### Recurring Billing Periods
- **Annual**: Calendar year basis for Schedule 1-A1 determination
- **Monthly**: Rate calculations (yearly rate ÷ 12)
- **Weekly**: Rate calculations (yearly rate ÷ 52)
- **Daily On-Peak**: Rate calculations (yearly rate ÷ 260)
- **Daily Off-Peak**: Rate calculations (yearly rate ÷ 365)
- **Hourly On-Peak**: Rate calculations (yearly rate ÷ 4,160)
- **Hourly Off-Peak**: Rate calculations (yearly rate ÷ 8,760)

### Time-of-Use Periods
- **On-Peak Hours**: HE 0700 through HE 2200 Central Prevailing Time (on qualifying days)
- **Off-Peak Days**: Saturdays, Sundays, and all NERC holidays

### Document Reference
- **Document Date**: August 27, 2025 (20250827)

## 5. Organizations and People Mentioned

### Organizations

**Primary Entities:**
- **SPP (Southwest Power Pool)** - Transmission Provider and Balancing Authority
- **Transmission Owners** - Multiple entities with approved/accepted rates
- **Network Customers** - Service recipients
- **Transmission Customers** - Point-to-Point service takers
- **NERC (North American Electric Reliability Corporation)** - Holiday schedule reference

**Geographic/Operational Entities:**
- **SPP Region** - Service territory
- **Eastern Interconnection** - Service application area
- **Western-UGP** - Exempt from Region-wide Charge
- **Zones** - Various transmission zones (unspecified by name in this chunk)

**Facility Types:**
- **Qualifying Generators (QGs)** - Reactive power providers
- **Joint Owned Units** - Shared generation facilities

### People Mentioned
No individual names are mentioned in this document chunk.

## 6. Links or References

### Internal Document References
- **Addendum 1 of Schedule 1-A** - Rate formula determination methodology
- **Section 31.4** - Network Load designation provisions
- **Part V of this Tariff** - Base Plan charges assessment
- **Table 1 ("Schedule 1 RR")** - Schedule 1 Revenue Requirements
- **Table 2 of Schedule 1** - Point-to-Point revenues already credited
- **Section III.B** - QG compensation calculations
- **Section III.C** - Rate calculation methodology
- **Section II.B.1** - Joint owned QG designation

### External Files/Systems
- **Revenue Requirements and Rates File (RRR File)** - Posted on SPP website
  - Schedule 1 tab
  - Zonal Sch 1 tab
- **SPP website** - Public posting location for rates

### Referenced Services
- **Network Integration Transmission Service**
- **Firm Point-To-Point Transmission Service**
- **Non-Firm Point-To-Point Transmission Service**
- **Grandfathered Agreements**
- **Scheduling, System Control and Dispatch Service**
- **Reactive Supply and Voltage Control Service**

## 7. Suggested Tags

### Primary Categories
- Transmission Rates
- Tariff Schedules
- Billing Determinants
- Rate Formulas

### Service Types
- Network Integration Service
- Point-to-Point Transmission
- Reactive Power Compensation
- Scheduling and Dispatch

### Technical Terms
- Revenue Requirements
- Zonal Charges
- Region-wide Charges
- On-Peak/Off-Peak
- Resident Load
- Reserved Capacity

### Regulatory/Compliance
- FERC Tariff
- SPP Comments
- RR696
- Rate Schedules

### Operational Concepts
- Through and Out Transactions
- Qualifying Generators
- Power Factor
- Dead Band
- MVArh Compensation

### Geographic
- SPP Region
- Eastern Interconnection
- Western-UGP
- Multi-owner Zones

## 8. Items That May Need Follow-Up

### Clarification Needed

1. **Western-UGP Exemption** - The text cuts off mid-sentence regarding Western-UGP's exemption from Region-wide Charge. **Complete language needed.**

2. **RR696 Document Context** - This is chunk 2 of 27; understanding the full context of what RR696 addresses and what changes are being proposed requires review of **chunks 1 and 3-27**.

3. **Specific Zone Identification** - No specific zone names or identifiers are provided in this chunk; clarification of which zones exist and their characteristics may be needed.

4. **Grandfathered Agreements** - Definition and specific terms of "Grandfathered Agreements" are referenced but not detailed; **cross-reference to definitions section needed**.

### Rate Review Items

5. **$2.26 per MVArh Rate Justification** - The Reactive Compensation Rate is stated as fixed, but periodic review mechanism is mentioned. **When was this rate last reviewed? What triggers review?**

6. **Revenue Mismatch Procedures** - Section III.D.2 addresses revenue mismatches but doesn't specify tolerance

---

# Chunk 3 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document is chunk 3 of 27 from SPP (Southwest Power Pool) tariff comments dated August 27, 2025 (RR696). It contains detailed provisions related to Schedule 11 (transmission charges), Schedule 12 (FERC Assessment Charge), and Attachment H (Annual Transmission Revenue Requirements). The content primarily focuses on the calculation methodologies for Base Plan Zonal Charges, Region-wide Charges, and FERC assessment recovery mechanisms. Key provisions address how transmission costs are allocated among Network Customers and Transmission Owners across different zones, with special exemptions for Western-UGP Federal Service and adjustments for point-to-point transmission revenue.

## 2. Key Topics

- **Schedule 11 Transmission Charges**: Methodology for calculating Base Plan Zonal Charges and Region-wide Charges for transmission service
- **Annual Transmission Revenue Requirement (ATRR)**: Calculation procedures including adjustments for point-to-point revenue, formula rates vs. stated rates
- **Load Ratio Shares**: Determination of monthly zonal and regional resident loads for various zones (Zones 1-19)
- **Special Zone Provisions**: 
  - Zone 10: Federal-Power Southwestern reductions
  - Zone 19: Western Interconnection and Western-UGP Federal Service Exemption exclusions
- **Revenue Adjustments**: Credits for point-to-point revenue, Attachment AU distributions, and SATOA market dispatches
- **Schedule 12 FERC Assessment**: Recovery mechanism for FERC regulatory charges
- **Western-UGP Statutory Load Obligations**: Treatment of Federal vs. Non-Federal service exemptions

## 3. Decisions or Actions

- **Annual FERC Assessment Calculation**: Transmission Provider must calculate and post FERC Assessment Charge Rate (FACR) prior to March 1 of each year
- **FACR Effective Date**: New rate becomes effective March 1 annually
- **Revenue Requirement Adjustments**: Transmission Provider shall adjust ATRRs based on previous calendar year point-to-point revenues (with different treatment for formula vs. stated rates)
- **Monthly Billing**: Transmission Provider shall bill customers in accordance with Section 7 procedures
- **Website Posting**: Results must be posted on SPP website
- **RRR File Updates**: Point-to-point revenue adjustments must be documented in the RRR (Rate Ready Reckoner) File

## 4. Important Dates

- **March 1 (Annual)**: Deadline for Transmission Provider to calculate and post FERC Assessment Charge Rate
- **March 1 (Annual)**: Effective date for new FERC Assessment Charge Rate
- **Previous Calendar Year**: Reference period for point-to-point revenue adjustments in ATRR calculations
- **Document Date**: August 27, 2025 (RR696 SPP Comments)

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)** - Transmission Provider
- **FERC (Federal Energy Regulatory Commission)** - Regulatory authority
- **Western-UGP (Western Area Power Administration - Upper Great Plains)** - Federal power entity
- **Network Customers** - Service recipients
- **Transmission Owners** - Facility owners in various zones
- **SATOA** (Specified entities with market dispatch revenue)

### People:
- No individual persons mentioned in this chunk

## 6. Links or References

### Internal Tariff References:
- Section 39.3(e) - Schedule 11 applicability
- Section 39.2 - Bundled Retail and Grandfathered Loads
- Section 31.3 - Network Load not physically interconnected
- Section 34.5 - Transmission System load determination
- Section 34.9 - Federal-Power Southwestern identification
- Section 7 - Billing procedures
- Attachment J - Cost allocation methodology (Section IV.A)
- Attachment H - ATRR specifications (Table 1, Table 2-A, Table 2-B, Table 3 Section 1)
- Attachment AU - Revenue distribution (Sections IV and V)
- Schedule 9 - Network Integration Transmission Service
- Schedule 11 - Base Plan transmission charges (Sections I, III)

### External References:
- FERC Part 382 regulations - FERC Assessment basis
- FERC Form 582 - Annual reporting form for energy transmission
- Commission filings - Required for Schedule 11 charge changes

### Website:
- SPP website - For posting FACR calculations

## 7. Suggested Tags

- Transmission_Rates
- Schedule_11
- Schedule_12
- FERC_Assessment
- Annual_Transmission_Revenue_Requirement
- Base_Plan_Zonal_Charges
- Region-wide_Charges
- Load_Ratio_Share
- Point-to-Point_Transmission
- Network_Integration_Service
- Western-UGP
- Federal_Service_Exemption
- Zone_Allocations
- Formula_Rates
- Revenue_Adjustments
- SPP_Tariff
- Attachment_H
- Attachment_J
- Cost_Recovery
- Transmission_Owner

## 8. Items That May Need Follow-Up

1. **FACR Calculation Verification**: Confirm March 1 deadline compliance for annual FERC Assessment Charge Rate calculation and posting

2. **Revenue Credit Methodology**: Verify proper treatment differences between Transmission Owners using:
   - Formula rates with annual updates (no adjustment per Section II.A.1)
   - Stated rates or formula rates without annual updates (differential adjustment per Section II.A.2)

3. **Zone-Specific Load Calculations**: Validate accurate determination of:
   - Zone 10 loads with Federal-Power Southwestern reductions
   - Zone 19 loads with Western Interconnection and Federal Service Exemption exclusions

4. **Western-UGP Federal Service Exemption Compliance**: Monitor instances where Non-Federal Service is provided to Western-UGP Statutory Load Obligations and ensure proper Region-wide Charge application per Section II.D

5. **RRR File Documentation**: Ensure all point-to-point revenue adjustments are properly documented in the Rate Ready Reckoner File

6. **Table 3 Section 1 Updates**: Verify Attachment H Table 3 Section 1 accurately reflects revenue credits already included in ATRR calculations

7. **Schedule 11 Commission Filing Requirements**: Track any proposed changes to Schedule 11 charges requiring Commission approval

8. **Balance Reconciliation**: Monitor Schedule 12 account balances for true-up calculations in subsequent years (Balance variable in FACR formula)

9. **Attachment AU Revenue Distributions**: Confirm proper allocation and distribution of point-to-point revenues under Sections IV and V of Attachment AU

10. **SATOA Market Dispatch Revenue**: Track and verify proper crediting of revenues from SATOA dispatches into Energy and Operating Reserve Markets where ATRR is recovered through Schedule 11

---

# Chunk 4 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document is chunk 4 of 27 from SPP (Southwest Power Pool) Comments dated August 27, 2025 (RR696). The content details technical specifications for calculating Annual Transmission Revenue Requirements (ATRR) across multiple zones and categories within the SPP region. It outlines the complex formula-based rate structures, revenue allocation methodologies, and specific transmission owner requirements. Key focus areas include Base Plan Upgrades, Region-wide ATRRs, Balanced Portfolio requirements, and special provisions for specific transmission owners like Southwestern Public Service Company and American Electric Power.

## 2. Key Topics

- **Annual Transmission Revenue Requirements (ATRR) Calculations**: Multiple methodologies for calculating zonal and region-wide ATRRs based on upgrade timing and classification
- **Base Plan Upgrades**: Different ATRR treatments for upgrades issued NTC (Notification to Construct) before vs. after June 19, 2010
- **Region-wide ATRR Components**: Including Base Plan, Balanced Portfolio, Interregional Planning, and JTIQ Upgrades
- **Revenue Requirement Filing Processes**: FERC filing requirements and formula rate update procedures
- **Transmission Owner-Specific Requirements**: Special provisions for SPS (Zone 11) and American Electric Power
- **Cost Recovery Mechanisms**: Schedule 7, 8, 9, and 11 revenue allocations
- **Canceled Project Recovery**: AEP recovery of $3,264,402.55 for specific canceled projects

## 3. Decisions or Actions

- **AEP Cost Recovery**: Commencing April 1, 2018, AEP ATRR includes $3,264,402.55 for canceled projects (Multi-Shipe Road and Line-Georgia Pacific projects)
- **Recovery Period**: 12-month recovery in equal monthly installments with interest per 18 C.F.R. § 35.19a(a)(2)(iii)
- **Formula Rate Updates**: Transmission Providers authorized to update revenue requirements on website upon successful completion of annual formula rate procedures without additional FERC filing
- **Joint Informational Filing Required**: SPP and AEP must file joint notification to FERC upon full recovery of canceled project costs

## 4. Important Dates

- **June 19, 2010**: Critical date distinguishing ATRR treatment for Base Plan Upgrades (NTC issued before vs. after)
- **October 1, 2015**: Transition date for Network Upgrade ATRR treatment (Table 2-A vs. Table 2-B)
- **April 1, 2018**: Commencement date for AEP canceled project cost recovery
- **October 1 (Annual)**: SPS formula calculation posting deadline
- **October 31 (Annual)**: AEP ATRR posting deadline
- **January 1 (Following Year)**: Effective date for annual rate updates

## 5. Organizations and People Mentioned

### Organizations:
- **Southwest Power Pool, Inc. (SPP)** - Transmission Provider
- **Federal Energy Regulatory Commission (FERC/Commission)** - Regulatory authority
- **Southwestern Public Service Company (SPS)** - Transmission Owner, Zone 11
- **Xcel Energy Operating Companies** - Parent/affiliated entity of SPS
- **American Electric Power (AEP)** - Transmission Owner
- **Associated Electric Cooperative, Inc.** - Party to cost sharing agreements
- **Various Transmission Owners** - Zones 1 through 19

### People Mentioned:
- None specifically identified

## 6. Links or References

### Internal Tariff References:
- **Schedule 7, 8, 9, 11** - Revenue schedules
- **Attachment H** - Current attachment being described
- **Attachment J** - Cost allocation methodology
- **Attachment Z2** - Upgrade Sponsor payment provisions
- **Attachment O** - Specific planning procedures; Addendum 1 lists coordination agreements
- **Attachment AU** - Revenue distribution methodology (Sections IV and V)
- **Attachment L** - Point-to-Point transmission revenue allocation
- **Attachment O – SPS** (Xcel Energy OATT) - SPS formula rate specification
- **Addendum 1 to Attachment H** - AEP formula rate

### External References:
- **18 C.F.R. § 35.19a(a)(2)(iii)** - Federal regulation for interest rate calculations
- **Revenue Requirements and Rates File (RRR File)** - Posted on SPP website
- **Xcel Energy OATT** - Joint Open Access Transmission Tariff
- **SPS OASIS website** - Rate posting location

### Specific Projects/Agreements:
- **Morgan Transformer Project** - Cost Sharing and Usage Agreement with AECI
- **Blackberry Substation Upgrade** - Cost and Usage Agreement with AECI
- **Multi-Shipe Road - East Rogers - Kings River 345 kV project** (Network Upgrades 10656, 10659, 10660) - Canceled
- **Line - Georgia Pacific - Keatchie 138 kV Ckt 1 project** (Network Upgrade 10616) - Canceled

## 7. Suggested Tags

- Annual Transmission Revenue Requirements (ATRR)
- Southwest Power Pool (SPP)
- Transmission Rate Structures
- FERC Tariff
- Base Plan Upgrades
- Network Upgrades
- Formula Rates
- Zone-Specific Rates
- Cost Recovery
- Interregional Planning
- Notification to Construct (NTC)
- Schedule 11
- American Electric Power (AEP)
- Southwestern Public Service (SPS)
- Balanced Portfolio
- JTIQ Upgrades
- Revenue Requirement Filing
- Canceled Projects

## 8. Items That May Need Follow-Up

1. **AEP Canceled Project Recovery Completion**: Monitor the full recovery of $3,264,402.55 and ensure joint SPP-AEP informational filing is made to FERC upon completion
   
2. **RRR File Updates**: Verify timely posting and removal of canceled project costs from RRR File after full recovery

3. **Annual Formula Rate Updates**: Track October 1 (SPS) and October 31 (AEP) posting deadlines for annual updates

4. **JTIQ ATRR Balance**: Monitor ongoing changes to JTIQ Upgrade-specific components as posted in RRR File

5. **Table References**: Note that actual Tables 1, 2-A, 2-B, and 3 are referenced but not shown in this chunk - verify completeness in full document

6. **Regulatory Acceptance**: Track status of revenue requirements pending acceptance/approval by applicable regulatory authorities

7. **Website Postings**: Confirm all required postings are made to SPP website and SPS OASIS website per specified timelines

8. **Coordination Agreement Updates**: Monitor any changes to coordination agreements listed in Addendum 1 to Attachment O that affect Line 7b calculations

9. **Document Completeness**: This is chunk 4 of 27 - review remaining chunks for additional context, decisions, or requirements

---

# Chunk 5 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document (chunk 5 of 27) from RR696 SPP Comments dated 2025-08-27 contains detailed provisions regarding cost recovery mechanisms for various network upgrades and transmission projects. The content primarily focuses on Annual Transmission Revenue Requirements (ATRR) for specific utilities including American Electric Power, Sunflower Electric Power Corporation, and Southwestern Power Administration. It outlines recovery processes for canceled network upgrade projects, sponsored upgrades, service upgrades, and generation interconnection-related network upgrades. The document establishes specific dollar amounts, recovery periods, and filing requirements for cost recovery related to transmission infrastructure.

## 2. Key Topics

- **Cost Recovery for Canceled Network Upgrades**: Mechanisms for recovering costs of canceled transmission projects through ATRR
- **American Electric Power (AEP) ATRR**: Recovery of costs for multiple canceled 138 kV and 345 kV projects totaling $414,465 (commencing March 1, 2019)
- **Sunflower Electric Power Corporation ATRR**: Recovery of $718,359 for canceled Device – Russell 115 kV project (commencing January 1, 2024)
- **Southwestern Power Administration Rate Calculations**: NITS ATRR component calculation methodology based on capacity ratios
- **Sponsored Upgrades**: Payment options and cost allocation for project sponsors
- **Service Upgrades**: Cost allocation per Attachment Z1 and eligibility for transmission revenue credits
- **Generation Interconnection Related Network Upgrades**: Cost allocation per Attachment V and ILTCR compensation mechanisms
- **Incremental Long Term Congestion Rights (ILTCRs)**: Compensation mechanism for various upgrade costs with 10-20 year terms

## 3. Decisions or Actions

- **Joint Informational Filings Required**: SPP and respective utilities must file with Commission upon:
  - Full recovery of canceled project costs
  - Sale or disposition of related property during recovery period
- **12-Month Recovery Period**: All canceled project costs to be recovered in equal monthly installments over 12 months
- **Property Sale Credits**: Revenues from sale/disposition of property must be credited against ATRR and reflected in RRR File
- **NITS ATRR Posting**: Southwestern Power Administration must provide supporting documentation and electronic notice when NITS ATRR is revised
- **Sponsored Upgrade Agreements**: Project Sponsors must execute agreements and elect payment method (lump sum or periodic charges)
- **True-Up Process**: Upon completion of Sponsored Upgrades, Transmission Provider shall true up costs to actual construction costs
- **ILTCR Elections**: Transmission Customers/Interconnection Customers must specify ILTCR MW and source-to-sink paths in agreements

## 4. Important Dates

- **March 1, 2019**: Commencement date for AEP ATRR inclusion of $414,465 for canceled Chapel Hill REC – Welsh Reserve and Welsh Reserve - Wilkes projects
- **January 1, 2024**: Commencement date for Sunflower Electric Power Corporation ATRR inclusion of $718,359 for canceled Russell 115 kV project
- **April 2017**: Reference date for Formula Rate Posting Information Notification List access information
- **12-Month Recovery Period**: Standard recovery period for all canceled project costs
- **10-20 Year Terms**: Range for ILTCR term specifications in agreements
- **20 Year Period**: Standard period for periodic charges for Sponsored Upgrades and plant life calculations

## 5. Organizations and People Mentioned

**Organizations:**
- American Electric Power (AEP)
- Sunflower Electric Power Corporation
- Southwestern Power Administration
- Western-UGP
- SPP (Southwest Power Pool/Transmission Provider)
- FERC (Federal Energy Regulatory Commission)

**Facilities/Projects Referenced:**
- Rogers - Kings River 345 kV project (Network Upgrades 10656, 10659, 10660)
- Line - Georgia Pacific - Keatchie 138 kV Ckt 1 (Network Upgrade 10616)
- Line – Chapel Hill REC – Welsh Reserve 138 kV Ckt 1 (Network Upgrade 50697)
- Line – Welsh Reserve - Wilkes 138 kV Ckt 1 (Network Upgrade 11423)
- Device – Russell 115 kV (Network Upgrade 122803)

## 6. Links or References

- **SPP Website**: http://www.spp.org/stakeholder-center/exploder-lists/ (as of April 2017)
- **Formula Rate Posting Information Notification List**: Accessible through "Exploder List" link on SPP website
- **Rate Schedule NFTS-13A**: Referenced for Southwestern Power Administration capacity information (872,000 kilowatts)
- **Tariff Attachments Referenced**:
  - Attachment H (Table 1, Column 3)
  - Attachment J (Section VIII, Section V, Section VII)
  - Attachment Z1 (cost allocation)
  - Attachment Z2 (ILTCR provisions, Sections I, II, IV)
  - Attachment V (generation interconnection cost allocation)
  - Attachment AH (Market Participant requirements)
- **Schedule 11**: Cost recovery mechanism
- **RRR File**: Revenue Requirements File

## 7. Suggested Tags

- Cost Recovery
- ATRR (Annual Transmission Revenue Requirements)
- Network Upgrades
- Canceled Projects
- Transmission Infrastructure
- FERC Filing
- Southwestern Power Administration
- American Electric Power
- Sunflower Electric
- Sponsored Upgrades
- Service Upgrades
- Generation Interconnection
- ILTCR (Incremental Long Term Congestion Rights)
- Rate Recovery
- Attachment J
- Attachment Z2
- Revenue Credits
- Transmission Service

## 8. Items That May Need Follow-Up

1. **Verification of Recovery Completion**: Monitor whether AEP has completed the 12-month recovery period for the $414,465 (started March 1, 2019) and confirm final informational filing
2. **Sunflower Recovery Status**: Track the recovery of $718,359 starting January 1, 2024, to ensure completion by December 31, 2024
3. **Property Disposition Tracking**: Monitor for any sales or dispositions of property related to canceled projects and verify proper crediting against ATRR
4. **RRR File Updates**: Confirm that zeros are properly reflected in RRR File upon full cost recovery
5. **Exploder List Currency**: Verify current URL for Formula Rate Posting Information Notification List (reference is from April 2017)
6. **ILTCR Agreement Terms**: Ensure all ILTCR agreements specify terms between 10-20 years as required
7. **Southwestern Power Administration Capacity Updates**: Monitor for any changes to the 872,000 kilowatt capacity stated in Rate Schedule NFTS-13A
8. **True-Up Filings**: Track completion of Sponsored Upgrades and verify true-up calculations are filed
9. **Market Participant Status**: Verify Project Sponsors receiving ILTCRs have executed Attachment AH if not already Market Participants
10. **Interest Recovery Documentation**: Confirm that interest recovered on canceled projects is properly documented in final filings

---

# Chunk 6 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary

This document contains sections from SPP (Southwest Power Pool) tariff attachments related to transmission service revenue allocation and cost treatment. The content primarily addresses how transmission upgrade costs are allocated across zones and how revenues from various transmission services (Network Integration and Point-to-Point) are distributed among Transmission Owners. Key provisions cover Zonal Reliability Upgrades, JTIQ (Joint Transmission Improvement Queue) upgrades, Grandfathered Agreements, and specific allocation methodologies for single-owner and multi-owner zones.

## 2. Key Topics

- **Zonal Reliability Upgrades**: Cost allocation for upgrades included in the 2005 SPP Transmission Expansion Plan
- **JTIQ Upgrades**: Treatment in Region-wide Charge calculations per Attachments L and AV
- **Grandfathered Agreements**: Protection of existing contractual rights and revenue treatment
- **Revenue Distribution Mechanisms**: 
  - Network Integration Transmission Service (NITS) revenue allocation
  - Point-to-Point Transmission Service revenue distribution
- **Single-Owner vs. Multi-Owner Zones**: Different methodologies based on zone ownership structure
- **Owner-Specific Zonal Annual Revenue Requirement (OZRR)**: Calculation and adjustment procedures
- **Load Ratio Share**: Methodology for calculating shares in accordance with Section 34.4
- **Creditable Upgrades**: Revenue credits under Tariff Attachment Z2
- **MW-mile Impact Calculations**: Distribution methodology using Attachment S procedures

## 3. Decisions or Actions

- **Zonal Reliability Upgrades placed in service prior to January 1, 2008** shall be allocated per Section III
- **All other Zonal Reliability Upgrades** shall be included in the applicable Zonal Annual Transmission Revenue Requirement
- **JTIQ ATRR Balance** to be included in Region-wide Charge
- **Revenue distribution split**: 50% based on OZRR proportions, 50% based on MW-mile impacts (for Point-to-Point service)
- **Grandfathered Agreement adjustments**: OZRR reductions/increases based on seller/purchaser status
- **Dispute resolution**: Parties unable to reach agreement may invoke tariff dispute resolution procedures or seek FERC determination
- **Zone-specific exceptions**: Special provisions for Zone 1 and Zone 19

## 4. Important Dates

- **January 1, 2008**: Cutoff date for Zonal Reliability Upgrades included in 2005 SPP Transmission Expansion Plan
- **October 1, 2015**: Cutoff for Network Load designated outside Transmission Provider's system (Zone 19 exception)

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)** - Transmission Provider
- **FERC (Federal Energy Regulatory Commission)** - Regulatory authority
- **American Electric Power** - Specifically mentioned regarding Zone 1
- **Transmission Owners** (various, unnamed)
- **Network Customers** (various, unnamed)
- **Transmission Customers** (various, unnamed)
- **Upgrade Sponsors** - Entities entitled to revenue credits

### Roles Referenced:
- Transmission Provider
- Transmission Owner(s)
- Network Customer(s)
- Native Load Customers

## 6. Links or References

### Internal Tariff References:
- **Attachment H**: OZRR information
- **Attachment L**: Treatment of Revenues (current document)
- **Attachment AV**: JTIQ calculation provisions
- **Attachment S**: MW-mile impact procedures
- **Attachment Z2**: Creditable Upgrades provisions
- **Section 31.4**: Network Load designation outside system
- **Section 34.1(2)**: OZRR adjustment procedures
- **Section 34.4**: Load Ratio Share calculations
- **Section 39**: Service provisions for Zone 1 Transmission Owners
- **Schedule 7**: Point-to-Point Transmission Service rates
- **Schedule 8**: Point-to-Point Transmission Service rates
- **Schedule 9**: Network Integration Transmission Service rates
- **Section III**: Allocation provisions (referenced but not included in excerpt)

### External References:
- **2005 SPP Transmission Expansion Plan**

## 7. Suggested Tags

- Revenue Allocation
- Transmission Service
- Cost Recovery
- Zonal Rates
- Network Integration Transmission Service (NITS)
- Point-to-Point Transmission
- Grandfathered Agreements
- OZRR (Owner-Specific Zonal Annual Revenue Requirement)
- Load Ratio Share
- MW-mile Methodology
- Creditable Upgrades
- SPP Tariff
- Multi-Owner Zones
- JTIQ (Joint Transmission Improvement Queue)
- FERC Jurisdiction
- Native Load
- Transmission Upgrades

## 8. Items That May Need Follow-Up

1. **Incomplete Section**: Document ends mid-sentence ("III. Distribution of Revenues From Ba...") - full Section III needed
2. **Grandfathered Agreement Disputes**: Process for disputes when Transmission Owners in multi-owner zones cannot reach agreement on treatment
3. **Zone 1 Special Treatment**: Clarification on why American Electric Power receives different treatment and implications for other potential Zone 1 Transmission Owners
4. **Zone 19 Exception**: Rationale for the October 1, 2015 designation cutoff for Network Load outside the system
5. **MW-mile Impact Calculations**: Detailed review of Attachment S procedures referenced but not included
6. **Creditable Upgrades**: Full provisions of Attachment Z2 for understanding revenue credit mechanisms
7. **2005 Transmission Expansion Plan**: Status of upgrades and verification of placement in service dates
8. **JTIQ ATRR Balance Calculation**: Review of Attachment AV methodology
9. **Hypothetical NITS Payments**: Verification methodology in paragraph II.B.2(c) for Transmission Owners not taking NITS
10. **Load Ratio Share Denominator Calculations**: Consistency in application across zones per Section 34.4

---

# Chunk 7 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary

This document is chunk 7 of 27 from SPP (Southwest Power Pool) Comments document RR696 dated August 27, 2025. The content primarily focuses on SPP's tariff provisions related to revenue distribution mechanisms for transmission services, loss compensation procedures, and the transmission planning process. Key sections include detailed methodologies for distributing revenues from Base Plan Zonal Charges, Region-wide Charges, and Interregional Projects; procedures for calculating transmission losses; and the framework for the SPP Transmission Expansion Plan (STEP). The content is highly technical and procedural, outlining the regulatory framework governing transmission revenue allocation and planning processes.

## 2. Key Topics

- **Revenue Distribution Mechanisms**: Multiple categories including Base Plan Upgrades, Balanced Portfolios, Interregional Projects, and JTIQ (Joint Targeted Interconnection Queue) Upgrades
- **Annual Transmission Revenue Requirements (ATRR)**: Distribution methodologies and calculations
- **Point-to-Point Transmission Service**: Revenue collection and distribution under Schedules 7, 8, and 11
- **Creditable Upgrades**: Revenue allocation to Upgrade Sponsors
- **JTIQ ATRR Balance**: Calculation methodology and application to generators and transmission owners
- **Loss Compensation Procedures**: Including Injection Loss Factors (ILF) and Delivery Loss Factors (DLF)
- **Transmission Planning Process**: Comprehensive overview of the SPP Transmission Expansion Plan (STEP)
- **Network Integration Transmission Service**: Loss responsibility calculations
- **Interregional Planning**: Coordination and cost allocation with other planning regions

## 3. Decisions or Actions

- Revenue distribution shall be proportionate to Transmission Owners' respective annual transmission revenue requirements
- JTIQ ATRR Balance shall be charged/credited monthly (one-twelfth basis) to Resident Load through Region-wide Charge
- Network Customers responsible for real power losses based on Zone DLF and hourly metered Network Load
- Transmission Provider must maintain schedule showing real power loss factors for each Zone
- Draft project lists must be posted on SPP website for stakeholder review
- All transmission projects must be endorsed or approved through proper processes to be included in STEP

## 4. Important Dates

- **Monthly**: One-twelfth of JTIQ ATRR Balance charged/credited each month
- **Annual**: Annual transmission revenue requirements form basis for revenue distribution
- **Planning Horizon**: Referenced for SPP Transmission Expansion Plan (no specific timeframe given in this chunk)
- **20-Year Assessment**: Mentioned as part of planning process (specific dates not provided in this section)

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)**: Transmission Provider
- **Transmission Owners**: Recipients of revenue distributions
- **Network Customers**: Responsible for losses on Network Integration Transmission Service
- **Transmission Customers**: Users of Point-to-Point service
- **Federal Power-Western-UGP**: Special mention for Statutory Load Obligations
- **Upgrade Sponsors**: Recipients of Creditable Upgrade revenues
- **Interregional Planning Regions**: Recipients of approved Interregional Project revenues
- **Stakeholders**: Invited to review and comment on draft project lists

**People:**
- No specific individuals mentioned in this chunk

## 6. Links or References

**Internal Tariff References:**
- Attachment H: Transmission revenue requirements specifications
- Attachment J, Section IV.A: Zonal ATRR reallocation
- Attachment L, Sections II.A, II.C, II.D, III.A: Revenue distribution procedures
- Attachment Z2, Sections II.D and III.C.2: Creditable Upgrades provisions
- Attachment O: Transmission Planning Process (with Addendum 1)
- Attachment AE: Energy and Operating Reserve Markets settlement procedures
- Attachment AQ: Delivery point facility changes
- Attachment AU: Revenue distribution and allocation
- Attachment AV (with Appendix 2): JTIQ Formula Rate template
- Attachment AX: Referenced process (not detailed in chunk)
- Attachment V: Generator Interconnection Requests
- Attachment Y: Competitive Upgrades definition
- Attachment Z1: Transmission service request evaluation
- Schedule 7, 8, 9, 11: Various transmission service schedules
- Appendix 1 to Attachment M: Zone loss factors (Columns D referenced)

**External References:**
- Section 39.3(e)(ii): Federal Power-Western-UGP provisions
- RRR File: Posted on SPP website for JTIQ ATRR Balance information
- SPP website: Location for posted draft project lists and other information

## 7. Suggested Tags

- Revenue Distribution
- Annual Transmission Revenue Requirements (ATRR)
- JTIQ (Joint Targeted Interconnection Queue)
- Transmission Planning
- SPP Transmission Expansion Plan (STEP)
- Loss Compensation
- Point-to-Point Transmission
- Network Integration Service
- Interregional Projects
- Balanced Portfolios
- Base Plan Upgrades
- Creditable Upgrades
- Sponsored Upgrades
- Tariff Provisions
- Cost Allocation
- Zone Loss Factors
- Integrated Marketplace
- Generator Interconnection
- 20-Year Assessment
- Competitive Upgrades

## 8. Items That May Need Follow-Up

1. **JTIQ ATRR Balance Calculation**: Verify that the RRR File is current and accurately reflects upgrade-specific components as posted on SPP website

2. **Zone Loss Factors**: Confirm that Appendix 1 to Attachment M contains current ILF and DLF values for all zones

3. **Revenue Distribution Accuracy**: Ensure proportionate distribution calculations account for all reductions (Schedule 11 point-to-point revenue, Attachment AU allocations)

4. **Stakeholder Comment Process**: Track submission and incorporation of written comments on draft project lists

5. **Interregional Coordination**: Monitor revenue distributions to Interregional Planning Regions and other transmission providers for approved projects

6. **Creditable Upgrades**: Verify that Upgrade Sponsors receive proper revenue distributions under Section II.D and III.C.2 of Attachment Z2

7. **Federal Power-Western-UGP**: Confirm special loss energy treatment for Statutory Load Obligations complies with Section 39.3(e)(ii)

8. **STEP Completeness**: Ensure all 11 categories of projects are properly evaluated and included in annual SPP Transmission Expansion Plan

9. **Competitive Upgrades**: Verify identification of reliability violations on adjacent neighboring transmission systems (Section V.7)

10. **Draft Project List Posting**: Confirm timely posting and proper identification of associated assessment processes

11. **Loss Energy Settlement**: Coordinate with Attachment AE procedures for Integrated Marketplace hourly energy settlement

12. **Generator Retirement Process**: Track projects approved through this process for inclusion in STEP

---

# Chunk 8 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document is chunk 8 of 27 from SPP (Southwest Power Pool) tariff comments dated August 27, 2025 (RR696). It contains detailed procedural requirements for transmission planning, upgrade approval processes, and transmission service timing requirements. The content focuses on three main areas: (1) the approval and endorsement process for various types of transmission upgrades through the SPP Transmission Expansion Plan (STEP), (2) procedures for plan updates, modifications, and status reporting, and (3) specific timing requirements for different categories of transmission service requests. The document emphasizes stakeholder involvement, transparency through website postings, and formal approval hierarchies involving the Markets and Operations Policy Committee and SPP Board of Directors.

## 2. Key Topics

- **SPP Transmission Expansion Plan (STEP) Approval Process**: Multiple upgrade categories requiring Board approval including ITP Upgrades, Balanced Portfolios, high priority upgrades, 20-Year Assessment upgrades, and Sponsored Upgrades
- **Stakeholder Review and Consultation**: Requirements for Regional State Committee and stakeholder working group involvement in reviewing draft project lists and modifications
- **Information Disclosure and Transparency**: Posting requirements for study results, criteria, assumptions, and analysis on SPP website with password protection for confidential/CEII information
- **Plan Modification and Updates**: Quarterly posting requirements for modifications and out-of-cycle adjustments for reliability and business opportunities
- **Upgrade Removal and Cost Recovery**: Procedures for removing upgrades with reimbursement provisions for incurred costs
- **Status Tracking and Reporting**: Quarterly reporting requirements to multiple committees and public posting
- **Transmission Service Timing Requirements**: Detailed deadlines for various service types including Next-Hour Market, hourly, daily, and long-term requests
- **Adjacent System Impacts**: Provisions regarding reliability violations on neighboring transmission systems caused by Competitive Upgrades

## 3. Decisions or Actions

**Required Approvals:**
- Markets and Operations Policy Committee must make recommendations on all upgrade categories before SPP Board action
- SPP Board of Directors approval required for: ITP Upgrades, Balanced Portfolios, high priority upgrades, 20-Year Assessment upgrades, Generator Retirement Upgrades, and JTIQ Upgrades
- SPP Board endorsement (not approval) required for Sponsored Upgrades
- Deviations from Committee recommendations must include explanations in the STEP

**Posting and Notice Requirements:**
- Projects requiring Board action must be posted to SPP website with email notice at least 10 days prior to Board meeting
- Quarterly posting of STEP modifications required
- Status updates must be posted quarterly and reported to Markets and Operations Policy Committee, Regional State Committee, and Board

**Process Actions:**
- Transmission Provider must work with stakeholders on ongoing basis throughout the year
- Stakeholders may submit written comments via electronic link on SPP website
- Lottery system to be used for simultaneously received reservation requests

## 4. Important Dates

**Recurring Deadlines:**
- **Quarterly**: Posting of STEP modifications to SPP website
- **Quarterly (minimum)**: Status reporting to committees and Board; status posting to website
- **At least annually**: SPP Transmission Expansion Plan presentation to SPP Board of Directors
- **10 days prior**: Minimum notice required before Board action on project lists

**Transmission Service Timing (referenced but specific times not fully visible in chunk):**
- Next-Hour Market requests: submitted on schedule and pre-confirmed
- Non-firm schedules: accepted after 15:00 day prior (if no new reliability risks)
- 5-minute window: Requests received within first 5 minutes after deadline deemed simultaneous
- DC tie requests: Between 09:55:00 a.m. and 10:05:00 a.m. CPT (limitation of 3 requests per customer/affiliate per tie per direction)

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)**: Transmission Provider conducting planning process
- **SPP Board of Directors**: Final approval authority for transmission expansion plans
- **Markets and Operations Policy Committee**: Makes recommendations to Board on all upgrade categories
- **Regional State Committee**: Reviews draft project lists and modifications
- **Stakeholder Working Groups**: Review and endorse modifications
- **Transmission Owners**: Implement upgrades; eligible for reimbursement if projects removed
- **Transmission Customers**: Submit transmission service requests
- **NERC (North American Electric Reliability Corporation)**: Referenced for priority classifications and holidays
- **Commission (FERC implied)**: Referenced regarding service agreement filings

**People:**
- No specific individuals mentioned

## 6. Links or References

**Internal Document References:**
- Attachment O (this document): Sections II, III, IV.7, V, VII, VIII
- Attachment J: Section VIII (reimbursement for removed upgrades)
- Attachment Z1: Provisions for transmission service upgrades approval
- Attachment V: Generator Interconnection Service provisions
- Attachment AB: Generator Retirement Upgrade provisions
- Attachment P: Transmission Service Timing Requirements
- Section 15.3 of the Tariff: Service agreement filing requirements
- Sections 13.2 and 14.2 of the SPP OATT: Capacity allocation principles

**External References:**
- SPP Membership Agreement: Confidentiality provisions
- NERC TLR (Transmission Loading Relief): Referenced in scheduling context
- CEII (Critical Energy Infrastructure Information) requirements
- OASIS (Open Access Same-Time Information System): Publication of transmission requests

**Website References:**
- SPP website: Multiple references for posting studies, plans, status updates, project lists, and comment submission

## 7. Suggested Tags

- Transmission Planning
- SPP Transmission Expansion Plan (STEP)
- Upgrade Approval Process
- ITP Upgrades
- Balanced Portfolio
- Board of Directors Approval
- Markets and Operations Policy Committee
- Stakeholder Engagement
- Regional State Committee
- Transmission Service Timing
- OASIS
- CEII
- Confidentiality
- Quarterly Reporting
- Generator Interconnection
- Sponsored Upgrades
- High Priority Upgrades
- 20-Year Assessment
- Competitive Upgrades
- Adjacent System Impacts
- Cost Recovery
- NERC Priority
- Non-Firm Transmission
- Generator Retirement

## 8. Items That May Need Follow-Up

**Process Clarifications Needed:**
1. **Balanced Portfolio Frequency**: Document states "SPP is not required to have a Balanced Portfolio each year" - may need clarification on decision criteria for when portfolios are developed
2. **Cost Responsibility for Adjacent System Impacts**: Provisions state SPP won't pay for upgrades on adjacent systems unless otherwise agreed - may need follow-up on existing agreements and coordination protocols
3. **Lottery System Details**: Reference to lottery for simultaneous requests needs operational procedure documentation
4. **Definition of "Affiliated Transmission Customers"**: DC tie request limitation references "group of affiliated Transmission Customers" - needs clear definition to prevent disputes

**Stakeholder Coordination Issues:**
1. **10-Day Notice Adequacy**: Minimum 10-day notice before Board action may be insufficient for complex projects requiring detailed stakeholder review
2. **Out-of-Cycle Modification Process**: While allowed, the procedural details for stakeholder review of out-of-cycle changes may need clarification
3. **Electronic Link Functionality**: Multiple references to electronic links for Transmission Owner plans and stakeholder comments - need verification of system functionality and accessibility

**Compliance and Reporting:**
1. **Quarterly Reporting Compliance**: Need to verify actual compliance with quarterly posting and reporting requirements across all categories
2. **Status Tracking System**: Requirements to track upgrade status "to ensure projects are built in time" - may need enhanced monitoring tools or accountability measures
3. **CEII Redaction Consistency**: Need to ensure consistent application of CEII redaction standards across all posted documents

**Cost and Financial Issues:**
1. **Reimbursement Process for Removed Upgrades**: Reference to Attachment J Section VIII - need to verify clarity and adequacy of cost recovery provisions
2. **Cost Allocation for Generator Retirement Upgrades**: Special provision for these upgrades may require additional stakeholder education and transparency

**Timing and Deadline Issues:**
1. **Non-Firm Schedule Acceptance After 15:00**: Conditional on "no new reliability risks" - needs clear criteria and decision authority
2. **Transmission Service Request Processing During 5-Minute Window**: Operational challenges of deeming requests simultaneous and conducting lottery may need system improvements
3. **Coordination with NERC

---

# Chunk 9 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document is chunk 9 of 27 from SPP (Southwest Power Pool) Comments dated August 27, 2025, regarding regulatory filing RR696. The content focuses on transmission service rate structures, specifically detailing Point-To-Point Transmission Service rates under Attachment T of the tariff. It covers service increments, rate calculation methodologies, and specific rate provisions for the American Electric Power - West (AEPW) rate zone and City Utilities of Springfield, Missouri. The document establishes standardized pricing structures for both firm and non-firm transmission services across various time increments (hourly, daily, weekly, monthly, yearly).

## 2. Key Topics

- **Transmission Service Increments and Windows**: Fixed Hourly, Fixed Daily, Extended Weekly, Extended Monthly, and Extended Yearly service options
- **Rate Structures for Point-To-Point Transmission Service**: Differentiation between On-Peak and Off-Peak rates
- **AEPW Rate Zone Provisions**: Multiple transmission owners and their applicable rates
- **Balanced Portfolio Reallocation Adjustments**: Methodology for adjusting rates based on zonal revenue requirements
- **Revenue Crediting Mechanisms**: Schedule 7 and 8 revenue adjustments and Attachment AU distributions
- **ERCOT-Specific Discount Provisions**: 45.27% discount for certain through and out service transactions
- **Formula Rate References**: Multiple formula rates (AEP, AEP-West Transco, AECC, TROK)
- **NAESB Standards Compliance**: Integration of WEQ-001 Business Practice Standards
- **Time Zone Conventions**: Central Prevailing Time with 24-hour clock convention

## 3. Decisions or Actions

- **Service Offerings Limited**: Transmission Provider offers only five specific service increment and window combinations
- **Rate Calculation Methodology Established**: Detailed formulas for calculating rates across different service durations
- **Discount Application**: 45.27% discount approved for Load Serving Entities taking ERCOT Regional Transmission Service
- **Revenue Crediting Implementation**: Rates must reflect adjustments for Schedule 7 and 8 revenues and Attachment AU allocations
- **Off-Peak Definition Standardization**: Defined as Saturdays, Sundays, and NERC Holidays (unless explicitly stated otherwise)
- **Holiday Definition**: NERC holidays specified as New Year's Day, Memorial Day, Independence Day, Labor Day, Thanksgiving Day, and Christmas Day

## 4. Important Dates

- **Document Date**: August 27, 2025 (RR696 SPP Comments dated 20250827)
- **Service Windows**: 
  - Fixed Daily: 00:00 to 24:00 same calendar day
  - Extended Weekly: >1 week to <4 weeks
  - Extended Monthly: >1 month to <12 months
  - Extended Yearly: >1 year
- **On-Peak Hours**: HE 0700 to HE 2200 (for hourly delivery purposes)
- **Rate Divisors**: 
  - 260 days (On-Peak daily calculations)
  - 365 days (Off-Peak daily calculations)
  - 4,160 hours (On-Peak hourly)
  - 8,760 hours (Off-Peak hourly)

## 5. Organizations and People Mentioned

### Organizations:
- **Southwest Power Pool (SPP)** - Transmission Provider
- **American Electric Power (AEP)** - Transmission Owner
- **American Electric Power - West (AEPW)** - Rate zone
- **East Texas Electric Cooperative, Inc.**
- **Deep East Electric Cooperative, Inc.**
- **Texas Electric Cooperatives** (collective reference)
- **Oklahoma Municipal Power Authority (OMPA)**
- **AEP West Transmission Companies (AEP-West Transco)**
- **Coffeyville Municipal Light and Power (CMLP)**
- **Arkansas Electric Cooperative Corporation (AECC)**
- **Transource Oklahoma (TROK)**
- **City Utilities of Springfield, Missouri**
- **AEP Texas Central Company (TCC)**
- **AEP Texas North Company (TNC)**
- **Public Service Company of Oklahoma**
- **Southwestern Electric Power Company**
- **NERC** (North American Electric Reliability Corporation)
- **NAESB** (North American Energy Standards Board)
- **ERCOT** (Electric Reliability Council of Texas)
- **Federal Energy Regulatory Commission (FERC/Commission)**

### People:
No individual names mentioned

## 6. Links or References

### Tariff Attachments Referenced:
- **Attachment T** - Rate Sheets for Point-To-Point Transmission Service
- **Attachment R-1** - NAESB WEQ-001 Business Practice Standards incorporation
- **Attachment X** - Central Prevailing Time definition
- **Attachment J, Section IV.A** - Balanced Portfolio Reallocation
- **Attachment AU** - Revenue distribution and allocation
- **Attachment H** (multiple addendums):
  - Addendum 4 - AEP Formula Rate
  - Addendum 12 - AEP-West Transco Formula Rate
  - Addendum 17 - City Utilities of Springfield, MO formula rate
  - Addendum 38 - AECC Formula Rate
  - Addendum 48 - TROK Formula Rate

### External Documents:
- **Revenue Requirements and Rates File (RRR File)** - Posted on SPP website
- **AEP Operating Companies' Tariff** - Filed with Commission for ERCOT Regional Transmission Service
- **NAESB Wholesale Electric Quadrant (WEQ-001) Business Practice Standards**
- **Tariff Section 34.1(2)** - Revenue crediting implementation
- **Schedules 7 and 8** - Revenue schedules

### File Reference:
- **Source**: RR696 SPP Comments 20250827.docx.txt (chunk 9 of 27)

## 7. Suggested Tags

- Transmission Rates
- Point-to-Point Service
- SPP Tariff
- AEPW Rate Zone
- Formula Rates
- Revenue Requirements
- ERCOT Interconnection
- NAESB Standards
- Network Integration
- On-Peak/Off-Peak Pricing
- Balanced Portfolio
- Revenue Crediting
- Firm Transmission Service
- Non-Firm Transmission Service
- Rate Schedule
- AEP
- FERC Compliance
- Wholesale Electric
- Transmission Service Increments

## 8. Items That May Need Follow-Up

1. **RRR File Verification**: Confirm that the Revenue Requirements and Rates File on the SPP website contains current and accurate rates for all mentioned transmission owners
2. **Formula Rate Updates**: Verify that all referenced formula rates in Attachment H addendums are current and properly calculated
3. **ERCOT Discount Application**: Monitor implementation of the 45.27% discount provision for qualifying transactions to ensure proper application
4. **NAESB Standards Compliance**: Confirm that the referenced WEQ-001 Business Practice Standards version is current
5. **Rate Zone Expansion**: Track whether additional transmission owners will be added to the AEPW rate zone
6. **Revenue Crediting Reconciliation**: Ensure Schedule 7 and 8 revenues and Attachment AU distributions are properly reflected in rates
7. **Holiday Calendar Updates**: Verify NERC holiday definitions remain consistent with current NERC standards
8. **Balanced Portfolio Reallocation**: Monitor any changes to Section IV.A of Attachment J that could impact rate adjustments
9. **Time Zone Clarification**: Confirm Central Prevailing Time definition in Attachment X is properly documented
10. **Rate Divisor Validation**: Verify 260-day and 365-day divisors appropriately account for leap years
11. **Service Increment Limitations**: Confirm rationale for offering only five specific service increment combinations
12. **Cross-Border Transaction Tracking**: Monitor ERCOT-SPP interface transactions to ensure proper rate application
13. **Peak Period Definition Consistency**: Ensure On-Peak hours (HE 0700-2200) align with broader tariff definitions
14. **Complete Document Review**: Review remaining 18 chunks of the 27-chunk document for related provisions

---

# Chunk 10 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document (chunk 10 of 27) contains detailed rate schedules and methodologies for Point-To-Point (PTP) Transmission Service across multiple utility zones within the SPP (Southwest Power Pool) system. The content covers rate structures for three main entities: The Empire District Electric Company, Evergy Kansas Central, Inc., and Evergy Metro, Inc. It outlines both Firm and Non-Firm transmission service rates, calculation methodologies, revenue crediting mechanisms, and balanced portfolio reallocation adjustments. All rates are maintained in a Revenue Requirements and Rates File (RRR File) posted on the SPP website.

## 2. Key Topics

- **Point-To-Point (PTP) Transmission Service Rates**: Comprehensive rate structures for reserved capacity transmission
- **Firm vs. Non-Firm Service**: Distinct pricing structures for guaranteed versus available-capacity transmission
- **Rate Calculation Methodologies**: Formula-based approaches using Zonal Annual Transmission Revenue Requirements (Zonal ATRR)
- **Delivery Period Options**: Yearly, monthly, weekly, daily, and hourly transmission reservations with corresponding rates
- **On-Peak vs. Off-Peak Pricing**: Differential rates based on demand periods
- **Revenue Crediting Mechanisms**: Adjustments for Schedule 7 and 8 revenues and Attachment AU allocations
- **Balanced Portfolio Reallocation**: Rate adjustments reflecting zonal revenue requirement reallocations
- **Multi-Entity Rate Zones**: Consolidated rates for zones containing multiple transmission owners

## 3. Decisions or Actions

No specific decisions are documented in this content. This appears to be a reference document establishing existing rate structures and methodologies rather than meeting minutes or decision records.

## 4. Important Dates

### Annual Posting Deadlines (for Existing Zonal ATRR):
- **October 15**: Evergy Kansas Central, Inc. Formula Rate posting deadline (effective January 1 following year)
- **September 1**: Prairie Wind Formula Rate posting deadline (effective January 1 following year)
- **October 1**: South Central MCN Formula Rate posting deadline (effective January 1 following year)
- **October 1**: Kansas Power Pool Formula Rate posting deadline (effective January 1 following year)
- **October 1**: NextEra Energy Transmission Southwest, LLC Formula Rate posting deadline (effective January 1 following year)

### Effective Dates:
- **January 1**: Annual effective date for all formula rate updates

## 5. Organizations and People Mentioned

### Organizations:

**Primary Transmission Service Providers:**
- The Empire District Electric Company
- Evergy Kansas Central, Inc.
- Evergy Kansas South, Inc.
- Evergy Metro, Inc.
- Southwest Power Pool (SPP) - Regional Transmission Organization

**Subsidiary/Associated Transmission Owners:**
- Prairie Wind Transmission LLC
- South Central MCN LLC
- Kansas Power Pool
- NextEra Energy Transmission Southwest, LLC (NEET Southwest)
- City of Independence, Missouri (INDP)

**People:**
None specifically mentioned.

## 6. Links or References

### Tariff References:
- **Attachment T**: Point-To-Point Transmission Service rate specifications
- **Attachment H**: Contains various formula rate addendums
  - Addendum 3: Evergy Kansas Central, Inc. Formula Rate
  - Addendum 15: Prairie Wind Formula Rate
  - Addendum 16: Kansas Power Pool Formula Rate
  - Addendum 18: Empire District Electric Company Formula Rate
  - Addendum 43: South Central MCN Formula Rate
  - Addendum 44: NEET Southwest Formula Rate
- **Attachment J, Section IV.A**: Balanced Portfolio Reallocation methodology
- **Attachment AU**: Revenue distribution and allocation provisions
- **Section 34.1(2)**: Revenue crediting implementation procedures

### Data Files:
- **Revenue Requirements and Rates File (RRR File)**: Posted on SPP website with specific tabs:
  - "Empire PTP Rate Att T" tab
  - "Evergy Kansas Central, Inc. PTP Rate Att T" tab
  - "EMe PTP Rate Att T" tab

### External Resources:
- SPP website (for RRR File access)

## 7. Suggested Tags

- Point-To-Point Transmission
- Transmission Rates
- SPP Tariff
- Empire District Electric
- Evergy Kansas Central
- Evergy Metro
- Firm Transmission Service
- Non-Firm Transmission Service
- Formula Rates
- Revenue Requirements
- Zonal ATRR
- Reserved Capacity
- On-Peak/Off-Peak Rates
- Transmission Service Agreements
- Balanced Portfolio
- Revenue Crediting
- Rate Schedules
- FERC Compliance

## 8. Items That May Need Follow-Up

### Rate Filing and Compliance:
1. **Annual Rate Updates**: Verify timely posting of formula rate updates by specified deadlines (September 1, October 1, October 15) for all entities
2. **Effective Date Coordination**: Confirm January 1 implementation of updated rates across all zones
3. **RRR File Maintenance**: Ensure Revenue Requirements and Rates File on SPP website is current and accessible

### Rate Calculation Verification:
4. **Multi-Entity Aggregation**: Validate proper summation of rates for Evergy Kansas Central zone (combining 5 separate formula rates)
5. **Demand Charge Caps**: Monitor compliance with weekly/daily cap provisions for non-firm service
6. **Peak vs. Off-Peak Divisions**: Confirm correct application of time-period divisors (5 days for peak, 7 for off-peak, etc.)

### Revenue Adjustment Tracking:
7. **Schedule 7 and 8 Revenue Credits**: Track implementation of revenue adjustments under Section 34.1(2)
8. **Attachment AU Allocations**: Monitor proper distribution and allocation of revenues
9. **Balanced Portfolio Reallocations**: Verify adjustments reflecting Section IV.A of Attachment J

### Documentation and Transparency:
10. **Cross-Reference Validation**: Confirm all referenced Attachments and Addendums are current and consistent
11. **Zone Boundary Clarification**: Verify accuracy of transmission owner assignments to rate zones, particularly for merged entities (Evergy Kansas South/Central)
12. **Customer Communication**: Ensure transmission customers have clear access to applicable rate information

### Regulatory Considerations:
13. **FERC Formula Rate Requirements**: Confirm compliance with Commission-approved rate methodologies
14. **Rate Zone Consolidation**: Track any ongoing integration of formerly separate Evergy entities
15. **Tariff Amendment Tracking**: Monitor for any needed updates or corrections to referenced sections

---

# Chunk 11 Analysis

# Regulatory Analysis Report
## Source: RR696 SPP Comments 20250827.docx.txt - chunk 11 of 27

---

## 1. Executive Summary

This document section contains detailed rate schedules and transmission service pricing structures for multiple utility zones within the Southwest Power Pool (SPP) transmission system. It outlines standardized compensation methods for both Firm and Non-Firm Point-to-Point Transmission Service across multiple delivery periods (yearly, monthly, weekly, daily, and hourly). The document covers rate structures for three primary transmission zones: Evergy Missouri West Inc., Grand River Dam Authority, and Kansas City Board of Public Utilities. All rates reference formula rates contained in Attachment H (various Addenda) and are published in the Revenue Requirements and Rates File (RRR File) on the SPP website.

---

## 2. Key Topics

- **Point-to-Point Transmission Service Pricing**: Detailed rate structures for both firm and non-firm transmission services
- **Formula Rate Calculations**: References to EMe formula rates, INDP rates, and zone-specific formula rates
- **Delivery Period Options**: Multiple pricing tiers including yearly, monthly, weekly, daily (on-peak/off-peak), and hourly (on-peak/off-peak) options
- **Reserved Capacity Compensation**: Transmission customer obligations based on Reserved Capacity (MW or kW)
- **Rate Adjustments**: 
  - Balanced Portfolio Reallocation Adjustment
  - Point-to-Point Transmission Service Revenue Crediting
  - Schedule 7 and 8 revenue adjustments
  - Attachment AU revenue distribution and allocation
- **Rate Caps**: Weekly and daily demand charge limitations based on highest capacity reservations
- **Zonal Rate Structures**: Separate rate sheets for different transmission owner zones

---

## 3. Decisions or Actions

No specific decisions or actions are documented in this section. This appears to be a tariff/rate schedule document that codifies existing rate structures rather than documenting regulatory decisions.

---

## 4. Important Dates

No specific dates are mentioned in this content chunk. The document references "currently effective rates" but does not provide effective dates or implementation timelines.

---

## 5. Organizations and People Mentioned

**Organizations:**
- **Southwest Power Pool (SPP)** - Regional transmission organization
- **Evergy Missouri West, Inc.** - Transmission owner
- **Transource Missouri, LLC** - Transmission owner in Evergy Missouri West zone
- **Grand River Dam Authority** - Transmission owner/zone
- **Kansas City Board of Public Utilities** - Transmission owner/zone
- **Transmission Provider** - Generic reference to service provider
- **Transmission Customer** - Generic reference to service recipient
- **Commission** - Regulatory body (context suggests FERC - Federal Energy Regulatory Commission)

**People:**
None mentioned.

---

## 6. Links or References

**Tariff Attachments and Addenda:**
- Attachment H, Addendum 10, Parts 1 and 2 (EMe formula rate)
- Attachment H, Addendum 11, Parts 1 and 2 (Evergy Missouri West formula rate)
- Attachment H, Addendum 13 (Grand River Dam Authority formula rate)
- Attachment H, Addendum 21 (Transource Missouri, LLC rate formula and protocols)
- Attachment H, Addendum 46 (Kansas City Board of Public Utilities formula rate)
- Attachment J, Section IV.A (Balanced Portfolio Reallocation)
- Attachment T (Point-to-Point Transmission Service rates)
- Attachment AU (Revenue distribution and allocation)
- Section 34.1(2) of Tariff

**External Files:**
- Revenue Requirements and Rates File (RRR File) - Posted on SPP website
- Specific tabs referenced:
  - "EMW PTP Rate Att T" tab
  - "GRDA PTP Rate Att T" tab
  - "BPU PTP Rate Att T" tab

**Rate Components:**
- INDP rate: $2,442.048 per MW (specified for certain calculations)
- Schedule 7 and 8 revenues

---

## 7. Suggested Tags

- Transmission Rates
- Point-to-Point Service
- SPP Tariff
- Formula Rates
- Firm Transmission Service
- Non-Firm Transmission Service
- Evergy Missouri West
- Grand River Dam Authority
- Kansas City BPU
- Reserved Capacity
- Rate Schedules
- Attachment H
- Revenue Requirements
- Zonal Rates
- FERC Tariff
- Transmission Pricing
- On-Peak/Off-Peak Rates

---

## 8. Items That May Need Follow-Up

1. **Rate Formula Verification**: Confirm accuracy of divisors used in rate calculations:
   - 260 days for on-peak daily delivery
   - 365 days for off-peak daily delivery
   - 4,160 hours for on-peak hourly delivery
   - 8,760 hours for off-peak hourly delivery
   - Ensure these align with industry standards and actual calendar calculations

2. **INDP Rate Justification**: The fixed INDP rate of $2,442.048 appears only in certain formulas - clarify what INDP stands for and verify this rate component is current

3. **Unit Consistency**: Grand River Dam Authority uses kW and kWh while other zones use MW - confirm this is intentional and verify conversion factors are properly documented

4. **RRR File Accessibility**: Verify that all referenced tabs in the RRR File on the SPP website are publicly accessible and current

5. **Commission Approval Status**: Confirm that all referenced transmission owner rates have current Commission approval as indicated in the document

6. **Rate Cap Application**: Verify the implementation of weekly and daily demand charge caps across all delivery period combinations to ensure no calculation conflicts

7. **Cross-Reference Attachments**: Validate that all referenced Attachment H Addenda contain the formula rates as specified and are properly coordinated

8. **Attachment AU Implementation**: Clarify the specific revenue distribution methodology under Attachment AU and how it impacts point-to-point rates

9. **Balanced Portfolio Adjustment Methodology**: Review Section IV.A of Attachment J to understand the specific reallocation calculation methodology

10. **Transource Missouri Integration**: As a newer transmission owner, verify Transource Missouri LLC's rate formula (Addendum 21) is properly integrated with Evergy Missouri West zone rates

---

# Chunk 12 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document (chunk 12 of 27) contains detailed tariff rate schedules for Point-To-Point (PTP) Transmission Service across multiple transmission zones within the SPP (Southwest Power Pool) network. It specifies compensation structures for both Firm and Non-Firm transmission services across various delivery timeframes (yearly, monthly, weekly, daily, and hourly) for several utility organizations including Kansas City Board of Public Utilities, Lincoln Electric System, Midwest Energy Inc., and Nebraska Public Power District. The content establishes standard rate formulas, capacity reservation charges, and revenue crediting mechanisms that govern transmission customer compensation to transmission providers.

## 2. Key Topics

- **Point-To-Point Transmission Service Rate Structures**: Detailed pricing frameworks for both Firm and Non-Firm service
- **Reserved Capacity Compensation**: Multiple delivery term options (yearly, monthly, weekly, daily, hourly)
- **On-Peak vs. Off-Peak Pricing**: Differentiated rates based on time of use (HE 0700-2200 Central Time, excluding Sundays and holidays)
- **Balanced Portfolio Reallocation Adjustments**: Rate adjustments reflecting zonal annual transmission revenue requirement reallocations
- **Revenue Crediting Mechanisms**: Adjustments for Schedule 7 and 8 revenues under Attachment AU
- **Demand Charge Caps**: Maximum weekly and daily charge limitations based on reserved capacity
- **Formula Rate References**: Multiple Attachment H addenda referenced for specific utility calculations
- **Revenue Requirements and Rates File (RRR File)**: Central posting location for effective rates on SPP website

## 3. Decisions or Actions

No specific decisions or actions are documented in this content. This appears to be established tariff language defining ongoing rate structures and compensation mechanisms.

## 4. Important Dates

- **December 15**: Annual deadline for posting NPPD formula calculation results (effective January 1 of following year)
- **June 15**: Annual deadline for posting Tri-State formula calculation results (effective July 1 of same year)
- **January 1**: Effective date for NPPD formula rate updates
- **July 1**: Effective date for Tri-State formula rate updates
- **NERC Holidays**: New Year's Day, Memorial Day, Independence Day, Labor Day, Thanksgiving Day, Christmas Day (used for On-Peak/Off-Peak definitions)

## 5. Organizations and People Mentioned

### Organizations:
- **Southwest Power Pool (SPP)** - Regional transmission organization
- **Kansas City, Kansas Board of Public Utilities** - Transmission provider
- **Lincoln Electric System (LES)** - Transmission provider/zone
- **Midwest Energy, Inc.** - Transmission provider/zone
- **Nebraska Public Power District (NPPD)** - Transmission provider/zone
- **Tri-State** - Referenced for formula rate calculations in NPPD zone
- **Central Nebraska Public Power and Irrigation District (CNPPID)** - Rate component in NPPD zone calculations
- **NERC (North American Electric Reliability Corporation)** - Holiday definition reference

### People:
No individuals are mentioned in this content.

## 6. Links or References

### Internal Tariff References:
- **Attachment H** - Contains formula rates for various utilities:
  - Addendum 46 (Kansas City, Kansas Board of Public Utilities)
  - Addendum 6 (Lincoln Electric System)
  - Addendum 14 (Midwest Energy, Inc.)
  - Addendum 7 (NPPD Formula Rate)
  - Addendum 36 (Tri-State Formula Rate)
- **Attachment J, Section IV.A** - Balanced Portfolio Reallocation provisions
- **Attachment T** - Point-To-Point Transmission Service rates
- **Attachment AU** - Revenue distribution and allocation
- **Section 34.1(2)** - Revenue crediting implementation provisions
- **Schedule 7 and 8** - Revenue sources for rate adjustments

### External References:
- **Revenue Requirements and Rates File (RRR File)** - Posted on SPP website with specific tabs:
  - "LES PTP Rate Att T"
  - "Midwest PTP Rate Att T"
  - "NPPD PTP Rate Att T"
- **NPPD Website** - Accessible location for formula rate postings
- **Tri-State Website** - Accessible location for formula rate postings

## 7. Suggested Tags

- Transmission Tariff
- Point-To-Point Service
- Rate Schedule
- Formula Rates
- Reserved Capacity
- Firm Transmission
- Non-Firm Transmission
- SPP Tariff
- Revenue Requirements
- Demand Charges
- On-Peak/Off-Peak Rates
- Zonal Rates
- Transmission Provider
- Transmission Customer
- OATT (Open Access Transmission Tariff)

## 8. Items That May Need Follow-Up

1. **Typographical Error**: In Lincoln Electric System Non-Firm Service hourly delivery rates, item 4 shows "rate per MWh of Reserved Capacity per week" for Off-Peak hourly delivery - should likely read "per hour" not "per week"

2. **Unit Consistency**: Verify consistency between MW (megawatt) and kW (kilowatt) usage across different utility zones - some use MW (Kansas City, Lincoln), others use kW (Midwest Energy) for similar rate structures

3. **CNPPID Rate**: The specific annual Point-to-Point rate of $128.961 per MW for CNPPID is mentioned but the section appears to be cut off mid-sentence at the end of the chunk

4. **Rate Update Verification**: Confirm that all referenced RRR File postings on SPP website are current and reflect latest December 15 (NPPD) and June 15 (Tri-State) updates

5. **Formula Rate Cross-Reference**: Verify that all Attachment H addenda references are correctly matched to their respective utilities in the complete document

6. **Balanced Portfolio Implementation**: Confirm consistency of Balanced Portfolio Reallocation language across all utility zones mentioned

7. **Peak Hour Definition Consistency**: Verify HE 0700-2200 Central Time Zone definition is consistent across all zones (appears consistent in this chunk but should be verified document-wide)

---

# Chunk 13 Analysis

# Regulatory Document Analysis Report

## 1. Executive Summary

This document (chunk 13 of 27) contains detailed tariff rate schedules for Point-to-Point Transmission Service across multiple utility service territories within the SPP (Southwest Power Pool) system. It specifies rate structures for both Firm and Non-Firm transmission services across various time periods (yearly, monthly, weekly, daily, and hourly) for CNPPID, Oklahoma Gas and Electric Company (OG&E), and Omaha Public Power District (OPPD). The rates are calculated using formula-based templates with specific revenue requirements and are subject to various adjustments including Balanced Portfolio Reallocation and revenue crediting mechanisms.

## 2. Key Topics

- **Point-to-Point Transmission Service Rates**: Detailed rate schedules for both Firm and Non-Firm services
- **Rate Calculation Methodologies**: Formula-based rates referencing specific Attachment H addendums
- **On-Peak/Off-Peak Definitions**: HE 0700-2200 Central Time (weekdays, excluding NERC holidays)
- **Multi-Entity Rate Structures**: Separate rates for CNPPID, OG&E (including AECC, PEC, NEET Southwest), OPPD
- **Revenue Requirements**: Zonal ATRR (Annual Transmission Revenue Requirement) calculations
- **Rate Adjustments**: Balanced Portfolio Reallocation and Schedule 7/8 revenue crediting
- **Billing Periods**: Yearly, monthly, weekly, daily (weekday/weekend), and hourly delivery options

## 3. Decisions or Actions

- **Rate Formula Implementation**: Rates calculated using specific formula templates in Attachment H (various Addendums: 7 for NPPD, 2-A/2-B for OG&E, 8 for OPPD, 38 for AECC, 51 for PEC, 44 for NEET Southwest)
- **Service Direction Policy**: Service in opposite direction of original schedule treated as new and separate service requiring separate charges
- **Demand Charge Caps**: Weekly and daily caps established to prevent excessive charges for shorter-term reservations
- **Capacity Loss Inclusion**: Capacity designations at Point(s) of Receipt inclusive of losses

## 4. Important Dates

- **September 1**: Deadline for posting OG&E Existing Zonal ATRR on SPP website (annually)
- **January 1**: Effective date for OG&E rates (following year after September 1 posting)
- **July 20**: Deadline for posting OPPD formula calculation results on SPP website (annually)
- **August 1**: Effective date for OPPD rates (same year as July 20 posting)
- **NERC Holidays**: New Year's Day, Memorial Day, Independence Day, Labor Day, Thanksgiving Day, Christmas Day

## 5. Organizations and People Mentioned

### Organizations:
- **CNPPID** (Central Nebraska Public Power and Irrigation District)
- **NPPD** (Nebraska Public Power District)
- **Tri-State** (referenced in formula rates)
- **OG&E** (Oklahoma Gas and Electric Company)
- **AECC** (Arkansas Electric Cooperative Corporation)
- **PEC** (People's Electric Cooperative)
- **NEET Southwest** (NextEra Energy Transmission Southwest, LLC)
- **OMPA** (Oklahoma Municipal Power Authority)
- **OPPD** (Omaha Public Power District)
- **SPP** (Southwest Power Pool)
- **NERC** (North American Electric Reliability Corporation)

### People:
- None specifically mentioned

## 6. Links or References

### Tariff Attachments Referenced:
- **Attachment H**: Contains formula rate templates
  - Addendum 2-A: OG&E Formula Rate
  - Addendum 2-B: OG&E Formula Rate Implementation Protocols
  - Addendum 7: NPPD Formula Rate Template
  - Addendum 8: OPPD Formula Rate Template
  - Addendum 38: AECC Formula Rate and Protocols
  - Addendum 44: NEET Southwest Formula Rate and Protocols
  - Addendum 51: PEC Formula Rate and Protocols
  - Section I, Table 1: Existing Zonal ATRR (Lines 7, 7a, 7c, 7d, 7e, Column 3)
- **Attachment J, Section IV.A**: Balanced Portfolio Reallocation
- **Attachment AU**: Revenue distribution and allocation
- **Attachment T**: Point-to-Point Transmission Service specifications
- **Section 34.1(2)**: Schedule 7 and 8 revenue adjustments
- **RRR File** (Revenue Requirements and Rates File): Posted on SPP website, contains "OGE PTP Rate Att T" tab

## 7. Suggested Tags

- Point-to-Point Transmission
- Transmission Rates
- Tariff Schedules
- Formula Rates
- NPPD
- OG&E
- OPPD
- CNPPID
- Firm Transmission Service
- Non-Firm Transmission Service
- Revenue Requirements
- ATRR
- SPP Tariff
- Rate Calculations
- On-Peak/Off-Peak
- Transmission Service Agreements

## 8. Items That May Need Follow-Up

1. **Annual Rate Updates**: Verification that OG&E rates are posted by September 1 and effective January 1 as specified
2. **OPPD Rate Posting**: Confirmation that OPPD formula results are posted by July 20 for August 1 effectiveness
3. **RRR File Accessibility**: Ensure RRR File is publicly accessible on SPP website with current rates
4. **Formula Rate Reconciliation**: Track any true-up mechanisms between formula-calculated rates and actual costs
5. **Balanced Portfolio Reallocation Impact**: Monitor adjustments under Attachment J, Section IV.A
6. **Schedule 7/8 Revenue Credits**: Verify proper application of revenue crediting adjustments
7. **Rate Comparability**: Ensure consistency across different transmission provider zones
8. **Incomplete OPPD Section**: Document appears cut off at "The results for the Point" - need complete text
9. **OMPA Additional Charges**: Clarify basis for Oklahoma Municipal Power Authority supplemental charges
10. **Holiday Definition Updates**: Verify NERC holiday list remains current

---

# Chunk 14 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document contains detailed tariff rate schedules and transmission service pricing structures for multiple utility zones within the SPP (Southwest Power Pool) system. The content specifically outlines Point-To-Point (PTP) transmission service rates for three major providers: Omaha Public Power District (OPPD), Southwestern Power Administration (Southwestern), and Southwestern Public Service Company (SPS). The document establishes pricing methodologies for both firm and non-firm transmission services across various delivery timeframes (yearly, monthly, weekly, daily, and hourly), along with adjustment mechanisms for revenue crediting and balanced portfolio reallocation.

## 2. Key Topics

- **Point-To-Point Transmission Service Rate Structures** for multiple utility zones
- **Firm vs. Non-Firm Transmission Service** pricing differentials
- **Delivery Period Variations**: Yearly, monthly, weekly, daily, and hourly rates
- **On-Peak vs. Off-Peak Rate Distinctions** with specific time and holiday definitions
- **Formula Rate Calculations** referenced in various Attachment H Addendums
- **Revenue Crediting Mechanisms** including Schedule 7 and 8 revenues
- **Balanced Portfolio Reallocation Adjustments** per Attachment J
- **Reserved Capacity Compensation** methodologies
- **Revenue Requirements and Rates File (RRR File)** posting requirements
- **NERC Holiday Definitions** affecting peak/off-peak classifications
- **Multi-Entity Rate Aggregation** (Southwestern zone includes multiple formula rates)

## 3. Decisions or Actions

- **Rate Publication**: All Point-To-Point rates must be posted in designated tabs of the RRR File on the SPP website
- **Formula Rate Application**: Specific formula rates from various Attachment H Addendums must be applied in calculating final rates
- **Demand Charge Caps**: Weekly and daily demand charge caps established to protect customers from excessive charges
- **Rate Posting Schedule**: For SPS, formula results must be posted by October 1 annually for effectiveness January 1 of following year
- **Revenue Adjustment Implementation**: Adjustments for Schedule 7 and 8 revenues and Attachment AU allocations must be incorporated per Section 34.1(2)
- **Reserved Capacity Calculation**: For certain Southwestern customers, specific methodology established using greatest of three measures

## 4. Important Dates

- **October 1**: Deadline for posting SPS formula calculation results on SPP and SPS OASIS websites
- **January 1**: Effective date for new SPS rates (following October 1 posting)
- **NERC Holidays** (affecting peak/off-peak classifications):
  - New Year's Day
  - Memorial Day
  - Independence Day
  - Labor Day
  - Thanksgiving Day
  - Christmas Day
- **On-Peak Hours**: HE 0700 through HE 2200 (Monday-Friday, excluding holidays)
- **On-Peak Days**: Monday through Friday (excluding NERC holidays)

## 5. Organizations and People Mentioned

### Organizations:
- **SPP** (Southwest Power Pool)
- **OPPD** (Omaha Public Power District)
- **Southwestern Power Administration** (Southwestern)
- **SPS** (Southwestern Public Service Company)
- **South Central MCN LLC** (South Central MCN)
- **MEUC** (Missouri Joint Municipal Electric Utility Commission)
- **PEC** (People's Electric Cooperative)
- **LCEC** (Lea County Electric Cooperative, Inc.)
- **Xcel Energy Operating Companies**
- **NERC** (North American Electric Reliability Corporation)

### People:
- None specifically mentioned

## 6. Links or References

### Internal Tariff References:
- **Attachment T** (Point-To-Point Transmission Service rates)
- **Attachment H** - Multiple Addendums:
  - Addendum 8 (OPPD Formula Rate)
  - Addendum 43 (South Central MCN Formula Rate)
  - Addendum 50 (MEUC Formula Rate)
  - Addendum 51 (PEC Formula Rate)
  - Addendum 52 (LCEC Formula Rate)
- **Attachment J, Section IV.A** (Balanced Portfolio Reallocation)
- **Attachment AU** (Revenue distribution and allocation)
- **Attachment O - SPS** of Xcel Energy OATT
- **Section 34.1(2)** of the Tariff (revenue adjustment implementation)

### File References:
- **RRR File** (Revenue Requirements and Rates File) - SPP website
  - "OPPD PTP Rate Att T" tab
  - "SPA PTP Rate Att T" tab
  - "SPS PTP Rate Att T" tab
- **Formula-based Rate Template for OPPD**, page 1, lines 13-18a
- **SPS OASIS website**

### External Documents:
- **Xcel Energy Operating Companies Joint Open Access Transmission Tariff**

## 7. Suggested Tags

- Transmission_Rates
- Point_To_Point_Service
- OPPD
- Southwestern_Power_Administration
- SPS
- Firm_Transmission
- Non_Firm_Transmission
- Formula_Rates
- Revenue_Requirements
- SPP_Tariff
- Peak_Pricing
- Reserved_Capacity
- Rate_Schedules
- Attachment_H
- Attachment_T
- RRR_File
- OATT

## 8. Items That May Need Follow-Up

1. **Rate Formula Verification**: Confirm all referenced formula rates in Attachment H Addendums (8, 43, 50, 51, 52) are current and properly posted
2. **RRR File Accessibility**: Verify all specified tabs are accessible and updated on SPP website
3. **SPS Rate Posting Compliance**: Monitor October 1 deadline compliance for annual rate postings
4. **Revenue Credit Reconciliation**: Verify Schedule 7 and 8 revenue adjustments are properly implemented across all zones
5. **Balanced Portfolio Adjustment**: Confirm Attachment J Section IV.A reallocation calculations are correctly applied
6. **Multi-Entity Rate Aggregation**: Validate proper summation of Southwestern zone rates (Southwestern + South Central MCN + MEUC + PEC)
7. **Peak Definition Consistency**: Ensure NERC holiday definitions are consistently applied across all rate schedules
8. **Demand Charge Cap Application**: Verify weekly and daily caps are properly implemented in billing systems
9. **OASIS Posting Coordination**: Confirm dual posting requirement (SPP website and SPS OASIS) is met
10. **Reserved Capacity Calculation Method**: Clarify application of three-measure calculation methodology for Southwestern customers
11. **Xcel Energy OATT Cross-Reference**: Verify consistency between SPP tariff and Xcel Energy OATT Attachment O-SPS
12. **Attachment AU Revenue Allocation**: Confirm proper distribution methodology is documented and applied

---

**Document Reference**: RR696 SPP Comments 20250827.docx.txt - chunk 14 of 27

---

# Chunk 15 Analysis

# REGULATORY ANALYSIS REPORT
## RR696 SPP Comments - Chunk 15 of 27

---

## 1. EXECUTIVE SUMMARY

This document section contains detailed rate schedules for Point-To-Point (PTP) Transmission Service across multiple transmission zones within the Southwest Power Pool (SPP) network. The content focuses on three major rate zones: Southwestern Public Service Company (SPS/Xcel Energy), Sunflower Electric Power Corporation, and Upper Missouri Zone (UMZ). The document outlines specific rate structures for both Firm and Non-Firm transmission services, including various delivery timeframes (yearly, monthly, weekly, daily, and hourly), with distinctions between on-peak and off-peak pricing. All rates reference the Revenue Requirements and Rates (RRR) File posted on the SPP website and include provisions for revenue crediting and balanced portfolio reallocation adjustments.

---

## 2. KEY TOPICS

### Rate Structures and Service Types
- **Firm Point-To-Point Transmission Service** (reserved capacity with guaranteed delivery)
- **Non-Firm Point-To-Point Transmission Service** (interruptible service)
- **Delivery timeframe options**: Yearly, Monthly, Weekly, Daily, and Hourly
- **Peak designation definitions**:
  - On-Peak: HE 0700-2200, Central Time Zone (excluding Sundays and NERC holidays)
  - Off-Peak: All other hours
  - NERC Holidays: New Year's Day, Memorial Day, Independence Day, Labor Day, Thanksgiving Day, Christmas Day

### Revenue Adjustments and Credits
- **Balanced Portfolio Reallocation Adjustment** - adjustments from Zonal Annual Transmission Revenue Requirement per Attachment J, Section IV.A
- **Schedule 7 and 8 Revenue Crediting** - adjustments per Section 34.1(2) of the Tariff
- **Attachment AU revenues** - distributed and allocated revenues

### Geographic Zones and Special Provisions
- **SPS Zone** (Southwestern Public Service Company/Xcel Energy)
  - LCEC Formula Rate provisions
  - Special Lamar Tie Line provisions (50% discounted rate for service to/from PSCo)
- **Sunflower Electric Power Corporation Zone**
- **Upper Missouri Zone (UMZ)** - includes 14 transmission owners

### Formula Rate References
- Multiple Attachment H Addendums referenced for rate calculations
- All rates published in RRR File tabs on SPP website

---

## 3. DECISIONS OR ACTIONS

### Rate Calculation Methodology
- Rates calculated using specific formula rates from Attachment H addendums
- Rates must reflect adjustments for Schedule 7 and 8 revenues
- Weekly demand charges capped at weekly rate × highest daily Reserved Capacity
- Daily demand charges capped at daily rate × highest hourly Reserved Capacity

### Special Service Provisions
- **Bidirectional service rule**: Service in opposite direction of original schedule treated as new, separate service requiring separate charge
- **Lamar Tie Line discount**: 50% rate discount for PTP service across Lamar Tie Line between PSCo and SPS Zone
- **Loss inclusion**: Capacity designations at Point(s) of Receipt inclusive of losses

### Administrative Requirements
- All effective rates posted in RRR File on SPP website
- Rates organized by specific tabs for each zone (e.g., "SECC PTP Rate Att T", "UMZ PTP Rate Att T")

---

## 4. IMPORTANT DATES

### Recurring Timeframes
- **Peak Hours**: Daily HE 0700-2200 Central Time (weekdays only)
- **NERC Holidays** (annual):
  - New Year's Day
  - Memorial Day
  - Independence Day
  - Labor Day
  - Thanksgiving Day
  - Christmas Day

### Service Delivery Periods
- Monthly delivery: charge divided by 12 months
- Weekly delivery: charge divided by 52 weeks
- Daily on-peak: weekly charge divided by 6 days
- Daily off-peak: weekly charge divided by 7 days
- Hourly on-peak: daily charge divided by 16 hours
- Hourly off-peak: daily charge divided by 24 hours

**Note**: No specific effective dates or implementation dates mentioned in this chunk.

---

## 5. ORGANIZATIONS AND PEOPLE MENTIONED

### Primary Transmission Providers/Zones
- **Southwest Power Pool (SPP)** - Regional Transmission Organization
- **Southwestern Public Service Company (SPS)** - Xcel Energy affiliate
- **La Plata Electric Cooperative (LCEC)**
- **Public Service Company of Colorado (PSCo)**
- **Sunflower Electric Power Corporation (SECC)**
- **ITC Great Plains, LLC**
- **Prairie Wind Transmission, LLC**

### Upper Missouri Zone (UMZ) Transmission Owners (14 entities)
1. **Basin Electric Power Cooperative** (Basin Electric)
2. **Heartland Consumers Power District** (Heartland)
3. **Missouri River Energy Services** (MRES)
4. **East River Electric Power Cooperative, Inc.** (East River)
5. **Corn Belt Power Cooperative** (Corn Belt)
6. **NorthWestern Energy Public Service Corporation** (NWPS)
7. **Northwest Iowa Power Cooperative** (NIPCO)
8. **Harlan Municipal Utilities** (HMU)
9. **Western Area Power Administration, Upper Great Plains Region** (Western-UGP)
10. **Central Electric Power Cooperative, Inc.** (Central Power)
11. **Mountrail-Williams Electric Cooperative** (Mountrail-Williams)
12. **Mor-Gran-Sou Electric Cooperative, Inc.** (Mor-Gran-Sou)
13. **Roughrider Electric Cooperative, Inc.** (Roughrider)
14. **L and O Power Cooperative** (LOPC)

### MRES Members (Partial list - text cut off)
- Moorhead Public Service
- Orange City Municipal Utilities
- City of Pierre, South Dakota
- City of Sioux Center, Iowa
- (Additional members indicated but not fully listed)

### Regulatory Body
- **NERC** (North American Electric Reliability Corporation) - defines holidays
- **Commission** (Federal Energy Regulatory Commission - implied)

---

## 6. LINKS OR REFERENCES

### Internal Document References

#### Tariff Attachments
- **Attachment T** - Point-To-Point Transmission Service Rate Sheets (current document)
- **Attachment H** - Formula Rate Templates:
  - Addendum 5: Southwestern Public Service Company formula rate
  - Addendum 9: ITC Great Plains, LLC formula rate
  - Addendum 15: Prairie Wind Transmission, LLC formula rate
  - Addendum 20: Sunflower Electric Power Corporation formula rate
- **Attachment J, Section IV.A** - Balanced Portfolio Reallocation provisions
- **Attachment AU** - Revenue distribution and allocation
- **Attachment O - SPS** - Xcel Energy OATT rate specifications

#### Tariff Sections
- **Section 34.1(2)** - Revenue crediting implementation provisions
- **Schedule 7 and 8** - Revenue crediting schedules

### External References
- **SPP Website** - hosts Revenue Requirements and Rates (RRR) File
- **RRR File Tabs**:
  - "SECC PTP Rate Att T" - Sunflower Electric rates
  - "UMZ PTP Rate Att T" - Upper Missouri Zone rates
  - (Additional tabs for other zones implied)
- **Xcel Energy OATT** (Open Access Transmission Tariff) - Page 1, Attachment O - SPS

### Geographic References
- **Lamar Tie Line** - interconnection between PSCo and SPS Zone
- **SPS Zone** - Southwestern Public Service territory
- **Central Time Zone** - for peak/off-peak definitions

---

## 7. SUGGESTED TAGS

### Primary Tags
- Point-To-Point Transmission Service
- Transmission Rates
- SPP Tariff
- Rate Schedules
- OATT (Open Access Transmission Tariff)

### Geographic/Zone Tags
- Southwestern Public Service (SPS)
- Sunflower Electric (SECC)
- Upper Missouri Zone (UMZ)
- Xcel Energy
- Lamar Tie Line

---

# Chunk 16 Analysis

# Regulatory Content Analysis Report
## Source: RR696 SPP Comments 20250827.docx.txt - Chunk 16 of 27

---

## 1. Executive Summary

This document chunk contains detailed transmission service rate schedules and integrated marketplace operational procedures for Southwest Power Pool (SPP). It covers two primary areas: (1) Point-to-Point transmission service rates for the Upper Missouri Zone (UMZ) and Western Farmers Electric Cooperative (WFEC) rate zones, including firm and non-firm service calculations, and (2) Integrated Marketplace operational requirements including must-offer obligations, Day-Ahead Market execution procedures, and resource commitment protocols. The content appears to be tariff language with extensive technical specifications for rate calculations and market operations.

---

## 2. Key Topics

- **Point-to-Point Transmission Service Rates**
  - UMZ rate zone transmission service pricing (yearly, monthly, weekly, daily, hourly)
  - WFEC rate zone transmission service pricing
  - Firm and Non-Firm Point-to-Point service distinctions
  
- **Revenue Crediting and Adjustments**
  - Balanced Portfolio Reallocation Adjustment
  - Schedule 7 and 8 revenue crediting
  - Attachment AU revenue distribution and allocation

- **Market Participant Requirements**
  - Must-offer obligation for Day-Ahead Market
  - Load and generation data submission requirements
  - Meter Agent function and registration

- **Day-Ahead Market Execution**
  - Security Constrained Unit Commitment (SCUC) algorithm application
  - Simultaneous co-optimization methodology
  - Resource commitment protocols and capacity limits
  - Handling of capacity shortages and surpluses

---

## 3. Decisions or Actions

- **Rate Calculation Methodology**: Specific formulas established for calculating transmission service rates based on Annual Transmission Revenue Requirements (ATRR) divided by load estimates and time periods

- **Must-Offer Compliance Framework**: 
  - 90% threshold established for compliance determination
  - Penalty assessment for non-compliance (referenced in Section 3.9 of Attachment AF)
  
- **Market Clearing Priorities**: Established priority order for addressing capacity shortages:
  1. Curtail non-firm fixed Export Interchange Transaction Bids
  2. Incorporate emergency capacity limits and reliability-only resources

- **Demand Charge Caps**: Weekly demand charges capped at weekly rate multiplied by highest daily megawatt reservation

---

## 4. Important Dates

No specific dates are mentioned in this content chunk. The document references "Operating Day" and "upcoming Operating Day" as operational timeframes but does not specify calendar dates.

---

## 5. Organizations and People Mentioned

**Transmission Owners/Utilities (UMZ Rate Zone):**
- Basin Electric
- Heartland Consumers Power District
- Missouri River Energy Services (MRES)
- MRES Members (Marshalltown Municipal Utility Department, Denison Municipal Utilities, Vermillion Light & Power)
- East River
- Corn Belt
- NWPS (Northwestern Public Service)
- NIPCO
- HMU (Heartland Municipal Utility)
- Western-UGP
- Central Power
- Mountrail-Williams
- Mor-Gran-Sou
- Roughrider
- LOPC

**Transmission Owners (WFEC Rate Zone):**
- Western Farmers Electric Cooperative (WFEC)
- People's Electric Cooperative (PEC)

**Key Entities:**
- Transmission Provider (SPP)
- Transmission Customers
- Market Participants
- Meter Agents
- Asset Owners
- Market Monitor

---

## 6. Links or References

**Tariff Attachments Referenced:**
- Attachment H (Addendums 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 37, 40, 41, 42, 45, 47, 49, 51)
- Attachment J, Section IV.A (Balanced Portfolio Reallocation)
- Attachment T (Point-to-Point Transmission Service rates)
- Attachment AU (Revenue distribution and allocation)
- Attachment AE (Integrated Marketplace)
- Attachment AF, Section 3.9 (Must-offer penalties)
- Attachment AM (Meter Agent Agreement)

**External Files:**
- Revenue Requirements and Rates File (RRR File) - posted on SPP website
- "WFEC PTP Rate Att T" tab
- Market Protocols

**Rate Schedules:**
- Schedule 7 and 8 revenues

**Specific Formula Rates:**
- WFEC Formula Rate (Attachment H, Addendum 39)
- PEC Formula Rate (Attachment H, Addendum 51)

---

## 7. Suggested Tags

- Transmission Service Rates
- Point-to-Point Service
- SPP Tariff
- Day-Ahead Market
- Must-Offer Requirement
- WFEC Rate Zone
- UMZ Rate Zone
- Market Participant Obligations
- SCUC Algorithm
- Integrated Marketplace
- Revenue Requirements
- Capacity Reservation
- Market Compliance
- Operating Reserves
- Resource Commitment
- Meter Agent
- Formula Rates

---

## 8. Items That May Need Follow-Up

1. **Revenue Requirements File Updates**: Verify that all referenced RRR Files are current and posted on SPP website with accurate rate calculations

2. **Must-Offer Compliance Monitoring**: Confirm Market Monitor has adequate tools and processes to track the 90% compliance threshold across all Asset Owners and hours

3. **Meter Agent Agreements**: Ensure all entities performing Meter Agent functions have executed required Attachment AM agreements

4. **Formula Rate Addendums**: Verify all 20+ referenced Attachment H addendums are Commission-approved and current (particularly new entities or recent changes)

5. **Penalty Assessment Procedures**: Review Section 3.9 of Attachment AF to ensure penalty calculations for must-offer violations are properly implemented

6. **Capacity Shortage Protocols**: Confirm operational procedures are in place for SCUC algorithm priority actions during capacity shortages

7. **Multi-Configuration Resource (MCR) Transitions**: Clarify operational rules for MCR resources during configuration transitions and regulation service eligibility

8. **Self-Charging MSR Treatment**: Verify de-commitment protocols for Self-Charging Market Storage Resources during capacity surplus conditions

9. **Emergency Capacity Limits**: Confirm documentation and reporting requirements when emergency capacity limits are incorporated into market clearing

10. **Non-Conforming Load Definition**: The glossary entry for "Non-Conforming Load" appears incomplete and should be verified

---

**End of Report**

---

# Chunk 17 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary

This document is chunk 17 of 27 from SPP (Southwest Power Pool) Comments (RR696) dated August 27, 2025. The content focuses on detailed operational procedures for the Day-Ahead Market Security Constrained Unit Commitment (SCUC) and Security Constrained Economic Dispatch (SCED) algorithms, as well as Day-Ahead Reliability Unit Commitment processes. It establishes protocols for handling capacity shortages/surpluses, manual commitments, local reliability issues, and compensation mechanisms. The document emphasizes non-discriminatory resource selection, Market Monitor verification, and differentiated cost recovery (regional vs. local) based on the nature of reliability commitments.

## 2. Key Topics

- **Day-Ahead Market SCUC/SCED Algorithms**: Procedures for optimizing resource commitment and dispatch
- **Capacity Management**: Handling capacity surpluses and shortages through curtailments and emergency limits
- **Manual Commitments**: Transmission Provider authority to manually commit/decommit resources for reliability
- **Local Reliability Issues**: Special procedures for addressing local transmission constraints and emergencies
- **Operating Reserve Requirements**: Integration with resource commitment and co-optimization logic
- **Multi-Configuration Resources (MCR)**: Restrictions on regulation services during transitions
- **Compensation and Cost Recovery**: Differentiated mechanisms for regional vs. local cost allocation
- **Market Monitor Oversight**: Verification of non-discriminatory resource selection
- **Virtual Energy Offers/Bids**: Integration into market clearing processes
- **Interchange Transactions**: Treatment of firm and non-firm import/export transactions

## 3. Decisions or Actions

**Automated Algorithm Actions:**
- Curtail non-firm fixed Import/Export Interchange Transactions as first priority during capacity issues
- Incorporate emergency capacity limits when economic capacity is insufficient
- Commit/decommit charging resources based on capacity conditions
- Apply Virtual Reserve Limits (VRLs) when shadow prices exceed appropriate thresholds

**Transmission Provider Actions:**
- Manually commit/decommit resources for transmission system security constraints
- Issue instructions for Local Reliability Issues at local operator request
- Re-run Day-Ahead SCUC after manual commitments (time permitting)
- Notify Market Participants when units are manually committed
- Select resources in non-discriminatory manner with Market Monitor verification
- Minimize commitment costs while adhering to system constraints

**Development Requirements:**
- Transmission Provider, local transmission operators, and Resource owners must develop operating guides for manual commitments addressing known and recurring Local Reliability Issues

## 4. Important Dates

- **Date Referenced in filename**: August 27, 2025 (RR696 SPP Comments 20250827)
- **Time Horizons**: 
  - "Upcoming Operating Day" (referenced throughout for day-ahead processes)
  - MCR Transition State Time threshold: 30 minutes

*Note: No other specific dates or deadlines are mentioned in this content chunk*

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)**: Transmission Provider and document author
- **Market Monitor**: Oversight entity verifying non-discriminatory practices
- **Local transmission operators**: Request manual commitments for local issues

**Roles Referenced (no specific individuals named):**
- Transmission Provider
- Reliability Coordinator
- Resource owners
- Market Participants

## 6. Links or References

**Internal Document References:**
- Section 4.1(10)(c) of Attachment AE (reliability only use designation)
- Section 4.1(10)(b) of Attachment AE (market commitment status)
- Section 6.1.2.1 of Attachment AE (Market Monitor verification process)
- Section 8.5.9 of Attachment AE (compensation for committed resources)
- Section 8.5.10 of Attachment AE (regional cost recovery)
- Section 8.6.44 of Attachment AE (local cost recovery)
- Section 3.3.1 of Attachment AE (SCED algorithm description)
- Section 8.3.2 of Attachment AE (VRL application in SCED)
- Section 8.6.5 of Attachment AE (Day-Ahead RUC compensation)
- Section 8.6.7(A) of Attachment AE (regional cost recovery for RUC)

**No external links or URLs provided**

## 7. Suggested Tags

- Day-Ahead Market
- SCUC (Security Constrained Unit Commitment)
- SCED (Security Constrained Economic Dispatch)
- Reliability Unit Commitment
- Manual Commitments
- Local Reliability Issues
- Capacity Adequacy
- Operating Reserves
- Market Monitor
- Cost Recovery
- Emergency Limits
- MCR (Multi-Configuration Resources)
- Virtual Energy Trading
- Interchange Transactions
- Transmission Security
- SPP Market Rules
- Non-Discriminatory Selection
- Shadow Pricing
- Regulation Services

## 8. Items That May Need Follow-Up

**Clarification Needed:**
1. **Operating Guide Development**: Status and timeline for developing operating guides between Transmission Provider, local transmission operators, and Resource owners for known/recurring Local Reliability Issues
2. **MCR Transition Limitations**: Impact assessment of 30-minute threshold on MCR eligibility for Operating Reserve and Regulation Services
3. **Re-run Timing**: Definition of "time permitting" for Day-Ahead SCUC re-runs after manual commitments

**Coordination Requirements:**
1. **Market Monitor Verification Process**: Details of Section 6.1.2.1 process for verifying non-discriminatory manual commitment selection
2. **Local vs. Regional Cost Allocation**: Criteria for determining when costs are recovered locally (Section 8.6.44) versus regionally (Section 8.5.10 or 8.6.7(A))
3. **Local Operator Request Procedures**: Formal process for local transmission operators to request manual commitments from Transmission Provider

**Potential Issues:**
1. **Capacity Surplus Management**: Priority order differences between Day-Ahead Market (2 steps) and Day-Ahead RUC (5 steps) may create conflicts
2. **Self-Committed Resource Treatment**: Decommitment of self-committed resources in both shortage and surplus scenarios may require participant notification protocols
3. **Emergency Limit Activation**: Frequency and duration tracking for Resources operating at Emergency Capacity Operating Limits
4. **VRL Application**: Circumstances triggering VRL use in SCED and impact on market efficiency

**Policy Questions:**
1. Compensation equity between market-committed and manually-committed resources
2. Criteria defining when a constraint "cannot be directly addressed" within SCUC algorithm
3. Local Emergency Condition continuation criteria from prior Reliability Unit Commitment processes

---

# Chunk 18 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document section covers SPP's (Southwest Power Pool) market protocols for Intra-Day Reliability Unit Commitment (RUC) processes and Delivery Point Assessment procedures. It details how resources are committed to maintain system reliability, including manual commitments for local reliability issues, compensation mechanisms, and cost recovery methods. The second portion addresses the formal process for making changes to delivery point facilities, including study requirements and cost responsibilities.

## 2. Key Topics

- **Intra-Day Reliability Unit Commitment (RUC) Execution**: SCUC algorithm processes for committing resources to meet load forecasts and operating reserves
- **Manual Commitment Procedures**: Protocols for manual resource commitments when algorithmic solutions are insufficient
- **Local Reliability Issues**: Special handling procedures for localized transmission system problems
- **Resource Compensation**: Payment mechanisms for committed resources (Section 8.6.5)
- **Cost Recovery Methods**: Regional vs. local collection of commitment costs (Sections 8.6.7(A) and 8.6.44)
- **Delivery Point Assessment Process (Attachment AQ)**: Formal procedures for changes to delivery point facilities
- **Operating Guides**: Development requirements for known and recurring reliability issues
- **Market Monitor Oversight**: Non-discriminatory selection verification processes

## 3. Decisions or Actions

**Required Actions:**
- Resource owners must develop operating guides for manual commitments addressing known/recurring Local Reliability Issues
- Transmission Provider must perform capacity adequacy analysis using SCUC algorithm
- Local transmission operators must notify Transmission Provider when issuing direct instructions to resources during Local Emergency Conditions
- Transmission operators must log all manual instructions
- Market Monitor must verify non-discriminatory resource selection through Section 6.1.2.1 processes
- Transmission Customers must submit written requests for delivery point changes to Transmission Provider and Host Transmission Owner
- Host Transmission Owner must respond within 10 Business Days to Load Connection Study requests

**Decision Hierarchy for Capacity Shortages (in priority order):**
1. Curtail non-firm fixed Export Interchange Transaction Bids
2. Incorporate emergency capacity limits and reliability-only resources
3. De-commit charging resources from Day-Ahead Market
4. De-commit self-committed charging resources

## 4. Important Dates

- **10 Business Days**: Host Transmission Owner response time for Load Connection Study requests

## 5. Organizations and People Mentioned

**Organizations:**
- **Transmission Provider** (SPP)
- **Market Monitor**
- **Host Transmission Owner**
- **Local Transmission Operator**
- **Resource Owners**
- **Transmission Customer**

**Roles Referenced:**
- Resource owners
- Transmission operators (local)

## 6. Links or References

**Internal Document References:**
- Section 4.1(10)(b) - Market commitment status
- Section 4.1(10)(c) - Reliability-only resource designation
- Section 6.1.1 - SCUC inputs
- Section 6.1.2.1 - Market Monitor verification process
- Section 8.6.5 - Resource compensation provisions
- Section 8.6.7(A) - Regional cost recovery
- Section 8.6.44 - Local cost recovery
- Section 20 - Network Operating Agreement
- Section 8 - Point to Point Transmission Service Agreement
- Attachment AE - General market attachment
- Attachment AQ - Delivery Point Assessment Process
- Addendum 1 - Sample Request for Change in Local Delivery Facilities

**Related Processes:**
- Day-Ahead Market SCUC
- Real-Time Balancing Market (RTBM) Offers
- Network Operating Agreement
- Point to Point Transmission Service Agreement

## 7. Suggested Tags

- Reliability Unit Commitment
- Intra-Day RUC
- SCUC Algorithm
- Local Reliability Issues
- Manual Commitment
- Resource Compensation
- Cost Recovery
- Market Monitor
- Delivery Point Assessment
- Load Connection Study
- Transmission System Security
- Operating Reserves
- Emergency Conditions
- Non-discriminatory Selection
- Host Transmission Owner
- SPP Market Operations

## 8. Items That May Need Follow-Up

**Procedural Clarifications Needed:**
1. **Operating Guide Development Timeline**: No specific deadline mentioned for resource owners to develop operating guides for manual commitments
2. **Market Monitor Verification Standards**: Section 6.1.2.1 standards referenced but not detailed in this excerpt
3. **Affiliation Determination**: Criteria for determining if a resource is "affiliated with the local transmission operator" needs clarification
4. **Cost Estimation Process**: LCS Agreement mentions "actual cost" and "$25,000" advance deposit but incomplete sentence at document end

**Policy Questions:**
1. What constitutes "discriminatory manner" in resource selection?
2. How are disputes resolved when Market Monitor determines discriminatory selection?
3. What happens if a resource affiliated with local transmission operator is found ineligible for compensation?
4. Are there time limits for coordination between local transmission operator and Transmission Provider?

**Incomplete Information:**
1. Document appears to cut off mid-sentence regarding LCS Agreement deposit requirements ("$25,000, whicheve...")
2. Delivery Point Network Study (DPNS) criteria mentioned in Section 3.2 but not detailed in this excerpt

**Cost Recovery Issues:**
1. Clarification needed on boundary between "regional" vs. "local" cost recovery
2. Treatment of costs when resources resolve both local and regional reliability issues simultaneously

**Exemptions Requiring Monitoring:**
1. Three specific exemptions from Attachment AQ process (capacity increases, transformer changes, facility rating increases) may need periodic review for potential abuse

---

# Chunk 19 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document chunk outlines detailed procedures for delivery point modifications and load connection studies within SPP's (Southwest Power Pool) transmission system framework. It covers two primary processes: the Load Connection Study (LCS) conducted by Host Transmission Owners and the Delivery Point Network Study (DPNS) conducted by Transmission Providers. The content establishes timelines, cost responsibilities, study requirements, and posting obligations for requests involving changes to local delivery facilities. Additionally, it introduces the Provisional Load Process (Attachment AX) for situations involving increased load without sufficient designated resources.

## 2. Key Topics

- **Load Connection Study (LCS) Process**: Requirements for Host Transmission Owners to assess feasibility of delivery point modifications using power flow and short circuit analyses
- **Deposit and Cost Reimbursement Procedures**: Financial arrangements for studies, including deposit requirements and refund processes with interest calculations per 18 C.F.R. § 35.19a(a)(2)
- **Transmission System Study Timeline**: 10 Business Day preliminary assessment requirement with possible 10-day extension
- **Delivery Point Network Study (DPNS)**: Process for requests with significant transmission system impact
- **Integrated Transmission Planning Assessment**: Further evaluation requirements for requests with identified Network Upgrades
- **Study Modification Provisions**: Process for changing planned facilities during studies
- **Request Documentation Requirements**: Detailed information requirements including technical specifications, load forecasts, and one-line diagrams
- **Provisional Load Process**: New attachment (AX) addressing increased load situations

## 3. Decisions or Actions

- **Study Request Withdrawal**: Automatically deemed withdrawn if executed LCS Agreement not returned within 30 Calendar Days with required deposit
- **Preliminary Assessment Posting**: SPP shall post all Requests for Change in Local Delivery Facilities on website by 20th day of each month
- **DPNS Agreement Delivery**: Must occur within 5 Business Days of preliminary assessment completion for significant impact cases
- **Study Deposit Requirements**: $10,000 or actual estimated study cost, whichever is less
- **LCS Completion**: Required within 60 Calendar Days after receipt of executed agreement, deposit, and necessary data
- **DPNS Report Posting**: Reports posted on SPP website once transmission customer notifies SPP to update applicable agreements
- **Restudy Authorization**: May proceed at Transmission Customer's expense if changes identified during study process
- **Integrated Planning Inclusion**: Requests with Network Upgrades subject to evaluation in soonest available Integrated Transmission Planning Assessment

## 4. Important Dates

- **30 Calendar Days**: Deadline for returning executed LCS/DPNS Agreements with deposits
- **10 Business Days**: Timeline for preliminary assessment of transmission system impact
- **Additional 10 Business Days**: Potential extension for requests beyond Attachment AQ scope
- **5 Business Days**: Timeline to deliver DPNS Agreement after finding significant impact
- **60 Calendar Days**: LCS completion deadline after receipt of executed agreement and deposit
- **20th day of each month**: Posting deadline for all preliminary assessments from prior calendar month
- **Study completion timeline**: (Note: specific timeframe appears blank/missing in document for DPNS completion)

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)** / **Transmission Provider**
- **Host Transmission Owner**
- **Transmission Customer**

### Roles Referenced:
- Representative of Transmission Customer (signature authority)
- Requestor Contact (various titles and contact information required)

## 6. Links or References

- **18 C.F.R. § 35.19a(a)(2)**: Federal regulation regarding interest calculation on deposits
- **Attachment AQ**: Delivery Point Assessment Process
- **Attachment AX**: Provisional Load Process
- **SPP Business Practices**: Standardized project timelines
- **SPP Website**: For posting requests and DPNS reports
- **Section 20 of the Network Operating Agreement**
- **Section 8 of the Point-to-Point Transmission Service Agreement**

## 7. Suggested Tags

- Transmission Studies
- Delivery Point Modifications
- Load Connection Study (LCS)
- Delivery Point Network Study (DPNS)
- Network Upgrades
- Integrated Transmission Planning
- SPP Tariff
- FERC Regulations
- Cost Recovery
- Study Deposits
- Preliminary Assessment
- Host Transmission Owner
- Attachment AQ
- Attachment AX
- Power Flow Analysis
- Short Circuit Analysis

## 8. Items That May Need Follow-Up

1. **Missing Timeline**: DPNS completion timeline appears incomplete in Section 3.2 ("Transmission Provider shall issue a study report... within ___ of the receipt")

2. **Interest-Bearing Account Clarification**: Need confirmation on whether interest-bearing accounts exist for all deposits or if default interest calculation per 18 C.F.R. § 35.19a(a)(2) applies

3. **Idev Modeling File Requirements**: Attachment requirement #3 mentions "Idev modeling file(s)" - clarification may be needed on format and specifications

4. **Network Upgrade Evaluation Criteria**: Process for determining whether Network Upgrades can meet study timeframe requirements needs clearer definition

5. **"Reasonably Possible" Timeline**: Section 3.2 uses this phrase for DPNS Agreement execution - may need more specific guidance

6. **Extension Agreement Process**: Multiple references to "later date as Parties may mutually agree" - standardized extension request procedures may be beneficial

7. **Significant Impact Definition**: Criteria for determining "significant impact on the Transmission System" should be clearly defined

8. **Provisional Load Process Details**: Attachment AX appears to begin but is cut off - full requirements need review

9. **GPS Coordinates Format**: Sample request form requires GPS coordinates but doesn't specify required format or datum

10. **Study Cost Estimation Accuracy**: No provisions for addressing significantly inaccurate cost estimates beyond providing revised estimates

---

# Chunk 20 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary
This document contains portions of SPP (Southwest Power Pool) tariff language covering two main areas: (1) the Provisional Load Process for delivery point modifications including study requirements, costs, and responsibilities between Transmission Customers, Host Transmission Owners, and Transmission Providers; and (2) Market Protocols related to Non-Conforming Load forecasting and Must-Offer Requirements. The content details procedural requirements for requesting delivery point changes, associated studies (Load Connection Study and Transmission System Study), timelines, cost allocations, and the template for provisional load process requests.

## 2. Key Topics
- **Provisional Load Process (Attachment AX)**: Process for modifying or establishing new delivery points
- **Load Connection Study (LCS)**: Host Transmission Owner assessment of delivery point feasibility
- **Provisional Load Process Study (PLPS)**: Transmission Provider assessment of transmission system impacts
- **Study Costs and Deposits**: Cost allocation methodology and deposit requirements (up to $25,000)
- **Study Timelines**: 90-day completion periods for studies
- **Non-Conforming Load**: Forecasting requirements for loads that don't follow normal patterns
- **Energy Storage Resources (ESR)**: ESRs not registered as MSR must be modeled as Non-Conforming Load
- **Must-Offer Requirement**: Market participant obligations (section appears incomplete)

## 3. Decisions or Actions
- **Study Request Requirements**: Transmission Customer must provide executed PLPS agreement with request
- **Host Transmission Owner Response**: Must respond within 10 business days of receipt
- **LCS Agreement Execution**: Transmission Customer must return executed LCS agreement within 30 calendar days or request is deemed withdrawn
- **Advance Deposit**: Host Transmission Owner may require deposit equal to estimated study cost or $25,000, whichever is less
- **Study Completion**: Both LCS and PLPS must be completed within 90 calendar days after receipt of executed agreement, deposit, and necessary data
- **Cost Reimbursement**: Transmission Customer must reimburse actual study costs upon completion
- **PLPS Report Posting**: If Network Upgrade identified, report posted on SPP website after notification
- **Non-Conforming Load Forecasts**: Must be submitted before Day-Ahead RUC process begins and updated up to 30 minutes before Operating Hour

## 4. Important Dates
- **10 Business Days**: Host Transmission Owner response time for LCS agreement
- **30 Calendar Days**: Deadline for Transmission Customer to return executed LCS agreement with deposit
- **90 Calendar Days**: Standard completion timeframe for both Load Connection Study and Transmission System Study
- **One Year**: Validity period for PLPS results after study report issuance
- **30 Minutes**: Final deadline before Operating Hour for Non-Conforming Load forecast updates
- **15 Minutes**: Rolling basis for Non-Conforming Load forecast submissions
- **6 Days**: Extended forecast period following Operating Day for Non-Conforming Load

## 5. Organizations and People Mentioned
### Organizations:
- **SPP (Southwest Power Pool)** - Transmission Provider
- **Host Transmission Owner** - Entity owning transmission facilities at delivery point
- **Transmission Customer** - Entity requesting delivery point changes
- **Market Participants** - Entities participating in SPP markets

### People:
- No specific individuals named in this content

## 6. Links or References
- **Addendum 1 to Attachment AX**: Sample Request for Provisional Load Process template
- **Addendum 2 and Addendum 3 of Attachment AX**: Provisional Load Process Agreements
- **18 C.F.R. § 35.19a(a)(2)**: Federal regulation for interest calculation
- **Section 6.2.2**: Reference for Non-Conforming Load description
- **Section 8.3**: Referenced but content not shown
- **OASIS**: Online system where PLPS agreement is available
- **SPP Website**: Location for posting PLPS reports
- **Market Protocols Glossary**: Referenced for definitions

## 7. Suggested Tags
- Provisional Load Process
- Delivery Point Modifications
- Load Connection Study
- Transmission System Study
- Study Costs and Deposits
- Network Upgrades
- Non-Conforming Load
- Energy Storage Resources
- Forecasting Requirements
- Day-Ahead RUC
- Market Protocols
- Transmission Service
- Tariff Requirements
- SPP OASIS

## 8. Items That May Need Follow-Up
1. **Incomplete Must-Offer Requirement Section**: Section 4.2.1 appears cut off mid-sentence - full text needed
2. **Missing Addendums**: References to Addendum 2 and 3 of Attachment AX but content not provided
3. **Section 8.3 Reference**: Cross-referenced but content not included in this chunk
4. **Operating Assumptions for Generating Facility**: Header appears without content
5. **Idev Modeling Files**: Technical modeling requirements mentioned but format/specifications not detailed
6. **Communication Configuration for Meters**: Listed as required but specifications not provided
7. **Interest-Bearing Account Details**: Process for deposit handling needs clarification if no account exists
8. **Definition of "Significant Impact"**: Criteria for determining significant vs. non-significant transmission system impact not specified
9. **Delivery Point Transfer Details**: Section 4.0 mentions this process but limited detail provided
10. **Coordination Between Studies**: Process for integrating LCS and PLPS results when both are required needs clarification
11. **MSR Registration Process**: Referenced but not explained in context of ESR requirements

---

# Chunk 21 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document section (chunk 21 of 27) from RR696 SPP Comments details the must-offer obligations and Day-Ahead Market execution procedures for Market Participants in the Southwest Power Pool (SPP). It outlines the requirements for Market Participants with registered load to offer generation resources, the calculation methodology for compliance, and the operational procedures for the Day-Ahead Market clearing process using SCUC (Security-Constrained Unit Commitment) and SCED (Security-Constrained Economic Dispatch) algorithms. The section also addresses treatment of firm power purchases/sales, reserve obligations, and procedures for handling reliability issues and capacity shortages/surpluses.

## 2. Key Topics

- **Must-Offer Obligations**: Market Participants with registered load must satisfy offering requirements for each Asset Owner
- **Day-Ahead Market Execution**: Simultaneous co-optimization methodology using SCUC and SCED algorithms
- **Net Resource Capacity Calculation**: Including firm power purchases/sales and operating reserve obligations
- **Compliance Thresholds**: 90% net resource capacity threshold for must-offer compliance
- **GFA Carve Out Requirements**: Resources used as source must be offered with sufficient capacity
- **Emergency Procedures**: Handling capacity shortages and surpluses on system-wide basis
- **Local Reliability Issues**: Manual commitment/decommitment procedures for transmission system constraints
- **Bilateral Contract Treatment**: Load registration and reporting requirements
- **MSR (Market Storage Resource) Self-Charging**: Impact on available generation calculations

## 3. Decisions or Actions

- Market Monitor will monitor Market Participant load, Operating Reserve obligations, offered Resources, and net Resource capacity for compliance
- Market Monitor may confirm firm purchases/sales with counterparties
- Market Participants must provide supporting documentation for firm power purchases/sales upon Market Monitor request
- SPP may manually commit/decommit Resources to alleviate transmission system security constraints
- Non-firm Export Interchange Transaction Bids will be curtailed in priority order during capacity shortages
- Non-firm Import Interchange Transaction Offers will be curtailed during capacity surplus situations
- Market Monitor will verify non-discriminatory Resource selection through Section 6.1.2.1 process

## 4. Important Dates

- **Operating Day**: Referenced throughout as the timeframe for load calculations and must-offer obligations
- No specific calendar dates are mentioned in this section

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)**: Market operator and Reliability Coordinator
- **Market Monitor**: Compliance monitoring and verification entity
- **Market Participants**: Load-serving entities with must-offer obligations
- **Asset Owners**: Entities associated with registered load
- **Local Transmission Operators**: May request SPP instructions for Local Reliability Issues

**People:**
- None specifically mentioned

## 6. Links or References

**Internal Document References:**
- Section 4.2.1.1 - Must-offer obligation criteria
- Section 4.1.3(4) - Operating Reserve obligation calculations
- Section 6.2.8 - Bilateral contract load registration
- Section 4.2.1.1.1 - Penalty assessment procedures
- Section 4.2.2.5.4 - JOU Individual Resource Option
- Section 6.1.14 - Combined Interest Resource modeling
- Section 6.1.7.1 - MCR registration options
- Section 4.5.9.12 - Compensation for committed Resources
- Section 4.5.9.13 - Regional cost recovery
- Section 6.1.2.1 of Attachment AE - Market Monitor verification process

**Referenced Services:**
- Firm Point-To-Point Transmission Service
- Firm Network Integration Transmission Service

## 7. Suggested Tags

- Must-Offer Obligation
- Day-Ahead Market
- Market Participant Compliance
- SCUC Algorithm
- SCED Algorithm
- Operating Reserves
- Net Resource Capacity
- Firm Power Transactions
- Market Monitor
- GFA Carve Out
- Local Reliability Issues
- Emergency Procedures
- Capacity Shortage
- Manual Commitment
- Bilateral Contracts
- Market Storage Resources (MSR)
- RUC (Reliability Unit Commitment)
- Asset Owner
- Transmission Constraints

## 8. Items That May Need Follow-Up

1. **Market Monitor Website Functionality**: Verification that the Market Monitor website for inputting firm power purchase/sale information is operational and accessible to all Market Participants

2. **Dispute Resolution Process**: Clarification needed on formal procedures when counterparties dispute firm purchases/sales with the Market Monitor

3. **90% Compliance Threshold Rationale**: Documentation or justification for the 90% net Resource capacity threshold for must-offer compliance

4. **Penalty Assessment Methodology**: Details from referenced Section 4.2.1.1.1 regarding penalty calculations and amounts for non-compliance

5. **Manual Commitment Selection Process**: Verification procedures to ensure non-discriminatory selection when SPP manually commits/decommits Resources

6. **GFA Carve Out Validation**: Monitoring process to ensure Resources offered have sufficient capacity to cover GFA Carve Out Schedules

7. **Emergency Limit Incorporation**: Operational impacts and frequency of utilizing Maximum/Minimum Emergency Capacity Operating Limits

8. **Local Reliability Issue Definition**: Clear boundaries between Local Reliability Issues and Local Emergency Conditions

9. **Compensation Recovery**: Regional allocation methodology referenced in Section 4.5.9.13 for manually committed Resources

10. **MCR Transition Hour Restrictions**: Operational impact of regulation eligibility restrictions during configuration transitions

11. **Supporting Documentation Standards**: Specific requirements for firm power purchase/sale documentation requested by Market Monitor

12. **Jointly Owned Unit Treatment**: Coordination between JOU Individual Resource Option and Combined Interest Resource modeling approaches

---

# Chunk 22 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document chunk (22 of 27) from SPP (Southwest Power Pool) comments contains detailed operational procedures for Day-Ahead Market operations, Day-Ahead Reliability Unit Commitment (RUC), and Intra-Day RUC execution. The content focuses on the algorithms and processes used for resource commitment, clearing offers, managing local reliability issues, and ensuring capacity adequacy. Key procedures include SCUC (Security Constrained Unit Commitment) and SCED (Security Constrained Economic Dispatch) algorithms, manual commitment processes, and compensation mechanisms for resources committed to address reliability issues.

## 2. Key Topics

- **Day-Ahead Market Operations**: SCUC and SCED algorithm execution for resource commitment and economic dispatch
- **Manual Resource Commitments**: Procedures for out-of-merit commitments to address reliability issues, including local transmission operator requests
- **Local Reliability Issues**: Process for addressing reliability concerns within local transmission operator areas
- **Compensation and Cost Recovery**: Methods for compensating committed resources and collecting costs locally or regionally
- **Day-Ahead RUC (Reliability Unit Commitment)**: Capacity adequacy analysis for the upcoming operating day
- **Intra-Day RUC**: Real-time capacity adequacy analysis throughout the operating day
- **MCR (Multi-Configuration Resources)**: Special rules for resources with transition times greater than 30 minutes
- **Operating Reserve Requirements**: Co-optimization of energy and operating reserves
- **Violation Relaxation Limits (VRLs)**: Application in SCED when constraints cannot be feasibly enforced
- **Emergency Operating Procedures**: Use of emergency capacity limits during shortages or surpluses

## 3. Decisions or Actions

- **Resource Commitment Priority Order** (Capacity Shortage):
  1. Curtail non-firm Export Interchange Transactions
  2. Incorporate emergency capacity limits
  3. Commit Reliability status resources
  4. De-commit charging resources from DA Market
  5. De-commit self-committed charging resources

- **Resource Management Priority Order** (Capacity Surplus):
  1. Curtail non-firm fixed Import Interchange Transactions
  2. Incorporate minimum emergency capacity limits
  3. Commit Reliability resources capable of charging
  4. De-commit Market-committed resources from DA Market
  5. De-commit self-committed resources

- **Operating Guide Development**: SPP, local transmission operators, and resource owners must develop operating guides for manual commitments addressing known and recurring Local Reliability Issues

- **SCUC Re-run Requirement**: SPP will re-run the Day-Ahead SCUC algorithm after manual commitments (time permitting) if not included in initial run

- **Market Participant Notification**: SPP will notify Market Participants when units are manually committed

## 4. Important Dates

No specific dates are mentioned in this content chunk. References to timing are procedural:
- "Operating Day" (upcoming)
- "Day-Ahead Market"
- "Intra-Day" operations
- 30-minute threshold for MCR transition times

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)** - Market operator and Reliability Coordinator
- **Local Transmission Operators** - Entities operating local transmission areas
- **Market Participants** - General reference to market entities
- **Market Monitor** - Oversight entity (referenced in Section 6.1.2.1)
- **Resource Owners** - Entities owning generation/storage resources

### People:
- **SPP Operators** - Receive advisory information from capacity adequacy analysis
- **SPP RUC Operators** - Day-Ahead and Intra-Day RUC operators who determine actions

## 6. Links or References

### Internal Section References:
- Section 4.5.8.12 (compensation recovery)
- Section 4.5.9.10(1) (local cost collection)
- Section 4.5.9.12 (compensation for manual commitments)
- Section 3.1.1 (Resource operating constraints and transmission constraints)
- Section 4.1.3.3 (VRL application in SCED)
- Section 6.1.7.1 (MCR registration option)
- Section 6.1.2.1 of Attachment AE (Market Monitor process)
- Section 4.5.9.8 (compensation for reliability commitments)
- Section 4.5.9.10 (regional cost collection)

### Document Reference:
- **Attachment AE to the Tariff** - Contains Market Monitor procedures

### Technical Components Referenced:
- SCUC algorithm (Security Constrained Unit Commitment)
- SCED algorithm (Security Constrained Economic Dispatch)
- RTBM Offers (Real-Time Balancing Market Offers)

## 7. Suggested Tags

- Day-Ahead Market
- Reliability Unit Commitment (RUC)
- SCUC Algorithm
- SCED Algorithm
- Manual Commitments
- Local Reliability Issues
- Resource Commitment
- Operating Reserves
- Capacity Adequacy
- Emergency Operations
- Multi-Configuration Resources (MCR)
- Cost Recovery
- Market Clearing
- Transmission Constraints
- Shadow Pricing
- Violation Relaxation Limits (VRL)
- Export/Import Interchange Transactions
- SPP Operations
- Market Procedures

## 8. Items That May Need Follow-Up

1. **Operating Guide Development Status**: Confirm whether operating guides have been developed between SPP, local transmission operators, and resource owners for addressing recurring Local Reliability Issues

2. **Market Monitor Review Process**: Verify the non-discriminatory selection process (Section 6.1.2.1 of Attachment AE) for manual commitments is functioning properly

3. **MCR Transition Rules**: Clarify implementation of restrictions on MCRs with transition times >30 minutes and their ineligibility for Contingency Reserve and regulation selection during configuration transitions

4. **Cost Allocation Methodology**: Verify proper implementation of local vs. regional cost recovery mechanisms for various types of manual commitments (Sections 4.5.9.10 and 4.5.9.10(1))

5. **VRL Application**: Monitor instances where Violation Relaxation Limits must be applied and ensure appropriately priced

6. **Coordination Procedures**: Review effectiveness of coordination between SPP and local transmission operators for reliability issue identification and resource commitment requests

7. **Emergency Capacity Usage**: Track frequency and circumstances of emergency capacity limit usage in both shortage and surplus situations

8. **SCUC Re-run Frequency**: Monitor how often SCUC must be re-run after manual commitments and whether this impacts market timing

9. **Lost Opportunity Cost Calculations**: Verify that Market Clearing Prices for Operating Reserve properly include lost opportunity costs to ensure market participant indifference

10. **Advisory Information Utilization**: Assess how effectively RUC Operators are using advisory information from capacity adequacy analysis to make operational decisions

---

# Chunk 23 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary

This document contains technical specifications from SPP (Southwest Power Pool) operational and planning criteria documents (RR696). The content focuses on three main areas: (1) real-time market operations and resource commitment protocols during capacity surplus and reliability events, (2) non-conforming load requirements and emergency operating procedures, and (3) transmission system planning definitions and connectivity requirements. The document establishes detailed procedures for manual resource commitments, local reliability issue resolution, and compensation recovery methods. It also sets forth requirements for ICCP (Inter-Control Center Communications Protocol) connectivity and defines key planning criteria concepts including Transmission Material Modification and Qualified Changes.

## 2. Key Topics

- **SCUC Algorithm Priority Operations**: Five-step priority process for addressing capacity surplus situations
- **Manual Resource Commitment Procedures**: Non-discriminatory selection processes for reliability-related commitments
- **Local Reliability Issues**: Protocols for coordination between SPP and local transmission operators during emergencies
- **Non-Conforming Load**: Registration requirements for loads ≥50 MW
- **Emergency Operating Plans (EOPs)**: Guidelines for operator-controlled load shedding and critical natural gas load protection
- **ICCP Node Connectivity**: Dual-node requirements for TOPs and GOPs to ensure reliability
- **Transmission Planning Criteria**: Definitions of Transmission Material Modification and Qualified Changes
- **Compensation and Cost Recovery**: Regional vs. local cost allocation methodologies

## 3. Decisions or Actions

- **SCUC Algorithm Actions During Capacity Surplus**:
  1. Curtail non-firm fixed Import Interchange Transactions
  2. Incorporate capacity down to emergency limits
  3. Commit available Resources with Reliability status capable of charging
  4. De-commit DA Market Resources with Market status
  5. De-commit self-committed Resources from Day-Ahead RUC

- **Manual Commitment Requirements**: 
  - Must be selected in non-discriminatory manner
  - Subject to Market Monitor verification per Section 6.1.2.1 of Attachment AE
  - Must minimize commitment costs while adhering to security constraints

- **Local Emergency Condition Procedures**:
  - Local transmission operator may issue initial instructions if time-critical
  - Must notify SPP of instructions given
  - SPP coordinates subsequent instructions
  - SPP logs as manual commitment/Out of Merit Dispatch

- **ICCP Connectivity Requirements**:
  - TOPs must configure ICCP nodes to connect to both primary and backup SPP sites concurrently
  - Alternate nodes must reconnect within 240 seconds of failure
  - GOPs with >1500 MW or 15+ capacity resources must configure dual nodes for setpoint instructions

## 4. Important Dates

- **240 seconds**: Maximum reconnection time for alternate ICCP nodes following failure
- **12 months**: Typical duration threshold for defining "permanent change" in Qualified Change and Transmission Material Modification definitions

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)**: Regional Transmission Organization and Transmission Provider
- **NERC**: Reliability standards authority
- **Market Monitor**: Oversight entity verifying non-discriminatory resource selection
- **TOPs (Transmission Operators)**: Registered NERC entities
- **GOPs (Generator Operators)**: Registered NERC entities
- **Market Participants**: Entities participating in SPP markets
- **Asset Owners**: Owners of Non-Conforming Load assets
- **Resource Owners**: Entities owning generation/load resources
- **Local Transmission Operators**: Entity-level reliability coordinators
- **Third-party ICCP providers**: Contracted connectivity service providers

### People:
No specific individuals mentioned

## 6. Links or References

### Internal Document References:
- **Section 4.5.9.8**: Resource compensation provisions
- **Section 4.5.9.10**: Cost recovery collection methodology (regional vs. local)
- **Section 6.1.2.1 of Attachment AE**: Market Monitor verification process for non-discriminatory resource selection
- **Attachment AE to the Tariff**: Market protocols
- **Attachment O**: Transmission Planning Process
- **Attachment V**: Generator Interconnection procedures
- **Attachment AB**: Retirement procedures
- **Attachment AQ**: Delivery point establishment procedures

### External Standards:
- **NERC Reliability Standards**: General compliance framework
- **NERC FAC-002-041**: Mandatory reliability standard for qualified changes
- **NERC Glossary of Terms**: Definitions reference
- **SPP OATT (Open Access Transmission Tariff)**: Governing tariff document

### Technical Systems:
- **SCUC (Security Constrained Unit Commitment) Algorithm**
- **DA Market (Day-Ahead Market)**
- **RTBM (Real-Time Balancing Market)**
- **Day-Ahead RUC (Reliability Unit Commitment)**
- **Intra-Day RUC**
- **ICCP (Inter-Control Center Communications Protocol)**
- **Energy Management Systems (EMS)**
- **RDS (Telemetering and Control System Status)**

## 7. Suggested Tags

- Real-Time Market Operations
- Resource Commitment
- SCUC Algorithm
- Local Reliability Issues
- Manual Commitment
- Market Monitor
- Non-Conforming Load
- Emergency Operating Plans
- ICCP Connectivity
- Transmission Planning
- Cost Recovery
- Load Shedding
- Transmission Material Modification
- Qualified Change
- BES (Bulk Electric System)
- Market Compensation
- Out of Merit Dispatch
- Reserve Zones
- GOP/TOP Requirements
- NERC Compliance

## 8. Items That May Need Follow-Up

### Operational Clarifications Needed:
1. **Manual Commitment Coordination**: Specific protocols for coordination between SPP and local transmission operators during time-sensitive Local Emergency Conditions
2. **Discriminatory Selection Determination**: Detailed criteria used by Market Monitor to assess whether resource selection was discriminatory (impacts compensation eligibility)
3. **Operating Guides Development**: Status and timeline for developing operating guides for manual commitments for known/recurring Local Reliability Issues

### Compliance and Monitoring:
4. **Non-Conforming Load Registration**: Process for Market Participants to identify and register Non-Conforming Loads ≥50 MW
5. **ICCP Node Compliance Verification**: How SPP monitors and enforces the 240-second reconnection requirement for TOPs/GOPs
6. **Planned Maintenance Outage Scheduling**: Detailed procedures referenced in RDS for ICCP node maintenance

### Policy and Procedure Questions:
7. **Affiliated Resource Compensation**: Definition and identification process for "affiliated Resources" that may be ineligible for compensation if selected discriminatorily
8. **Critical Natural Gas Load Prioritization**: Methodology for TOPs/BAs to identify and protect critical natural gas loads from load shedding
9. **Load Rotation Intervals**: Specific time intervals or criteria for rotating operator-controlled load shedding between different areas

### Technical Requirements:
10. **Third-Party ICCP Contract Requirements**: Specifications that must be included in third-party ICCP contracts to ensure 240-second reconnection capability
11. **1500 MW Threshold Application**: Clarification on how "net aggregate generation" is calculated for GOP ICCP requirements
12. **Transmission Material Modification Assessment Process**: Detailed submission and evaluation procedures for changes that may meet the definition

### Cost Recovery Verification:
13. **Regional vs. Local Cost Allocation**: Specific criteria determining when compensation is recovered regionally versus locally under Section 4.5.9.10
14. **Compensation Calculation Methodology**: How compensation is calculated for Resources committed for Local Reliability Issues versus general transmission system reliability

---

# Chunk 24 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document chunk (24 of 27) from RR696 SPP Comments contains detailed technical requirements and business practices related to SPP's (Southwest Power Pool) transmission system operations and generator interconnection processes. The content primarily covers:

- Requirements for reporting permanent changes to transmission facilities (derates >20%, impedance changes >±30%, voltage changes, configuration changes, and protection system changes)
- Procedures for non-jurisdictional facility system studies (Business Practice 7250)
- HILLGA (High Impact Long Lead Generating Addendum) network study processes
- Delivery Point evaluation procedures (Business Practice 7850 for Attachment AQ and AX processes)
- Coordination between Transmission Owners, SPP, and interconnection customers

The material is highly technical and procedural, establishing protocols for managing grid changes and ensuring system reliability.

## 2. Key Topics

1. **Transmission System Facility Changes**
   - Derating thresholds (>20%)
   - Impedance magnitude changes (>±30%)
   - Operating voltage changes
   - System configuration modifications
   - System protection capability reductions

2. **Non-Jurisdictional Generator Interconnection (BP 7250)**
   - Study requirements and procedures
   - Affected system studies
   - Coordination between SPP and Transmission Owners
   - Network Upgrade requirements

3. **HILLGA Network Studies**
   - Queue position determination
   - Serial vs. parallel processing (based on Electrically-Equivalent status)
   - Model development and analysis procedures
   - Short-circuit fault current calculations

4. **Delivery Point Processes (BP 7850)**
   - Delivery Point Additions, Modifications, and Retirements
   - Attachment AQ and AX processes
   - Network Integration Transmission Service (NITS)
   - Local Delivery Facilities management

## 3. Decisions or Actions

**Required Actions:**

1. **Transmission Owners must:**
   - Conduct required studies when notified of generator interconnection requests
   - Notify SPP of impacts to the Transmission System
   - Provide system impact studies detailing impacts
   - Complete generator interconnection agreements
   - Complete Network Upgrades prior to Generating Facility operation

2. **SPP responsibilities:**
   - Perform studies for non-jurisdictional facilities where warranted
   - Determine additional required studies for impacted systems
   - Study impacts in Definitive Interconnection System Impact Studies

3. **Transmission Customers must:**
   - Notify SPP to update NITS Agreements for Delivery Point changes
   - Notify SPP to update Provisional Load Process Agreements
   - Submit requests through Attachment AQ/AX processes

## 4. Important Dates

No specific dates are mentioned in this content chunk. The document references:
- "SPP Annual data request" (timing not specified)
- Network Upgrades completion required "prior to operation of the Generating Facility"
- Study timelines based on "standardized project timelines as provided in BP 7060"

## 5. Organizations and People Mentioned

**Organizations:**

- **SPP (Southwest Power Pool)** - Primary regulatory entity
- **Transmission Owners** - Multiple references
- **Associated Electric Cooperatives, Inc.**
- **California Independent System Operator Corporation**
- **Electric Reliability Council of Texas (ERCOT)**
- **Midcontinent Independent System Operator, Inc (MISO)**
- **Peak**
- **Public Service Company of Colorado**
- **Saskatchewan Power Corporation**
- **Southwestern Power Administration**
- **Tennessee Valley Authority**

**People:** None specifically mentioned

## 6. Links or References

**Referenced Documents and Tariffs:**

- SPP Open Access Transmission Tariff (OATT)
- Attachment BB (multiple section references: 4.1.1, 8.4.1)
- Attachment V - Generator Interconnection Procedures
- Attachment AQ - Delivery Point evaluation process
- Attachment AX - Delivery Point Additions (with planned generation)
- Business Practice 7250 - System Studies for Non-Jurisdictional Facilities
- Business Practice 7850 - Delivery Point Evaluation Process
- Business Practice 7060 - Standardized project timelines
- SPP ITP Manual Short-Circuit Analysis
- SPP Model Development Procedure Manual
- SPP Disturbance Performance Requirements
- SPP Quarterly Project Tracking Report
- Request Management System
- New Three Stage Interconnection Process
- Seams Agreements (various entities listed)

## 7. Suggested Tags

- Transmission Planning
- Generator Interconnection
- System Studies
- Network Upgrades
- HILLGA
- NITS (Network Integration Transmission Service)
- Business Practices
- Delivery Points
- Short-Circuit Analysis
- Affected Systems
- Non-Jurisdictional Facilities
- SPP OATT
- Transmission System Configuration
- System Protection
- Queue Management
- ITP (Integrated Transmission Planning)

## 8. Items That May Need Follow-Up

1. **Incomplete/Placeholder Content:**
   - "(Placeholder)" notation appears in HILLGA Network studies section - requires completion

2. **Threshold Clarifications:**
   - Verification of 20% derate threshold applicability across all facility types
   - Confirmation of ±30% impedance change threshold measurement methodology

3. **Study Agreement Details:**
   - Financial responsibility allocation between Transmission Owners and interconnection customers
   - Specific timelines for study completion (references BP 7060 but not detailed here)

4. **Aggregation of Requests:**
   - Section ends mid-sentence: "When a Transmission Customer has multiple requests for changes in Delivery Points within relative proximity to each other, the requ" - requires completion

5. **Model Update Procedures:**
   - Coordination process for incorporating GIAs that occur "subsequent to the publishing of the ITP models"
   - Definition and application of "Electrically-Equivalent" criteria

6. **Cost Allocation:**
   - Detailed cost assignment methodology for Network Upgrades
   - Financial arrangements for affected system studies

7. **NITS Agreement Updates:**
   - Specific procedures and timelines for updating agreements post-Attachment AQ/AX review

8. **Cross-Reference Verification:**
   - Ensure consistency between Business Practice 7250, 7850, and referenced Attachments (AQ, AX, BB, V)

---

# Chunk 25 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document section (chunk 25 of 27) from "RR696 SPP Comments 20250827.docx" contains technical procedures and business practices related to Southwest Power Pool (SPP) transmission operations. The content covers three main areas: (1) Delivery Point Addition/Modification processes under Attachments AQ and AX, (2) Business Practice 8100 regarding Resource Adequacy requirements for Demand Response Programs and Behind-The-Meter Generation, and (3) excerpts from the Integrated Transmission Planning (ITP) Manual. The document also includes two revenue requirement tables listing SPP Transmission Owners and their associated credits.

## 2. Key Topics

- **Delivery Point Network Study (DPNS) and Provisional Load Process Study (PLPS)**: Procedures for aggregating delivery point addition requests for more comprehensive system analysis
- **Attachment AQ Process**: Evaluation criteria for delivery point changes when the Transmission Customer has sufficient Designated Resources
- **Attachment AX Process**: Evaluation criteria when the Transmission Customer lacks sufficient Designated Resources
- **Demand Response Programs**: Requirements for controllable/dispatchable vs. non-controllable/non-dispatchable programs
- **Behind-The-Meter Generation**: Treatment of resources less than 10 MW for Resource Adequacy purposes
- **Load Forecasting**: Requirements for non-coincident peak load forecasts for ITP assessments
- **Persistent Operational Needs Assessment**: Criteria for identifying economic and reliability-related operational needs
- **Revenue Requirements**: Tables showing Transmission Owner revenue requirements and Schedule 1 PTP Revenue Credits

## 3. Decisions or Actions

- Transmission Provider must evaluate and approve aggregation of delivery point requests before proceeding
- Transmission Provider shall propose aggregated study approach to all Parties and evaluate feedback
- Each Load Responsible Entity (LRE) must report projected MW level of Peak Demand reduction as informational line item in the Workbook
- Load forecasts must be submitted to SPP using the process described in the Model Development Procedure Manual
- SPP may propose additional operational needs to ESWG and TWG for review and endorsement
- Non-dispatchable/non-controllable Demand Response Programs may only be considered in LRE's forecasted Peak Demand

## 4. Important Dates

No specific dates are mentioned in this content section. The document appears to be dated August 27, 2025 (based on filename: 20250827), but this may be a future effective date or comment deadline.

## 5. Organizations and People Mentioned

### Organizations:
- **Southwest Power Pool (SPP)** - Regional Transmission Organization
- **Transmission Owner Organizations** (24 entities listed):
  - AEP West Transmission Companies (AEP Oklahoma Transmission Company, Inc and AEP Southwestern Transmission Company, Inc)
  - American Electric Power (Public Service Company of Oklahoma and Southwestern Electric Power Company)
  - Arkansas Electric Cooperative Corporation (Zones 1 and 7)
  - City Utilities of Springfield
  - Corn Belt Power Cooperative
  - Empire District Electric Company
  - Evergy Kansas Central, Inc. (including Evergy Kansas South, Inc.)
  - Evergy Metro, Inc.
  - Evergy Missouri West, Inc.
  - Grand River Dam Authority
  - Kansas City Board of Public Utilities
  - Lincoln Electric System
  - Midwest Energy, Inc
  - Missouri Joint Municipal Electric Utility Commission
  - Nebraska Public Power District
  - Oklahoma Gas and Electric
  - Omaha Public Power District
  - Southwestern Power Administration
  - Southwestern Public Service Company
  - Sunflower Electric Power Corporation
  - Tri-State G&T Association
  - Western Farmers Electric Cooperative
  - Western-UGP

### Working Groups:
- **ESWG** (Economic Studies Working Group)
- **TWG** (Transmission Working Group)

### Stakeholder Categories:
- Transmission Providers
- Transmission Customers
- Network Customers
- Load Responsible Entities (LRE)
- Market Participants

### People:
No individual names are mentioned in this section.

## 6. Links or References

### Internal Document References:
- **Attachment AQ** - Process for delivery point changes with sufficient resources
- **Attachment AX** - Process for delivery point additions without sufficient resources
- **Attachment AA** - Resource Adequacy Requirement and Winter Season Obligation
- **Business Practice 8100** - Resource Adequacy requirements for Demand Response Programs
- **Model Development Procedure Manual** - Load forecast submission procedures
- **Integrated Transmission Planning (ITP) Manual** - Sections 2.1.3 and 4.4
- **Workbook** - Reporting tool for Peak Demand reduction
- **RRR File** - Revenue Requirement Reference File

### Referenced Tables:
- **TABLE 1**: Revenue Requirements for the Allocation of Through And Out Transactions
- **TABLE 2**: Schedule 1 Point-to-Point ("PTP") Revenue Credit

## 7. Suggested Tags

- SPP Transmission
- Delivery Point Process
- Attachment AQ
- Attachment AX
- Resource Adequacy
- Demand Response
- Behind-The-Meter Generation
- Network Upgrades
- Load Forecasting
- Integrated Transmission Planning
- Revenue Requirements
- Business Practice 8100
- DPNS (Delivery Point Network Study)
- PLPS (Provisional Load Process Study)
- Transmission Service
- Network Customer
- Load Responsible Entity
- Peak Demand
- Operational Needs Assessment

## 8. Items That May Need Follow-Up

1. **Aggregation Decision Process**: Clarification on the specific criteria and timeline for Transmission Provider to deem aggregation "appropriate" and evaluate Party feedback

2. **Resource Adequacy Compliance**: Verification that all LREs are properly reporting non-controllable/non-dispatchable demand response programs in the Workbook as informational line items

3. **50-50 Forecast Methodology**: Confirmation that Peak Demand forecasts incorporating non-controllable programs maintain the 50% probability threshold

4. **Historical Data Requirements**: Specific guidelines on what constitutes "sufficient" historical hourly demand data for seasonal demand reduction determination

5. **RRR File References**: All revenue requirements reference "See RRR File" - need to cross-reference actual values and ensure current accuracy

6. **Schedule 1 PTP Revenue Credit Clarification**: Multiple entities show "N/A" vs. "$0" - clarification needed on the distinction and implications

7. **Behind-The-Meter Generation Threshold**: Confirmation of the 10 MW threshold applicability and treatment of resources at or near this limit

8. **Persistent Operational Needs**: Process and criteria for SPP to propose "additional needs" beyond defined criteria thresholds, including documentation requirements

9. **ESWG and TWG Endorsement Process**: Timeline and voting procedures for working group review and endorsement of additional operational needs

10. **Interface Transmission Service**: Definition and requirements for transmission service "already granted across the interface" for non-SPP interconnected delivery points

11. **Local Delivery Facilities Definition**: Clear boundaries between Local Delivery Facilities and other Transmission Facilities for modification evaluation purposes

12. **Document Version Control**: This is chunk 25 of 27 - ensure complete context by reviewing adjacent sections and final document assembly

---

# Chunk 26 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document contains detailed tables (Tables 3, 4, and 5) from SPP's (Southwest Power Pool) Rate Revision Request (RR696) submitted on August 27, 2025. The tables outline the Annual Transmission Revenue Requirement (ATRR) allocation structure across 19 zones and numerous transmission entities within the SPP footprint. The tables specify zonal ATRR allocations, base plan ATRRs, reallocations to balanced portfolio region-wide ATRR, and payments to upgrade sponsors. Most specific dollar amounts reference "Att. H tab, posted RRR File" for detailed figures, with only a few explicit dollar amounts provided in the excerpt.

## 2. Key Topics

- **Annual Transmission Revenue Requirement (ATRR) allocation** across SPP zones
- **Zonal transmission pricing structure** for 19 distinct zones
- **Base Plan ATRR** calculations (pre and post June 19, 2010)
- **Balanced Portfolio Region-wide ATRR** reallocation methodology
- **Upgrade Sponsor payment mechanisms**
- **Interregional planning cost allocation** (SPP and other regions)
- **Network Integration Transmission Service (NITS) ATRR**
- **JTIQ ATRR Balance** (Joint Transmission Investment Queue)

## 3. Decisions or Actions

- Establishment of zone-specific ATRR allocations for transmission entities
- Reallocation of certain ATRR amounts to Balanced Portfolio Region-wide ATRR
- Designation of specific ATRR amounts for upgrade sponsor payments
- Reservation of certain zones for future use (Zones 1c, 11b, and 15)
- Integration of multiple sub-zones under parent organizations (e.g., Zone 19 Upper Missouri Zone with 14 sub-zones)

**Explicit Dollar Amounts Identified:**
- East Texas Electric Cooperative: $14,567,983
- Deep East Texas Electric Cooperative: $2,576,698
- Oklahoma Municipal Power Authority (Zone 1e): $768,624
- Coffeyville Municipal Light and Power: $391,790
- City of Independence, Missouri: $7,043,930
- Oklahoma Municipal Power Authority (Zone 7b): $368,501
- Southwestern Power Administration: $15,533,800
- Central Nebraska Public Power and Irrigation District: $327,891

## 4. Important Dates

- **June 19, 2010** - Critical transition date for Base Plan Zonal ATRR calculations (appears in columns 4 and 5 of Table 3)
- **August 27, 2025** (RR696 SPP Comments date) - Document submission date
- No other specific implementation or effective dates mentioned in this excerpt

## 5. Organizations and People Mentioned

### Primary Organizations:

**Zone 1 - AEP West Region:**
- American Electric Power (AEP-West)
- Public Service Company of Oklahoma
- Southwestern Electric Power Company
- East Texas Electric Cooperative
- Deep East Texas Electric Cooperative
- Oklahoma Municipal Power Authority
- AEP Oklahoma Transmission Company
- AEP Southwestern Transmission Company
- Coffeyville Municipal Light and Power
- Arkansas Electric Cooperative Corporation
- Transource Oklahoma, LLC

**Zones 2-14 - Central/Southern SPP:**
- Kansas City Board of Public Utilities
- City Utilities of Springfield, Missouri
- Empire District Electric Company
- Grand River Dam Authority
- Evergy Metro, Inc.
- City of Independence, Missouri
- Oklahoma Gas and Electric
- People's Electric Cooperative
- NextEra Energy Transmission Southwest, LLC
- Midwest Energy, Inc.
- Evergy Missouri West, Inc.
- Transource Missouri, LLC
- Southwestern Power Administration
- South Central MCN LLC
- Missouri Joint Municipal Electric Utility Commission
- Southwestern Public Service Company
- Lea County Electric Cooperative
- Sunflower Electric Power Corporation
- ITC Great Plains, LLC
- Prairie Wind Transmission, LLC
- Western Farmers Electric Cooperative
- Evergy Kansas Central, Inc.
- Evergy Kansas South, Inc.
- Kansas Power Pool

**Zones 16-19 - Northern SPP:**
- Lincoln Electric System
- Nebraska Public Power District
- Central Nebraska Public Power and Irrigation District
- Tri-State G&T Association
- Omaha Public Power District
- Western-UGP
- Basin Electric Power Cooperative
- Heartland Consumers Power District
- Missouri River Energy Services (and 8 sub-entities)
- East River Electric Power Cooperative
- Corn Belt Power Cooperative
- NorthWestern Energy Public Service Corporation
- Northwest Iowa Power Cooperative
- Harlan Municipal Utilities
- Central Power Electric Cooperative
- Mountrail-Williams Electric Cooperative
- Mor-Gran-Sou Electric Cooperative
- Roughrider Electric Cooperative
- L and O Power Cooperative

**No individual people mentioned**

## 6. Links or References

- **Attachment H tab, posted RRR File** - Referenced extensively throughout all three tables as the source for detailed ATRR figures
- **Section II.2** - Referenced for American Electric Power details
- **Column (6), Section I, Table 1** - Referenced in Tables 4 and 5 for ATRR reallocation totals
- Source document: **RR696 SPP Comments 20250827.docx.txt** (chunk 26 of 27)

## 7. Suggested Tags

- SPP
- Rate Revision Request
- RR696
- ATRR (Annual Transmission Revenue Requirement)
- Transmission Pricing
- Zonal Allocation
- Base Plan
- Balanced Portfolio
- Southwest Power Pool
- Upgrade Sponsors
- Interregional Planning
- Network Integration Transmission Service
- NITS
- Tariff Amendment
- Cost Allocation

## 8. Items That May Need Follow-Up

1. **Missing Details**: Most ATRR amounts reference "Att. H tab" - **need to obtain and review Attachment H** for complete financial details

2. **Reserved Zones**: Zones 1c, 11b, and 15 are "Reserved for Future Use" - **monitor for future assignments**

3. **June 19, 2010 Transition**: Multiple references to pre/post June 2010 methodologies - **verify rationale and regulatory basis** for this transition date

4. **Section II.2 Reference**: American Electric Power details deferred to Section II.2 - **need to review complete document** for this section

5. **JTIQ ATRR Balance** (Table 5, Line 9): **Clarify what Joint Transmission Investment Queue balance represents** and how it's calculated

6. **Interregional Planning Allocations**: Tables 4 and 5 reference "Other Interregional Planning Region ATRR" and "Other transmission provider ATRR" - **identify which regions/providers are included**

7. **Duplicate OMPA Entries**: Oklahoma Municipal Power Authority appears in both Zone 1e ($768,624) and Zone 7b ($368,501) - **verify if these are separate allocations or need reconciliation**

8. **NextEra Energy Transmission Southwest**: Appears in both Zone 7e and Zone 14e with references to posted files - **confirm separate project allocations**

9. **Table Continuity**: This is chunk 26 of 27 - **obtain previous chunks to understand complete table context** and column definitions

10. **Regulatory Approval Status**: **Confirm if RR696 has been approved** and what the implementation timeline is

11. **Cost Recovery Mechanism**: **Clarify how "Base Plan Zonal ATRR to pay Upgrade Sponsors" (Column 7) operates** and which upgrades are covered

---

# Chunk 27 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document (chunk 27 of 27 from "RR696 SPP Comments 20250827.docx.txt") contains technical tariff information from the Southwest Power Pool (SPP). The content primarily consists of structured tables detailing: (1) zonal transmission owner credits and rates, (2) transmission service request timelines and requirements for various service types (Long Term Firm, Short-Term Firm, Non-Firm, and Next Hour Market), and (3) a comprehensive acronym reference list for industry-standard terms. This appears to be the final section of a regulatory filing or comment document related to SPP's transmission tariff structure.

## 2. Key Topics

- **Transmission Zone Structure**: 19 defined zones with multiple sub-zones containing various transmission owners and utilities
- **Zonal ATRR Credits**: Credits for Annual Transmission Revenue Requirements across zones
- **Schedule 11 Credits**: Specific credits for certain transmission owners (mostly $0 or N/A)
- **Transmission Service Types**: Multiple categories including Long Term Firm, Short-Term Firm, Non-Firm, and Next Hour Market
- **Service Request Timelines**: Detailed scheduling requirements ranging from 90 days prior to 20 minutes prior to service start
- **Energy Scheduling Changes**: Requirements for modifications to energy schedules
- **Study Processes**: Aggregate Transmission Service Study, System Capacity Impact studies, and expedited designation processes
- **Industry Standards**: NERC compliance, Generator Interconnection procedures, and FERC regulations

## 3. Decisions or Actions

No specific decisions or actions are documented in this chunk. The content appears to be reference material (tables and definitions) that supports tariff implementation rather than documenting meeting decisions.

**Implied Requirements:**
- Long Term Firm (1 year+) requests must be submitted no later than 90 days prior (expedited process) or per open season schedule
- Short-Term Firm requests have varying deadlines from 31 days to 10:00 day prior depending on term length
- Non-Firm requests range from 3 days prior to 30 minutes prior
- All service types require energy scheduling changes no later than 20 minutes prior to start of schedule

## 4. Important Dates

**Recurring Deadlines by Service Type:**

**Long Term Firm (1 Year+):**
- Application: 90 days prior (expedited) or per open season
- Provider response: 10 days or at close of open season
- Customer response: 3 days or per Sections 19.4/32.4 schedule
- Energy scheduling changes: 12:00 day prior

**Short-Term Firm (Monthly):**
- Application: 8-31 days prior (varies by term)
- Provider response: 24 hours
- Study timeline: 30-60 days
- Customer response: 4 days

**Non-Firm (Hourly):**
- Application: 30 minutes to 20 minutes prior
- Provider response: Best effort to 30 minutes
- Energy scheduling changes: 20 minutes prior to hour

**Next Hour Market:**
- Application: 20 minutes prior to 1 hour prior
- Energy scheduling changes: 20 minutes prior to hour

## 5. Organizations and People Mentioned

**Major Utility Companies/Organizations:**

**Zone 1 (American Electric Power – West):**
- Public Service Company of Oklahoma
- Southwestern Electric Power Company
- East Texas Electric Cooperative, Inc.
- Deep East Texas Electric Cooperative, Inc.
- Oklahoma Municipal Power Authority
- AEP Oklahoma Transmission Company, Inc.
- AEP Southwestern Transmission Company, Inc.
- Coffeyville Municipal Light and Power (CMLP)
- Arkansas Electric Cooperative Corporation (AECC)
- Transource Oklahoma, LLC

**Other Major Entities:**
- Kansas City Board of Public Utilities
- City Utilities of Springfield, Missouri
- Empire District Electric Company
- Grand River Dam Authority
- Evergy Metro, Inc. / Evergy Missouri West, Inc. / Evergy Kansas Central, Inc.
- Oklahoma Gas and Electric
- Midwest Energy, Inc.
- Southwestern Power Administration
- Southwestern Public Service Company
- Sunflower Electric Power Corporation
- ITC Great Plains, LLC
- Western Farmers Electric Cooperative
- Lincoln Electric System
- Nebraska Public Power District
- Omaha Public Power District
- Basin Electric Power Cooperative
- Missouri River Energy Services
- NorthWestern Energy Public Service Corporation

**Regulatory Bodies:**
- Federal Energy Regulatory Commission (FERC)
- North American Electric Reliability Corporation (NERC)
- Southwest Power Pool (SPP)

*Note: No individual people are mentioned by name in this chunk.*

## 6. Links or References

**Referenced Sections/Attachments:**
- Section II.3
- Section II of Attachment Z1
- Sections 19.4 and 32.4
- Section 30.2.2 (Expedited designation process)

**Referenced Standards/Documents:**
- Open Access Transmission Tariff (OATT)
- Generator Interconnection Procedures (GIP)
- Generator Interconnection Agreement (GIA)
- NERC Transmission System Planning Performance Requirement (TPL)
- Integrated Transmission Planning (ITP)

**Systems/Software:**
- Request Management System (RMS)
- Power System Simulator for Engineering (PSS/E)

*Note: No URLs or external links are provided in this content.*

## 7. Suggested Tags

- SPP
- Southwest Power Pool
- Transmission Tariff
- OATT
- ATRR Credits
- Transmission Service
- Long Term Firm
- Short-Term Firm
- Non-Firm Service
- Next Hour Market
- Generator Interconnection
- FERC
- NERC
- Transmission Zones
- Energy Scheduling
- Transmission Requests
- Network Resource Interconnection
- Variable Energy Resource
- Transmission Owner
- Zonal Credits
- Schedule 11
- RR696
- Regulatory Filing

## 8. Items That May Need Follow-Up

**Administrative Follow-Up:**
1. **Reserved Zones**: Zone 1c, Zone 11b, and Zone 15 are marked as "Reserved for Future Use" – may need tracking for future assignments
2. **Document Completeness**: This is chunk 27 of 27; need to verify all tables 11-46 (listed but not populated with content) are intentionally blank or missing
3. **Cross-Reference Verification**: Multiple references to "Section II.3," "Sections 19.4 or 32.4," and "Attachment Z1" should be verified for consistency with complete document

**Technical/Regulatory Follow-Up:**
4. **Credits Analysis**: Majority of entries show "N/A" for both Zonal ATRR and Schedule 11 credits – may need clarification on why certain entities have $0 vs. N/A designation
5. **Expedited Process Requirements**: Section 30.2.2 requirements for expedited designation process should be reviewed for compliance criteria
6. **Study Timeline Variations**: Wide variance in study completion times (best effort to 60 days) may need operational guidelines
7. **Next Hour Market**: Marked as "best effort" with "N/A" for customer response – may need clarification on firm commitment requirements

**Compliance Considerations:**
8. **NERC TPL Compliance**: Ensure all transmission planning meets NERC TPL standards as referenced
9. **FERC Alignment**: Verify all timelines and procedures comply with current FERC orders
10. **Date Validation**: Document filename suggests date of 20250827 (August 27, 2025) – verify this future date is intentional or if it's a typo