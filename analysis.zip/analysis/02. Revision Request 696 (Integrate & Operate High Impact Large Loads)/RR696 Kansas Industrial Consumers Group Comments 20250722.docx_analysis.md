# REGULATORY MEETING/CONTENT ANALYSIS REPORT

## 1. Executive Summary

The Kansas Industrial Consumers Group (KIC) and Kansans for Lower Electric Rates (KLER) submitted comments on July 28, 2025, regarding SPP's Revision Request 696 (RR696). The RR seeks to implement a High Impact Large Load (HILL) integration assessment framework and create a new Conditional High Impact Large Load (CHILL) Service to accelerate large load interconnections while maintaining grid reliability. KIC/KLER generally support the HILL program but request two key amendments: (1) expansion to recognize that some large load customers don't require firm transmission service, and (2) allow flexible/interruptible large loads to pay only for transmission service actually used. These amendments are positioned as aligned with cost causation principles and essential for promoting economic development in Kansas's agriculture-based economy.

## 2. Key Topics

- **High Impact Large Load (HILL) Framework**: New assessment process for accelerated large load interconnections with integrated design, study, registration, and operations
- **Conditional HILL (CHILL) Service**: New service type allowing large loads to interconnect with conditional (non-firm) transmission service
- **Non-Firm Transmission**: Recognition of business models that don't require firm transmission service
- **Usage-Based Transmission Pricing**: Proposal for interruptible loads to pay only for actual transmission usage
- **Cost Causation**: Alignment of transmission costs with actual usage patterns
- **Economic Development**: Emphasis on fostering Kansas economic growth, particularly agriculture-based industries
- **Grid Reliability**: Ensuring system stability while accommodating new large loads
- **Market Efficiency**: Reducing uncertainty, improving transparency, and accelerating market entry

## 3. Decisions or Actions

**No formal decisions documented** - this is a comment submission on a proposed Revision Request.

**Requested Actions:**
- Amend HILL program to recognize large load customers that don't require firm transmission service
- Implement usage-based transmission payment structure for flexible/interruptible large loads
- Expedite implementation of the HILL program with requested amendments

**Proposed Changes to Governing Documents:**
- SPP Open Access Transmission Tariff
- Market Protocols
- SPP Operating Criteria
- SPP Planning Criteria
- SPP Business Practices
- Integrated Transmission Planning (ITP) Manual

## 4. Important Dates

- **July 28, 2025**: Comment submission date
- **1998**: Year KIC was established (27 years of advocacy noted)

## 5. Organizations and People Mentioned

**Organizations:**
- Kansas Industrial Consumers Group, Inc. (KIC)
- Kansans for Lower Electric Rates, Inc. (KLER)
- Southwest Power Pool (SPP)
- Kansas Corporation Commission (KCC)
- Federal Energy Regulatory Commission (FERC)
- Antora Energy (KIC commercial group member)
- Renew Kansas (advocates for 13 Kansas ethanol manufacturing facilities)
- NERC (North American Electric Reliability Corporation)

**People:**
- **Jim Zakoura**: President of both KIC and KLER; email: jzakoura@foulston.com; affiliated with Foulston law firm

**Stakeholder Groups Represented:**
- Manufacturing entities
- Commercial entities
- Agricultural entities
- Medical facilities (hospitals)
- Educational institutions
- Ethanol manufacturing facilities (13 in Kansas)

## 6. Links or References

**Regulatory References:**
- RR696 (Revision Request 696)
- NERC standards (referenced for reliability alignment)
- SPP governing documents (multiple, listed in Section 3)

**No URLs or hyperlinks provided in document**

## 7. Suggested Tags

- RR696
- HILL (High Impact Large Load)
- CHILL (Conditional High Impact Large Load)
- Kansas Industrial Consumers Group
- Non-Firm Transmission
- Interruptible Load
- Cost Causation
- Economic Development
- SPP
- Transmission Pricing
- Load Interconnection
- Grid Reliability
- Market Efficiency
- Kansas
- Usage-Based Pricing
- Agricultural Loads
- Ethanol Industry

## 8. Items That May Need Follow-Up

**Policy/Regulatory Follow-Up:**
1. **Amendment Request Review**: Track SPP's response to the two proposed amendments regarding non-firm transmission recognition and usage-based pricing
2. **Impact Analysis**: Assess how proposed amendments affect firm transmission customers (submitter claims no harm, but verification needed)
3. **Cost Causation Study**: Evaluate whether usage-based transmission pricing for interruptible loads aligns with SPP cost allocation principles
4. **Precedent Research**: Determine if other RTOs/ISOs have similar flexible pricing structures for large interruptible loads

**Stakeholder Engagement:**
5. **Firm Transmission Customer Response**: Monitor comments from firm transmission customers who may be affected by cost allocation changes
6. **Other State Interests**: Track whether industrial consumer groups from other SPP states support or oppose these amendments
7. **Developer Feedback**: Follow up with large load developers (e.g., Antora Energy) on business model requirements

**Technical/Implementation:**
8. **Timeline Tracking**: Monitor progress on "expeditious" implementation request
9. **Tariff Language**: Review actual proposed redline changes to governing documents (referenced but not provided in this submission)
10. **NERC Compliance**: Verify that proposed amendments maintain compliance with NERC standards

**Economic Analysis:**
11. **Quantification of Benefits**: Follow up on claimed benefits (planning reserve margin reduction, avoided upgrades, curtailment reduction, emergency procedure savings, study efficiency improvements) - currently listed as qualitative
12. **Kansas Economic Development Impact**: Track actual economic development outcomes if amendments are adopted

**Documentation:**
13. **Missing Redline Text**: The submission references providing redlined revisions in various SPP documents but no actual redline text is included - obtain complete submission package