# Final Combined Report

# COMPREHENSIVE REGULATORY ANALYSIS REPORT
## SPP HILL Fault Ride Through Requirements V1.0 (September 3, 2025)

---

## 1. EXECUTIVE SUMMARY

Southwest Power Pool (SPP) has developed comprehensive Fault Ride Through (FRT) requirements for High Impact Large Loads (HILLs) and co-located generation resources in response to the rapid proliferation of large loads such as data centers, industrial facilities, and crypto mining operations that pose increasing risks to grid stability. This Version 1.0 document (dated September 3, 2025) establishes binding technical standards covering:

- **Voltage Ride-Through**: RMS voltage profiles based on ITIC curve standards
- **Transient Overvoltage Ride-Through**: Requirements based on IEEE 2800-2022
- **Frequency Ride-Through**: Requirements based on NERC standard PRC-029-1
- **Control Methodologies**: Mandatory constant current operation (not constant power mode)

The requirements are tied to the effective date of Revision Request 696 (RR696), with different obligations for pre-existing versus new facilities. The document aligns with industry standards from IEEE, NERC, and parallels similar initiatives by ERCOT and AESO, positioning SPP as proactive in addressing emerging grid reliability challenges from the unprecedented growth in large electronic loads.

**Critical Status**: The document remains subject to stakeholder approval and technical refinement, with several key parameters marked as "TBD" (To Be Determined).

---

## 2. KEY TOPICS

### 2.1 Voltage Ride-Through Requirements
- **Performance Standards**: Based on ITIC (formerly CBEMA) curve standards for sensitive electronic equipment
- **Shallow Voltage Sags**: 0.5-0.8 per unit (pu) voltage requirements
- **Deep Voltage Sags**: Requirements for voltages below 0.5 pu
- **Recovery Requirements**: Mandatory return to 90% of pre-disturbance consumption within one second of voltage recovery
- **Control Mode**: Constant current mode operation required (constant power mode prohibited)
- **Measurement Point**: All voltage measurements at Point of Interconnection (POI) in per-unit of nominal values

### 2.2 Transient Overvoltage Ride-Through
- **Standard Basis**: IEEE 2800-2022 Table 14
- **Voltage Ranges**: 
  - 1.20-1.70 p.u.: Specific ride-through times from 0.2 to 15.0 milliseconds
  - Above 1.80 p.u.: Optional tripping allowed
- **Measurement Window**: Cumulative duration over 1-minute windows
- **Surge Arrester Consideration**: Residual voltages calculated with surge arresters applied

### 2.3 Frequency Ride-Through Requirements
- **Standard Basis**: NERC PRC-029-1 (currently under FERC review)
- **Continuous Operation Zone**: 58.8-61.2 Hz (no trip required)
- **Mandatory Ride-Through**: 
  - 57.0-58.8 Hz: 299 seconds
  - 61.2-61.8 Hz: 299 seconds
- **Optional Tripping Zones**: ≥61.8 Hz or <57.0 Hz

### 2.4 Co-Located Generation Resources
- **Inverter-Based Resources (IBRs)**: Must follow IEEE 2800-2022 Clause 7 with specific exceptions
- **Synchronous Generators/Type 1-2 Wind**: Must follow NERC PRC-024-4
- **Coordination Requirement**: Resources co-located with HILLs must coordinate ride-through performance

### 2.5 Control Methodology and Protection
- **Mandatory Constant Current Control**: Required during disturbances
- **Prohibited**: Constant power control during fault conditions
- **Fault Clearing Capability**: Ride-through for minimum 6 fault clearing attempts within 90 seconds
- **Current Limitation**: Reasonable current limitation required (specific value TBD)

### 2.6 Applicability Framework
- **New Facilities**: Full compliance required for interconnection requests on or after RR696 effective date
- **Pre-RR696 Facilities**: Must make "reasonable efforts" with documentation requirements
- **Assessment Process**: Capabilities evaluated during generator interconnection and load addition studies

---

## 3. DECISIONS OR ACTIONS

### 3.1 Required Administrative Actions
| Action Item | Description | Status |
|-------------|-------------|--------|
| **Insert RR696 Effective Date** | Critical date determining applicability must be inserted throughout document | **PENDING** |
| **Determine Current Limitation Value** | Specific "reasonable current limitation" parameters for constant current mode | **TBD** |
| **Develop Compliance Mechanisms** | Formal compliance verification procedures through stakeholder process | **PENDING** |
| **Incorporate into Governing Documents** | Potential integration into SPP OATT and other governing documents | **PENDING** |

### 3.2 Performance Requirements Established
- **Voltage Ride-Through**: HILLs must maintain operation per specified voltage profiles
- **Overvoltage Tolerance**: Mandatory ride-through times for voltages 1.20-1.70 p.u.
- **Frequency Tolerance**: 299-second ride-through for frequencies 57.0-58.8 Hz and 61.2-61.8 Hz
- **Recovery Performance**: 90% load restoration within 1 second of voltage recovery
- **Control Mode**: Constant current operation during disturbances

### 3.3 Evaluation and Verification Requirements
- **Study Phase**: Ride-through capabilities evaluated during interconnection/load addition studies
- **Verification Methods**: 
  - Dynamic load modeling validation
  - Commissioning tests and demonstrations
  - Operational monitoring and data retention
- **Documentation**: Pre-RR696 facilities must provide documentation of reasonable efforts

### 3.4 Technical Specifications Mandated
- **UPS Systems**: Must maintain ride-through performance during transitions
- **Protection Coordination**: HILL protection schemes must coordinate with grid protection
- **Reactive Current**: Default relationships between positive/negative sequence reactive currents required

---

## 4. IMPORTANT DATES

| Date | Significance | Category |
|------|--------------|----------|
| **August 28, 2025** | Initial draft version (v.0.1) by Baker/Sedighizadeh | Development |
| **September 3, 2025** | Document Version 1.0 release date | Current Version |
| **[TBD - RR696 Effective Date]** | **CRITICAL**: Determines applicability for new vs. existing facilities | **Compliance Trigger** |
| **July 11, 2025** | ERCOT LLWG meeting reference for Large Electronic Load VRT Requirements | Industry Context |
| **August 22, 2025** | AESO Connection Requirements for Transmission-Connected Data Centers published | Industry Context |
| **1-minute window** | Cumulative measurement period for overvoltage ride-through | Technical Standard |
| **1 second** | Maximum time to restore 90% of pre-disturbance load after voltage recovery | Performance Standard |
| **90 seconds** | Time window for minimum 6 fault clearing attempts | Performance Standard |
| **299 seconds** | Required ride-through duration for frequency deviations (57.0-58.8 Hz, 61.2-61.8 Hz) | Performance Standard |

---

## 5. ORGANIZATIONS AND PEOPLE MENTIONED

### 5.1 Primary Organizations

**Southwest Power Pool (SPP)**
- Role: Issuing authority and Regional Transmission Organization
- Function: Establishing and enforcing HILL FRT requirements

**North American Electric Reliability Corporation (NERC)**
- Role: Standards authority
- Relevant Standards: PRC-024-4, PRC-029-1
- Task Forces: Large Load Task Force (LLTF), Load Modeling Task Force (LMTF)

**Institute of Electrical and Electronics Engineers (IEEE)**
- Role: Technical standards developer
- Key Standards Referenced: IEEE 2800-2022, IEEE 1547, IEEE 1668-2017

### 5.2 Referenced Regional Entities and Organizations

| Organization | Acronym | Role/Relevance |
|--------------|---------|----------------|
| Electric Reliability Council of Texas | 

---

# Partial Chunk Reports

# Chunk 1 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document establishes comprehensive Fault Ride Through (FRT) requirements for High Impact Large Loads (HILLs) and co-located generation resources connecting to the Southwest Power Pool (SPP) Transmission System. The requirements are being developed in response to the rapid growth of large loads such as data centers, industrial facilities, and crypto mining operations that pose increasing risks to grid stability during voltage and frequency disturbances. The document proposes binding technical standards for voltage ride-through, transient overvoltage ride-through, frequency ride-through, and control methodologies, with applicability tied to Revision Request 696 (RR696) effective date. These requirements align with industry standards from IEEE, NERC, and reference similar initiatives by ERCOT and other regional entities.

## 2. Key Topics

### Voltage Ride-Through Requirements
- RMS voltage profiles based on ITIC curve standards
- Performance expectations during shallow voltage sags (0.5-0.8 pu) and deep sags (<0.5 pu)
- Mandatory return to 90% of pre-disturbance consumption within one second of voltage recovery
- Constant current mode operation requirement (not constant power mode)

### Transient Overvoltage Ride-Through
- Requirements based on IEEE 2800-2022 Table 14
- Cumulative duration thresholds for instantaneous voltage magnitudes over 1-minute windows

### Frequency Ride-Through
- Requirements based on NERC standard PRC-029-1
- Continuous operation requirements within specified frequency boundaries

### Co-located Resources Requirements
- Different standards for Inverter-Based Resources (IBRs) vs. synchronous generators
- IBRs must follow IEEE 2800-2022 Clause 7 (with specific exceptions)
- Synchronous generators/Type 1-2 wind follow PRC-024-4

### Control Methodology
- Mandatory constant current control during disturbances
- Prohibition of constant power control
- Ride-through capability for minimum 6 fault clearing attempts within 90 seconds

## 3. Decisions or Actions

### Required Actions:
- **Insert Effective Date for RR696**: Document requires insertion of the effective date for Revision Request 696 in multiple sections
- **Determine Reasonable Current Limitation (TBD)**: Specific current limitation values need to be established for constant current mode operation
- **Develop Compliance Mechanisms**: Compliance mechanisms to be determined through stakeholder discussions

### Performance Requirements Established:
- HILLs must ride through specified voltage, frequency, and transient overvoltage profiles
- Resources co-located with HILLs must coordinate ride-through performance
- Pre-RR696 facilities must make "reasonable efforts" and provide documentation

### Evaluation Requirements:
- Ride-through capabilities evaluated during generator interconnection and load addition studies
- Verification through modeling, commissioning tests, or operational monitoring
- Potential compliance mechanisms include dynamic load modeling validation, ride-through demonstrations, and data retention

## 4. Important Dates

- **August 28, 2025 (v.0.1)**: Initial draft version by Daniel Baker/Mostafa Sedighizadeh
- **[Insert Effective Date of RR696]**: Critical date for applicability (TBD) - interconnection requests on or after this date must comply with full requirements
- **July 11, 2025**: ERCOT Large Electronic Load Voltage Ride-Through Performance Requirements referenced (LLWG meeting)
- **August 22, 2025**: AESO Connection Requirements for Transmission-Connected Data Centers publication date
- **September 3, 2025**: Document version date (V1.0)

## 5. Organizations and People Mentioned

### Organizations:
- **Southwest Power Pool (SPP)** - Regional transmission organization establishing these requirements
- **NERC (North American Reliability Corporation)** - Standards authority
  - Large Load Task Force (LLTF)
  - Load Modeling Task Force (LMTF)
- **IEEE (Institute of Electrical and Electronics Engineers)** - Standards developer
- **ERCOT (Electric Reliability Council of Texas)** - Referenced for voltage ride-through concepts
- **ITIC (Information Technology Industry Council)** - Formerly CBEMA
- **AESO (Alberta Electric System Operator)** - Referenced for data center connection requirements
- **ESIG (Energy Systems Integration Group)** - Large Load Task Force
- **EPRI (Electric Power Research Institute)** - Large Load subprogram (DCFlex)
- **FERC (Federal Energy Regulatory Commission)** - Regulatory oversight

### People:
- **Daniel Baker** - Initial draft author
- **Mostafa Sedighizadeh** - Initial draft co-author

## 6. Links or References

### Standards Referenced:
- NERC PRC-024-4 (Frequency and Voltage Protection Settings)
- NERC PRC-029-1 (Frequency and Voltage Ride-through Requirements for IBRs) - under FERC review
- IEEE 2800-2022 (IBR Interconnection and Interoperability with Transmission Systems)
- IEEE 1547 (Distributed Energy Resources Interconnection)
- IEEE 1668-2017 (Voltage Sag and Short Interruption Ride-Through Testing)
- ANSI C84.1-2016 (voltage standards)

### Online Reference:
- https://www.itic.org/ - ITIC Curve: CBEMA Curve Update, 2000

### External Documents:
- SPP Open Access Transmission Tariff
- HILLGIA Agreement (High Impact Large Load Generator Interconnection Assessment)
- EPRI White Paper on Grid Flexibility & Data Centers (DCFlex)
- ERCOT Large Electronic Load Voltage Ride-Through Performance Requirements (LLWG July 11, 2025)
- AESO Connection Requirements for Transmission-Connected Data Centers (August 22, 2025)

## 7. Suggested Tags

- High Impact Large Loads (HILLs)
- Fault Ride Through (FRT)
- Voltage Ride Through
- Southwest Power Pool (SPP)
- Data Centers
- Grid Stability
- Inverter-Based Resources (IBR)
- Interconnection Requirements
- RR696
- NERC Standards
- IEEE 2800-2022
- Power Quality
- Reliability Standards
- Crypto Mining
- Industrial Facilities
- Load Modeling
- Transmission System
- ERCOT
- Frequency Ride Through
- Constant Current Control

## 8. Items That May Need Follow-Up

### Critical Missing Information:
1. **RR696 Effective Date**: The effective date for Revision Request 696 needs to be finalized and inserted throughout the document - this is critical for determining applicability
2. **Current Limitation Value (TBD)**: Specific reasonable current limitation parameters need to be determined for constant current mode operation
3. **Table 1 and Figure 1**: Actual voltage ride-through values/curves are referenced but not visible in this text chunk

### Pending Stakeholder Actions:
4. **Stakeholder Approval**: Document states requirements are "subject to future technical refinement, stakeholder approval"
5. **Compliance Mechanisms**: Need formal determination and approval of compliance mechanisms including:
   - Dynamic load modeling validation procedures
   - Ride-through performance demonstration protocols
   - Data retention and performance logging requirements
6. **Incorporation into SPP Governing Documents**: Potential incorporation into other SPP governing documents pending

### Technical Clarifications Needed:
7. **UPS Integration Requirements**: Specific technical requirements for UPS transition and restoration need detailed specification
8. **Transmission Owner Voltage Specifications**: Per Subclause 7.2.2.1, Transmission Owners need to specify nominal voltages
9. **Reactive Current Relationships**: Per Subclause 7.2.2.3.4, default relationships between positive and negative sequence reactive currents need submission
10. **Protection Scheme Coordination**: Detailed coordination requirements between HILL protection and grid protection schemes
11. **Pre-RR696 Facility Documentation**: Process and standards for "reasonable efforts" documentation from existing facilities

### Industry Alignment:
12. **NERC PRC-029-1 Status**: Monitor FERC review and approval status
13. **Coordination with NERC LLTF and LMTF**: Ongoing alignment with industry task force efforts
14. **ESIG Large Load Task Force**: Track parallel interconnection requirements development

---

# Chunk 2 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary
This document outlines Southwest Power Pool (SPP) High-Impact Large Load (HILL) Fault Ride-Through Requirements (Version 1.0, dated 09-03-2025). The document establishes technical specifications for voltage and frequency ride-through capabilities that large loads must maintain during system disturbances. Three tables provide specific thresholds for overvoltage ride-through times, frequency deviation tolerances, and acronym definitions relevant to grid reliability standards.

## 2. Key Topics
- **Overvoltage Ride-Through Requirements**: Specifications for instantaneous phase-to-phase or phase-to-ground voltage tolerance levels
- **Frequency Ride-Through Requirements**: System frequency deviation tolerance specifications ranging from 57.0 Hz to 61.8 Hz
- **Grid Reliability Standards**: Technical requirements for High-Impact Large Loads to maintain grid stability during disturbances
- **Point of Interconnection (POI) Standards**: Voltage measurements specified at the POI in per-unit of nominal values
- **Surge Arrester Application**: Residual voltages calculated with surge arresters applied

## 3. Decisions or Actions
- **Mandatory Ride-Through Thresholds Established**:
  - Voltages between 1.20-1.70 p.u. require specific ride-through times (0.2-15.0 milliseconds)
  - Voltages above 1.80 p.u. allow optional tripping
  - Continuous operation required for frequencies between 58.8-61.2 Hz
  - 299-second ride-through required for frequencies between 57.0-58.8 Hz and 61.2-61.8 Hz
  - Optional tripping allowed for frequencies ≥61.8 Hz or <57.0 Hz
- **Cumulative Time Window**: Ride-through times measured cumulatively over 1-minute windows

## 4. Important Dates
- **September 3, 2025**: Document version date (V1.0) - Updated Version
- **1-minute time window**: Specified for cumulative ride-through time measurement

## 5. Organizations and People Mentioned
### Organizations:
- **SPP (Southwest Power Pool)**: Issuing authority
- **CBEMA (Computer & Business Equipment Manufacturers Association)**: Referenced industry organization
- **ERCOT (Electric Reliability Council of Texas)**: Referenced regional entity
- **FERC (Federal Energy Regulatory Commission)**: Regulatory authority
- **NERC (North American Electric Reliability Corporation)**: Reliability standards organization
- **IEEE (Institute of Electrical and Electronics Engineers)**: Technical standards organization
- **ITIC (Information Technology Industry Council)**: Industry standards body

### People:
None specifically mentioned

## 6. Links or References
- CBEMA/ITIC voltage tolerance curves (implied reference)
- IEEE standards (implied)
- NERC reliability standards (implied)
- FERC regulatory framework (implied)
- Surge arrester specifications (referenced in Table 3 footnote)

## 7. Suggested Tags
- #FaultRideThrough
- #SPP
- #HILL
- #GridReliability
- #VoltageRideThrough
- #FrequencyRideThrough
- #PowerQuality
- #Interconnection
- #LargeLoad
- #GridStability
- #NERC
- #FERC
- #TechnicalRequirements

## 8. Items That May Need Follow-Up
1. **Implementation Timeline**: When do these requirements become enforceable for existing vs. new HILL facilities?
2. **Compliance Verification**: What testing or certification processes are required to demonstrate compliance?
3. **Definition of "High-Impact Large Load"**: What size/characteristics qualify a load as HILL under these requirements?
4. **Penalties for Non-Compliance**: What are the consequences for facilities that fail to meet ride-through requirements?
5. **Equipment Specifications**: What specific surge arrester ratings are assumed in the voltage calculations?
6. **Monitoring Requirements**: What measurement and recording equipment is required at the POI?
7. **Exception Process**: Is there a waiver or exception process for loads that cannot meet these requirements?
8. **Coordination with Other RTOs**: How do these requirements align with ERCOT, MISO, or other neighboring grid operators?
9. **Inverter-Based Resource (IBR) Considerations**: Special requirements or modifications for IBR-type loads?
10. **Version History**: What changed from previous versions (if any) to justify this "Updated Version" designation?