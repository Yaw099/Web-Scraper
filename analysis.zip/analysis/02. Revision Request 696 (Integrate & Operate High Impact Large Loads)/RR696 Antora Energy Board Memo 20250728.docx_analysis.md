# REGULATORY ANALYSIS REPORT
## RR696 Antora Energy Board Memo - January 28, 2025

---

## 1. Executive Summary

Antora Energy is commenting on SPP's Tariff Revision Request 696 (RR696) regarding the proposed "Conditional High Impact Large Load (CHILL) Service." While supportive of the concept, Antora identifies significant gaps in the current draft that create barriers for thermal energy storage systems. The company proposes two key modifications: (1) allowing CHILLS as a long-term non-firm transmission service, and (2) enabling flexible reservation periods (hourly/monthly) rather than requiring annual reservations. Antora has 1.5 GW of storage projects totaling $5 billion in investment ready to deploy in SPP territory, contingent on appropriate interconnection and transmission service pathways. Their modeling shows system cost reductions of 1-8% depending on deployment scenarios.

---

## 2. Key Topics

- **CHILLS (Conditional High Impact Large Load Service)**: Proposed SPP tariff allowing large loads to interconnect quickly with conditional curtailment rights
- **Thermal Energy Storage Systems**: Industrial-scale batteries with 3:1 charge-discharge ratios, low load factors (~40% or less), and high flexibility
- **Transmission Service Barriers**: Current SPP policy requires firm transmission and one-to-one matching of designated network resources to non-coincident peak load
- **Cost Allocation Issues**: Annual reservation requirements create disproportionate costs for low load-factor, flexible loads
- **Grid Benefits**: TES deployment reduces curtailment, limits volatility, lowers wholesale prices, and improves transmission utilization
- **Economic Opportunity**: $5 billion investment pipeline in SPP region

---

## 3. Decisions or Actions

### **Requested Board Actions (Primary Request):**
- Include proposed amendments before final approval of CHILLS
- Alternative: Direct staff to propose amendments for discussion at upcoming special MOPC meeting

### **Alternative Request (if primary denied):**
1. Direct staff to immediately initiate stakeholder outreach for new RR allowing thermal storage interconnection with reasonable cost allocation
2. Request staff work with Antora on project waivers to allow thermal storage interconnection

### **Proposed Tariff Amendments:**

**Amendment 1:** Establish CHILL service as permanent option for loads meeting criteria:
- Load factor of 40% or less
- Demonstrated curtailment/dispatch performance
- Curtailment during localized high load congestion periods

**Amendment 2:** Modify reservation periods:
- Change from yearly designation to hourly, monthly, or one-year options
- Bill based on reserved capacity MW for actual reservation periods submitted

---

## 4. Important Dates

- **Document Date**: January 28, 2025 (20250728 in filename)
- **Upcoming Special MOPC Meeting**: Referenced but specific date not provided
- **Next Board Meeting**: Referenced as follow-up to MOPC meeting
- **2035 Projection**: Timeline used for grid modeling analysis

---

## 5. Organizations and People Mentioned

### **Organizations:**
- **Antora Energy** (primary commenter)
- **SPP (Southwest Power Pool)** (regulatory body)
- **MOPC** (Markets and Operations Policy Committee)
- **MISO** (referenced in grid analysis)
- **GenX** (open-source grid capacity expansion model)

### **People:**
- No specific individuals named in document

### **Industrial Application Sectors:**
- Biofuel production
- Food and beverage processing

---

## 6. Links or References

### **Academic Research:**
Van der Jagt et al., "Understanding the role and design space of demand sinks in low-carbon power systems," Energy and Climate Change (2024)
- DOI: https://doi.org/10.1016/j.egycc.2024.100132

### **Regulatory Documents:**
- Tariff Revision Request 696 (RR696)
- SPP Tariff (existing non-firm transmission service provisions)
- AQ process (Aggregate Study process)

### **Modeling Tools:**
- GenX (open-source grid capacity expansion model)

---

## 7. Suggested Tags

- Tariff Revision
- RR696
- CHILLS
- Thermal Energy Storage
- Energy Storage Systems
- Transmission Service
- Non-Firm Transmission
- Load Factor
- Grid Flexibility
- Interconnection
- SPP
- MOPC
- Cost Allocation
- Demand Response
- Industrial Load
- Curtailable Load
- Southwest Power Pool
- Designated Network Resources

---

## 8. Items That May Need Follow-Up

### **Immediate Actions:**
1. **Board Decision Timeline**: Confirm date of board vote on RR696 and whether amendments can be incorporated before approval
2. **MOPC Special Meeting**: Obtain specific date and agenda to determine if amendments can be discussed
3. **Waiver Process**: If amendments are not accepted, establish process and timeline for project-specific waivers

### **Technical Clarifications Needed:**
4. **Load Factor Threshold**: Validate 40% load factor criterion is appropriate threshold for CHILL service eligibility
5. **Curtailment Performance Standards**: Define specific metrics and requirements for "demonstrated performance during curtailment/dispatch events"
6. **Billing Mechanism**: Clarify technical implementation of hourly/monthly reservation and billing systems

### **Economic/Project-Specific:**
7. **Project Pipeline Details**: Obtain more specific information on the "dozens of sites totaling 1.5 GW" to understand urgency
8. **Cost Impact Analysis**: Quantify specific cost differences between annual vs. hourly/monthly reservation for representative projects
9. **Comparison with Other RTOs**: Research how other grid operators handle thermal energy storage interconnection

### **Policy Development:**
10. **Stakeholder Engagement**: If new RR is required, establish timeline for stakeholder process
11. **Precedent Analysis**: Examine existing hourly non-firm transmission service framework and applicability to CHILLS
12. **Grid Impact Validation**: Review Antora's modeling methodology and results (1-8% system cost reduction claims)

### **Legal/Regulatory:**
13. **FERC Approval**: Determine if proposed amendments would require additional FERC review or delay approval
14. **Discriminatory Treatment**: Assess whether current RR696 language could be challenged as unduly discriminatory against storage technologies

---

**Report Prepared**: Analysis of RR696 Antora Energy Board Memo dated January 28, 2025