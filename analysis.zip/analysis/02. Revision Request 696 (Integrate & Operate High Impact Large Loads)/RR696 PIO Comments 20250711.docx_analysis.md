# Final Combined Report

# REGULATORY MEETING ANALYSIS REPORT
**Source: RR696 PIO Comments 20250711.docx.txt - Complete Document**

---

## 1. EXECUTIVE SUMMARY

Public Interest Organizations (PIOs)—Earthjustice, Natural Resources Defense Council (NRDC), Renew Missouri, Sierra Club, and Sustainable FERC Project—submitted comprehensive comments on Southwest Power Pool's (SPP) Revision Request 696 (RR696) concerning the integration of High Impact Large Loads (HILL) and Conditional High Impact Large Load Service (CHILLS). 

While the PIOs support conditional service concepts that accelerate market entry without compromising reliability, they raise critical concerns about:

1. **Cost allocation**: Risk of existing ratepayers subsidizing large load interconnections and associated network upgrades
2. **Queue integrity**: Creation of a fourth parallel interconnection study process (HILLGA) that could disrupt existing queue management and double-count transmission capacity
3. **Resource neutrality**: Need to ensure non-discriminatory treatment across all resource types consistent with FERC Open Access principles
4. **Process efficiency**: Recommendation to transition from serial to quarterly cluster studies to prevent speculative requests and duplicated study efforts

The PIOs provide seven detailed recommendations emphasizing that large load customers must bear full interconnection costs, policies must remain resource-neutral, and the proposal should better align with SPP's forthcoming Consolidated Planning Process (CPP). They urge SPP to incorporate industry best practices while maintaining system planning integrity amid accelerating large load interconnection requests.

---

## 2. KEY TOPICS

### A. High Impact Large Load (HILL) Integration Framework
- **HILL and CHILLS Service**: Framework for accelerating large load interconnections through integrated design, study, registration, and operations
- **Conditional Service**: Expedited grid interconnection for flexible loads willing to accept curtailment during grid stress periods
- **Long-term flexible service options**: Including thermal energy storage and other highly flexible resources

### B. HILLGA (High Impact Large Load Generation Addition) Process
- **HILLGA-DA (Deliverability Area)**: Proposed pathway allowing generation interconnection within load deliverability area
- **HILLGA-Local**: Alternative pathway for generation co-located with large loads
- **Serial vs. Cluster Studies**: Current serial process versus proposed quarterly cluster approach
- **Study timeline**: SPP's targeted 90-day study completion goal

### C. Cost Allocation and Ratepayer Protection
- Risk of shifting network upgrade costs to existing ratepayers
- Need for large load customers to bear full interconnection costs
- Obligation to provide least-cost electric service to existing customers
- Concerns about subsidization of paired generation resources
- Deferred transmission constraint mitigation costs

### D. Interconnection Queue Integrity
- **Fourth parallel process**: HILLGA alongside existing DISIS, ERAS, and Surplus+ processes
- **Queue priority issues**: First-come, first-served provisions (Section 4.1.1)
- **Withdrawal flexibility**: At-will withdrawal provisions (Section 3.7) enabling speculative requests
- **Base model concerns**: Exclusion of non-GIA resources from HILLGA studies
- **Double-counting risks**: Transmission headroom across multiple parallel processes
- **Preferential treatment**: Concerns about advantages over standard DISIS process

### E. Resource Neutrality and Open Access
- Discrimination concerns against specific resource types
- FERC Open Access Transmission Tariff compliance
- Equal treatment across all generation technologies
- Support for large load access to cost-effective, carbon-free generation
- Capacity caps and policy limitations applied equally

### F. Demand-Side Resource Accreditation
- **Horizontal consistency**: Equal capacity credit for resources with equal risk reduction contributions
- **Framework alignment**: Consistency across DR (Demand Response), LPD (LRE Peak Demand), and CHILLS
- **Accredited capacity-based caps**: Versus MW-based capacity limitations
- **ESIG design principles**: Industry best practices for capacity accreditation

### G. Load Forecasting Improvements
- **Objective criteria development**: Standardized framework for incorporating large loads into forecasts
- **Firmness assessment categories**:
  - Financial credibility
  - Technical requirements
  - Equipment procurement status
  - Site control documentation
- **RTO transparency**: Improved visibility into load forecast assumptions
- **Double-counting prevention**: Avoiding duplication of large load requests without firmness verification
- **Confidentiality protocols**: NDAs and data aggregation methods for proprietary information

### H. Consolidated Planning Process (CPP) Alignment
- Transition pathways from temporary to full GIAs through CPP
- Consistency between RR696 and forthcoming CPP
- Integration of HILLGA with long-term transmission planning
- Load-limited GIA concepts

### I. Modeling and Study Process
- Enhanced modeling capabilities for high volumes of large loads
- Curtailment frequency modeling and tracking
- Fragmented assessment risks under serial process
- Study efficiency and reduced rework potential

---

## 3. DECISIONS OR ACTIONS

### SPP's Stated Objectives (from RR Form)
- Implement HILL integration assessment framework
- Incorporate language into SPP governing documents for HILL requirements and CHILLS Service
- Maintain grid reliability while balancing cost-effectiveness with expedited timelines
- Target 90-day study completion timeline

### Seven PIO Recommendations

**Recommendation #1 (CHILLS)**
- Expand access to long-term non-firm service
- Include highly flexible resources like thermal energy storage
- Provide periodic updates on expected versus actual curtailment of large load customers

**Recommendation #2 (HILLGA - Cost Allocation)**
- Ensure existing ratepayers do not subsidize large load customer interconnections
- Require large load customers to bear full costs of paired generation interconnections
- Prevent cost-shifting of network upgrades to existing ratepayers

**Recommendation #3 (HILLGA - Resource Neutrality)**
- Implement resource-neutral barriers and policy limitations
- Apply accredited capacity caps equally across all resource types
- Amend SPP tariff sections to achieve resource neutrality
- Allow large load customers access to cost-effective, carbon-free generation options

**Recommendation #4 (HILLGA - Interconnection Pathways)**
- **Primary recommendation**: Eliminate HILLGA-DA option altogether; ensure HILLGA-Local generators receive clear pathway to full GIAs through CPP
- **Alternative recommendation**: Issue temporary GIAs for HILLGA-DA and load-limited GIAs for HILLGA-Local, both with defined paths to full GIAs through CPP
- Align HILLGA-DA treatment with HILLGA-Local if retained

**Recommendation #5 (HILLGA - Study Process)**
- Transition from serial interconnection process to quarterly cluster study process
- Implement quarterly (90-day) cadence for study windows
- Prevent speculative request flooding
- Reduce duplicated study efforts and fragmented assessments
- Improve study efficiency

**Recommendation #6 (Demand-Side Resource Accreditation)**
- Ensure consistency across all demand-side resource accreditation frameworks
- Achieve horizontal consistency between DR, LPD, and CHILLS policies
- Apply equal capacity credit for resources providing equal risk reduction

**Recommendation #7 (Load Forecasting)**
- Prioritize standardization of objective criteria for large load inclusion in forecasts
- Establish firmness assessment framework
- Expedite Load Forecasting Task Force work
- Implement confidentiality agreements and data aggregation methods
- Improve RTO load forecast transparency

### Additional Recommendations
- Review and incorporate insights from GridLab/Elevate Energy Consulting report (Sections 6 and 7)
- Enhance modeling capabilities for studying high volumes of large loads and curtailments
- Establish reporting mechanisms for curtailment expectations and actuals

---

## 4. IMPORTANT DATES

- **June 10, 2025**: PJM released "Draft for Discussion: Load Adjustment Request Implementation"
- **July 1, 2025**: Large Load Stakeholder Engagement Forum presentation by SPP
- **July 11, 2025**: PIO comment submission date
- **90-day timeline**: SPP's targeted study completion period for HILLGA requests
- **Quarterly cadence**: Proposed timing for cluster studies (every 90 days)
- **Future CPP implementation**: Timeline not specified but referenced as forthcoming

---

## 5. ORGANIZATIONS AND PEOPLE MENTIONED

### Public Interest Organizations (Commenters)
1. **Natural Resources Defense Council (NRDC) - Sustainable FERC Project**
   - Annie Minondo, Advocate (aminondo@

---

# Partial Chunk Reports

# Chunk 1 Analysis

# REGULATORY MEETING ANALYSIS REPORT
**Source: RR696 PIO Comments 20250711.docx.txt - chunk 1 of 2**

---

## 1. Executive Summary

Public Interest Organizations (PIOs) - consisting of Earthjustice, Natural Resources Defense Council, Renew Missouri, Sierra Club, and Sustainable FERC Project - submitted comments on SPP's Revision Request 696 regarding the integration of High Impact Large Loads (HILL) and Conditional High Impact Large Load Service (CHILLS). While PIOs support conditional service concepts that provide speed-to-market without compromising reliability, they raise significant concerns about cost allocation to existing ratepayers, resource neutrality, and the creation of a fourth parallel interconnection study process (HILLGA) that could disrupt queue integrity. The organizations urge SPP to ensure that large load customers bear all associated costs, maintain resource-neutral policies, and better align the proposal with the forthcoming Consolidated Planning Process (CPP).

---

## 2. Key Topics

### High Impact Large Load Integration Framework
- **HILL and CHILLS Service**: Framework for accelerating large load interconnections through integrated design, study, registration, and operations
- **Conditional Service**: Expedited grid interconnection for flexible loads willing to accept curtailment during grid stress periods

### Cost Allocation Concerns
- Risk of shifting network upgrade costs to existing ratepayers
- Need for large load customers to bear full costs of their interconnection
- Obligation to provide least-cost electric service to existing customers

### Resource Neutrality
- Concerns about discrimination against specific resource types
- Emphasis on Open Access principles per FERC requirements
- Support for large load customers accessing cost-effective, carbon-free generation

### Interconnection Queue Integrity
- HILLGA as potential fourth parallel generation interconnection study process (alongside DISIS, ERAS, and Surplus+)
- Risk of double-counting transmission headroom
- Concerns about preferential treatment compared to DISIS process
- Queue disruption from excluding non-GIA resources from HILLGA base models

### Alignment with Consolidated Planning Process (CPP)
- Need for consistency between RR 696 and forthcoming CPP
- Recommendation for temporary GIAs followed by transition to full GIAs through CPP

---

## 3. Decisions or Actions

### SPP's Stated Objectives (from RR Form)
- Implement HILL integration assessment framework
- Incorporate language into SPP governing documents for HILL requirements and CHILL Service
- Maintain grid reliability while balancing cost-effectiveness with expedited timelines

### PIO Recommendations
1. **Expand conditional service** to include long-term flexible service options (e.g., thermal energy storage)
2. **Provide periodic updates** on expected vs. actual curtailment of large load customers
3. **Review and incorporate insights** from Elevate Energy Consulting and GridLab report (Sections 6 and 7)
4. **Ensure full cost allocation** to large load customers without subsidies from existing ratepayers
5. **Amend SPP tariff sections** to achieve resource neutrality
6. **Consider removing HILLGA-DA option** altogether due to disruption risks
7. **If HILLGA-DA retained**, align with HILLGA-Local treatment: expedited temporary GIAs followed by CPP transition
8. **Ensure consistency** across demand-side resource accreditation frameworks
9. **Improve transparency** of RTO load forecasts

---

## 4. Important Dates

- **July 1, 2025**: Large Load Stakeholder Engagement Forum presentation
- **July 11, 2025**: Comment submission date by PIOs

---

## 5. Organizations and People Mentioned

### Organizations
**Public Interest Organizations (PIOs) - Commenters:**
- Earthjustice
- Natural Resources Defense Council (NRDC)
- Renew Missouri
- Sierra Club
- Sustainable FERC Project

**Other Entities:**
- Southwest Power Pool (SPP)
- SPP's Load Responsible Entities (LREs)
- Federal Energy Regulatory Commission (FERC)
- North American Electric Reliability Corporation (NERC)
- Elevate Energy Consulting
- GridLab

### People
- **Annie Minondo**: NRDC representative, comment submitter (aminondo@nrdc.org)

---

## 6. Links or References

### External Reports
- **GridLab and Elevate Energy Consulting**: "Practical Guidance and Considerations for Large Load Interconnections"
  - URL: https://gridlab.org/portfolio-item/practical-guidance-and-considerations-for-large-load-interconnections/
  - Specific recommendation to review Sections 6 and 7

### SPP Processes Referenced
- DISIS (existing GI study process)
- ERAS (existing GI study process)
- Surplus+ (existing GI study process)
- HILLGA (proposed High Impact Large Load Generation Addition process)
- HILLGA-DA (HILLGA-Deliverability Area)
- HILLGA-Local
- CPP (Consolidated Planning Process - forthcoming)
- ITP (Integrated Transmission Planning)
- GRID-C (cost allocation mechanism)

### Regulatory Framework
- FERC Open Access principles
- NERC standards

---

## 7. Suggested Tags

- RR696
- High Impact Large Loads
- HILL
- CHILLS
- Large Load Interconnection
- SPP
- Generation Interconnection
- HILLGA
- Cost Allocation
- Resource Neutrality
- Queue Management
- Conditional Service
- Consolidated Planning Process
- CPP
- Public Interest Organizations
- NRDC
- Ratepayer Protection
- Transmission Planning
- Grid Reliability

---

## 8. Items That May Need Follow-Up

### Critical Issues Requiring Resolution
1. **Cost allocation methodology** - How will SPP ensure large load customers bear full network upgrade costs without ratepayer subsidies?
2. **HILLGA-DA future** - Will SPP remove this option or modify it per PIO recommendations?
3. **Resource neutrality implementation** - Which specific SPP tariff sections need amendment?
4. **Base model assumptions** - How will SPP address concerns about excluding non-GIA resources from HILLGA studies?

### Process and Policy Questions
5. **Modeling enhancements** - What additional modeling capabilities does SPP need to study high volumes of large loads and curtailments?
6. **Curtailment frequency** - What reporting mechanism will SPP establish for curtailment expectations and actuals?
7. **Long-term flexible service** - Will SPP develop pathways for thermal energy storage and other highly flexible resources?
8. **CPP alignment** - How will temporary GIAs transition to full GIAs through CPP?

### Study Coordination Issues
9. **Multiple parallel studies** - How will SPP prevent double-counting transmission headroom across DISIS, ERAS, Surplus+, and HILLGA?
10. **Queue hierarchy protection** - What safeguards will protect existing DISIS customers from HILLGA impacts?
11. **Transmission constraint mitigation** - How will deferred constraints be addressed without shifting costs to ratepayers?

### Quantitative Benefits Validation
12. **Planning reserve margin reduction** - Quantification needed
13. **Transmission upgrade avoidance** - Cost savings estimation needed
14. **Curtailment reduction benefits** - Quantified analysis needed
15. **Emergency procedure cost savings** - Measurement methodology needed
16. **Study efficiency gains** - Metrics for reduced rework needed

### Stakeholder Engagement
17. **PIO concerns response** - How will SPP formally respond to these comments?
18. **Future iterations timeline** - When will revised proposals be presented?
19. **Implementation timeline** - What is the fast-track schedule for RR 696?

### Regulatory Compliance
20. **FERC filing requirements** - Does this require FERC approval? Timeline?
21. **NERC standards compliance** - Verification of alignment needed

---

**Note**: This is chunk 1 of 2. Additional items may be identified in the second chunk.

---

# Chunk 2 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document contains public interest organization (PIO) comments on SPP's Revision Request 696 (RR 696) regarding the integration and operation of High Impact Large Loads (HILLGA). The PIOs provide seven detailed recommendations addressing CHILLS (Commercial High Impact Large Load Service), HILLGA processes, resource accreditation, and load forecasting improvements. Key concerns include preventing ratepayer subsidization of large load interconnections, ensuring resource-neutral policies, transitioning HILLGA to quarterly cluster studies, achieving consistent demand-side resource accreditation, and improving large load forecasting methodologies. The comments emphasize the need for SPP to align with industry best practices and maintain system planning integrity amid increasing large load requests.

## 2. Key Topics

- **HILLGA (High Impact Large Load) Process Reform**: Proposed transition from serial to quarterly cluster study process
- **CHILLS (Commercial High Impact Large Load Service)**: Access to long-term non-firm service
- **Generator Interconnection Pathways**: HILLGA-DA elimination and HILLGA-Local reforms with paths to full GIAs through CPP
- **Cost Allocation and Ratepayer Protection**: Ensuring existing ratepayers don't subsidize large load interconnections
- **Resource Neutrality**: Ensuring capacity caps and policy limitations apply equally across all resource types
- **Demand-Side Resource Accreditation**: Consistency across DR (Demand Response), LPD (LRE Peak Demand), and CHILLS frameworks
- **Load Forecasting Standardization**: Development of objective criteria for incorporating large load requests into forecasts
- **Horizontal Consistency**: Equal capacity credit for resources with equal risk reduction contributions

## 3. Decisions or Actions

**Recommendations Submitted:**

1. **Recommendation #1 (CHILLS)**: Expand access to long-term non-firm service
2. **Recommendation #2 (HILLGA)**: Existing ratepayers must not subsidize large load customer interconnections or paired generation
3. **Recommendation #3 (HILLGA)**: Implement resource-neutral barriers and policy limitations (e.g., accredited capacity caps)
4. **Recommendation #4 (HILLGA)**: Primary - eliminate HILLGA-DA and ensure HILLGA-Local generators receive clear path to full GIAs through CPP; Alternative - issue temporary GIAs for HILLGA-DA and load-limited GIAs for HILLGA-Local with CPP path
5. **Recommendation #5 (HILLGA)**: Transition to quarterly cluster study process from serial interconnection process
6. **Recommendation #6 (OTHER)**: Ensure consistency across all demand-side resource accreditation frameworks
7. **Recommendation #7 (OTHER)**: Prioritize standardization of objective criteria for large load inclusion in load forecasts

**Specific Concerns Raised:**
- Risk of speculative request flooding due to at-will withdrawal provisions (Section 3.7) and first-come, first-served queue priority (Section 4.1)
- Potential for duplicated study efforts and fragmented assessments under serial process
- Risk of double counting large load requests without firmness assessment

## 4. Important Dates

- **June 10, 2025**: PJM released "Draft for Discussion: Load Adjustment Request Implementation"
- **July 11, 2025**: Date indicated in source filename (RR696 PIO Comments 20250711)
- **90-day timeline**: SPP's targeted study timeline for HILLGA requests
- **Quarterly cadence**: Proposed timing for cluster studies (every 90 days)

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)**: RTO subject of the comments
- **Natural Resources Defense Council (NRDC)** - Sustainable FERC Project
- **Earthjustice**
- **Sierra Club**
- **Renew Missouri**
- **Energy Systems Integration Group (ESIG)**
- **PJM**: Referenced for comparative load forecasting approach
- **Other RTOs**: Mentioned as developing load forecast enhancements

**People:**
- **Annie Minondo**, Advocate, NRDC Sustainable FERC Project (aminondo@nrdc.org)
- **Alexander Tom**, Senior Attorney, Earthjustice (atom@earthjustice.org)
- **Greg Wannier**, Senior Attorney, Sierra Club (greg.wannier@sierraclub.org)
- **Nicole Mers**, General Counsel, Renew Missouri (nicole@renewmo.org)

## 6. Links or References

1. **ESIG Report**: https://www.esig.energy/wp-content/uploads/2023/02/ESIG-Design-principles-capacity-accreditation-report-2023.pdf
   - "New Design Principles for Capacity Accreditation," page 39

2. **PJM Document**: https://www.pjm.com/-/media/DotCom/committees-groups/subcommittees/las/2025/20250613/20250613-load-adjustment-request---draft.pdf
   - "Draft for Discussion: Load Adjustment Request Implementation," June 10, 2025

**Regulatory References:**
- **Attachment BB, Section 3.7**: HILLGA Customer withdrawal provisions
- **Attachment BB, Section 4.1.1**: Queue position assignment based on receipt date/time
- SPP Open Access Transmission Tariff
- Market Protocols

## 7. Suggested Tags

- RR696
- HILLGA
- CHILLS
- High-Impact-Large-Loads
- SPP
- Generator-Interconnection
- Demand-Side-Resources
- Resource-Accreditation
- Load-Forecasting
- Cluster-Study
- CPP-Transition
- Demand-Response
- Ratepayer-Protection
- Resource-Neutrality
- Transmission-Planning
- Public-Interest-Organizations
- NRDC
- Earthjustice
- Sierra-Club
- Renew-Missouri

## 8. Items That May Need Follow-Up

1. **Load Forecasting Task Force Progress**: Monitor expedited adoption of SPP-wide framework with objective criteria for large load incorporation

2. **CPP (Comprehensive Planning Process) Integration**: Track how HILLGA processes are integrated once CPP is implemented

3. **Confidentiality Agreements**: Follow up on whether SPP establishes NDAs with parties for proprietary large load information and data aggregation methods

4. **Objective Criteria Development**: Monitor development of firmness categories including:
   - Financial credibility assessments
   - Technical requirements evaluation
   - Equipment procurement verification
   - Site control documentation

5. **Accreditation Framework Alignment**: Track harmonization efforts across DR, LPD, and CHILLS policies for horizontal consistency

6. **Quarterly Cluster Study Implementation**: Follow whether SPP adopts the recommended quarterly cluster approach versus serial interconnection

7. **HILLGA-DA and HILLGA-Local Policy Decisions**: Monitor SPP's response to recommendations regarding elimination/modification and GIA pathway provisions

8. **Cost Allocation Methodology**: Track how SPP addresses ratepayer subsidy concerns in final policy

9. **Resource-Neutral Capacity Cap**: Follow implementation of accredited capacity-based caps versus MW-based caps

10. **Comparison with Other RTOs**: Monitor how SPP's approach compares with PJM and other RTOs developing large load policies

11. **Stakeholder Response Timeline**: Track SPP's response given the "expedited timeline" mentioned in closing

12. **90-Day Study Timeline Feasibility**: Monitor whether SPP can maintain targeted timeline under current versus proposed processes