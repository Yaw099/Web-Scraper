# REGULATORY MEETING ANALYSIS REPORT

## 1. Executive Summary

This document contains a comment submission from Enchanted Rock regarding SPP's Revision Request RR696 "Integrate & Operate High Impact Large Loads" dated July 10, 2025. Enchanted Rock proposes a phased framework for integrating large loads (particularly data centers) with co-located dispatchable generation to accelerate interconnection while maintaining grid reliability. The proposal introduces a "Load Co-located with Dispatchable Generation" (LCDG) model that allows loads to take interruptible service during Phase 1, with conversion to firm service in Phase 2 once infrastructure is complete. The comment emphasizes that this approach can integrate approximately 10 GW of new load in SPP with minimal curtailment (0.5% annually) while protecting ratepayers from infrastructure overpayment.

## 2. Key Topics

- **High Impact Large Load (HILL) Integration Framework**: Assessment and interconnection process for significant new loads
- **CHILL Service**: Complementary service offering for large load interconnection
- **Load Co-located with Dispatchable Generation (LCDG)**: Two-phase model allowing interruptible service initially, converting to firm service later
- **Non-Firm/As-Available Transmission Service**: Alternative to traditional firm 24/7 service for faster interconnection
- **Curtailment Recognition**: Valuing customer curtailment capability in transmission planning processes
- **Co-located Generation**: On-site dispatchable generation supporting data centers and large loads
- **Grid Optimization**: Better utilization of existing infrastructure by serving non-firm loads during off-peak periods
- **Ratepayer Protection**: Keeping financial risks with asset owners rather than ratepayers
- **Transmission Planning Process**: Integration of curtailment values and load forecasting
- **FERC Docket No. EL25-49**: Federal proceeding on co-located loads in PJM serving as reference model

## 3. Decisions or Actions

**No explicit decisions documented** - this is a comment submission proposing actions.

**Proposed Actions:**
- Implement HILL integration assessment framework in SPP governing documents
- Establish LCDG phased approach with Phase 1 (interruptible service) and Phase 2 (firm service conversion)
- Create expedited permitting and interconnection processes for loads with on-site generation
- Recognize curtailment value in transmission planning and load forecasting
- Develop "Available Transmission Capacity Service" similar to PJM's interruptible options
- Allow on-site generators to supply power back to grid during peak periods
- Fast-track interconnection for LCDG generation resources

## 4. Important Dates

- **July 10, 2025**: Date of comment submission
- **May 27, 2025**: SPP Large Load Process presentation referenced (mentioned FERC 206 Proceeding)
- **No specific implementation deadlines provided**

## 5. Organizations and People Mentioned

**Organizations:**
- **Enchanted Rock** (submitter) - Houston-based microgrid owner/operator/developer with 1+ GW capacity across 329 sites
- **SPP (Southwest Power Pool)** - Grid operator/RTO
- **Microsoft** - Client for data center project in northern California
- **Duke University** - Author of "Rethinking Load Growth" report
- **FERC (Federal Energy Regulatory Commission)** - Regulatory authority
- **PJM Interconnection** - Reference RTO for comparison
- **NERC** - Reliability standards organization

**People:**
- **James Huang** - Submitter, Enchanted Rock
  - Email: jhuang@enchantedrock.com
  - Phone: 713-429-4091

## 6. Links or References

**Documents Referenced:**
- RR696 Revision Request Form (SPP)
- Duke University "Rethinking Load Growth" report
- SPP Large Load Process presentation (May 27, 2025)
- FERC Docket No. EL25-49 (PJM co-located load proceeding)
- PJM "Option 6" and "Option 7" interconnection options

**SPP Documents Subject to Revision (listed but no specific changes provided):**
- SPP Open Access Transmission Tariff
- Market Protocols
- SPP Operating Criteria
- SPP Planning Criteria
- SPP Business Practices
- Integrated Transmission Planning (ITP) Manual
- Minimum Transmission Design Standards for Competitive Upgrades
- Reliability Coordinator and Balancing Authority Data
- SPP Communications Protocols
- Revision Request Process

## 7. Suggested Tags

- Large Load Integration
- Data Centers
- Co-located Generation
- Microgrids
- Interruptible Service
- Non-Firm Transmission
- Load Curtailment
- Dispatchable Generation
- Economic Development
- Grid Flexibility
- Transmission Planning
- Ratepayer Protection
- LCDG Model
- HILL Framework
- CHILL Service
- Enchanted Rock
- RR696
- FERC Compliance
- PJM Comparison
- Behind-the-Meter Generation

## 8. Items That May Need Follow-Up

1. **Missing Redlined Language**: Comment form requests specific redlined revisions to SPP governing documents, but submitter provided no detailed text changes in any of the listed document sections

2. **LCDG Model Details**: Need clarification on:
   - Specific criteria for Phase 1 to Phase 2 conversion
   - Definition of "Available Transmission Capacity Service" in SPP context
   - Curtailment dispatch protocols and compensation mechanisms
   - Metering and telemetry requirements for co-located facilities

3. **Economic Analysis**: 
   - Verification of 10 GW integration capacity with 0.5% curtailment claim
   - Quantification of claimed benefits (reserve margin reduction, upgrade avoidance, cost savings)
   - Impact analysis on existing ratepayers

4. **Coordination with FERC Docket EL25-49**: Track outcomes from PJM proceeding and alignment with SPP proposal

5. **Behind-the-Meter Generation Treatment**: Clarify whether LCDG generation under Phase 1 is truly non-network or requires network resource interconnection study

6. **Stakeholder Process**: 
   - Timeline for RR696 review and approval
   - Other stakeholder comments and positions
   - Working group assignments

7. **Reliability Studies**: Need confirmation that NERC standards compliance is maintained under LCDG model, particularly for:
   - Load modeling requirements
   - Transmission planning criteria
   - Real-time operational protocols

8. **Market Design Questions**:
   - How LCDG interacts with capacity markets
   - Energy pricing for curtailable loads
   - Transmission cost allocation for interruptible vs. firm service

9. **Technical Requirements**: Specification of "dispatchable generation" qualifications, response times, and operational protocols for grid dispatch of on-site generation