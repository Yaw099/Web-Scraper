# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

**Source File:** RR696 Antora Comments 20250728.docx.txt

---

## 1. EXECUTIVE SUMMARY

This document is a comment submission from Antora Energy regarding Revision Request 696 (RR696), which proposes to establish a framework for integrating High Impact Large Loads (HILL) into the SPP grid system. The submission, dated July 28, 2025, introduces a new Conditional High Impact Large Load (CHILL) Service to accelerate large load interconnections while maintaining grid reliability. The proposal seeks to modify SPP's governing documents and tariff structure to provide clear integration assessment frameworks, conditional transmission service, and standardized processes for significant load additions.

---

## 2. KEY TOPICS

- **High Impact Large Load (HILL) Integration Framework**: Accelerated interconnection process through integrated design, study, registration, and operations
- **Conditional High Impact Large Load (CHILL) Service**: New service allowing large loads to interconnect with conditional transmission service
- **Grid Reliability and Operational Efficiency**: Balancing cost-effectiveness with expedited market deployment
- **SPP Tariff Modifications**: Proposed changes to SPP Open Access Transmission Tariff, specifically Schedule 15
- **Market Efficiency and Transparency**: Clear, consistent interconnection rules for large load developers
- **NERC Standards Compliance**: Alignment with reliability standards
- **Planning Reserve Margin Requirements**: Potential reduction due to improved load predictability

---

## 3. DECISIONS OR ACTIONS

### Proposed Actions:
- **Implement HILL integration assessment framework** incorporating design, study, registration, and operations
- **Create new CHILL Service** in SPP governing documents
- **Modify SPP Open Access Transmission Tariff** - specifically Part 1, Common Service Provisions, Schedule 15
- **Incorporate language** addressing planning, market, and operation aspects of HILL requirements
- **Establish clear interconnection process** for significant loads before grid connection

### Expected Outcomes:
- Reduced uncertainty for developers
- Faster market entry for large loads
- Enhanced price signals
- Better cost certainty and speed to market
- Improved system stability and modeling accuracy

---

## 4. IMPORTANT DATES

- **July 28, 2025**: Date of comment submission by Antora Energy

---

## 5. ORGANIZATIONS AND PEOPLE MENTIONED

### Organizations:
- **Antora Energy** (submitting company)
- **SPP (Southwest Power Pool)** (regulatory entity)
- **NERC (North American Electric Reliability Corporation)** (standards body)

### People:
- **Noah Long** 
  - Company: Antora Energy
  - Email: noah.long@antora.com
  - Role: Submitter of comment form

---

## 6. LINKS OR REFERENCES

### Referenced Documents:
- **RR Form** (Revision Request Form)
- **Board Memo Appendix**: "Suggested RR 696 Changes"
- **SPP Open Access Transmission Tariff**
  - Part 1, Common Service Provisions
  - Schedule 15 (Page 63) - CONDITIONAL HIGH IMPACT LARGE LOAD SERVICE

### Regulatory References:
- **NERC standards** (referenced for reliability compliance)
- **SPP governing documents** (to be amended)

---

## 7. SUGGESTED TAGS

- RR696
- Revision Request
- High Impact Large Load (HILL)
- Conditional High Impact Large Load (CHILL)
- Antora Energy
- SPP Tariff
- Load Interconnection
- Grid Reliability
- Market Efficiency
- Transmission Service
- NERC Compliance
- Schedule 15
- Planning Reserve Margin
- Large Load Integration
- Southwest Power Pool

---

## 8. ITEMS THAT MAY NEED FOLLOW-UP

### Regulatory/Compliance:
1. **Review of proposed tariff language changes** - Document indicates changes are "highlighted in yellow" but actual redlined text is not fully provided
2. **Board memo appendix review** - Referenced "Suggested RR 696 Changes" appendix needs examination
3. **NERC standards alignment verification** - Ensure proposed framework complies with all applicable NERC requirements

### Technical/Operational:
4. **Quantification of claimed benefits** - Need supporting data for:
   - Reduction in planning reserve margin requirements
   - Avoided transmission upgrade costs
   - Curtailment reduction metrics
   - Cost savings from reduced emergency procedures
   - Study efficiency improvements
5. **Definition clarification** - Formal definitions needed for HILL and CHILL thresholds and criteria
6. **Coordination requirements** - Details on how cross-entity coordination will be implemented

### Process/Administrative:
7. **Comment period status** - Confirm if this is within an open comment period and when it closes
8. **Stakeholder feedback** - Track other stakeholder comments on RR696
9. **Implementation timeline** - No implementation dates provided; needs clarification
10. **Cost allocation methodology** - How will costs be distributed among beneficiaries?

### Documentation:
11. **Complete redlined language** - Full proposed tariff language modifications needed for review
12. **Supporting analysis** - Technical studies or data supporting the quantitative benefits claims
13. **Precedent review** - How other ISOs/RTOs handle similar large load integrations