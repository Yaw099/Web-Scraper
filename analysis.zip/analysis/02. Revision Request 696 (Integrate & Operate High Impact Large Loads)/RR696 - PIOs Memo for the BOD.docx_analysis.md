# Regulatory Analysis Report: RR696 - PIOs Memo for the BOD

## 1. Executive Summary

Public Interest Organizations (PIOs) including Earthjustice, NRDC, Sierra Club, and the Sustainable FERC Project have submitted critical comments on RR 696 regarding the integration and operation of High Impact Large Loads (HILLGA). The PIOs oppose two fundamental aspects of the proposal: (1) HILLGA Path 3 (HILLGA-DA pathway), which they argue creates conflicts with existing interconnection processes and unfairly shifts costs to ratepayers, and (2) capacity limitations based on nameplate capacity rather than accredited capacity, which they contend discriminates against clean energy resources. The PIOs state they **cannot endorse the proposal** unless both issues are resolved.

## 2. Key Topics

- **HILLGA (High Impact Large Loads) Implementation** - Process for integrating large electrical loads into SPP's grid
- **Interconnection Queue Conflicts** - Concerns about parallel processes (DISIS, ERAS, Surplus+, and proposed HILLGA)
- **Resource Neutrality** - Ensuring non-discriminatory treatment of different generation resource types
- **Cost Allocation** - Risk of unfair cost shifting to existing ratepayers
- **Capacity Measurement Standards** - Nameplate capacity vs. accredited capacity
- **Grid Reliability** - Potential impacts from uncoordinated study processes
- **Open Access Principles** - Compliance with longstanding regulatory requirements
- **Clean Energy Access** - Large load customers' ability to meet sustainability goals

## 3. Decisions or Actions

### Required Actions (Per PIOs):
1. **Eliminate HILLGA Path 3 (HILLGA-DA) entirely** - Complete removal from the proposal
2. **Change capacity limitation methodology** - Set final capacity limitation in terms of accredited capacity instead of nameplate capacity

### Current Status:
- SPP Board of Directors (BOD) has not yet voted on RR 696
- PIOs have submitted formal written comments with comprehensive feedback beyond this memo
- SPP has made some improvements (calculating capacity additions in terms of accredited need) but not sufficient to gain PIO support

## 4. Important Dates

- **July 28, 2025** - Submission date of PIO comments
- **Pending** - BOD vote on RR 696 (referenced but not scheduled in this document)

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)** - Grid operator implementing RR 696
- **Public Interest Organizations (PIOs)** - Collective submitting comments
  - Earthjustice
  - NRDC (Natural Resources Defense Council)
  - Sierra Club
  - Sustainable FERC Project
- **LREs (Load Responsible Entities)** - Organizations with service obligations
- **FERC (Federal Energy Regulatory Commission)** - Regulatory authority (implicit reference)

### People:
- **Annie Minondo** - PIO representative/commenter
- **Greg Wannier** - PIO representative/commenter
- **Aaron Stemplewicz** - PIO representative/commenter

### Governance:
- **BOD (Board of Directors)** - SPP's decision-making body

## 6. Links or References

### Related Processes:
- **DISIS** - Existing SPP interconnection study process
- **ERAS** - Existing SPP study process
- **Surplus+** - Existing SPP study process
- **RR 696** - Revision Request under review

### Referenced Documents:
- PIOs' full set of written comments (mentioned but not included in this memo)
- SPP's large load policy

### Regulatory Framework:
- Open access principles (longstanding FERC requirements)

## 7. Suggested Tags

- RR696
- HILLGA
- High-Impact-Large-Loads
- Interconnection-Queue
- SPP-Southwest-Power-Pool
- Public-Interest-Organizations
- Resource-Neutrality
- Capacity-Accreditation
- Grid-Reliability
- Cost-Allocation
- Clean-Energy
- Earthjustice
- NRDC
- Sierra-Club
- DISIS
- ERAS
- Ratepayer-Protection
- Open-Access
- Stakeholder-Comments

## 8. Items That May Need Follow-Up

### Critical Issues Requiring Resolution:
1. **Path 3 Elimination Decision** - BOD must decide whether to remove HILLGA-DA pathway entirely before PIOs will support proposal
2. **Capacity Limitation Methodology** - SPP must finalize whether to use accredited vs. nameplate capacity standards
3. **BOD Vote Scheduling** - Timing and agenda for RR 696 consideration needs confirmation

### Documentation Gaps:
4. **Full PIO Comments Review** - Complete written comments should be obtained and analyzed for comprehensive understanding
5. **SPP Response to Comments** - SPP's official response to PIO concerns should be tracked
6. **Technical Analysis** - Detailed impact assessment of Path 3 on existing interconnection processes
7. **Cost Impact Studies** - Quantification of potential ratepayer cost shifts under different scenarios

### Stakeholder Engagement:
8. **Large Load Customer Input** - Perspectives from actual large load customers on sustainability goals and resource preferences
9. **Other Stakeholder Comments** - Review comments from other parties on RR 696
10. **Coordination Mechanisms** - SPP's plan for coordinating four parallel study processes (DISIS, ERAS, Surplus+, HILLGA)

### Regulatory Compliance:
11. **FERC Open Access Review** - Assessment of whether proposal complies with open access requirements
12. **Legal Analysis** - Review of potential discrimination issues related to resource-type restrictions

### Implementation Planning:
13. **Alternative Solutions** - Exploration of compromise approaches that might address PIO concerns while meeting SPP objectives
14. **Timeline Adjustments** - Whether concerns will delay RR 696 implementation schedule