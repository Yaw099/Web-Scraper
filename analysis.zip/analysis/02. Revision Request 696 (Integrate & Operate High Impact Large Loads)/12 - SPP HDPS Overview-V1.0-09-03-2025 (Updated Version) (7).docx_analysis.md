# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document outlines the Southwest Power Pool's (SPP) High Impact Large Load Delivery Point Study (HDPS) process for managing High Impact Large Loads (HILLs). The framework is designed to ensure reliable and efficient integration of large loads into the transmission system through a comprehensive two-stage study process: base studies and supplemental studies. The HDPS aligns with SPP Tariff requirements (Attachments AQ, AX, BA, and BB), Business Practice 7850, SPP Planning Criteria, and NERC standards. The process includes multiple technical analyses ranging from steady-state power flow and short circuit studies to advanced Electromagnetic Transients (EMT) screening and converter-driven stability assessments. This is an initial draft (Version 0) prepared for Revision Request (RR) 696 approval.

## 2. Key Topics

- **High Impact Large Loads (HILLs) Integration**: Framework for managing reliability and operational challenges
- **Two-Stage Study Process**:
  - **Base Studies Stage**: Thermal overload, voltage stability, short circuit, RMS dynamic performance, and EMT screening
  - **Supplemental Studies Stage**: Triggered if EMT screening fails; includes detailed EMT analyses
- **Technical Study Types**:
  - Steady-state power flow analysis
  - Short circuit duty assessment
  - Transient stability evaluation
  - EMT screening using SCRCCT approach (SCR, WSCR, CSCR, CCT metrics)
  - Sub-synchronous oscillation studies (SSR and SSCI)
  - Converter-driven stability analysis
  - Emergency power control evaluation
  - Power quality studies
  - Fault ride-through capability assessment
- **Screening Thresholds**: SCR/WSCR/CSCR ≥ 6.0 and CCT ≥ 0.15 seconds
- **Model Verification**: RMS and EMT model consistency validation
- **Compliance Requirements**: NERC TPL-001-5.1, SPP Disturbance Performance Requirements (DPR)

## 3. Decisions or Actions

- **SPP Responsibilities**: SPP will conduct all base studies and supplemental studies (if triggered)
- **EMT Screening Implementation**: SPP plans to adopt the SCRCCT screening approach for system strength assessment
- **EPRI Tool Utilization**: SPP utilizes the EPRI Grid Assessment Tool (GSAT) for rapid screening
- **Collaborative Resolution**: SPP and Transmission Customers will work with affected third parties to resolve converter-driven stability concerns
- **Model Submission**: Transmission/Network Customers must provide RMS and EMT models for verification
- **Mitigation Requirements**: Projects must implement necessary mitigations identified through studies before interconnection

## 4. Important Dates

- **09/23/2025**: Version 0 initial draft created
- **Document Title Reference**: "09-03-2025" appears in filename, suggesting a September 3, 2025 version date
- **Pending Approval**: Document awaiting RR 696 approval (no specific approval date mentioned)

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)**: Primary organization conducting studies and managing process
- **NERC (North American Electric Reliability Corporation)**: Standards authority
- **CIGRE**: Referenced for Technical Brochure 909 guidelines on SSO studies
- **EPRI (Electric Power Research Institute)**: Provider of Grid Assessment Tool (GSAT)

### People:
- **Mostafa Sedighizadeh**: Co-author of Version 0
- **Jason Davis**: Co-author of Version 0

### Stakeholder Categories:
- Transmission Customer(s)
- Network Customer(s)
- Third-party affected entities
- Study engineers

## 6. Links or References

### SPP Documents:
- **SPP Tariff**: Attachments AQ, AX, BA, and BB
- **Business Practice 7850** (BP 7850)
- **SPP Planning Criteria**
- **SPP Disturbance Performance Requirements (DPR)**

### Standards:
- **NERC TPL-001-5.1**: Transmission planning reliability standards

### Technical Guidelines:
- **CIGRE Technical Brochure 909**: Sub-synchronous oscillation study guidelines

### Tools:
- **EPRI Grid Assessment Tool (GSAT)**: System strength screening tool

### Process Reference:
- **Revision Request 696 (RR 696)**: Approval process for this document

## 7. Suggested Tags

- High Impact Large Loads (HILLs)
- HDPS (High Impact Large Load Delivery Point Study)
- SPP Tariff
- EMT Screening
- Transient Stability
- Short Circuit Analysis
- Power Flow Studies
- Sub-Synchronous Oscillations
- Converter-Driven Stability
- NERC Compliance
- Transmission Planning
- Interconnection Studies
- System Strength Assessment
- Power Quality
- Fault Ride-Through
- Model Verification
- RR 696
- Business Practice 7850

## 8. Items That May Need Follow-Up

### Immediate Follow-Up:
1. **RR 696 Approval Status**: Track approval process and timeline for this HDPS manual
2. **Document Finalization**: Current Version 0 requires progression through revision process
3. **Threshold Validation**: Confirm final adoption of SCR/WSCR/CSCR ≥ 6.0 and CCT ≥ 0.15 seconds screening criteria

### Technical Development:
4. **WSCR/CSCR Adaptation**: Monitor "ongoing development" of WSCR and CSCR methods for multi-HILL scenarios
5. **GSAT Refinement**: Track SPP's refinement of EPRI Grid Assessment Tool for HILL-specific applications
6. **EMT Modeling Standards**: Establish specific requirements for EMT model submissions from customers

### Process Implementation:
7. **Stakeholder Training**: Develop training programs for study engineers and customers on new HDPS process
8. **Third-Party Coordination**: Establish protocols for engaging affected third parties in converter-driven stability resolutions
9. **Mitigation Tracking**: Create system for tracking and verifying implementation of required mitigations

### Compliance and Coordination:
10. **NERC Standard Updates**: Monitor any changes to NERC TPL-001-5.1 that may affect HDPS requirements
11. **Tariff Alignment**: Ensure continued alignment with SPP Tariff Attachments AQ, AX, BA, and BB
12. **Study Timeline**: Establish and communicate expected timelines for base and supplemental study completion

### Ongoing Monitoring:
13. **Case Study Development**: Document initial HDPS applications to refine process
14. **Industry Best Practices**: Monitor CIGRE, EPRI, and industry developments in HILL integration
15. **Model Verification Protocols**: Formalize procedures for RMS-EMT model comparison and validation