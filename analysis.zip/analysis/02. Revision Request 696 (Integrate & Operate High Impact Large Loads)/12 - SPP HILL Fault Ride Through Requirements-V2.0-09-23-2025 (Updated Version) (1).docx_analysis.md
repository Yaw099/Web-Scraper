# Final Combined Report

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT
## SPP HILL Fault Ride Through Requirements - Version 2.0

---

## 1. Executive Summary

This document (Version 2.0, dated September 23, 2025) establishes comprehensive and binding Fault Ride-Through (FRT) requirements for High Impact Large Loads (HILLs) and their co-located generation resources interconnecting to the Southwest Power Pool (SPP) Transmission System. Authored by Daniel Baker and Mostafa Sedighizadeh for RR 696 approval, the document addresses growing grid reliability concerns stemming from the rapid expansion of data centers, industrial facilities, and crypto mining operations.

The requirements mandate three-tiered voltage ride-through capabilities (aligned with ITIC curves and ERCOT proposals), frequency ride-through per NERC PRC-029-1, and mandatory constant current control during disturbances. Co-located generation resources must comply with IEEE 2800-2022 (for Inverter-Based Resources) or PRC-024-4 (for synchronous generators). These requirements apply to interconnection requests submitted on or after the effective date of RR696, with existing facilities required to make reasonable efforts toward compliance. The document remains subject to stakeholder approval and technical refinement.

---

## 2. Key Topics

### High Impact Large Load (HILL) Definitions and Applicability
- Requirements apply exclusively to HILLs (data centers, industrial facilities, crypto mining operations)
- Applies to interconnection requests submitted after RR696 effective date
- Definition references SPP Tariff

### Voltage Ride-Through Requirements
- **Three-tiered approach:**
  1. RMS voltage ride-through (six voltage bands from <0.50 to >1.20 p.u.)
  2. Transient overvoltage protection (five voltage thresholds with cumulative time limits)
  3. Deep voltage sag performance requirements
- Continuous operation required for 0.90-1.10 p.u. voltage range
- Based on ITIC curves and ERCOT voltage ride-through concepts
- Point of Interconnection (POI) as measurement reference

### Frequency Ride-Through
- Based on NERC PRC-029-1 standards
- Continuous operation required between 58.8-61.2 Hz
- 299-second minimum ride-through for moderate deviations (61.2-61.8 Hz and 57.0-58.8 Hz)
- Optional trip zones at extreme frequencies (≥61.8 or <57.0 Hz)

### Control Methodology Requirements
- Mandatory constant current control during disturbances
- Prohibition of constant power mode operation during voltage sags
- Reasonable current limitation (TBD)
- During voltage sags (0.5-0.8 pu), loads must continue consuming with proportional reduction

### Co-located Generation Resources
- Separate requirements for IBRs (IEEE 2800-2022 Clause 7 with specified exceptions)
- Synchronous generators must comply with PRC-024-4
- Transmission Provider maintains decision authority in IEEE 2800-2022 implementation

### Protection Scheme Limitations
- HILLs must ride through at least six voltage fault-clearing attempts within 90 seconds
- Prevents premature disconnection during reclosing sequences

### Load Recovery Requirements
- Return to 90% of pre-disturbance consumption within one second of voltage recovery
- Applies when voltage returns to ≥0.9 pu

### Industry Alignment
- Coordination with NERC, IEEE, ERCOT, AESO, ESIG, and EPRI efforts
- References to Large Load Task Forces and modeling initiatives

---

## 3. Decisions or Actions

### Established Requirements
1. **Voltage Ride-Through:** HILLs must ride through voltage profiles per Table 1/Figure 1 (ITIC-based curves)
2. **Voltage Tolerance Bands:** Six categories established ranging from V<0.50 p.u. to V>1.20 p.u.
3. **Operational Mode Restrictions:** Loads shall NOT operate in constant power mode during disturbances
4. **Control System Mandate:** Must use constant current control with reasonable current limitation (TBD)
5. **Recovery Performance:** 90% consumption recovery within 1 second after voltage returns to ≥0.9 pu
6. **Protection Coordination:** Must ride through at least 6 fault-clearing attempts in 90 seconds
7. **IBR Compliance:** IBRs paired with HILLs must adhere to IEEE 2800-2022 Clause 7 (with specified exceptions)
8. **Synchronous Generator Compliance:** Must comply with PRC-024-4
9. **Frequency Requirements:** Continuous operation required between 58.8-61.2 Hz
10. **Instantaneous Overvoltage Limits:** Five voltage thresholds defined with cumulative time limits over 1-minute windows

### Pending Actions
1. **Insert effective date of RR696** (multiple instances throughout document)
2. **Determine "reasonable current limitation"** (marked as TBD in Section 4.1)
3. **Finalize compliance mechanisms** through stakeholder discussions
4. **Complete stakeholder approval process** for RR 696
5. **Potential incorporation** into other SPP governing documents
6. **Define testing and verification protocols** for compliance demonstration
7. **Establish monitoring and reporting requirements** for cumulative time windows
8. **Clarify penalty and enforcement mechanisms** for non-compliance

---

## 4. Important Dates

### Document Milestones
- **September 23, 2025:** Document version date and initial draft submission (Version 2.0)
- **[Insert Effective Date of RR696]:** Critical cutoff date for applicability of requirements (**DATE NOT YET SPECIFIED**)

### Applicability Timelines
- **Prior to RR696 Effective Date:** Existing HILLs and resources must make "reasonable efforts" and provide documentation
- **On or after RR696 Effective Date:** Full compliance mandatory for new interconnection requests

### Performance Timing Requirements
- **1 second:** Maximum time for load recovery to 90% after voltage restoration
- **90 seconds:** Time window for required ride-through of 6 fault-clearing attempts
- **1 minute:** Time window for cumulative transient overvoltage duration calculation
- **299 seconds:** Minimum ride-through time for frequency deviations (61.2-61.8 Hz and 57.0-58.8 Hz)

### Referenced Standard Dates
- **IEEE 2800-2022**
- **ANSI C84.1-2016**
- **IEEE 1668-2017**
- **ITIC Curve Update: 2000**
- **AESO Connection Requirements: August 22, 2025**
- **ERCOT Large Electronic Load Requirements: LLWG July 11, 2025**

---

## 5. Organizations and People Mentioned

### People
- **Daniel Baker:** Co-author
- **Mostafa Sedighizadeh:** Co-author

### Organizations

**Primary Regulatory Bodies:**
- **Southwest Power Pool (SPP):** Primary regulatory body establishing requirements
- **FERC (Federal Energy Regulatory Commission):** Reviewing NERC PRC-029-1, regulatory authority
- **NERC (North American Electric Reliability Corporation):** Standards body (PRC-024-4, PRC-029-1)
  - Large Load Task Force (LLTF)
  - Load Modeling Task Force (LMTF)

**Standards Organizations:**
- **IEEE (Institute of Electrical and Electronics Engineers):** Technical standards (2800-2022, 1547, 1668-2017)
- **ITIC (Information Technology Industry Council):** Formerly CBEMA, voltage tolerance curves
- **CBEMA (Computer & Business Equipment Manufacturers Association):** Industry reference organization

**Regional Grid Operators:**
- **ERCOT (Electric Reliability Council of Texas):** Referenced for voltage ride-through concepts
- **AESO (Alberta Electric System Operator):** Referenced for data center requirements (August 22, 2025 requirements)

**Industry Groups:**
- **ESIG (Energy Systems Integration Group):** Large Load Task Force
- **EPRI (Electric Power Research Institute):** Large Load subprogram, DCFlex white paper

**Stakeholders:**
- **Transmission Owners:** Receiving interconnection

---

# Partial Chunk Reports

# Chunk 1 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document establishes binding Fault Ride-Through (FRT) requirements for High Impact Large Loads (HILLs) and their co-located generation resources interconnecting to the Southwest Power Pool (SPP) Transmission System. The document addresses growing reliability concerns from the rapid expansion of data centers, industrial facilities, and crypto mining operations. Key requirements include voltage ride-through capabilities (aligned with ITIC curves and ERCOT proposals), frequency ride-through per NERC PRC-029-1, and mandatory constant current control during disturbances. Resources paired with HILLs must comply with IEEE 2800-2022 (for IBRs) or PRC-024-4 (for synchronous generators). The requirements apply to interconnection requests submitted on or after the effective date of RR696, with existing facilities required to make reasonable efforts toward compliance.

## 2. Key Topics

- **High Impact Large Load (HILL) Definitions and Applicability**: Requirements apply exclusively to HILLs (data centers, industrial facilities, crypto mining) submitting interconnection requests after RR696 effective date
- **Voltage Ride-Through Requirements**: Three-tiered approach including RMS voltage, transient overvoltage, and deep voltage sag performance
- **Frequency Ride-Through**: Based on NERC PRC-029-1 standards
- **Control Methodology**: Mandatory constant current control during disturbances; prohibition of constant power mode during voltage sags
- **Co-located Generation Resources**: Separate requirements for IBRs (IEEE 2800-2022) and synchronous generators (PRC-024-4)
- **Protection Scheme Limitations**: HILLs must ride through at least six voltage fault-clearing attempts within 90 seconds
- **Load Recovery Requirements**: Return to 90% pre-disturbance consumption within one second of voltage recovery
- **Industry Alignment**: Coordination with NERC, IEEE, ERCOT, AESO, ESIG, and EPRI efforts

## 3. Decisions or Actions

**Established Requirements:**
- HILLs must ride through voltage profiles per Table 1/Figure 1 (ITIC-based curves)
- During voltage sags (0.5-0.8 pu), loads must continue consuming with proportional reduction
- Loads shall NOT operate in constant power mode during disturbances
- Must use constant current control with reasonable current limitation (TBD)
- 90% consumption recovery within 1 second after voltage returns to ≥0.9 pu
- Must ride through at least 6 fault-clearing attempts in 90 seconds
- IBRs paired with HILLs must adhere to IEEE 2800-2022 Clause 7 (with specified exceptions)
- Synchronous generators paired with HILLs must comply with PRC-024-4

**Pending Actions:**
- Insert effective date of RR696 (multiple instances)
- Determine "reasonable current limitation" (marked as TBD)
- Finalize compliance mechanisms through stakeholder discussions
- Potential incorporation into other SPP governing documents

## 4. Important Dates

- **[Insert Effective Date of RR696]**: Critical cutoff date for applicability of requirements (date not yet specified)
- **Prior to RR696 Effective Date**: Existing HILLs and resources must make "reasonable efforts" and provide documentation
- **On or after RR696 Effective Date**: Full compliance mandatory for new interconnection requests
- **1 second**: Maximum time for load recovery to 90% after voltage restoration
- **90 seconds**: Time window for required ride-through of 6 fault-clearing attempts
- **1 minute**: Time window for cumulative transient overvoltage duration calculation

**Referenced Standard Dates:**
- IEEE 2800-2022
- ANSI C84.1-2016
- IEEE 1668-2017
- ITIC Curve Update: 2000
- AESO Connection Requirements: August 22, 2025
- ERCOT Large Electronic Load Requirements: LLWG July 11, 2025

## 5. Organizations and People Mentioned

**Organizations:**
- **Southwest Power Pool (SPP)** - Primary regulatory body establishing requirements
- **NERC (North American Reliability Corporation)** - Standards body (PRC-024-4, PRC-029-1)
  - Large Load Task Force (LLTF)
  - Load Modeling Task Force (LMTF)
- **IEEE (Institute of Electrical and Electronics Engineers)** - Technical standards (2800-2022, 1547, 1668-2017)
- **ITIC (Information Technology Industry Council)** - Formerly CBEMA, voltage tolerance curves
- **ERCOT (Electric Reliability Council of Texas)** - Referenced for voltage ride-through concepts
- **AESO (Alberta Electric System Operator)** - Referenced for data center requirements
- **ESIG (Energy Systems Integration Group)** - Large Load Task Force
- **EPRI (Electric Power Research Institute)** - Large Load subprogram, DCFlex white paper
- **FERC (Federal Energy Regulatory Commission)** - Reviewing NERC PRC-029-1
- **Transmission Owners** - Receiving interconnection requests, setting specifications
- **Transmission Provider** - Decision authority in IEEE 2800-2022 implementation
- **Interconnection Customer** - Required to submit IBR Plant controls documentation

**People Mentioned:**
- None specifically named

## 6. Links or References

**Standards and Documents:**
- NERC PRC-024-4 (Frequency and Voltage Protection Settings)
- NERC PRC-029-1 (Frequency and Voltage Ride-through Requirements for IBRs)
- IEEE 2800-2022 (IBR Interconnection with Transmission Systems)
- IEEE 1547 (DER Interconnection Standard)
- IEEE 1668-2017 (Voltage Sag Ride-Through Testing)
- ANSI C84.1-2016 (voltage standards)
- ITIC Curve: https://www.itic.org/
- SPP Open Access Transmission Tariff
- SPP Tariff (HILL definition)
- AESO Connection Requirements for Transmission-Connected Data Centers (August 22, 2025)
- ERCOT Large Electronic Load Voltage Ride-Through Performance Requirements (LLWG July 11, 2025)
- EPRI White Paper on Grid Flexibility & Data Centers (DCFlex)
- High Impact Large Load Generator Interconnection Assessment (HILLGIA) Agreement

## 7. Suggested Tags

- High Impact Large Loads (HILL)
- Fault Ride-Through (FRT)
- Voltage Ride-Through (VRT)
- Data Centers
- Crypto Mining
- Inverter-Based Resources (IBR)
- IEEE 2800-2022
- NERC PRC-024-4
- NERC PRC-029-1
- SPP Interconnection
- Grid Stability
- Power Electronic Loads
- Variable Speed Drives (VSD)
- Constant Current Control
- Load Modeling
- Transmission Reliability
- RR696
- ITIC Curve
- Frequency Ride-Through
- Transient Overvoltage
- UPS Systems
- Cascading Outages
- Generator Interconnection

## 8. Items That May Need Follow-Up

**Critical Missing Information:**
1. **Effective Date of RR696**: Required for implementation (appears 4+ times as placeholder)
2. **"Reasonable current limitation" definition**: Marked as "TBD" in Section 4.1
3. **Compliance mechanisms**: To be determined through stakeholder discussions

**Technical Clarifications Needed:**
4. **Constant current control specifications**: Exact parameters for "reasonable current limitation"
5. **Documentation requirements**: Specific format and content for facilities making "reasonable efforts"
6. **Testing protocols**: Methods for ride-through performance demonstration and validation
7. **Data retention requirements**: Specific details on performance logs following disturbance events

**Stakeholder/Approval Process:**
8. **Stakeholder approval status**: Document notes requirements are "subject to future technical refinement, stakeholder approval"
9. **Incorporation into governing documents**: Timeline for integration into other SPP documents
10. **Transmission Owner voltage specifications**: Per Subclause 7.2.2.1, nominal voltages must be specified
11. **IBR

---

# Chunk 2 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary
This document presents Version 0 of the SPP HILL (High-Impact Large Load) Fault Ride Through Requirements, authored by Daniel Baker and Mostafa Sedighizadeh for RR 696 approval. The document establishes technical specifications for voltage and frequency ride-through requirements that large loads must meet to maintain grid stability during system disturbances. It defines operational parameters for root mean square voltage, instantaneous voltage transients, and system frequency variations, specifying minimum ride-through times before facilities may disconnect from the grid.

## 2. Key Topics
- **Fault Ride-Through Requirements**: Technical specifications for HILL facilities to remain connected during grid disturbances
- **Voltage Ride-Through Standards**: Both RMS and instantaneous voltage tolerance requirements
- **Frequency Ride-Through Standards**: Operational requirements across various frequency deviation scenarios
- **Grid Stability**: Requirements designed to prevent cascading failures from large load disconnections
- **Regulatory Compliance**: Standards for Southwest Power Pool member facilities

## 3. Decisions or Actions
- **Initial draft submitted** for RR 696 approval
- **Voltage tolerance bands established**: Six categories ranging from V<0.50 p.u. to V>1.20 p.u.
- **Frequency tolerance requirements set**: Continuous operation required between 58.8-61.2 Hz
- **Instantaneous overvoltage limits defined**: Five voltage thresholds with cumulative time limits over 1-minute windows
- **Optional trip zones identified**: Facilities may disconnect at extreme voltage (>1.20 or <0.50 p.u.) and frequency (≥61.8 or <57.0 Hz) levels

## 4. Important Dates
- **September 23, 2025**: Document version date and initial draft submission
- **Continuous operation requirement**: Applies to voltage range 0.90-1.10 p.u. and frequency range 58.8-61.2 Hz
- **299-second minimum**: Required ride-through time for frequency deviations (61.2-61.8 Hz and 57.0-58.8 Hz)

## 5. Organizations and People Mentioned
### People:
- **Daniel Baker**: Co-author
- **Mostafa Sedighizadeh**: Co-author

### Organizations:
- **SPP (Southwest Power Pool)**: Primary regulatory body
- **NERC (North American Electric Reliability Corporation)**: Referenced standard-setting organization
- **FERC (Federal Energy Regulatory Commission)**: Regulatory authority
- **ERCOT (Electric Reliability Council of Texas)**: Regional grid operator (reference)
- **IEEE (Institute of Electrical and Electronics Engineers)**: Technical standards organization
- **CBEMA (Computer & Business Equipment Manufacturers Association)**: Industry reference organization
- **ITIC (Information Technology Industry Council)**: Industry reference organization

## 6. Links or References
- **RR 696**: Revision request requiring approval
- **CBEMA/ITIC curves**: Industry-standard voltage tolerance references
- **IEEE standards**: Implied technical standards framework
- **NERC reliability standards**: Underlying regulatory framework
- **POI (Point of Interconnection)**: Technical reference point for measurements

## 7. Suggested Tags
- Fault-Ride-Through
- HILL-Requirements
- Grid-Stability
- Voltage-Tolerance
- Frequency-Response
- SPP-Standards
- RR-696
- Interconnection-Requirements
- Power-Quality
- Large-Load-Compliance
- Inverter-Based-Resources
- Transmission-Grid

## 8. Items That May Need Follow-Up

1. **RR 696 Approval Status**: Track the approval process and timeline for this revision request
2. **Implementation Timeline**: Determine effective date and compliance deadlines once approved
3. **Existing Facility Compliance**: Assess whether grandfather provisions apply to existing HILL facilities or if retrofits are required
4. **Testing and Verification Protocols**: Clarify how facilities will demonstrate compliance with these ride-through requirements
5. **Definition of "High-Impact Large Load"**: Confirm threshold criteria (MW capacity, impact assessment) for facilities subject to these requirements
6. **Coordination with NERC Standards**: Verify alignment with applicable NERC reliability standards
7. **Surge Arrester Specifications**: Clarify requirements for surge arresters referenced in Table 3, footnote a
8. **Cumulative Time Window Monitoring**: Establish monitoring and reporting requirements for the 1-minute cumulative time windows
9. **UPS and VSD Equipment Compliance**: Determine if special provisions apply to facilities with uninterruptible power supplies or variable speed drives
10. **Penalty and Enforcement Mechanisms**: Clarify consequences for non-compliance once standards are approved