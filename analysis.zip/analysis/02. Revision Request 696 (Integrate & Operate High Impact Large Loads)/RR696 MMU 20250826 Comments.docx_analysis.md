# Regulatory Meeting Analysis Report
**Source:** RR696 MMU 20250826 Comments.docx.txt

---

## 1. Executive Summary

This document contains comments from the Southwest Power Pool (SPP) Market Monitoring Unit (MMU) regarding Revision Request 696 (RR696), which establishes a framework for integrating High Impact Large Loads (HILL) into the SPP grid. The MMU submitted revised comments on August 26, 2025, following removal of Conditional High Impact Large Loads (CHILLs) and HILLGA-DA provisions from the original proposal. The MMU's primary concern is strengthening tariff language to ensure adequate oversight and compliance with new requirements for market participants connecting HILLs and supporting generation. The comments emphasize the MMU's advisory (not decisional) role and propose specific tariff language additions to enhance data accuracy requirements.

---

## 2. Key Topics

- **High Impact Large Load (HILL) Integration Framework**: Accelerated interconnection process balancing reliability, cost-effectiveness, and speed-to-market
- **MMU Oversight Enhancement**: Strengthening tariff language for RTO and MMU oversight capabilities
- **Data Accuracy Requirements**: Implementing requirements for accurate information submission by market participants
- **Regulatory Compliance**: Alignment with FERC Order 719, 18 C.F.R. § 35.28(g)(3)(ii), and SPP OATT Attachment AG
- **Market Efficiency**: Improved transparency, reduced uncertainty, and faster market entry for large loads
- **Grid Reliability**: Proper study requirements, system stability, and NERC standards alignment
- **Cross-Reference with RR655**: Integration of data accuracy language from pending Revision Request 655

---

## 3. Decisions or Actions

**Proposed Actions:**
- Strengthen and clarify tariff language for RTO and MMU oversight
- Incorporate data accuracy requirements from RR655 into RR696
- Add new language to Attachments BA and BB regarding accurate information submission
- Add Section 8.5 "Accuracy of Data and Information" to Attachment AG

**MMU Recommendations:**
- Address post-implementation recommendations from original July 29th comments after RR696 completion
- Ensure market participants adhere to tariff provisions, agreements, and new requirements
- Implement due diligence standards for data submission under Good Utility Practice

**Scope Changes:**
- Conditional High Impact Large Loads (CHILLs) removed from revision request
- HILLGA-DA path removed from revision request

---

## 4. Important Dates

- **July 29, 2025**: MMU submitted original comments for RR696
- **August 26, 2025**: MMU submitted revised comments (current document)
- **June 2025**: Markets and Operations Policy Committee (MWG) approved Revision Request 655 Outage Criteria

---

## 5. Organizations and People Mentioned

**Organizations:**
- Southwest Power Pool (SPP)
- SPP Market Monitoring Unit (MMU)
- Federal Energy Regulatory Commission (FERC)
- North American Electric Reliability Corporation (NERC)
- Markets and Operations Policy Committee (MWG)

**Individual:**
- **Michael Redlinger**: Submitter, Southwest Power Pool
  - Email: mredlinger@spp.org

---

## 6. Links or References

**Regulatory References:**
- FERC Order 719
- 18 C.F.R. § 35.28(g)(3)(ii)
- SPP OATT Attachment AG, §1.3
- SPP OATT Attachment AG, Section 8
- SPP OATT Attachment BA (High Impact Large Load)
- SPP OATT Attachment BB (High Impact Large Load Generation Assessment)

**Related Proceedings:**
- Revision Request 655 (Outage Criteria) - approved June 2025
- Original RR696 comments submitted July 29, 2025

---

## 7. Suggested Tags

- RR696
- High Impact Large Load (HILL)
- Market Monitoring Unit (MMU)
- SPP Tariff
- Load Interconnection
- Data Accuracy
- FERC Order 719
- Grid Reliability
- Market Efficiency
- NERC Standards
- Revision Request 655
- Attachment AG
- Attachment BA
- Attachment BB
- Regulatory Compliance
- Oversight

---

## 8. Items That May Need Follow-Up

1. **Post-Implementation Recommendations**: MMU's original July 29th comments contained post-implementation recommendations that need to be addressed after RR696 completion

2. **RR655 Integration**: Monitor approval and implementation of language from Revision Request 655 that is being incorporated into RR696, particularly Section 8.5 on data accuracy

3. **CHILL and HILLGA-DA Provisions**: Determine if/when the removed Conditional High Impact Large Load and HILLGA-DA path provisions will be addressed in future revision requests

4. **Tariff Language Finalization**: Ensure final tariff redlines for Attachments BA and BB Section 13 incorporate the proposed accuracy requirements

5. **Stakeholder Process**: Track progression of RR696 through SPP stakeholder forums and eventual Board approval

6. **MMU Oversight Implementation**: Develop procedures for MMU to exercise enhanced oversight authority under new tariff provisions

7. **Market Participant Compliance**: Establish mechanisms to ensure market participants understand and comply with new data accuracy and information submission requirements

8. **Definition of "Reasonable Time"**: Clarify what constitutes "reasonable amount of time" for Market Participants to deliver requested information

9. **Error Correction Procedures**: Develop specific procedures for when Market Participants discover errors in submitted information

10. **Quantitative Benefits Measurement**: Establish baseline metrics to measure claimed benefits (planning reserve margin reduction, curtailment reduction, cost savings, study efficiency improvements)