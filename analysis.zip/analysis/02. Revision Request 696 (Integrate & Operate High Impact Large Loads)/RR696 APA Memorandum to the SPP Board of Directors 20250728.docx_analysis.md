# REGULATORY ANALYSIS REPORT
## RR696 APA Memorandum to SPP Board of Directors

---

## 1. Executive Summary

The American Public Power Association (APA) submitted feedback to the SPP Board of Directors regarding Revision Request 696 (RR696), which addresses the integration and operation of High Impact Large Loads. APA opposes approval of RR696 in its current form, citing three critical issues: HILLGA Path 3 provisions that allow queue jumping, lack of resource neutrality, and inadequate design of the CHILLS (large load interconnection) proposal. APA argues that the expedited timeline has not allowed sufficient stakeholder review of this 500-page proposal and warns that approving it without amendments could negatively impact grid reliability, violate open access principles, and create discriminatory interconnection processes. APA acknowledges some value in portions of the policy but insists on substantive revisions before supporting approval.

---

## 2. Key Topics

- **HILLGA Path 3 (Deliverability Area)**: Allows generation projects to bypass existing DISIS queue projects; gives Transmission Customers (including TO Load Serving Entities) ability to block competitor generation; potentially discriminatory
  
- **Resource Neutrality**: Current proposal contains language restricting certain resource types; capacity calculations need to be based on accredited capacity rather than just accredited need

- **CHILLS (Large Load Interconnection Process)**: 
  - Lacks sufficient provisions to enable large load interconnection
  - Five-year delay in procuring transmission service creates cost uncertainty
  - No recognition of flexible load value
  - Will exacerbate existing congestion ($1-2 billion annual cost)
  - Lacks transparency in curtailment determinations
  - Insufficient for BESS (Battery Energy Storage System) loads

- **Grid Reliability Concerns**: Multiple simultaneous policy initiatives (ERAS, Surplus+, DISIS, Large Load policy) may create cumulative reliability challenges

- **Stakeholder Process Issues**: Insufficient time for review and feedback on 500-page RR; deviation from SPP's longstanding adoption processes

---

## 3. Decisions or Actions

**Requested Actions:**
- Board should NOT approve RR696 without amendments
- If Board proceeds with approval, must:
  - Exclude HILLGA Path 3
  - Ensure resource neutrality in eligibility and application
  - Make appropriate changes to CHILLS

**Previously Taken Actions:**
- APA submitted formal comments via RMS on July 11, 2025
- APA made motion at MOPC to provide stakeholders limited additional review time

**Recommended Improvements:**
- Expand CPP (Competitive Procurement Process) to include large load interconnection similar to generation
- Introduce GRID-C like fee for large load interconnection
- Develop interim interconnection process with GRID-C like charges
- Integrate CHILLS curtailment process into well-developed DR (Demand Response) policy
- Allow transmission charges to reflect value of flexible loads

---

## 4. Important Dates

- **July 11, 2025**: APA submitted formal comments via RMS
- **July 28, 2025**: Date of this memorandum to Board of Directors
- **Five-year timeline**: Referenced as problematic delay for transmission service procurement in CHILLS

---

## 5. Organizations and People Mentioned

**Organizations:**
- **APA (American Public Power Association)** - submitting organization
- **SPP (Southwest Power Pool)** - RTO developing the policy
- **FERC (Federal Energy Regulatory Commission)** - approved ERAS
- **MOPC** - committee where APA made motion
- **Google** - stakeholder with unresolved concerns
- **Antora** - stakeholder with unresolved concerns
- **Tri-State** - stakeholder commenting on unintended consequences
- **SPP Board of Directors** - decision-making body
- **SPP Staff** - policy developers
- **IMM (Independent Market Monitor)** - source of congestion data
- **Transmission Customers/TOs (Transmission Owners)** - Load Serving Entities

**People:**
- No specific individuals named

---

## 6. Links or References

**Referenced Documents/Systems:**
- RR696 (Revision Request 696) - 500-page document
- APA formal comments submitted via RMS (July 11, 2025)
- FERC order approving ERAS
- IMM report on 2024 average LMPs
- ITP25 large spot load locations graphics

**Related Policies/Initiatives:**
- ERAS (referenced as recently FERC-approved)
- DISIS (Definitive Interconnection System Impact Study)
- Surplus+ policy
- CPP (Competitive Procurement Process)
- GRID-C (fee mechanism)
- DR (Demand Response) policy
- SPP Tariff language

---

## 7. Suggested Tags

- RR696
- High Impact Large Loads
- HILLGA
- CHILLS
- Interconnection Policy
- Resource Neutrality
- Grid Reliability
- Queue Reform
- Transmission Planning
- Congestion Management
- ERAS
- DISIS
- Demand Response
- SPP Board
- Stakeholder Process
- FERC Compliance
- Non-Discriminatory Access
- Battery Storage
- Generation Interconnection
- Load Interconnection

---

## 8. Items That May Need Follow-Up

**Critical Issues Requiring Resolution:**
1. **HILLGA Path 3 elimination or modification** - discriminatory queue-jumping provisions
2. **Resource neutrality language** - ensure all resource types treated equally; final capacity set in terms of accredited capacity
3. **CHILLS redesign** - address fundamental design flaws

**Technical Clarifications Needed:**
4. **BESS load treatment** - SPP must justify why CHILLS is insufficient for battery storage
5. **Curtailment transparency** - develop clear criteria for when CHILLS loads will be curtailed
6. **Geographic guardrails** - establish limits on where CHILLS loads may interconnect
7. **Flexible load recognition** - develop mechanism to value loads that avoid high-risk/peak periods

**Process Issues:**
8. **Stakeholder review period** - ensure adequate time for feedback on complex proposals
9. **Unresolved stakeholder concerns** - address specific issues raised by Google, Antora, and Tri-State regarding:
   - Ride-through requirements
   - Non-conforming resources definition
   - Five-year timeline concerns

**Broader Policy Coordination:**
10. **Policy integration analysis** - assess cumulative impacts of ERAS, Surplus+, DISIS, and Large Load policy
11. **DR policy coordination** - integrate CHILLS curtailment into comprehensive Demand Response framework
12. **Reliability impact assessment** - evaluate potential for increased conservative operations and EEA events
13. **Congestion mitigation** - address $1-2 billion annual congestion costs before adding loads that may exacerbate issues

**Cost/Economic Issues:**
14. **Transmission cost certainty** - develop mechanism for earlier cost determination
15. **Loss allocation** - clarify how congestion costs and curtailment impacts will be allocated