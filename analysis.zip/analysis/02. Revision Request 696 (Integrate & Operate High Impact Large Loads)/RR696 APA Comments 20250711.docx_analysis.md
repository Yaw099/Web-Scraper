# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document contains comments from the Advanced Power Alliance (APA) submitted on July 11, 2025, regarding Revision Request 696 (RR696) concerning the integration and operation of High Impact Large Loads (HILL). While APA acknowledges the urgency of establishing policies for large load interconnections within SPP's region, they express significant concerns about the expedited process and potential unintended consequences. The organization supports Path 1 of the HILLGA proposal, is willing to explore Path 2, but finds Path 3 untenable due to discriminatory queue-jumping provisions that could violate FERC Open Access principles. APA emphasizes the need for holistic policy development rather than fragmented solutions and raises critical questions about grid reliability, stakeholder process integrity, and interaction with existing SPP policies.

## 2. Key Topics

- **High Impact Large Load (HILL) Integration Framework**: Proposed assessment framework to accelerate load interconnections while maintaining grid reliability
- **CHILL Service**: Conditional High Impact Large Load service with 5-year term provisions
- **HILLGA Paths 1, 2, and 3**: Three different pathways for generation interconnection with varying degrees of support from APA
- **Queue Management and Preferential Access**: Concerns about Path 3 allowing generation to bypass existing DISIS projects
- **Discriminatory Practices**: Path 3 giving Load Serving Entities power to block competitor generation
- **Grid Reliability Concerns**: Potential risks from fragmented policies and possible capacity double-counting
- **Interaction with Existing Policies**: Integration with Surplus+, ERAS, ITP process, and Consolidated Planning Process
- **Resource Neutrality**: Ensuring all resource types can participate, including Demand Response
- **Stakeholder Process**: Inadequate time for comprehensive review of complex proposals

## 3. Decisions or Actions

**Requested Actions:**
- Revise RR696 to modify Paths 2 and 3 to provide interim service for HILLGA generation until Consolidated Planning Process implementation
- Require HILLs to pay full GRID-Contribution (GRID-C) once CPP is in effect
- Create permanent option for flexible resources to obtain long-term conditional service
- Ensure Tariff language reflects resource neutrality for HILLGA
- Remove or modify language restricting participation of certain resource types
- Set HILLGA capacity limitations in terms of accredited capacity
- Clarify what happens after 5-year CHILLS term expires
- Provide clarity on simultaneous study processes (AQ, AX, and CHILLS)
- Integrate proposals holistically before implementation

**APA Position:**
- Supports HILLGA Path 1
- Willing to explore Path 2 with additional time
- Opposes Path 3 as untenable

## 4. Important Dates

- **July 11, 2025**: Comment submission date
- **5-year term**: Duration mentioned for CHILLS service (endpoint unclear)

## 5. Organizations and People Mentioned

**Organizations:**
- Advanced Power Alliance (APA) - submitting organization
- Southwest Power Pool (SPP) - regional transmission organization
- FERC (Federal Energy Regulatory Commission)
- Antora - mentioned as submitting related comments
- Load Serving Entities (LSEs)
- Transmission Customers

**People:**
- **Maya Nevels** - Submitter from Advanced Power Alliance
  - Email: Maya.Nevels@PowerAlliance.org
  - Phone: 512-651-0291

**Other Stakeholders:**
- Interconnection customers
- Generators in queue
- GI customers
- Developers

## 6. Links or References

**Regulatory References:**
- RR696 (Revision Request 696)
- NERC standards
- FERC Open Access principles
- SPP governing documents
- SPP Open Access Transmission Tariff
- Market Protocols

**Related SPP Processes/Policies:**
- DISIS (Definitive Interconnection System Impact Study)
- ERAS proposal (currently under FERC review)
- Surplus+ policy
- ITP (Integrated Transmission Planning) process
- CPP (Consolidated Planning Process)
- GRID-Contribution (GRID-C)
- AQ, AX studies

## 7. Suggested Tags

- RR696
- High Impact Large Load
- HILL
- CHILL
- HILLGA
- Large Load Integration
- Queue Reform
- Interconnection Process
- Grid Reliability
- SPP Policy
- Transmission Planning
- FERC Compliance
- Open Access
- Preferential Treatment
- Generation Interconnection
- Resource Neutrality
- Stakeholder Process
- Advanced Power Alliance

## 8. Items That May Need Follow-Up

**Critical Policy Clarifications Needed:**
1. **Post-CHILLS Service**: What happens when 5-year CHILLS term expires? Can customers reapply? Can they remain curtailed indefinitely? Transition to CPP?
2. **Simultaneous Study Processing**: How do AQ, AX, and CHILLS studies interact when applied for simultaneously?
3. **PRM Impact**: How will CHILLS and HILLGA participants affect Local Resource Entity Planning Reserve Margin requirements?
4. **ITP Interaction**: Clarify interaction between HILLGA/CHILLS and Integrated Transmission Planning process
5. **Capacity Accounting**: Address potential double-counting concerns with Surplus+ and ERAS

**Discriminatory Practice Concerns:**
6. **Path 3 Queue Jumping**: Address concerns about generation bypassing existing DISIS queue projects
7. **LSE Blocking Power**: Review provision allowing Transmission Customers to approve/block generation studies
8. **FERC Compliance**: Ensure compliance with Open Access principles to avoid ERAS-like disputes

**Technical Requirements:**
9. **Resource Neutrality**: Ensure all resource types can participate equally
10. **Demand Response Accreditation**: Accurate accreditation methodology needed
11. **Capacity Limits**: Define HILLGA capacity additions in terms of accredited capacity

**Process Issues:**
12. **Stakeholder Engagement**: Provide adequate time for comprehensive stakeholder review
13. **Holistic Policy Integration**: Map how RR696 fits within entire SPP policy ecosystem
14. **Grid Stability Analysis**: Complete comprehensive reliability assessment before implementation

**Documentation:**
15. **Tariff Language**: Revise to ensure resource neutrality is clearly reflected
16. **Working Group Meetings**: Continue stakeholder discussions with extended timelines
17. **Additional APA Comments**: APA indicated comments are not comprehensive due to short timeline