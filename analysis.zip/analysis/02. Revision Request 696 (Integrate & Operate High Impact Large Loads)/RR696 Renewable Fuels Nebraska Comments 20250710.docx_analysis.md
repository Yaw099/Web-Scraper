# Regulatory Content Analysis Report

## 1. Executive Summary

Renewable Fuels Nebraska submitted comments on July 10, 2025, regarding RR696, which addresses the integration and operation of High Impact Large Loads (HILL) and Conditional High Impact Large Load (CHILL) service. While expressing strong support for SPP's development of a conditional/non-firm transmission interconnection pathway for large loads, the organization raises concerns that the current proposal creates unreasonable costs and barriers for flexible loads. They propose two key modifications: (1) extending conditional service beyond the current five-year limit, and (2) implementing usage-based cost recovery instead of maximum potential usage charges.

## 2. Key Topics

- **High Impact Large Load (HILL) integration framework** - New assessment process for large load interconnections
- **Conditional High Impact Large Load (CHILL) Service** - Non-firm transmission service option
- **Five-year conditional service limitation** - Proposed restriction on conditional service timeframe
- **Cost recovery methodology** - Current requirement to pay based on maximum potential usage versus actual use
- **Flexible load operations** - Loads that can help balance the transmission grid
- **Economic development impacts** - Effect on Nebraska's biofuels, ethanol industry, and rural communities
- **Grid reliability and NERC standards compliance**
- **Transmission cost certainty** - Predictability for large load developers

## 3. Decisions or Actions

**No final decisions documented** - this is a comment submission on a proposed Revision Request.

**Requested Actions:**
1. Extend conditional service options beyond five years to support long-term investment
2. Revise cost recovery model to align with actual usage rather than maximum potential usage
3. Consider impacts on flexible loads and their grid-balancing benefits

## 4. Important Dates

- **July 10, 2025** - Date of comment submission by Renewable Fuels Nebraska

*Note: No other specific deadlines or implementation dates are mentioned in the document.*

## 5. Organizations and People Mentioned

**Organizations:**
- **Renewable Fuels Nebraska** (Submitter organization)
- **SPP (Southwest Power Pool)** - Grid operator developing the policy
- **Antora Energy** - Member of Renewable Fuels Nebraska with projects in Nebraska
- **NERC** - Referenced regarding standards compliance

**People:**
- **Dawn Caldwell** - Submitter
  - Company: Renewable Fuels Nebraska
  - Email: dawnc@renewablefuelsne.org
  - Phone: 402-325-0045

## 6. Links or References

**Referenced Documents:**
- RR696 Revision Request Form (source document)
- SPP Open Access Transmission Tariff (subject to revision)
- Market Protocols (subject to revision)
- Antora Energy comments (referenced as attached/on file)
- NERC standards (referenced for reliability requirements)

**No URLs or hyperlinks provided in the document.**

## 7. Suggested Tags

- RR696
- HILL (High Impact Large Load)
- CHILL (Conditional High Impact Large Load)
- SPP
- Renewable Fuels Nebraska
- Transmission Interconnection
- Load Integration
- Grid Reliability
- Cost Recovery
- Conditional Service
- Flexible Loads
- Biofuels
- Ethanol Industry
- Nebraska Energy
- Tariff Revision
- Market Protocols
- Economic Development

## 8. Items That May Need Follow-Up

1. **Five-year conditional service limit** - Requires clarification on rationale and consideration of extension request
2. **Cost recovery methodology revision** - Need to evaluate feasibility of usage-based versus maximum capacity-based billing
3. **Antora Energy comments** - Review referenced attachment for additional context and coordination
4. **Economic impact analysis** - Assessment of how proposed changes affect biofuels/ethanol industry investments in Nebraska
5. **Flexible load benefits quantification** - Analysis of grid-balancing benefits and cost reduction claims for all customers
6. **Long-term investment certainty** - Evaluation of how current five-year limit impacts project financing and development
7. **Tariff and protocol language** - Specific redlined revisions were requested but not provided in the submitter document sections
8. **Stakeholder coordination** - Engagement with other Nebraska energy stakeholders potentially affected by these policies
9. **NERC compliance verification** - Ensure any modifications maintain reliability standards compliance
10. **Implementation timeline** - Once revisions are considered, establish clear timeline for policy adoption and effective dates