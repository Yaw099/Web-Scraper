# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This is a letter dated July 28, 2025, from the Thermal Battery Alliance (TBA) to the Southwest Power Pool (SPP) Board of Directors regarding the Conditional High Impact Large Load Service (CHILLS) Process under regulatory revision RR696. The TBA advocates for amendments to the CHILLS framework to accommodate thermal battery storage projects that represent gigawatts of potential load and billions in economic benefits. The organization requests modifications to make CHILLS a permanent option for low load factor, flexible loads and to allow more granular reservation periods (hourly, monthly, or yearly) rather than only yearly designations.

## 2. Key Topics

- **Conditional High Impact Large Load Service (CHILLS) Process** - Non-firm transmission service framework
- **Thermal Battery Technology** - Energy storage solution that charges with off-peak power and stores energy as heat for industrial operations or electricity generation
- **Non-Firm Transmission Service** - Access to transmission without requiring designated network resources
- **Load Factor Requirements** - Proposed 40% or less threshold for CHILLS eligibility
- **Cost Allocation Principles** - Fair distribution of transmission costs based on actual usage/reservation
- **Reservation Periods** - Request to modify from yearly-only to hourly, monthly, or yearly options
- **Interconnection Requirements** - Seeking waiver of designated resource preconditions

## 3. Decisions or Actions

### Requested Board Actions:
1. **Primary Request**: Ask staff to include two specific amendments before final approval of CHILLS:
   - Establish CHILLS as permanent option based on criteria including 40% or less load factor, demonstrated curtailment performance, or curtailment during congestion
   - Modify reservation periods from yearly-only to hourly, monthly, or one-year options with billing based on reserved capacity

2. **Alternative Process**: If amendments need stakeholder input, ask staff to:
   - Propose amendments for discussion at upcoming special MOPC meeting
   - Board consideration at next Board meeting or special Board meeting following MOPC

3. **Fallback Request** (if CHILLS approved without amendments):
   - Direct staff to immediately initiate stakeholder outreach and develop new RR for thermal storage interconnection
   - Ask staff to work with thermal storage companies on project waivers for shovel-ready projects

## 4. Important Dates

- **July 28, 2025** - Date of letter submission
- **Upcoming special Markets and Operations Policy Committee (MOPC) meeting** - Mentioned as potential venue for amendment discussion (specific date not provided)
- **Next Board meeting** - Referenced for potential consideration (specific date not provided)

## 5. Organizations and People Mentioned

### Organizations:
- **Thermal Battery Alliance (TBA)** - Coalition advocating for thermal battery deployment
- **Southwest Power Pool (SPP)** - Regional transmission organization
- **SPP Board of Directors** - Decision-making body
- **Markets and Operations Policy Committee (MOPC)** - SPP stakeholder committee
- **Antora Energy** - Referenced for comments letter supporting amendments

### People:
- **Katherine Hamilton** - Executive Director, Thermal Battery Alliance (letter author)

## 6. Links or References

- **RR696** - Regulatory revision number for the CHILLS process
- **Antora Energy's comments letter** - Referenced document containing detailed amendment proposals
- **Existing SPP non-firm transmission framework** - Referenced as precedent for hourly reservation periods
- **Point-to-point reservation requirements** - Existing cost allocation framework referenced

## 7. Suggested Tags

- Thermal Battery Storage
- CHILLS Process
- Non-Firm Transmission Service
- RR696
- Load Factor
- Interconnection
- Cost Allocation
- Southwest Power Pool
- SPP Board
- Industrial Manufacturing
- Energy Storage
- Grid Reliability
- Curtailment
- Reservation Periods
- MOPC
- Thermal Battery Alliance

## 8. Items That May Need Follow-Up

1. **Board Decision on Amendments** - Whether SPP Board approves the two requested amendments to CHILLS before final approval
2. **MOPC Meeting Scheduling** - Confirmation of special MOPC meeting date and whether amendments will be on agenda
3. **Antora Energy Comments Letter** - Obtain and review full detailed comments referenced in this letter
4. **Waiver Process** - If amendments not approved, track development of waiver process for shovel-ready thermal storage projects
5. **New RR Development** - If fallback option pursued, monitor initiation of new regulatory revision for thermal storage
6. **Stakeholder Outreach** - Track any staff-initiated outreach to thermal storage companies
7. **Economic Impact Assessment** - "Tens of billions of dollars in economic benefits" claim may require verification/documentation
8. **Technical Capability Verification** - Claim that thermal batteries can address "99% of emissions and 80% of U.S. industrial heat demand" may need substantiation
9. **Current Project Pipeline** - Follow up on "gigawatts of potential load" in TBA project pipeline within SPP territory
10. **Implementation Timeline** - If approved, track timeline for CHILLS implementation with or without amendments