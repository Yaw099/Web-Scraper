# REGULATORY MEETING/CONTENT ANALYSIS REPORT

**Source File:** RR696 Antora Energy Comments 20250709.docx.txt

---

## 1. EXECUTIVE SUMMARY

Antora Energy submitted comments on Revision Request RR689 regarding the integration and operation of High Impact Large Loads (HILL) in SPP's system. While supporting SPP's initiative to create a faster interconnection process through Tariff Attachments BA & BB, Antora argues that the current draft disproportionately burdens highly flexible, low load-factor loads that consume off-peak energy. Antora proposes three key tariff modifications to make the Conditional High Impact Large Load Service (CHILLS) permanent with specific performance requirements, implement hourly non-firm point-to-point pricing, and clarify resource adequacy treatment. Antora offers to use its thermal energy storage projects as pilot programs to demonstrate the value of flexible, rapidly dispatchable loads.

---

## 2. KEY TOPICS

- **High Impact Large Load (HILL) Integration Framework**: New assessment framework to accelerate large load interconnections while maintaining grid reliability
- **Conditional High Impact Large Load Service (CHILLS)**: Proposed permanent service option for flexible, low load-factor customers
- **Cost Allocation and Pricing Structure**: Debate over appropriate pricing methodology for flexible loads with low capacity factors
- **Thermal Energy Storage Technology**: Antora's thermal batteries that charge ~33% of the time for continuous heat discharge
- **Grid Flexibility Services**: Demand response capabilities beyond emergency curtailment
- **Load Factor Requirements**: Proposed thresholds of 40-80% for CHILLS eligibility
- **Transmission Pricing**: Hourly non-firm point-to-point rates versus monthly demand charges
- **Resource Adequacy Obligations**: Treatment of CHILLS loads under capacity requirements
- **Pilot Program Proposal**: Testing system impacts and benefits of responsive, dispatchable loads

---

## 3. DECISIONS OR ACTIONS

**Actions Proposed by Antora:**

1. **Make CHILLS Permanent**: Convert CHILLS from temporary to enduring optional service with:
   - Load factor requirement of less than 80% (possibly 40%, 50%, or 60%)
   - Acceptance of curtailment/dispatchability obligations
   - Eligibility beyond 5 years contingent on continuous performance compliance

2. **Implement Hourly Pricing**: Apply hourly non-firm point-to-point pricing based on scheduled usage:
   - Bill only for hours and capacity scheduled (up to Reserved Capacity)
   - Use Schedule 11 hourly, non-firm, point-to-point zonal rates
   - Leverage existing hourly transmission reservation process

3. **Clarify Resource Adequacy**: Explicitly state that CHILLS loads do not create additional Resource Adequacy obligations for Load Serving Entities

4. **Establish Pilot Program**: Use Antora's initial SPP projects to quantify true system impacts and benefits

**Proposed Tariff Changes:**
- Detailed Schedule 15 language provided with modifications to billing methodology
- Cap on total monthly demand charges
- Redispatch cost calculations per Attachment K
- Real power loss responsibility per Attachment M

---

## 4. IMPORTANT DATES

- **July 9, 2025**: Date of comment submission
- **5-year eligibility milestone**: Referenced as threshold for continued CHILLS service eligibility

---

## 5. ORGANIZATIONS AND PEOPLE MENTIONED

**Organizations:**
- **Antora Energy** (Submitter)
- **Southwest Power Pool (SPP)** (Transmission Provider)
- **Federal Energy Regulatory Commission (FERC)**
- **North American Electric Reliability Corporation (NERC)**

**SPP Member Zones Listed (19 zones):**
1. American Electric Power – West
2. Kansas City Board of Public Utilities
3. City Utilities of Springfield, Missouri
4. Empire District Electric Company
5. Grand River Dam Authority
6. Evergy Metro, Inc.
7. Oklahoma Gas & Electric Company
8. Midwest Energy, Inc.
9. Evergy Missouri West, Inc.
10. Southwestern Power Administration
11. Southwestern Public Service
12. Sunflower Electric Power Corporation
13. Western Farmers Electric Cooperative
14. Evergy Kansas Central, Inc.
15. Reserved for Future Use
16. Lincoln Electric System
17. Nebraska Public Power District
18. Omaha Public Power District
19. Upper Missouri Zone

**Individual Contact:**
- **Mark Brueggemann** (Antora Energy)
  - Email: mark.brueggemann@antora.com
  - Phone: 859-512-6672

---

## 6. LINKS OR REFERENCES

**Regulatory References:**
- **FERC Order 2022**: Referenced regarding demand response value
- **NERC standards**: Mentioned for reliability compliance
- **SPP Tariff Attachments BA & BB**: New large load interconnection process
- **SPP Tariff Attachment K**: Redispatch cost formula and protocols
- **SPP Tariff Attachment M**: Real power losses determination
- **SPP Tariff Section 44.4**: Penalties for exceeding curtailment limits
- **SPP Tariff Section 45.7**: Real power losses
- **Schedule 10**: Wholesale Distribution Service charges
- **Schedule 11**: Point-to-point transmission rates (zonal and region-wide)
- **Schedule 15**: CHILLS service rates (proposed revision)
- **SPP OASIS**: Rate posting and discount notification system

---

## 7. SUGGESTED TAGS

- High Impact Large Load (HILL)
- Conditional High Impact Large Load Service (CHILLS)
- Thermal Energy Storage
- Demand Response
- Load Factor
- Transmission Pricing
- Tariff Revision
- Resource Adequacy
- Grid Flexibility
- Point-to-Point Transmission
- SPP Interconnection
- Data Center Loads
- Off-Peak Energy
- Curtailable Load
- Pilot Program
- Cost Causation
- RR689
- RR696

---

## 8. ITEMS THAT MAY NEED FOLLOW-UP

**Technical Clarifications Needed:**
1. **Load Factor Threshold**: Specific determination needed on whether 40%, 50%, 60%, or 80% is appropriate for CHILLS eligibility
2. **Performance Metrics Definition**: Detailed specifications for continuous performance requirements beyond 5 years
3. **Curtailment Obligations**: "To-be-developed" curtailment/dispatchability obligations mentioned but not defined

**Pricing and Cost Issues:**
4. **Revenue Impact Analysis**: Assessment of transmission revenue impacts from hourly pricing versus monthly demand charges
5. **Cost-Causation Methodology**: Validation that proposed hourly pricing appropriately reflects actual cost causation
6. **Discount Framework**: Details on how discount provisions would apply under hourly pricing model

**Resource Adequacy Concerns:**
7. **LSE Obligation Clarification**: Formal ruling needed on whether CHILLS loads create Resource Adequacy obligations
8. **Planning Reserve Margin Treatment**: Quantification of claimed reduction in planning reserve margin requirements

**Operational Details:**
9. **Pilot Program Structure**: Framework, metrics, duration, and evaluation criteria for proposed pilot projects
10. **Frequency Support Services**: Development of compensation mechanisms for millisecond-response ramping capability
11. **FERC Order 2022 Compliance**: Integration of additional demand response participation opportunities

**Stakeholder Engagement:**
12. **Stakeholder Response**: Need to track SPP and other stakeholder reactions to Antora's proposals
13. **LSE Impact**: Assessment from Load Serving Entities on resource adequacy clarification request
14. **High Load-Factor Customer Impact**: Evaluation of fairness concerns from traditional customers

**Regulatory Process:**
15. **FERC Filing Requirements**: Determination of whether proposed changes require separate FERC approval
16. **Comment Period Deadline**: Confirmation of deadline for this RR689 comment process
17. **Implementation Timeline**: Schedule for tariff revisions if proposals are accepted

**Documentation:**
18. **Quantified Benefits**: Request mentions several quantifiable benefits but doesn't provide actual numbers (congestion cost avoidance, curtailment reduction, study efficiency improvements, emergency procedure savings)
19. **Thermal Battery Technical Specifications**: More detailed operational parameters may be needed for interconnection studies