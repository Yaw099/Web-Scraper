# Final Combined Report

# COMPREHENSIVE ANALYSIS REPORT: RR696 SPP Comments 20250711

## EXECUTIVE SUMMARY

This comprehensive report consolidates analysis of all 24 chunks from SPP's (Southwest Power Pool) Revision Request 696 (RR696) comments dated July 11, 2025. The document proposes significant changes to SPP's Open Access Transmission Tariff to implement a High Impact Large Load (HILL) integration assessment framework and create a new Conditional High Impact Large Load (CHILL) Service. The revision encompasses extensive modifications to transmission service rates, revenue requirements, market operations, planning processes, and interconnection procedures across SPP's 19-zone footprint covering multiple states.

**Key Components:**
- New HILL/CHILL framework for accelerating large load interconnections
- Comprehensive transmission rate schedules for all SPP zones
- Detailed market operation protocols (Day-Ahead and Real-Time)
- Transmission planning and reliability assessment procedures
- Generator interconnection and resource commitment processes
- Revenue allocation and cost recovery methodologies

---

## KEY TOPICS (Consolidated)

### 1. HILL/CHILL Framework (Primary Focus)
- **High Impact Large Load (HILL) Integration Framework**: New assessment processes for accelerating large load interconnections while maintaining reliability
- **Conditional High Impact Large Load (CHILL) Service**: New conditional transmission service category
- **Energy Storage Resource Load Assessment**: Integration pending MOPC approval (July 2025)
- **Capacity Accreditation Changes**: Shift from nameplate to projected capacity accreditation MW values for maximum injection limits

### 2. Transmission Service and Rates
- **Point-to-Point Transmission Service**: Firm and Non-Firm rates across all 19 zones
- **Network Integration Transmission Service (NITS)**: Rate structures and revenue requirements
- **Time-of-Use Pricing**: On-Peak (HE 0700-2200 Central Time) and Off-Peak distinctions
- **Delivery Periods**: Yearly, monthly, weekly, daily, and hourly service options
- **Through and Out Transactions**: Special rate treatment for pass-through service
- **Schedule 1, 7, 8, 9, 11, 12**: Multiple tariff schedules governing various service types

### 3. Revenue Requirements and Cost Allocation
- **Annual Transmission Revenue Requirements (ATRR)**: Zonal and region-wide calculations
- **Formula Rates**: 50+ referenced formula rate addendums in Attachment H
- **Balanced Portfolio Reallocation**: Adjustments per Attachment J, Section IV.A
- **Revenue Crediting**: Schedule 7 and 8 revenue adjustments via Attachment AU
- **Base Plan vs. Balanced Portfolio**: Different cost allocation methodologies
- **Interregional Projects**: Cost sharing with adjacent planning regions
- **JTIQ (Joint Transmission Interconnection Queue)**: Upgrade cost recovery mechanisms

### 4. Market Operations
- **Day-Ahead Market**: SCUC/SCED algorithm execution and clearing processes
- **Real-Time Balancing Market (RTBM)**: Intra-day operations
- **Must-Offer Requirements**: 90% capacity threshold for compliance
- **Resource Commitment**: Market, Self, and Reliability commitment statuses
- **Operating Reserves**: Co-optimization with energy markets
- **Reliability Unit Commitment (RUC)**: Day-Ahead and Intra-Day processes
- **Manual Commitments**: Protocols for transmission security and local reliability issues

### 5. Transmission Planning
- **SPP Transmission Expansion Plan (STEP)**: Annual comprehensive project listing
- **ITP Upgrades**: Integrated Transmission Planning projects
- **20-Year Assessment**: Long-term planning horizon
- **Sponsored Upgrades**: Voluntary transmission enhancements
- **Competitive Upgrades**: Market-driven projects per Attachment Y
- **Generator Retirement**: Procedures per Attachment AB
- **Stakeholder Process**: Working groups, Regional State Committee review, Board approval

### 6. Interconnection and Service Provisions
- **Generator Interconnection**: Procedures per Attachment V
- **Network Upgrades**: Service, Sponsored, JTIQ, and Zonal Reliability categories
- **Delivery Point Management**: Attachment AQ and AX processes
- **Local Delivery Facilities**: Modification and retirement procedures
- **Non-Conforming Load**: Registration requirements for loads ≥50 MW
- **ICCP Connectivity**: Dual-node requirements for TOPs and GOPs

### 7. Resource Adequacy and Demand Response
- **Load Responsible Entity (LRE) Obligations**: Winter/Summer season requirements
- **Demand Response Programs**: Treatment in resource adequacy calculations
- **Behind-The-Meter Generation**: Rules for resources <10 MW
- **Load Forecasting**: 50-50 probability, non-coincident peak requirements

### 8. Specialized Provisions
- **Zone-Specific Rates**: Unique provisions for Zones 1, 10, 19
- **Western-UGP Federal Service**: Special exemptions per Section 39.3(e)
- **SATOA (Southwestern Area Transmission Owners Agreement)**: Dispatch revenue treatment
- **ERCOT Interface**: 45.27% discount for cross-system transactions (Lamar Tie Line)
- **Multi-Owner Zones**: Revenue distribution among multiple transmission owners

---

## DECISIONS AND ACTIONS (Consolidated)

### Tariff Modifications Approved/Proposed:
1. **Amendment of Attachment BB**: Include Energy Storage Resource Load Assessment language
2. **Maximum Injection Limit Calculations**: Change from nameplate to capacity accreditation values
3. **CHILL Definition and Provisions**: New service category implementation
4. **Definition Updates**: Conditional HILL, Delivering Party, Load Shedding, Points of Delivery/Receipt, Transmission Customer, Transmission System

### Board/Committee Actions Required:
5. **SPP Board of Directors Approval**: ITP Upgrades, Balanced Portfolios, High Priority Upgrades, 20-Year Assessment Upgrades, Generator Retirement Upgrades, JTIQ Upgrades
6. **MOPC Recommendations**: Required for all upgrade categories
7. **MOPC Approval (July 2025)**: Energy Storage Resource Load Assessment language

### Operational Requirements:
8. **Rate Posting Deadlines**: Multiple annual deadlines (September 1, October 1, October 15, December 15, June 15, July 20)
9. **RRR File Updates**: Quarterly and annual postings of Revenue Requirements and Rates File
10. **Market Monitor Verification**: Non-discriminatory resource selection for manual commitments
11. **Must-Offer Compliance**: Market Participants must maintain ≥90% net resource capacity
12. **ICCP Node Configuration**: TOPs/GOPs must establish dual nodes with 240-second reconnection capability

### Study and Planning Processes:
13. **Aggregate Transmission Service Studies**: For multiple requests in proximity
14. **Delivery Point Network Study (DPNS)**: For NITS delivery point changes
15. **Provisional Load Process Study (PLPS)**: For new delivery points with planned generation
16. **Non-Jurisdictional Facility Studies**: SPP coordination studies for generators outside jurisdiction

### Cost Recovery Mechanisms:
17. **Canceled Project Recovery**: AEP and Sunflower Electric specific provisions over 12-month periods
18. **Upgrade Sponsor Compensation**: Creditable upgrades per Attachment Z2
19. **Regional vs. Local Cost Allocation**: Different treatment per Sections 8.6.7(A) and 8.6.44
20. **FERC Assessment Charge**: Annual true-up via Schedule 12

---

## IMPORTANT DATES (Consolidated)

### Critical Historical Dates:
- **June 19, 2010**: Dividing line for Base Plan Upgrade cost allocation methodology
- **October 1, 2015**: Cutoff for different Region-wide ATRR treatment; Zone 19 designated load grandfathering
- **April 1, 2018**: AEP canceled project cost recovery commencement ($3,264,402.55)
- **March 1, 2019**: AEP additional canceled project recovery commencement ($414,465)
- **January 1, 2024**: Sunflower Electric canceled project recovery commencement ($718,359)

### Annual Recurring Deadlines:
- **March 1**: FERC Assessment Charge Rate calculation/posting
- **June 15**: Tri-State formula

---

# Partial Chunk Reports

# Chunk 1 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document presents SPP's (Southwest Power Pool) comments on Revision Request 696 (RR696), which proposes to implement a High Impact Large Load (HILL) integration assessment framework and create a new Conditional High Impact Large Load (CHILL) Service. The framework aims to accelerate load interconnections while maintaining grid reliability and operational efficiency. The revision includes amendments to SPP's Open Access Transmission Tariff, with specific modifications to Attachment BB language, definitions, and various service provisions. Key changes include language for Energy Storage Resource Load Assessment, updates to maximum injection limits based on projected capacity accreditation MW values rather than nameplate values, and introduction of CHILL-related definitions and processes.

## 2. Key Topics

- **High Impact Large Load (HILL) Integration Framework**: Development of assessment processes for accelerating large load interconnections
- **Conditional High Impact Large Load (CHILL) Service**: New service allowing HILLs to interconnect with conditional transmission service
- **Tariff Modifications**: Updates to Part 1 Common Service Provisions, definitions, and schedules
- **Energy Storage Resource Load Assessment**: Integration of ESR language pending MOPC approval (July 2025)
- **Capacity Accreditation**: Shift from generator nameplate values to projected capacity accreditation MW values for maximum injection limits
- **Transmission Administration Services**: Schedule 1-A provisions and cost recovery mechanisms
- **Network Load Service**: Monthly demand charge calculations for various zones
- **Reliability and Market Efficiency**: Enhanced grid stability, system modeling, and NERC standards alignment

## 3. Decisions or Actions

- Amendment of Attachment BB language to include Energy Storage Resource Load Assessment language
- Modification of maximum injection limit calculations (from nameplate to capacity accreditation values)
- Updates to "shall" usage throughout documents
- Introduction of CHILL definition and related transmission service provisions
- Updates to definitions for:
  - Conditional High Impact Large Load (CHILL)
  - Delivering Party
  - Load Shedding
  - Point(s) of Delivery
  - Point(s) of Receipt
  - Transmission Customer
  - Transmission System
- Revisions to Schedule 1-A Transmission Administration Services provisions
- Changes to Monthly Demand Charge provisions (Sections 34.1, 34.2, 34.3)

## 4. Important Dates

- **July 11, 2025**: Date of comment submission
- **July 2025**: MOPC (Markets and Operations Policy Committee) meeting for Energy Storage Resource Load Assessment language approval
- **Prior calendar year references**: Multiple sections reference "previous calendar year" for revenue calculations and billing determinants

## 5. Organizations and People Mentioned

### Organizations:
- **SPP** (Southwest Power Pool) - Transmission Provider
- **NERC** (North American Electric Reliability Corporation)
- **FERC/Commission** (Federal Energy Regulatory Commission)
- **MOPC** (Markets and Operations Policy Committee)
- **American Electric Power** - Transmission Owner in Zone 1
- **Southwestern Public Service** - Transmission Owner in Zone 11
- **Transmission Owners** (various, not specifically named)

### People:
- **Caroline Chapman** - Submitter, SPP (cchapman@spp.org)

## 6. Links or References

### Internal Document References:
- Attachment BB
- Attachment H (Zonal ATRR, Addendum 1, Addendum 5, Table 1, Table 3)
- Attachment J (Section IV.A)
- Attachment L
- Attachment AU (Section IV, Section V)
- Part I, II, III, IV of the Tariff
- Schedule 1-A (Addendum 1)
- Schedule 7
- Schedule 8
- RRR File

### Standards Referenced:
- NERC standards (general reference)
- SPP governing documents
- Open Access Transmission Tariff provisions

## 7. Suggested Tags

- RR696
- High Impact Large Load (HILL)
- Conditional High Impact Large Load (CHILL)
- Tariff Revision
- Load Interconnection
- Energy Storage Resources
- Transmission Service
- Capacity Accreditation
- Grid Reliability
- Market Efficiency
- SPP
- NERC Compliance
- Network Integration
- Transmission Planning
- MOPC
- Attachment BB

## 8. Items That May Need Follow-Up

1. **MOPC Approval Status**: Confirmation of Energy Storage Resource Load Assessment language approval at July 2025 MOPC meeting
2. **Complete Document Review**: This is chunk 1 of 24 - remaining 23 chunks need analysis for complete picture
3. **Stakeholder Comments**: Need to review other stakeholder comments beyond SPP's submission
4. **Implementation Timeline**: No specific implementation dates provided - need clarification on when changes become effective
5. **CHILL Service Details**: Full definition and operational procedures appear to be referenced but not fully detailed in this chunk
6. **Capacity Accreditation Methodology**: Need clarification on how "projected capacity accreditation MW value" will be calculated
7. **Highlighted Changes**: Document references changes "highlighted in yellow throughout" - need to verify all changes are properly tracked
8. **Cost Impact Analysis**: Quantitative benefits mentioned but specific calculations/estimates not provided
9. **NERC Standards Alignment**: Specific NERC standards that apply should be identified
10. **Incomplete Sentences**: Several sections end abruptly (e.g., "Transmission System not located wit") - need complete text
11. **Zone-Specific Provisions**: Need to verify all zones are properly addressed in revisions
12. **Service Agreement Templates**: May need updates to reflect CHILL service provisions
13. **Regulatory Compliance**: FERC filing requirements and timeline unclear

---

# Chunk 2 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document is chunk 2 of 24 from SPP (Southwest Power Pool) Comments dated July 11, 2025 (filename: RR696 SPP Comments 20250711.docx.txt). The content consists of detailed tariff schedules outlining transmission service rates, charges, and billing methodologies. Specifically, it covers Schedule 1 (transmission charges for point-to-point and network services), Schedule 2 (reactive supply and voltage control service compensation), and the beginning of Schedule 11 (Base Plan Zonal and Region-wide Charges). The text provides comprehensive rate calculation formulas, on-peak/off-peak definitions, revenue requirement adjustments, and compensation mechanisms for qualifying generators.

## 2. Key Topics

- **Transmission Service Pricing Structure**: Point-to-Point and Network Integration Transmission Service rates
- **On-Peak/Off-Peak Definitions**: Saturdays, Sundays, and NERC holidays are Off-Peak; On-Peak hours are HE 0700-2200 Central Prevailing Time
- **Through and Out Transactions**: Special rate treatment for transactions passing through the SPP system
- **Multi-owner Zone Rate Calculations**: Methodology for zones with multiple transmission owners
- **Reactive Power Compensation**: $2.26/MVArh rate for Qualified Generators (QGs)
- **Revenue Requirement Adjustments**: Annual updates and Point-to-Point revenue credits
- **Base Plan Zonal Charges**: Cost recovery mechanisms for transmission upgrades
- **Western-UGP Exemptions**: Special treatment for Western-UGP regarding Region-wide Charges

## 3. Decisions or Actions

- Transmission Provider shall calculate Schedule 1 rates by summing rates from the Zonal Sch 1 tab of the RRR file for multi-owner zones
- Transmission Provider shall not adjust Schedule 1 RR for Transmission Owners with formula rates that automatically update annually
- Transmission Provider shall reduce Schedule 1 RR by the difference between previous calendar year revenues and already-credited amounts for stated rate owners
- Transmission Provider may periodically review the Reactive Compensation Rate (RCR) to ensure it remains at the upper end of reasonable cost ranges
- SPP shall bill customers for monthly Schedule 2 charges in the next billing cycle after sufficient data is available
- SPP shall post applicable monthly Schedule 2 charges promptly after data becomes available

## 4. Important Dates

- **Previous calendar year**: Referenced for Schedule 1 Point-to-Point revenue adjustments and average of 12 monthly peaks
- **Monthly billing cycles**: For Schedule 2 reactive power charges
- **Annual updates**: For formula rate calculations and revenue requirement adjustments
- **Periodic reviews**: RCR review timing not specified but noted as subject to Transmission Provider discretion

Note: No specific future dates are mentioned in this chunk.

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)**: The Transmission Provider
- **Transmission Owners**: Multiple entities with approved/accepted revenue requirements
- **Network Customers**: Entities taking Network Integration Transmission Service
- **Transmission Customers**: Entities taking Point-to-Point Transmission Service
- **Qualifying Generators (QGs)**: Generators eligible for reactive power compensation
- **Western-UGP**: Exempt from certain Region-wide Charges
- **NERC**: Referenced for holiday definitions
- **Commission (FERC)**: Approves revenue requirements and rate changes

### People:
No specific individuals are mentioned in this content.

## 6. Links or References

- **Revenue Requirements and Rates File (RRR File)**: Posted on SPP website, contains Schedule 1 tab and Zonal Sch 1 tab
- **Table 1 ("Schedule 1 RR")**: Lists revenue requirements
- **Table 2 of Schedule 1**: Contains Point-to-Point revenues already credited amounts
- **Section 31.4**: Regarding Network Load designation
- **Part V of this Tariff**: Base Plan assessment provisions
- **Attachment J of this Tariff**: Cost allocation methodology
- **Section III of this Schedule 11**: Point-to-point revenue charges
- **Section IV of Attachment AU**: Revenue distribution provisions
- **Section V of Attachment AU**: Point-To-Point Transmission Service Schedule 11 revenue allocation
- **Section 39.3(e) of this Tariff**: Western-UGP exemption provisions

## 7. Suggested Tags

- Transmission Rates
- Point-to-Point Service
- Network Integration Service
- Reactive Power Compensation
- Revenue Requirements
- Tariff Schedules
- SPP
- Rate Calculations
- Zonal Charges
- Through and Out Transactions
- Formula Rates
- FERC Regulation
- Transmission Pricing
- On-Peak/Off-Peak
- Qualifying Generators
- Base Plan
- Cost Recovery

## 8. Items That May Need Follow-Up

1. **RCR Periodic Review**: The $2.26/MVArh Reactive Compensation Rate is subject to periodic review - unclear when last reviewed or when next review is scheduled
   
2. **Revenue Requirement True-up**: Schedule 2 states "no true-ups" for monthly calculations, but Schedule 1 references annual updates - potential reconciliation processes unclear

3. **Missing Revenue Distribution Details**: Section D.1 of Schedule 11 (Base Plan) appears incomplete - text cuts off mid-sentence regarding revenue reductions

4. **Western-UGP Exemption Details**: Reference to Section 39.3(e) for Western-UGP exemption - need to verify full exemption criteria and implications

5. **Multi-owner Zone Coordination**: Process for updating rates when new Transmission Owners join multi-owner zones not specified

6. **QG Certification Process**: References certification requirements for Qualifying Generators but process details not included in this chunk

7. **Point-to-Point Revenue Credit Tracking**: Mechanism for tracking and posting amounts already credited in Table 2 - need verification of update frequency

8. **Formula Rate vs. Stated Rate Distinctions**: Different treatment for different rate types - may need clarification on which Transmission Owners use which methodology

9. **Incomplete Document**: This is chunk 2 of 24 - need review of remaining chunks for complete context and any related decisions or modifications

---

# Chunk 3 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary

This document is chunk 3 of 24 from SPP (Southwest Power Pool) comments (RR696) dated July 11, 2025. The content consists of detailed tariff language covering transmission service revenue requirements, charges, and billing procedures. It specifically addresses:

- Revenue adjustments for Transmission Owners related to point-to-point transmission service under Schedule 11
- Base Plan Zonal Charges and Region-wide Charges for both network and point-to-point transmission service
- FERC Assessment Charge methodology (Schedule 12)
- Annual Transmission Revenue Requirements structure (Attachment H)

The content is highly technical regulatory tariff language defining cost allocation methodologies and billing procedures for transmission service across SPP's multi-zone system.

## 2. Key Topics

- **Revenue Adjustments and Credits**: Mechanisms for adjusting Transmission Owner revenue requirements based on point-to-point service revenues, including SATOA (Southwestern Area Transmission Owners Agreement) dispatch revenues
- **Zonal Charge Methodology**: Calculation of Base Plan Zonal Charges based on Load Ratio Share and zonal revenue requirements
- **Region-wide Cost Allocation**: Distribution of region-wide transmission costs across network customers and transmission owners
- **Zone-Specific Provisions**: Special treatment for Zones 10 and 19, including Western Interconnection load exemptions and Federal Power considerations
- **FERC Assessment Recovery**: Annual true-up mechanism for recovering FERC regulatory assessment charges
- **Revenue Requirement Structure**: Differentiation between Base Plan upgrades issued NTC (Notification to Construct) before and after June 19, 2010

## 3. Decisions or Actions

No specific decisions or actions are documented in this chunk. The content consists of existing tariff language/provisions rather than meeting minutes or decision records. However, the document references:

- Annual posting requirements for FERC Assessment Charge Rate calculations (by March 1 each year)
- Annual revenue requirement filings via the RRR File (Revenue Requirements and Rates File)
- Monthly billing procedures for transmission customers

## 4. Important Dates

- **June 19, 2010**: Critical date distinguishing treatment of Base Plan Upgrades (different cost recovery methodology applies for NTC issued before vs. after this date)
- **October 1, 2015**: Dividing date for Region-wide ATRR treatment of Network Upgrades (Table 2-A vs. Table 2-B)
- **March 1 (annual)**: Deadline for Transmission Provider to calculate and post FERC Assessment Charge Rate
- **Calendar year basis**: Various revenue adjustments and true-ups occur on calendar year basis

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)**: The Transmission Provider
- **FERC (Federal Energy Regulatory Commission)**: Regulatory authority assessing annual charges
- **Transmission Owners**: Various entities owning transmission facilities within SPP
- **Network Customers**: Entities receiving network integration transmission service
- **Western-UGP**: Western Area Power Administration - Upper Great Plains (referenced for Federal Service Exemption)
- **SATOA**: Southwestern Area Transmission Owners Agreement members

### People:
None specifically mentioned

## 6. Links or References

### Internal Tariff References:
- **Schedule 9**: Network Integration Transmission Service
- **Schedule 11**: Base Plan transmission service charges
- **Schedule 12**: FERC Assessment Charge
- **Section 31.3**: Provisions for designated Network Load not physically interconnected
- **Section 34.5**: Transmission System load determination
- **Section 34.9**: Federal-Power Southwestern identification
- **Section 39.2**: Bundled Retail and Grandfathered Loads provisions
- **Section 7**: Billing procedures
- **Attachment AU**: Revenue distribution and allocation mechanism
- **Attachment H**: Annual Transmission Revenue Requirements
- **Attachment J** (Section IV.A): Reallocation provisions
- **Attachment Z2**: Upgrade Sponsor payment provisions

### External References:
- **FERC Form 582**: Report of transmission megawatt-hours
- **FERC Part 382**: Regulations governing FERC assessments
- **RRR File (Revenue Requirements and Rates File)**: Posted on SPP website with detailed ATRR values

## 7. Suggested Tags

- Transmission Revenue Requirements
- Cost Allocation Methodology
- SPP Tariff
- Schedule 11
- Schedule 12
- FERC Assessment
- Zonal Charges
- Region-wide Charges
- Point-to-Point Transmission Service
- Network Integration Transmission Service
- Base Plan Upgrades
- Formula Rates
- Load Ratio Share
- Western Interconnection
- Federal Power Exemptions
- SATOA

## 8. Items That May Need Follow-Up

1. **RRR File Verification**: Confirm that actual ATRR values in Table 1 (Note A reference) are accessible and current on SPP website

2. **Formula Rate Updates**: Verify which Transmission Owners use formula rates with annual updates vs. stated rates, as this affects revenue adjustment methodology (Section II.A.1 vs. II.A.2)

3. **SATOA Revenue Treatment**: Clarify current treatment of dispatch revenues from SATOA members whose ATRR is recovered through Schedule 11 charges

4. **Zone 10 and Zone 19 Special Provisions**: Monitor any changes to Western-UGP Federal Service Exemption or Western Interconnection load treatment

5. **June 19, 2010 NTC Date**: Confirm accurate tracking of which Base Plan Upgrades fall before vs. after this critical date for proper cost recovery allocation

6. **March 1 FACR Posting Compliance**: Track annual compliance with FERC Assessment Charge Rate calculation and posting deadline

7. **Attachment H Tables**: Section I ends mid-sentence referencing "Balanced Portfolio Region-wide ATRR" - need complete Table 2-A and Table 2-B from continuation

8. **Section III Content**: The document shows "III. Base Plan Zonal Charge and Region-wide Charge for Point-To-Point Transmission Service" with ellipsis, indicating missing content that should be reviewed

9. **True-up Mechanism**: Monitor actual FERC assessment costs vs. estimates to ensure proper functioning of Schedule 12 true-up formula

10. **Reallocation Tracking**: Verify amounts reallocated under Attachment J Section IV.A are properly reflected in zonal charge calculations

---

# Chunk 4 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary

This document is chunk 4 of SPP's (Southwest Power Pool) comments dated July 11, 2025, regarding regulatory requirements document RR696. The content focuses on the technical details of transmission revenue requirements (ATRR), including calculation methodologies, allocation procedures, and specific provisions for various transmission owners. Key topics include Region-wide ATRR calculations, formula rate procedures, cost recovery mechanisms for Base Plan and Interregional Projects, and specific revenue requirement treatments for Southwestern Public Service Company and American Electric Power. The document establishes protocols for updating revenue requirements and handling canceled transmission projects.

## 2. Key Topics

- **Region-wide Annual Transmission Revenue Requirements (ATRR)** calculation methodologies across multiple categories
- **Base Plan and Balanced Portfolio ATRR** components and allocation
- **Interregional Project cost recovery** mechanisms
- **JTIQ (Joint Transmission Integration Queue) Upgrades** cost treatment
- **Formula rate processes** and update procedures for Transmission Owners
- **Zonal ATRR allocation** across Zones 1-19
- **Revenue crediting mechanisms** including Schedule 7, 8, and 11 revenues
- **Transmission Owner-specific requirements** (SPS and American Electric Power)
- **Canceled project cost recovery** provisions
- **FERC filing requirements** and approval processes

## 3. Decisions or Actions

- Transmission Provider shall allocate accepted/approved revenue requirements for Base Plan Upgrades in accordance with Attachment J
- Transmission Provider authorized to update Transmission Owner revenue requirements upon successful completion of formula rate update procedures without FERC filing
- Revenue requirements must be posted on SPP website in RRR File
- For non-formula rate Transmission Owners, specific revenue crediting procedures established
- American Electric Power ATRR includes recovery of canceled project costs with defined recovery periods
- Joint informational filings required between SPP and AEP upon full cost recovery of canceled projects

## 4. Important Dates

- **October 1, 2015**: Effective date threshold for different Base Plan Region-wide ATRR treatment
- **October 1 (annual)**: Deadline for SPS formula calculation posting on SPP website
- **October 31 (annual)**: Deadline for American Electric Power ATRR posting on SPP website
- **January 1 (following year)**: Effective date for updated ATRRs
- **April 1, 2018**: Commencement date for AEP recovery of $3,264,402.55 for canceled projects
- **March 1, 2019**: Commencement date for AEP recovery of $414,465 for additional canceled projects

## 5. Organizations and People Mentioned

### Organizations:
- **Southwest Power Pool, Inc. (SPP)** - Transmission Provider
- **Federal Energy Regulatory Commission (FERC/Commission)**
- **Southwestern Public Service Company (SPS)** - Transmission Owner (Zone 11)
- **Xcel Energy Operating Companies**
- **American Electric Power (AEP)** - Transmission Owner
- **Associated Electric Cooperative, Inc.**

### Specific Projects/Facilities Referenced:
- Morgan Transformer Project
- Blackberry Substation Upgrade
- Multi - Shipe Road - East Rogers - Kings River 345 kV project (Network Upgrades 10656, 10659, 10660)
- Line - Georgia Pacific - Keatchie 138 kV Ckt 1 project (Network Upgrade 10616)
- Line – Chapel Hill REC – Welsh Reserve 138 kV Ckt 1 (Network Upgrade 50697)
- Line – Welsh Reserve - Wilkes 138 kV Ckt 1 (Network Upgrade 11423)

## 6. Links or References

### Tariff Attachments Referenced:
- Attachment Z2 (Upgrade Sponsor payment provisions)
- Attachment O (Coordination agreements - Addendum 1)
- Attachment H (Revenue requirements)
- Attachment J (Cost allocation methodology)
- Attachment AU (Revenue distribution and allocation)
- Attachment L (Point-to-Point transmission revenue allocation)
- Attachment O – SPS of Xcel Energy OATT (SPS formula rate)
- Addendum 1 to Attachment H (AEP formula rate)

### Schedules Referenced:
- Schedule 7 and 8 (Network Integration Transmission Service revenues)
- Schedule 9 (Generator interconnection charges)
- Schedule 11 (Point-to-Point Transmission Service)

### External References:
- 18 C.F.R. § 35.19a(a)(2)(iii) (FERC interest rate regulations)
- Cost Sharing and Usage Agreement Between SPP and Associated Electric Cooperative (Morgan Transformer)
- Cost and Usage Agreement Between SPP and Associated Electric Cooperative (Blackberry Substation)

### Website References:
- SPP website (RRR File posting location)
- SPS OASIS website (formula rate posting)

## 7. Suggested Tags

- Annual Transmission Revenue Requirements (ATRR)
- Cost Allocation
- Formula Rates
- Transmission Planning
- Base Plan Upgrades
- Interregional Projects
- JTIQ Upgrades
- Revenue Requirements
- FERC Filing Requirements
- Zonal Rates
- Canceled Projects
- Southwest Power Pool
- Transmission Owners
- Network Integration
- Point-to-Point Service
- Cost Recovery
- Regulatory Compliance

## 8. Items That May Need Follow-Up

1. **Canceled Project Cost Recovery Status**: Monitor completion of 12-month recovery periods for AEP canceled projects (commencing April 1, 2018 and March 1, 2019) - joint informational filings required upon full recovery

2. **Property Disposition Credits**: Track any sales or dispositions of property related to canceled AEP projects that would require credits against the AEP ATRR and joint informational filing

3. **RRR File Updates**: Verify timely annual updates to the RRR File posted on SPP website, particularly:
   - By October 1 for SPS
   - By October 31 for AEP
   - JTIQ ATRR Balance updates

4. **Formula Rate Posting Compliance**: Confirm Transmission Owners are posting populated formula rates for public review and comment as required

5. **Revenue Requirement Changes**: Monitor any new or amended revenue requirements requiring FERC filings with cost support documentation

6. **Coordination Agreement Projects**: Track revenue requirements for Morgan Transformer Project and Blackberry Substation Upgrade per cost sharing agreements

7. **Incomplete Text**: The document appears to cut off mid-sentence regarding the $414,465 AEP recovery - need to review complete text in subsequent chunks

8. **Zone 19 Implementation**: Verify proper application of Region-wide Charges for Zone 19 (based solely on Line 10 of Table 2-B)

9. **SATOA Revenue Crediting**: Monitor proper crediting of revenues received from dispatches into Energy and Operating Reserve Markets from SATOAs

10. **Commission Approval Processes**: Track regulatory acceptance/approval of revenue requirements by applicable regulatory or governing authorities before SPP implementation

---

# Chunk 5 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document section (chunk 5 of 24) from RR696 SPP Comments details specific cost recovery mechanisms and allocation methodologies for multiple transmission owners within the SPP (Southwest Power Pool) system. The content primarily addresses:

- Cost recovery provisions for canceled network upgrade projects for AEP and Sunflower Electric Power Corporation
- Southwestern Power Administration's NITS ATRR calculation methodology
- Recovery mechanisms for various types of network upgrades including Sponsored Upgrades, Service Upgrades, Generation Interconnection Related Network Upgrades, and Zonal Reliability Upgrades
- Revenue distribution procedures associated with Zonal Annual Transmission Revenue Requirements

The text represents amendments or clarifications to SPP's tariff Attachments H, J, and L, which govern transmission cost recovery and revenue allocation.

## 2. Key Topics

1. **Canceled Project Cost Recovery**
   - AEP's recovery of costs for canceled Chapel Hill REC – Welsh Reserve and Welsh Reserve - Wilkes 138 kV projects
   - Sunflower Electric's recovery of costs for canceled Russell 115 kV device project

2. **Cost Recovery Mechanisms**
   - 12-month recovery period in equal monthly installments
   - ATRR (Annual Transmission Revenue Requirement) adjustments
   - RRR File tracking and reporting requirements

3. **Southwestern Power Administration Rate Calculations**
   - NITS ATRR component calculation methodology
   - Ratio-based approach using Power Repayment Study
   - Total capacity of 872,000 kilowatts for Network Integration Transmission Service

4. **Network Upgrade Types and Cost Allocation**
   - Sponsored Upgrades: Voluntary cost-bearing by Project Sponsors
   - Service Upgrades: Allocated per Attachment Z1
   - Generation Interconnection Related Network Upgrades: Allocated per Attachment V
   - Zonal Reliability Upgrades: Different treatment based on timing
   - JTIQ Upgrades: Included in Region-wide Charge

5. **Compensation Mechanisms**
   - Candidate ILTCRs (Incremental Long-Term Congestion Rights)
   - Transmission revenue credits
   - Terms ranging from 10-20 years

6. **Payment Options**
   - Lump sum payment
   - Periodic charges over 20-year period (monthly basis)
   - Western-UGP limited to lump sum only

## 3. Decisions or Actions

**Required Actions:**

1. **Joint Informational Filings Required:**
   - SPP and AEP must file jointly when $4,465 is fully recovered
   - SPP and Sunflower must file jointly when $718,359 is fully recovered
   - Filings required if property is sold or disposed of during recovery period

2. **Credits to ATRR:**
   - Revenues from sale/disposition of property must be credited against ATRR
   - Credits must be reflected in RRR File

3. **Documentation Requirements:**
   - Southwestern Power Administration must provide supporting documentation when NITS ATRR calculations are revised
   - Documentation to be posted on SPP website
   - Electronic notice to Formula Rate Posting Information Notification List

4. **Agreement Execution Requirements:**
   - Project Sponsors must execute Agreement for Sponsored Upgrade
   - Transmission Customers receiving ILTCRs must execute Attachment AH if not already a Market Participant
   - Candidate ILTCR MW and source-to-sink paths must be included in agreements

5. **True-Up Process:**
   - Transmission Provider must true up Directly Assigned Upgrade Costs to actual construction costs upon completion

## 4. Important Dates

1. **January 1, 2024** - Commencement date for Sunflower Electric Power Corporation ATRR inclusion of $718,359 for canceled Device – Russell 115 kV project

2. **12-month recovery period** - Standard recovery timeline for canceled project costs (both AEP and Sunflower)

3. **20-year period** - Standard term for periodic charges for Sponsored Upgrades (unless different term established in agreement)

4. **10-20 years** - ILTCR term range (must be specified in agreements)

5. **January 1, 2008** - Cutoff date for Zonal Reliability Upgrades included in 2005 SPP Transmission Expansion Plan placed in service

6. **April 2017** - Reference date for Exploder List titled "Formula Rate Posting Information Notification"

## 5. Organizations and People Mentioned

**Organizations:**

1. **SPP (Southwest Power Pool)** - Transmission Provider
2. **AEP (American Electric Power)** - Transmission Owner with canceled projects
3. **Sunflower Electric Power Corporation** - Transmission Owner with canceled project
4. **Southwestern Power Administration** - Federal power marketing administration
5. **FERC (Federal Energy Regulatory Commission)** - Regulatory authority
6. **Western-UGP** - Entity with specific payment limitations

**Roles/Entities (not specific names):**
- Transmission Owner
- Transmission Customer
- Project Sponsor
- Interconnection Customer
- JTIQ Generation Interconnection Customer
- Market Participant

## 6. Links or References

**Web References:**
1. http://www.spp.org/stakeholder-center/exploder-lists/ - Link to Formula Rate Posting Information Notification exploder list (as of April 2017)
2. SPP website - For posting supporting documentation

**Document/Tariff References:**
1. Addendum 20 of Attachment H
2. Section VIII of Attachment J
3. Attachment J - Recovery of Costs Associated with New Facilities
4. Schedule 11
5. Attachment Z1 - Cost allocation for Service Upgrades
6. Attachment Z2 - ILTCRs and transmission revenue credits
7. Attachment AH - Market Participant requirements
8. Attachment V - Cost allocation for generation interconnection Network Upgrades
9. Attachment L - Treatment of Revenues
10. Attachment AV
11. Table 1 of Attachment H
12. Section 2.3.3 of Southwestern Power Administration's Rate Schedule NFTS-13A
13. Schedule 1 of Attachment J
14. Federal Power Act

**Project References:**
1. Network Upgrade 50697 - Line – Chapel Hill REC – Welsh Reserve 138 kV Ckt 1 (canceled)
2. Network Upgrade 11423 - Line – Welsh Reserve - Wilkes 138 kV Ckt 1 (canceled)
3. Network Upgrade 122803 - Device – Russell 115 kV (canceled)
4. 2005 SPP Transmission Expansion Plan

## 7. Suggested Tags

- Cost Recovery
- Canceled Projects
- ATRR (Annual Transmission Revenue Requirement)
- Network Upgrades
- SPP Tariff
- FERC Compliance
- Transmission Rates
- Southwestern Power Administration
- AEP (American Electric Power)
- Sunflower Electric
- Sponsored Upgrades
- ILTCRs (Incremental Long-Term Congestion Rights)
- Revenue Credits
- RRR File
- Generation Interconnection
- Zonal Reliability Upgrades
- JTIQ Upgrades
- Grandfathered Agreements
- Formula Rate
- Attachment H
- Attachment J
- Attachment L
- True-Up Process
- Directly Assigned Upgrade Costs

## 8. Items That May Need Follow-Up

**Immediate Follow-Up Required:**

1. **Recovery Tracking:**
   - Monitor AEP's recovery of $4,465 for canceled projects over 12-month period
   - Monitor Sunflower Electric's recovery of $718,359 starting January 1, 2024 (may already be completed or in progress depending on current date)
   - Verify RRR File updates are occurring properly

2. **Joint Filing Verification:**
   - Confirm whether AEP and SPP have completed joint informational filing upon full recovery
   - Confirm whether Sunflower and SPP have completed or scheduled joint informational filing

3. **Property Disposition Monitoring:**
   - Track any sales or dispositions of property related to canceled projects
   - Ensure proper credits are applied to ATRR if property is sold

**Documentation and Process Follow-Up:**

4. **

---

# Chunk 6 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary
This document is a portion of Attachment L from SPP's (Southwest Power Pool) tariff regarding revenue distribution mechanisms for transmission services. It details complex methodologies for distributing transmission revenues among transmission owners in both single-owner and multi-owner zones. The content covers Network Integration Transmission Service (NITS), Point-to-Point Transmission Service, and Base Plan charges, including special provisions for grandfathered agreements, creditable upgrades, and interregional projects.

## 2. Key Topics
- **Revenue Distribution Methodologies** for Network Integration Transmission Service in single-owner and multi-owner zones
- **Grandfathered Agreements** treatment and revenue adjustments between transmission owners
- **Owner-Specific Zonal Annual Revenue Requirements (OZRR)** calculations and adjustments
- **Point-to-Point Transmission Service** revenue distribution using 50/50 split (OZRR proportion and MW-mile impacts)
- **Creditable Upgrades** and Upgrade Sponsor compensation (Attachment Z2)
- **Network Load** designated outside the Transmission System (Section 31.4)
- **Base Plan Zonal Charges** and Region-wide Annual Transmission Revenue Requirements
- **Load Ratio Share** calculations for zones
- **Zone-specific provisions** (particularly Zone 1 and Zone 19)
- **Balanced Portfolios** and Interregional Projects revenue treatment

## 3. Decisions or Actions
- Revenue distribution formulas established for single-owner zones under Schedule 9
- Multi-owner zone revenue distribution requires calculation of adjusted OZRRs
- Grandfathered Agreement revenues must be credited/debited from seller/purchaser OZRRs
- Hypothetical NITS payments calculated for transmission owners not taking Network Integration Transmission Service
- Dispute resolution procedures available if transmission owners cannot reach agreement on Grandfathered Agreement treatment
- Point-to-Point revenues split 50/50 between OZRR-proportional and MW-mile impact-proportional distribution
- Special carve-outs for Zone 1 (American Electric Power provisions) and Zone 19 (pre-October 1, 2015 designated loads)
- Transmission owners retain rights to seek separate zone designation

## 4. Important Dates
- **October 1, 2015** - Cutoff date for Network Load designated outside Transmission System in Zone 19 (grandfathered treatment applies to loads designated prior to this date)

## 5. Organizations and People Mentioned
- **Transmission Provider** (SPP)
- **Transmission Owners** (multiple, within various zones)
- **Network Customers**
- **Transmission Customers**
- **American Electric Power** (specifically mentioned regarding Zone 1)
- **Upgrade Sponsors** (entities receiving revenue credits for Creditable Upgrades)
- **FERC** (Federal Energy Regulatory Commission) - dispute resolution authority
- **Native Load Customers**

## 6. Links or References
- **Schedule 9** - Network Integration Transmission Service rates
- **Schedule 7 and 8** - Point-to-Point Transmission Service
- **Schedule 11** - Base Plan charges
- **Attachment H** - Zonal Annual Transmission Revenue Requirements
- **Attachment L** - Current document (revenue distribution)
- **Attachment Z2** - Creditable Upgrades provisions
- **Attachment S** - MW-mile impact procedures
- **Attachment J, Section IV.A** - Reallocation from Zonal ATRRs
- **Attachment AU** - Revenue distribution and allocation
- **Section 31.4 of the Tariff** - Network Load outside Transmission System
- **Section 34.4 of the Tariff** - Load Ratio Share calculations
- **Section 34.1(2) of the Tariff** - OZRR adjustments
- **Section 39** - Transmission service provisions
- **Tariff dispute resolution procedures**

## 7. Suggested Tags
- Revenue Distribution
- Transmission Service
- NITS (Network Integration Transmission Service)
- Point-to-Point Transmission
- OZRR (Owner-Specific Zonal Annual Revenue Requirement)
- Grandfathered Agreements
- Multi-Owner Zones
- Creditable Upgrades
- Load Ratio Share
- Base Plan Upgrades
- SPP Tariff
- Attachment L
- Zone 1
- Zone 19
- MW-mile Impacts
- Interregional Projects
- Balanced Portfolios

## 8. Items That May Need Follow-Up
1. **Grandfathered Agreement Disputes** - Monitoring any disputes requiring FERC determination under Section II.B.2(e)
2. **Zone 1 Multi-Owner Provisions** - Tracking if additional transmission owners establish OZRRs in Zone 1 beyond American Electric Power
3. **Zone 19 Pre-2015 Designated Loads** - Verification of loads designated before October 1, 2015, and their special revenue treatment
4. **Creditable Upgrades Revenue Credits** - Tracking Upgrade Sponsor compensation under Attachment Z2
5. **Separate Zone Designation Requests** - Monitoring transmission owner requests to establish separate zones (Section II.B.2(i))
6. **Network Load Outside Transmission System** - Ensuring proper revenue distribution for Section 31.4 designated loads
7. **OZRR Adjustments** - Annual verification of adjustments per Section 34.1(2)
8. **Hypothetical NITS Payment Calculations** - Verification for transmission owners not taking NITS for Native Load
9. **MW-mile Impact Calculations** - Ensuring Attachment S procedures are properly applied
10. **Interregional Project Revenue Treatment** - Incomplete section (cuts off mid-sentence) requiring full document review

---

# Chunk 7 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document segment contains detailed tariff provisions from SPP (Southwest Power Pool) regarding revenue distribution mechanisms, transmission loss compensation procedures, and transmission planning processes. The content primarily focuses on technical procedures for distributing various types of transmission revenues among transmission owners, handling JTIQ (Joint Transmission Interconnection Queue) upgrade balances, calculating transmission losses, and developing the SPP Transmission Expansion Plan (STEP). This appears to be part of a comprehensive tariff document governing SPP's transmission planning and cost allocation framework.

## 2. Key Topics

- **Revenue Distribution Mechanisms**: Multiple categories including point-to-point revenues, Zonal ATRR reallocations, creditable upgrades, interregional projects, and JTIQ upgrades
- **JTIQ ATRR Balance Methodology**: Complex calculation system for Joint Transmission Interconnection Queue upgrades
- **Loss Compensation Procedures**: Methods for quantifying real power losses for transmission customers across zones
- **Transmission Planning Process**: Comprehensive framework including 11 different sources of transmission facility proposals
- **SPP Transmission Expansion Plan (STEP)**: Annual comprehensive listing of all transmission projects
- **Stakeholder Review Process**: Procedures for development, disclosure, and approval of recommended upgrades

## 3. Decisions or Actions

- **JTIQ ATRR Balance Settlement**: Monthly settlements require one-twelfth of JTIQ ATRR Balance to be charged or credited to Resident Load through Region-wide Charge
- **Revenue Distribution Protocols**: Revenues must be distributed to appropriate parties (Transmission Owners, Upgrade Sponsors, Interregional Planning Regions, other transmission providers)
- **Loss Factor Application**: Network customers responsible for losses based on Zone DLF multiplied by hourly metered Network Load coincident with Zone monthly peak
- **Draft Project List Development**: Transmission Provider must prepare and post draft project lists following completion of planning studies
- **Stakeholder Consultation**: Written comments must be invited and stakeholder working groups and Regional State Committee must review draft project lists

## 4. Important Dates

- **Monthly**: JTIQ ATRR Balance settlements (one-twelfth charged/credited each month)
- **Annual**: SPP Transmission Expansion Plan reporting cycle
- No specific calendar dates are mentioned in this chunk

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)** - The Transmission Provider
- **Transmission Owners** - Entities receiving revenue distributions
- **Network Customers** - Responsible for loss compensation
- **Transmission Customers** - Service recipients under various schedules
- **Interregional Planning Regions** - Recipients of interregional project revenues
- **Upgrade Sponsors** - Entities receiving revenues for Creditable Upgrades
- **Regional State Committee** - Reviews draft project lists
- **Stakeholder Working Groups** - Participate in planning review process
- **Western-UGP** - Specifically mentioned regarding Federal Power delivery

### People:
- No specific individuals are named in this content

## 6. Links or References

### Internal Tariff References:
- **Schedules**: 7, 8, 9, 11
- **Attachments**: J (Section IV.A), L (Sections II.A, II.C, III.A), Z2 (Sections II.D, III.C.2), O (Addendum 1, Addendum(s)), AE, AV (Appendix 2), AQ, AX, V, Y, Z1
- **Appendix 1 to Attachment M** - Contains Zone ILF and DLF factors (Column D)
- **Section 39.3(e)(ii)** - Federal Power-Western-UGP provisions
- **Figure 1** - Illustrates planning processes within SPP

### External References:
- **SPP Website** - Multiple references for posting RRR Files, project lists, study results
- **Integrated Marketplace** - Energy and Operating Reserve Markets
- **Generator Interconnection Agreements** - JTIQ Portfolio

## 7. Suggested Tags

- Transmission Revenue Distribution
- JTIQ ATRR Balance
- Loss Compensation
- Transmission Planning Process
- SPP Transmission Expansion Plan (STEP)
- Cost Allocation
- Tariff Provisions
- Network Integration Transmission Service
- Point-to-Point Transmission Service
- Interregional Projects
- Stakeholder Process
- Regional Transmission Organization (RTO)
- Zonal ATRR
- Creditable Upgrades
- Balanced Portfolio
- Generator Interconnection

## 8. Items That May Need Follow-Up

1. **JTIQ Formula Rate Template Verification**: Review Appendix 2 of Attachment AV to understand complete JTIQ ATRR Balance calculation methodology

2. **Loss Factor Updates**: Verify current Zone ILF and DLF values in Appendix 1 to Attachment M (Column D referenced)

3. **Stakeholder Meeting Schedule**: Confirm timing and access procedures for planning summits, working group meetings, and sub-regional planning meetings

4. **Website Access Protocols**: Verify password protection requirements and confidentiality procedures for study data posted on SPP website

5. **Coordination Agreements**: Review Addendum 1 to Attachment O regarding coordination agreements with other transmission providers

6. **RRR File Posting Schedule**: Confirm frequency and format of RRR File updates showing JTIQ Upgrade-specific components

7. **Generator Retirement Process**: This is mentioned as item #10 in sources of potential upgrades but details are not provided in this chunk

8. **Competitive Upgrades Definition**: Reference made to Attachment Y definition - may need clarification on how these interact with reliability violations on adjacent systems

9. **Federal Power-Western-UGP Arrangements**: Section 39.3(e)(ii) referenced for Statutory Load Obligations - may need detailed review

10. **Draft Project List Comment Period**: Duration and format requirements for written comments submission not specified

11. **Integrated Marketplace Settlement Procedures**: Cross-reference with Attachment AE for complete understanding of loss energy accounting

12. **20-Year Assessment Process**: Multiple references but detailed procedures not included in this chunk

---

# Chunk 8 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document contains excerpts from SPP's (Southwest Power Pool) tariff documentation, specifically focusing on transmission planning and service requirements. The content details the approval processes for the SPP Transmission Expansion Plan (STEP), including governance procedures, stakeholder engagement requirements, and various types of transmission upgrades. It also outlines transmission service timing requirements and service increment definitions. The document emphasizes the critical role of the SPP Board of Directors and Markets and Operations Policy Committee in transmission planning decisions, while ensuring transparency through regular posting and stakeholder notification requirements.

## 2. Key Topics

- **SPP Transmission Expansion Plan (STEP) Approval Process**
  - Multiple upgrade categories requiring Board approval
  - Markets and Operations Policy Committee recommendation requirements
  - Stakeholder consultation and comment mechanisms

- **Transmission Upgrade Categories**
  - ITP Upgrades
  - Balanced Portfolios
  - High Priority Upgrades
  - 20-Year Assessment Upgrades
  - Sponsored Upgrades
  - Generator Retirement Upgrades
  - JTIQ Upgrades
  - Interregional Projects
  - Competitive Upgrades

- **Plan Maintenance and Updates**
  - Quarterly modification postings
  - Out-of-cycle adjustments for reliability and business opportunities
  - Upgrade removal procedures with cost reimbursement provisions

- **Transmission Service Framework**
  - Point-to-Point and Network Integration services
  - Service timing requirements for various reservation types
  - NAESB WEQ-001 Business Practice Standards compliance

- **Adjacent System Impacts**
  - Evaluation of competitive upgrades on neighboring systems
  - Cost responsibility limitations for external violations

## 3. Decisions or Actions

**Required Actions:**
- SPP Board of Directors must approve:
  - ITP Upgrades
  - Balanced Portfolios
  - High Priority Upgrades
  - 20-Year Assessment Upgrades
  - Generator Retirement Upgrades
  - JTIQ Upgrades
  - Modifications to approved upgrade lists

- SPP Board of Directors must endorse:
  - Sponsored Upgrades

- Markets and Operations Policy Committee must:
  - Make recommendations on all upgrade types
  - Review upgrade status reports quarterly

- Transmission Provider must:
  - Post project lists at least 10 days before Board meetings
  - Email stakeholders notice of postings
  - Track upgrade status and ensure timely completion
  - Post quarterly modifications to STEP
  - Report quarterly to MOPC, Regional State Committee, and Board
  - Work with stakeholders on ongoing basis for newly identified issues

**Decision-Making Authority:**
- Deviations from MOPC recommendations require written explanation in STEP
- Upgrade removals require stakeholder consultation and cost reimbursement

## 4. Important Dates

**Recurring Deadlines:**
- **10 days prior to Board meetings**: Project list posting and stakeholder notification required
- **Quarterly**: 
  - STEP modifications posted
  - Status reports to MOPC, Regional State Committee, and Board
  - Upgrade status posted on website
- **Annually**: STEP presented to SPP Board of Directors (minimum once per year)

**Transmission Service Timing (referenced but specific times in excluded portions):**
- Next-Hour Market requests (pre-confirmed)
- Daily Non-Firm requests (09:55-10:05 a.m. CPT window mentioned)
- 5-minute simultaneous submission window for reservation priorities
- 15:00 day prior deadline for non-firm schedules

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)** - Transmission Provider
- **SPP Board of Directors** - Primary approval authority
- **Markets and Operations Policy Committee (MOPC)** - Recommendation body
- **Regional State Committee** - Review and oversight role
- **Transmission Owners** - Individual utilities with specific local plans
- **NERC** - Reliability standards authority
- **NAESB** - Standards organization (WEQ-001 referenced)
- **Commission** - Federal regulatory authority (FERC implied)

**Roles/Positions Referenced:**
- Transmission Provider
- Transmission Customers
- Stakeholders (general)
- Stakeholder working groups

**No individual names mentioned in this excerpt**

## 6. Links or References

**Tariff Attachments Referenced:**
- Attachment O (current document, Sections IV.7, V, VII, VIII)
- Attachment Z1 (transmission service upgrades)
- Attachment V (Generator Interconnection Service)
- Attachment J, Section VIII (cost reimbursement for removed upgrades)
- Attachment AB (Generator Retirement Upgrades)
- Attachment P (Transmission Service Timing Requirements)
- Attachment R-1 (NAESB standards incorporation)
- Attachment T (rate determination)

**External References:**
- SPP Membership Agreement
- SPP Tariff (general)
- SPP OATT Sections 13.2 and 14.2
- NAESB Wholesale Electric Quadrant (WEQ-001) Business Practice Standards
- NERC TLR (Transmission Loading Relief)
- CEII (Critical Energy Infrastructure Information) requirements

**Electronic Resources:**
- SPP website (for plan posting, stakeholder comments, and status updates)
- OASIS (capacity request publication)

## 7. Suggested Tags

- Transmission Planning
- SPP Transmission Expansion Plan (STEP)
- Tariff Compliance
- Governance Process
- Board Approval
- MOPC
- ITP Upgrades
- Balanced Portfolio
- Stakeholder Process
- CEII
- Generator Interconnection
- Competitive Upgrades
- Transmission Service
- NAESB Standards
- Quarterly Reporting
- Regional Planning
- Cost Allocation
- Service Increments
- NERC Compliance
- Interregional Coordination

## 8. Items That May Need Follow-Up

**Process Clarifications Needed:**
1. **Deviation Documentation**: Specific format and content requirements when Board approves projects not recommended by MOPC
2. **CEII Access Procedures**: Complete process for stakeholders to obtain unredacted versions of plans
3. **Lottery System Details**: Specific procedures for simultaneous reservation request prioritization
4. **Affiliated Customer Definition**: Criteria for determining "group of affiliated Transmission Customers" (relevant to DC tie abuse prevention)

**Policy Questions:**
5. **Balanced Portfolio Frequency**: Clarification on decision criteria for years when no Balanced Portfolio is proposed
6. **Adjacent System Cost Disputes**: Process for resolving disagreements about cost responsibility for impacts on neighboring systems
7. **Acceptable Mitigation Plans**: Definition and approval process for alternatives to timely project completion
8. **Out-of-Cycle Modification Thresholds**: Criteria determining when modifications can wait vs. requiring immediate out-of-cycle processing

**Operational Items:**
9. **Quarterly Posting Compliance**: Verification that all quarterly posting requirements are being met consistently
10. **10-Day Notice Compliance**: Tracking mechanism to ensure advance notice requirements are satisfied
11. **Stakeholder Comment Integration**: Process for reviewing and incorporating written comments received via website link
12. **Reimbursement Procedures**: Implementation details for Transmission Owner cost recovery when upgrades are removed

**Documentation Gaps:**
13. **Service Increment Details**: Complete table of transmission service increments appears truncated
14. **Timing Requirements Table**: Full timing requirements referenced but not fully displayed in this excerpt
15. **Electronic Link Maintenance**: Responsibility and update frequency for Transmission Owner specific local plan links

**Coordination Needs:**
16. **Regional State Committee Role**: Specific review and endorsement procedures for quarterly modifications
17. **Interregional Project Approval**: Coordination with Section IV.7 processes
18. **Generator Retirement Coordination**: Integration with Attachment AB procedures

---

# Chunk 9 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary
This document excerpt contains technical tariff language from SPP (Southwest Power Pool) Rate Schedule Attachment T, which details Point-To-Point Transmission Service rates and methodologies for multiple transmission zones. The content focuses on rate structures, calculation methods, and billing procedures for various transmission owners within the SPP footprint, particularly the American Electric Power - West (AEPW) zone, City Utilities of Springfield, and Empire District Electric Company.

## 2. Key Topics
- **Point-to-Point Transmission Service Rates**: Firm and Non-Firm service rate structures
- **Rate Calculation Methodologies**: Including formula rates, revenue crediting, and balanced portfolio reallocation adjustments
- **Time-Based Rate Structures**: Yearly, monthly, weekly, daily, and hourly delivery rates with On-Peak/Off-Peak distinctions
- **ERCOT Interface Provisions**: Special discount provisions for ERCOT-related transactions through AEP pricing zone (45.27% discount)
- **Revenue Requirements and Rates (RRR) File**: Central repository for current effective rates posted on SPP website
- **Multiple Transmission Owner Rate Zones**: AEP-West, City Utilities of Springfield, Empire District Electric Company

## 3. Decisions or Actions
- Transmission rates shall be adjusted to reflect Balanced Portfolio Reallocation adjustments per Section IV.A of Attachment J
- Rates must reflect Schedule 7 and 8 revenue adjustments per Section 34.1(2) of the Tariff
- All current effective rates to be posted in the RRR File on the SPP website
- Implementation of specific discount provision (45.27% reduction) for ERCOT Regional Transmission Service transactions

## 4. Important Dates
- **Holiday Definitions** (for rate calculation purposes):
  - New Year's Day
  - Memorial Day
  - Independence Day
  - Labor Day
  - Thanksgiving Day
  - Christmas Day
- **On-Peak Hours**: HE 0700 to HE 2200, Central Time Zone (excluding Sundays and holidays)
- **Time Convention**: Central Prevailing Time per Attachment X; 24-hour clock convention

## 5. Organizations and People Mentioned

### Organizations:
- **Southwest Power Pool (SPP)** - Transmission Provider
- **American Electric Power (AEP)** and AEP-West
- **Public Service Company of Oklahoma**
- **Southwestern Electric Power Company**
- **East Texas Electric Cooperative, Inc.**
- **Deep East Electric Cooperative, Inc.** (collectively "Texas Electric Cooperatives")
- **Oklahoma Municipal Power Authority (OMPA)**
- **AEP West Transmission Companies (AEP-West Transco)**
- **Coffeyville Municipal Light and Power (CMLP)**
- **Arkansas Electric Cooperative Corporation (AECC)**
- **Transource Oklahoma (TROK)**
- **City Utilities of Springfield, Missouri**
- **The Empire District Electric Company**
- **AEP Texas Central Company (TCC)**
- **AEP Texas North Company (TNC)**
- **ERCOT (Electric Reliability Council of Texas)**
- **NERC (North American Electric Reliability Corporation)**
- **FERC/Commission** (Federal Energy Regulatory Commission - implied)

### People:
None specifically mentioned

## 6. Links or References

### Internal Tariff References:
- Attachment X (time definitions)
- Attachment T (Point-To-Point Rate Sheets)
- Attachment J, Section IV.A (Balanced Portfolio Reallocation)
- Attachment AU (revenue distribution and allocation)
- Attachment H, Addendums 4, 12, 17, 38, and 48 (various formula rates)
- Section 34.1(2) of the Tariff (revenue crediting implementation)
- Schedule 7 and 8 (revenue adjustments)
- Part II and Part IV of various tariffs

### External References:
- **Revenue Requirements and Rates File (RRR File)** - posted on SPP website
- **AEP Operating Companies' Tariff** - on file with FERC
- **NERC holiday definitions**

### Website:
- SPP website (for RRR File access)

## 7. Suggested Tags
- Point-to-Point Transmission Service
- Transmission Rates
- SPP Tariff
- Formula Rates
- AEPW Rate Zone
- ERCOT Interface
- Revenue Requirements
- Non-Firm Transmission
- Firm Transmission
- Balanced Portfolio
- Rate Schedules
- Attachment T
- Peak/Off-Peak Rates

## 8. Items That May Need Follow-Up

1. **Rate Updates**: Verification that current rates in the RRR File on SPP website match tariff provisions
2. **Formula Rate Protocols**: Review of referenced Addendums (4, 12, 17, 38, 48) in Attachment H for consistency
3. **ERCOT Discount Verification**: Confirm 45.27% discount calculation and eligibility criteria for Load Serving Entities
4. **Specific Rate Values**: Several specific rates mentioned (e.g., $2,053.993/MW for Texas Electric Cooperatives, $91.51/MW for OMPA, $47.32/MW for CMLP) - may need verification for currency
5. **Peak/Off-Peak Definitions**: Ensure consistency with NERC standards and any recent changes to holiday definitions
6. **Transmission Owner List**: Confirm complete and current list of transmission owners in each rate zone
7. **Revenue Crediting Methodology**: Clarification on Schedule 7 and 8 revenue calculation and distribution under Attachment AU
8. **Empire District Content**: Document appears truncated at Empire District section - full content review needed

---

# Chunk 10 Analysis

# Regulatory Analysis Report: RR696 SPP Comments

## 1. Executive Summary

This document contains detailed tariff language for Point-To-Point (PTP) Transmission Service rate structures for multiple transmission providers within the SPP (Southwest Power Pool) system. The content specifies compensation methods, rate calculation formulas, and filing requirements for various transmission entities including The Empire District Electric Company, Evergy Kansas Central, Inc., and Evergy Metro, Inc. The document outlines both Firm and Non-Firm transmission service rates with various delivery timeframes (yearly, monthly, weekly, daily, and hourly) and defines how rates are calculated, adjusted, and posted.

## 2. Key Topics

- **Point-To-Point Transmission Service Rate Structures** (Firm and Non-Firm)
- **Rate Calculation Methodologies** using formula rates in Attachment H
- **Zonal Annual Transmission Revenue Requirement (Zonal ATRR)** calculations
- **Revenue Requirements and Rates File (RRR File)** posting requirements
- **Balanced Portfolio Reallocation Adjustments**
- **Revenue Crediting** for Schedule 7 and 8 revenues
- **Reserved Capacity Compensation** across multiple time periods
- **On-Peak and Off-Peak Rate Differentials**
- **Multiple Transmission Zone Rate Structures**

## 3. Decisions or Actions

- **Rate Posting Requirements**: Multiple rate formulas must be posted on SPP website at various deadlines
- **Rate Calculations**: Specific formulas defined for calculating charges across different delivery timeframes
- **Demand Charge Caps**: Weekly and daily demand charges capped at specified rates multiplied by highest Reserved Capacity
- **Revenue Crediting Implementation**: Rates must reflect adjustments per Section 34.1(2) of Tariff
- **Reallocation Adjustments**: Rates adjusted to reflect amounts reallocated from Zonal ATRR per Attachment J, Section IV.A

## 4. Important Dates

- **October 15**: Evergy Kansas Central, Inc. Existing Zonal ATRR posting deadline (annually)
- **September 1**: Prairie Wind Formula Rate Existing Zonal ATRR posting deadline (annually)
- **October 1**: South Central MCN Formula Rate, Kansas Power Pool Formula Rate, and NEET Southwest Formula Rate Existing Zonal ATRR posting deadlines (annually)
- **January 1**: Effective date for all posted rates (following year after posting)
- **Document Date**: July 11, 2025 (20250711 in filename)

## 5. Organizations and People Mentioned

### Organizations:
- **Southwest Power Pool (SPP)** - Regional Transmission Organization
- **The Empire District Electric Company** - Transmission Provider
- **Evergy Kansas Central, Inc.** (formerly Evergy Kansas South, Inc.)
- **Evergy Metro, Inc. (EMe)**
- **Prairie Wind Transmission LLC**
- **South Central MCN LLC**
- **Kansas Power Pool**
- **NextEra Energy Transmission Southwest, LLC (NEET Southwest)**
- **City of Independence, Missouri (INDP)**
- **Commission** (Federal Energy Regulatory Commission implied)

### People:
None specifically mentioned

## 6. Links or References

### Tariff Attachments Referenced:
- **Attachment H**: Formula rates for multiple entities
  - Addendum 3: Evergy Kansas Central, Inc. Formula Rate
  - Addendum 10, Parts 1 and 2: EMe formula rate
  - Addendum 15: Prairie Wind Formula Rate
  - Addendum 16: Kansas Power Pool Formula Rate
  - Addendum 18: Empire District Electric Company formula rate
  - Addendum 43: South Central MCN Formula Rate
  - Addendum 44: NEET Southwest Formula Rate
- **Attachment H, Section I, Table 1**: Zonal ATRR specifications (Lines 14, 14a-e, Column 3)
- **Attachment J, Section IV.A**: Balanced Portfolio Reallocation procedures
- **Attachment T**: Point-To-Point Transmission Service rates
- **Attachment AU**: Revenue distribution and allocation
- **Section 34.1(2)**: Revenue crediting implementation

### External References:
- **RRR File**: Revenue Requirements and Rates File posted on SPP website
- Specific tabs: "Evergy Kansas Central, Inc. PTP Rate Att T," "EMe PTP Rate Att T"

## 7. Suggested Tags

- Point-To-Point Transmission
- Transmission Rates
- SPP Tariff
- Formula Rates
- Evergy
- Empire District Electric
- Zonal ATRR
- Firm Transmission Service
- Non-Firm Transmission Service
- Revenue Requirements
- Rate Design
- Transmission Revenue
- Reserved Capacity
- On-Peak/Off-Peak Rates
- RRR File

## 8. Items That May Need Follow-Up

1. **Rate Formula Accuracy**: Verify all formula rate calculations in referenced Attachment H Addendums are current and accurate
2. **Posting Deadline Compliance**: Confirm all entities meet their respective posting deadlines (September 1, October 1, October 15)
3. **RRR File Accessibility**: Ensure SPP website properly displays all referenced tabs and rate information
4. **Revenue Crediting Implementation**: Verify proper application of Schedule 7 and 8 revenue adjustments per Section 34.1(2)
5. **Reallocation Adjustments**: Confirm Balanced Portfolio Reallocation calculations per Attachment J, Section IV.A are correctly applied
6. **INDP Fixed Rate**: Verify the $2,442.048 rate for City of Independence, Missouri remains current
7. **On-Peak/Off-Peak Definitions**: Confirm definitions are consistently applied across all rate zones
8. **Demand Charge Cap Calculations**: Audit application of weekly and daily caps to ensure proper implementation
9. **Zonal ATRR Calculation Methodology**: Review Table 1 calculations for each zone for consistency
10. **Formula Rate Protocol Compliance**: Verify each entity follows associated protocols for their respective formula rates

---

# Chunk 11 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document chunk (11 of 24) from "RR696 SPP Comments 20250711.docx.txt" contains detailed rate schedules and transmission service tariff information for multiple transmission providers within the SPP (Southwest Power Pool) region. The content specifies Point-To-Point Transmission Service rates for both firm and non-firm service across different delivery timeframes (yearly, monthly, weekly, daily, and hourly) for four transmission zones: Evergy Missouri West, Grand River Dam Authority, Kansas City Board of Public Utilities, and Lincoln Electric System (partial). Each zone's rates incorporate Balanced Portfolio Reallocation Adjustments and Revenue Crediting mechanisms.

## 2. Key Topics

- **Point-To-Point Transmission Service Rate Structures**
  - Firm and Non-Firm service rates
  - Multiple delivery period options (yearly, monthly, weekly, daily, hourly)
  - On-peak and off-peak distinctions

- **Rate Calculation Methodologies**
  - Reserved Capacity-based charging
  - Demand charge caps and limitations
  - Formula rate references (Attachment H addendums)

- **Revenue Requirements and Adjustments**
  - Balanced Portfolio Reallocation Adjustment
  - Schedule 7 and 8 revenue crediting
  - Attachment AU revenue distribution

- **Zonal Rate Administration**
  - Zone-specific rate schedules
  - RRR File (Revenue Requirements and Rates File) references
  - Multiple transmission owners within single zones

## 3. Decisions or Actions

No specific decisions or actions are documented in this chunk. This appears to be a tariff rate schedule document outlining existing rate structures rather than documenting meeting decisions or regulatory actions.

## 4. Important Dates

No specific dates are mentioned in this content chunk beyond the source document date (20250711 - July 11, 2025).

## 5. Organizations and People Mentioned

**Organizations:**
- **Evergy Missouri West, Inc.** - Transmission Owner/Provider
- **Transource Missouri, LLC** - Transmission Owner in EMW zone
- **Grand River Dam Authority (GRDA)** - Transmission Owner/Provider
- **Kansas City Board of Public Utilities (BPU)** - Transmission Owner/Provider
- **Lincoln Electric System** - Transmission Owner/Provider (section incomplete)
- **SPP (Southwest Power Pool)** - Regional Transmission Organization

**People:** None mentioned

## 6. Links or References

**Internal Tariff References:**
- Attachment T (Point-To-Point Transmission Service rates)
- Attachment H, Addendum 11, Parts 1 and 2 (Evergy Missouri West formula rate)
- Attachment H, Addendum 21 (Transource Missouri rate formula)
- Attachment H, Addendum 13 (Grand River Dam Authority formula rate)
- Attachment H, Addendum 46 (Kansas City BPU formula rate)
- Attachment J, Section IV.A (Balanced Portfolio Reallocation)
- Attachment AU (Revenue distribution and allocation)
- Section 34.1(2) of Tariff (Revenue crediting implementation)
- Schedule 7 and 8 (Revenue schedules)

**External References:**
- RRR File posted on SPP website (multiple tabs referenced):
  - "EMW PTP Rate Att T" tab
  - "GRDA PTP Rate Att T" tab
  - "BPU PTP Rate Att T" tab

## 7. Suggested Tags

- Transmission Rates
- Point-To-Point Service
- SPP Tariff
- Firm Transmission
- Non-Firm Transmission
- Reserved Capacity
- Revenue Requirements
- Rate Schedules
- Evergy Missouri West
- Grand River Dam Authority
- Kansas City BPU
- Balanced Portfolio
- Attachment T
- Formula Rates
- Demand Charges

## 8. Items That May Need Follow-Up

1. **Lincoln Electric System Section** - The document cuts off mid-section for Lincoln Electric System rates, requiring review of the complete section.

2. **RRR File Verification** - Confirm that all referenced tabs in the Revenue Requirements and Rates File are current and accessible on the SPP website.

3. **Formula Rate Cross-Reference** - Verify that all referenced Attachment H addendums (11, 13, 21, 46) are properly documented and consistent with these rate structures.

4. **Rate Calculation Consistency** - Review consistency of rate calculation methodologies across different zones (note: GRDA uses kW while others use MW).

5. **Transmission Owner Listing** - Confirm complete list of transmission owners for each zone, as only EMW zone explicitly lists multiple owners (Evergy Missouri West and Transource Missouri).

6. **Balanced Portfolio Reallocation Impact** - Assess how adjustments under Section IV.A of Attachment J affect rates across different zones.

7. **Schedule 7 and 8 Revenue Crediting** - Review implementation of revenue crediting mechanisms referenced in Section 34.1(2).

8. **Cap Calculation Verification** - Ensure demand charge cap calculations (daily not exceeding weekly, hourly not exceeding daily) are properly implemented in billing systems.

---

# Chunk 12 Analysis

# REGULATORY ANALYSIS REPORT
## Source: RR696 SPP Comments 20250711.docx.txt - Chunk 12 of 24

---

## 1. Executive Summary

This document section details Point-To-Point (PTP) Transmission Service rate structures and calculation methodologies for multiple transmission zones within the Southwest Power Pool (SPP) network. The content covers three specific utility zones: Lincoln Electric System (LES), Midwest Energy Inc., and Nebraska Public Power District (NPPD). Each zone has specific rate sheets, formula calculations, and service categories (Firm and Non-Firm) with varying delivery timeframes (yearly, monthly, weekly, daily, and hourly). All rates are subject to Balanced Portfolio Reallocation Adjustments and Revenue Crediting adjustments, with rates published in the Revenue Requirements and Rates File (RRR File) on the SPP website.

---

## 2. Key Topics

- **Point-To-Point Transmission Service Rate Structures** for three utility zones (LES, Midwest Energy, NPPD)
- **Firm vs. Non-Firm Service Categories** with different pricing models
- **Delivery Period Options**: Yearly, monthly, weekly, daily, and hourly service
- **On-Peak and Off-Peak Rate Differentials**
  - On-Peak: Hours ending 0700-2200 Central Time (excluding weekends/holidays)
  - Off-Peak: All other hours
- **Balanced Portfolio Reallocation Adjustments** per Attachment J, Section IV.A
- **Revenue Crediting** for Schedule 7 and 8 revenues and Attachment AU distributions
- **Formula Rate Calculations** referenced in Attachment H (multiple addenda)
- **Reserved Capacity Compensation** measured in MW or kW depending on zone
- **NERC-Defined Holidays**: New Year's Day, Memorial Day, Independence Day, Labor Day, Thanksgiving Day, Christmas Day

---

## 3. Decisions or Actions

**No explicit decisions or actions are identified in this content.** This appears to be regulatory tariff language establishing rate structures rather than meeting minutes or decision documentation.

**Implicit Requirements:**
- Transmission Customers must compensate Transmission Providers monthly for reserved capacity
- Rate calculations must follow specified formula rates in Attachment H addenda
- Demand charge caps apply to prevent weekly charges from exceeding specified maximums
- All rates must be published in the RRR File on SPP website

---

## 4. Important Dates

### Recurring Deadlines:
- **December 15 (annually)**: NPPD formula calculation results must be posted on SPP and NPPD websites
- **January 1 (annually)**: NPPD rates become effective
- **June 15 (annually)**: Tri-State formula calculation results must be posted on SPP and Tri-State websites
- **July 1 (annually)**: Tri-State rates become effective

### On-Peak Hours Definition:
- **HE 0700 - HE 2200** (Central Time Zone), excluding weekends and NERC holidays

---

## 5. Organizations and People Mentioned

### Organizations:
1. **Southwest Power Pool (SPP)** - Regional transmission organization
2. **Lincoln Electric System (LES)** - Transmission zone operator
3. **Midwest Energy, Inc.** - Transmission zone operator
4. **Nebraska Public Power District (NPPD)** - Transmission zone operator
5. **The Central Nebraska Public Power and Irrigation District (CNPPID)** - Included in NPPD zone calculations
6. **Tri-State** - Formula rate contributor to NPPD zone
7. **NERC (North American Electric Reliability Corporation)** - Holiday definition authority

### People:
None mentioned

---

## 6. Links or References

### Internal Tariff References:
- **Attachment T** - Point-To-Point Transmission Service rates
- **Attachment H** - Formula rates
  - Addendum 6 (Lincoln Electric System)
  - Addendum 7 (NPPD)
  - Addendum 14 (Midwest Energy, Inc.)
  - Addendum 36 (Tri-State)
- **Attachment J, Section IV.A** - Balanced Portfolio Reallocation methodology
- **Attachment AU** - Revenue distribution and allocation
- **Section 34.1(2)** - Revenue crediting implementation

### External References:
- **RRR File (Revenue Requirements and Rates File)** - Posted on SPP website
- Specific RRR File tabs:
  - "LES PTP Rate Att T"
  - "Midwest PTP Rate Att T"
  - "NPPD PTP Rate Att T"
- **NPPD website** - Rate posting location
- **Tri-State website** - Rate posting location

### Specific CNPPID Rates Referenced:
- Annual: $128.961 per MW
- Monthly: $10.747 per MW
- Weekly: $2.480 per MW
- Daily On-Peak: $0.496 per MW
- Daily Off-Peak: $0.353 per MW

---

## 7. Suggested Tags

- Point-To-Point Transmission Service
- PTP Rates
- SPP Tariff
- Transmission Pricing
- Lincoln Electric System
- Midwest Energy
- Nebraska Public Power District (NPPD)
- Firm Transmission Service
- Non-Firm Transmission Service
- Reserved Capacity
- Formula Rates
- Attachment H
- Attachment T
- Revenue Requirements
- Balanced Portfolio Reallocation
- On-Peak/Off-Peak Rates
- CNPPID
- Tri-State
- Electric Transmission Tariff
- Zonal Rates

---

## 8. Items That May Need Follow-Up

### Rate Posting Compliance:
1. **Verification of timely rate postings** - Confirm NPPD and Tri-State meet December 15 and June 15 deadlines respectively
2. **RRR File accessibility** - Ensure all referenced tabs are current and accessible on SPP website

### Rate Calculation Accuracy:
3. **Formula rate verification** - Confirm calculations in Attachment H addenda align with published rates in RRR File
4. **CNPPID rate updates** - Verify whether the specific dollar amounts for CNPPID ($128.961/MW annual, etc.) are current or require updating

### Potential Discrepancies:
5. **On-Peak definition inconsistency** - NPPD section excludes Saturdays from On-Peak while LES/Midwest sections only exclude Sundays; confirm if intentional
6. **Units inconsistency** - LES uses "MW," Midwest uses "kW" for Reserved Capacity; verify if this is correct or needs standardization

### Revenue Crediting Implementation:
7. **Schedule 7 and 8 revenue tracking** - Confirm proper application of revenue credits per Section 34.1(2)
8. **Attachment AU allocations** - Verify distributions are correctly reflected in final rates

### Customer Communication:
9. **Rate change notifications** - Ensure transmission customers receive adequate notice of annual rate updates
10. **Website maintenance** - Confirm all referenced websites (SPP, NPPD, Tri-State) maintain accessible rate information

### Regulatory Compliance:
11. **FERC approval status** - Verify all formula rates and methodologies have current FERC approval
12. **Tariff consistency** - Cross-reference with other SPP tariff sections for consistency in terminology and rate treatment

---

# Chunk 13 Analysis

# STRUCTURED ANALYSIS REPORT
## RR696 SPP Comments - Chunk 13 of 24

---

## 1. Executive Summary

This document section contains detailed tariff rate schedules for Point-To-Point Transmission Service for multiple utility organizations within the Southwest Power Pool (SPP). The content specifies pricing structures for both Firm and Non-Firm transmission services across various delivery periods (yearly, monthly, weekly, daily, and hourly). Three main utility rate sheets are covered: an unnamed utility (likely continuation from previous chunk), Oklahoma Gas and Electric Company (OG&E), and Omaha Public Power District (OPPD). Each rate sheet references specific formula rates and calculation methodologies stored in various Attachments and Addendums to the SPP Tariff.

---

## 2. Key Topics

- **Point-To-Point Transmission Service Rate Structures**
  - Firm vs. Non-Firm service pricing
  - Multiple delivery period options (yearly, monthly, weekly, daily, hourly)
  - On-Peak vs. Off-Peak rate differentiation

- **Formula Rate References and Calculations**
  - NPPD Formula Rate (Attachment H, Addendum 7)
  - OG&E Formula Rate (Attachment H, Addendum 2-A and 2-B)
  - OPPD Formula Rate (Attachment H, Addendum 8)
  - Tri-State Formula Rate
  - AECC Formula Rate (Attachment H, Addendum 38)
  - PEC Formula Rate (Attachment H, Addendum 51)
  - NEET Southwest Formula Rate (Attachment H, Addendum 44)

- **Rate Adjustments and Credits**
  - Balanced Portfolio Reallocation Adjustment
  - Schedule 7 and 8 revenue crediting
  - Attachment AU revenue distribution and allocation

- **Specific Rate Components**
  - CNPPID Point-to-Point rates (ranging from $0.015/MW to $10.747/MW depending on service type)
  - Oklahoma Municipal Power Authority additional charges ($0.0002/kW to $0.0752/kW)
  - Zonal Annual Transmission Revenue Requirement (Zonal ATRR)

- **Peak Period Definitions**
  - On-Peak: HE 0700 to HE 2200, Central Time, excluding weekends and NERC holidays
  - NERC-defined holidays: New Year's Day, Memorial Day, Independence Day, Labor Day, Thanksgiving Day, Christmas Day

---

## 3. Decisions or Actions

- **Rate Posting Requirements**
  - OG&E Existing Zonal ATRR to be posted on SPP website by September 1 of each year
  - OPPD Formula Rate results to be posted on SPP website by July 20 of each year

- **Rate File Publications**
  - All Point-To-Point rates to be published in Revenue Requirements and Rates File (RRR File)
  - OG&E rates specifically set forth in "OGE PTP Rate Att T" tab
  - OPPD rates specifically set forth in "OPPD PTP Rate Att T" tab

- **Demand Charge Caps**
  - Weekly caps on daily delivery charges established
  - Daily caps on hourly delivery charges established
  - Prevents overcharging through multiple short-term reservations

---

## 4. Important Dates

- **September 1** - Deadline for posting OG&E Existing Zonal ATRR on SPP website (annual)
- **January 1** - Effective date for OG&E rates posted previous September (annual)
- **July 20** - Deadline for posting OPPD Formula Rate calculation results (annual)
- **August 1** - Effective date for OPPD rates posted in July (annual)

- **Peak Period Hours**: HE 0700 - HE 2200 (Central Time)

- **NERC Holidays Referenced**:
  - New Year's Day
  - Memorial Day
  - Independence Day
  - Labor Day
  - Thanksgiving Day
  - Christmas Day

---

## 5. Organizations and People Mentioned

### Organizations:

1. **NPPD** - Nebraska Public Power District (implied)
2. **CNPPID** - Central Nebraska Public Power and Irrigation District
3. **Tri-State** (generation and transmission entity)
4. **Oklahoma Gas and Electric Company (OG&E)**
5. **Arkansas Electric Cooperative Corporation (AECC)**
6. **People's Electric Cooperative (PEC)**
7. **NextEra Energy Transmission Southwest, LLC (NEET Southwest)**
8. **Oklahoma Municipal Power Authority**
9. **Omaha Public Power District (OPPD)**
10. **Southwest Power Pool (SPP)** - Transmission Provider
11. **NERC** - North American Electric Reliability Corporation

### Roles Referenced:
- Transmission Customer
- Transmission Provider

### People:
- None specifically mentioned

---

## 6. Links or References

### Tariff Attachments and Addendums:
- **Attachment H** - Formula Rate Protocols
  - Addendum 2-A: OG&E Formula Rate
  - Addendum 2-B: OG&E Formula Rate Implementation Protocols
  - Addendum 7: NPPD Formula Rate Template
  - Addendum 8: OPPD Formula-based Rate Template
  - Addendum 38: AECC Formula Rate and Protocols
  - Addendum 44: NEET Southwest Formula Rate and Protocols
  - Addendum 51: PEC Formula Rate and Protocols
  - Section I, Table 1: Existing Zonal ATRRs (Lines 7, 7a, 7c, 7d, 7e, Column 3)

- **Attachment J** - Section IV.A (Balanced Portfolio Reallocation)
- **Attachment AU** - Revenue distribution and allocation
- **Attachment T** - Point-To-Point Transmission Service rates

### Other References:
- **Section 34.1(2)** of the Tariff - Schedule 7 and 8 revenue adjustments
- **Revenue Requirements and Rates File (RRR File)** - Posted on SPP website
  - "OGE PTP Rate Att T" tab
  - "OPPD PTP Rate Att T" tab

### External Resources:
- **SPP website** - Location for rate postings and RRR File

---

## 7. Suggested Tags

- Point-To-Point Transmission Service
- Rate Schedules
- Tariff Provisions
- Formula Rates
- OG&E
- OPPD
- NPPD
- CNPPID
- Firm Transmission Service
- Non-Firm Transmission Service
- On-Peak/Off-Peak Rates
- Zonal ATRR
- Revenue Requirements
- SPP Tariff
- Transmission Pricing
- Balanced Portfolio Reallocation
- Schedule 7 and 8 Credits
- Oklahoma Municipal Power Authority
- AECC
- PEC
- NEET Southwest
- Reserved Capacity
- Demand Charges

---

## 8. Items That May Need Follow-Up

### Clarification Needed:
1. **First Rate Sheet Identification** - The document begins mid-section without clearly identifying which utility's rate sheet is being described in the opening paragraphs (appears to be NPPD/CNPPID/Tri-State combined)

2. **CNPPID Rate Justification** - The specific CNPPID rates ($10.747/MW monthly down to $0.015/MW hourly off-peak) should be verified for accuracy and consistency with formula calculations

3. **Loss Inclusion** - The statement "Capacity designations at the Point(s) of Receipt will be inclusive of losses" appears only for one utility - confirm if this applies to all rate zones

### Compliance Monitoring:
4. **Rate Posting Deadlines** - Track compliance with:
   - OG&E: September 1 posting deadline
   - OPPD: July 20 posting deadline

5. **Website Publication Verification** - Confirm that RRR File tabs are correctly maintained:
   - "OGE PTP Rate Att T" tab
   - "OPPD PTP Rate Att T" tab

### Consistency Checks:
6. **Unit Consistency** - OG&E rates use 

---

# Chunk 14 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document is chunk 14 of SPP (Southwest Power Pool) tariff comments dated July 11, 2025 (RR696). The content consists of detailed rate schedules and formulaic structures for Point-to-Point Transmission Service across multiple transmission providers within the SPP footprint. The document outlines specific rate structures for OPPD (Omaha Public Power District), Southwestern Power Administration, and Southwestern Public Service Company, including both Firm and Non-Firm transmission service rates with various delivery timeframes (yearly, monthly, weekly, daily, and hourly). The rates incorporate multiple formula-based calculations and revenue crediting mechanisms.

## 2. Key Topics

- **Point-to-Point Transmission Service Rate Structures** for multiple SPP transmission providers
- **Firm vs. Non-Firm Transmission Service** pricing differentiation
- **On-Peak and Off-Peak Rate Definitions** with specific NERC holiday exclusions
- **Formula-based Rate Templates** referenced in Attachment H with multiple addendums
- **Revenue Crediting Mechanisms** including Schedule 7 and 8 revenues and Attachment AU allocations
- **Multi-entity Rate Calculations** combining rates from primary providers and subsidiary entities
- **Balanced Portfolio Reallocation Adjustments** for SPS rates
- **Reserved Capacity Calculations** and demand charge limitations
- **Rate Filing and Posting Requirements** via RRR (Revenue Requirements and Rates) Files

## 3. Decisions or Actions

- **Rate Posting Requirement**: Results of formula calculations must be posted on SPP website and SPS OASIS website by **October 1** of each calendar year
- **Rate Effectiveness**: Posted rates become effective on **January 1** of the following calendar year
- **Demand Charge Caps**: Total demand charges for shorter-term reservations cannot exceed longer-term rates (e.g., weekly charges cannot exceed weekly rate × peak kW)
- **Secondary Transmission Service Limitations**: Service limited to the greater of recent peak demand or contracted capacity
- **Revenue Crediting Implementation**: Adjustments for Schedule 7 and 8 revenues must be implemented per Section 34.1(2) of the Tariff

## 4. Important Dates

- **October 1** (annually): Deadline for posting formula calculation results on SPP and SPS OASIS websites
- **January 1** (annually): Effective date for new rates posted previous October
- **NERC Defined Holidays** (for On-Peak/Off-Peak determinations):
  - New Year's Day
  - Memorial Day
  - Independence Day
  - Labor Day
  - Thanksgiving Day
  - Christmas Day
- **Document Date**: July 11, 2025 (RR696 SPP Comments)

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)** - Transmission Provider/Tariff Administrator
- **OPPD (Omaha Public Power District)** - Transmission Provider
- **Southwestern Power Administration** - Federal Transmission Provider
- **South Central MCN LLC** - Rate component entity (Addendum 43)
- **MEUC (Missouri Joint Municipal Electric Utility Commission)** - Rate component entity (Addendum 50)
- **PEC (People's Electric Cooperative)** - Rate component entity (Addendum 51)
- **Southwestern Public Service Company (SPS)** - Transmission Provider
- **Xcel Energy Operating Companies** - Parent/affiliated companies
- **LCEC (Lea County Electric Cooperative, Inc.)** - Rate component entity (Addendum 52)
- **NERC (North American Electric Reliability Corporation)** - Holiday definition authority

**People Mentioned:**
- None specifically identified

## 6. Links or References

**Tariff Attachments and Addendums:**
- Attachment H, Addendum 8 (OPPD Formula Rate)
- Attachment H, Addendum 43 (South Central MCN Formula Rate)
- Attachment H, Addendum 50 (MEUC Formula Rate)
- Attachment H, Addendum 51 (PEC Formula Rate)
- Attachment H, Addendum 5 (SPS Formula Rate)
- Attachment H, Addendum 52 (LCEC Formula Rate)
- Attachment O - SPS (Xcel Energy OATT)
- Attachment J, Section IV.A (Balanced Portfolio Reallocation)
- Attachment AU (Revenue Distribution and Allocation)
- Attachment T (Point-to-Point Transmission Service Rate Sheet)
- Section 34.1(2) of SPP Tariff (Revenue Crediting Implementation)

**Referenced Files/Systems:**
- Revenue Requirements and Rates File (RRR File) - Posted on SPP website
- SPP OASIS website
- SPS OASIS website

## 7. Suggested Tags

- Transmission Rates
- Point-to-Point Service
- SPP Tariff
- Formula Rates
- FERC Regulation
- Revenue Requirements
- Firm Transmission Service
- Non-Firm Transmission Service
- OPPD
- Southwestern Power Administration
- SPS/Xcel Energy
- Rate Design
- On-Peak/Off-Peak Pricing
- OATT (Open Access Transmission Tariff)
- Wholesale Transmission

## 8. Items That May Need Follow-Up

1. **Formula Rate Validation**: Verify that all referenced Attachment H addendums (5, 8, 43, 50, 51, 52) contain current and accurate formulas consistent with these rate sheet descriptions

2. **RRR File Posting Compliance**: Confirm that all transmission providers meet the October 1 posting deadline and that rates properly become effective January 1

3. **Rate Component Reconciliation**: Validate that composite rates (e.g., Southwestern Zone = SPA + South Central MCN + MEUC + PEC) are correctly calculated and summed in posted RRR Files

4. **On-Peak Hour Definition Consistency**: Note potential discrepancy - Hourly delivery defines On-Peak as "HE 0700 through HE 2200" (16 hours used in divisor calculations) but verify this aligns with actual hour-ending conventions

5. **Secondary Service Limitation Enforcement**: Clarify implementation procedures for limiting secondary transmission service based on 11-month rolling peak demand for Southwestern customers

6. **Schedule 7 and 8 Revenue Credits**: Track that revenue crediting adjustments are properly reflected in rates per Section 34.1(2) requirements

7. **Balanced Portfolio Reallocation**: Monitor SPS-specific adjustments under Attachment J, Section IV.A and verify proper reflection in posted rates

8. **Reserved Capacity Measurement**: Clarify procedures for determining "highest amount in kilowatts of Reserved Capacity" for demand charge cap calculations

9. **Document Context**: This is chunk 14 of 24 - review preceding and following chunks for complete context on any cross-referenced provisions or definitions

10. **Effective Date Confirmation**: Document dated July 11, 2025 appears to be future-dated from current perspective - confirm whether this is a comment filing on proposed rates or an error in dating

---

# Chunk 15 Analysis

# Regulatory Document Analysis Report

## 1. Executive Summary

This document contains detailed transmission service rate schedules and pricing structures for multiple utility zones within the SPP (Southwest Power Pool) Open Access Transmission Tariff. The content focuses on Point-to-Point Transmission Service rates for both Firm and Non-Firm services across multiple rate zones, including Southwestern Public Service Company (SPS), Sunflower Electric Power Corporation, and Upper Missouri Zone (UMZ). The document specifies calculation methodologies, time-of-use definitions (On-Peak/Off-Peak), and formula rate references for transmission customers.

## 2. Key Topics

- **Point-to-Point Transmission Service Pricing** - Firm and Non-Firm service rates
- **Rate Zone Structures** - Multiple zones including SPS, SECC, and UMZ
- **Time-of-Use Pricing** - On-Peak (HE 0700-2200) and Off-Peak periods
- **Delivery Period Options** - Yearly, monthly, weekly, daily, and hourly
- **Revenue Crediting and Adjustments** - Schedule 7 and 8 revenues, Attachment AU allocations
- **Balanced Portfolio Reallocation** - Adjustments per Attachment J
- **Formula Rate Applications** - Multiple Attachment H addendums referenced
- **Reserved Capacity Calculations** - Per MW/kW pricing structures
- **Lamar Tie Line Discounting** - 50% discount for cross-system service

## 3. Decisions or Actions

- **Rate Posting Requirement** - All rates to be set forth in Revenue Requirements and Rates File (RRR File) on SPP website
- **Charge Caps Implemented** - Weekly charges capped at weekly rate × highest daily capacity; similar caps for hourly/daily combinations
- **Bidirectional Service Treatment** - Service in opposite direction treated as new, separate service requiring separate charges
- **NERC Holiday Adoption** - Holidays defined as per NERC standards (6 holidays specified)
- **Loss Treatment** - Capacity designations at Point(s) of Receipt are inclusive of losses

## 4. Important Dates

**Time-of-Use Definitions:**
- On-Peak Hours: HE 0700 through HE 2200, Central Time Zone
- Off-Peak: All other hours
- Sundays: Classified as Off-Peak
- **Holidays** (Off-Peak designation):
  - New Year's Day
  - Memorial Day
  - Independence Day
  - Labor Day
  - Thanksgiving Day
  - Christmas Day

**No specific implementation or filing dates mentioned in this excerpt**

## 5. Organizations and People Mentioned

**Transmission Owners/Service Providers:**
- Southwestern Public Service Company (SPS)
- Xcel Energy
- LCEC
- Public Service Company of Colorado (PSCo)
- Sunflower Electric Power Corporation (SECC)
- ITC Great Plains, LLC
- Prairie Wind Transmission, LLC
- Basin Electric Power Cooperative
- Heartland Consumers Power District
- Missouri River Energy Services (MRES)
- East River Electric Power Cooperative, Inc.
- Corn Belt Power Cooperative
- NorthWestern Energy Public Service Corporation (NWPS)
- Northwest Iowa Power Cooperative (NIPCO)
- Harlan Municipal Utilities (HMU)
- Western Area Power Administration, Upper Great Plains Region (Western-UGP)
- Central Electric Power Cooperative, Inc.
- Mountrail-Williams Electric Cooperative
- Mor-Gran-Sou Electric Cooperative, Inc.
- Roughrider Electric Cooperative, Inc.
- L and O Power Cooperative (LOPC)

**MRES Members:**
- Moorhead Public Service
- Orange City Municipal Utilities
- City of Pierre, South Dakota
- City of Sioux Center, Iowa
- Watertown Municipal Utility Department
- Denison Municipal Utilities
- Vermillion Light & Power

**Regulatory Bodies:**
- NERC (North American Electric Reliability Corporation)
- FERC (Commission - Federal Energy Regulatory Commission)
- SPP (Southwest Power Pool)

## 6. Links or References

**Tariff Attachments Referenced:**
- Attachment O – SPS (Xcel Energy OATT)
- Attachment H, Addendum 5 (SPS formula rate)
- Attachment H, Addendum 9 (ITC Great Plains formula rate)
- Attachment H, Addendum 15 (Prairie Wind Transmission formula rate)
- Attachment H, Addendum 20 (Sunflower Electric formula rate)
- Attachment H, Addendums 22-35, 37, 40-42, 45, 47, 49 (UMZ zone formula rates)
- Attachment J, Section IV.A (Balanced Portfolio Reallocation)
- Attachment AU (Revenue allocation)
- Attachment T (Rate sheets)
- Section 34.1(2) of Tariff (Revenue crediting implementation)

**RRR File Tabs:**
- "SECC PTP Rate Att T"
- "UMZ PTP Rate Att T"

**External References:**
- SPP website (for RRR File posting)
- NERC holiday definitions

## 7. Suggested Tags

- Transmission Service Rates
- Point-to-Point Service
- SPP OATT
- Firm Transmission
- Non-Firm Transmission
- Rate Zones
- Formula Rates
- Revenue Requirements
- Time-of-Use Pricing
- Reserved Capacity
- Upper Missouri Zone
- Southwestern Public Service
- Sunflower Electric
- Transmission Tariff
- Energy Pricing
- FERC Regulation
- Balanced Portfolio
- Revenue Crediting

## 8. Items That May Need Follow-Up

1. **RRR File Updates** - Verify current posting and accessibility of Revenue Requirements and Rates File on SPP website for all referenced tabs

2. **Formula Rate Reconciliation** - Track annual true-ups for all Attachment H formula rates (20+ addendums referenced)

3. **Lamar Tie Line Discount Application** - Monitor usage and validate 50% discount calculations for PSCo/SPS cross-system transactions

4. **NERC Holiday Calendar Alignment** - Confirm annual synchronization with NERC holiday definitions for any changes

5. **Load Estimate Updates** - UMZ monthly delivery rate depends on "total load estimate" - ensure current projections are being used

6. **Facility Credit Tracking** - Verify ATRR (Annual Transmission Revenue Requirement) adjustments for facility credits in UMZ rate zone

7. **Schedule 7 and 8 Revenue Credits** - Monitor quarterly/annual revenue crediting calculations and distributions under Section 34.1(2)

8. **Attachment AU Implementation** - Track revenue distribution and allocation methodology changes

9. **Balanced Portfolio Reallocation** - Verify Section IV.A of Attachment J calculations are properly reflected in rates

10. **Multi-Entity Coordination** - UMZ zone involves 15+ transmission owners - ensure coordinated rate filings and updates

11. **Capacity Reservation Caps** - Monitor billing to ensure weekly/daily caps are properly applied as specified

12. **Loss Factor Updates** - Points of Receipt include losses - verify current loss factors being applied

---

# Chunk 16 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document chunk is from SPP (Southwest Power Pool) tariff Attachment T and Attachment AE, detailing Point-to-Point Transmission Service rates and Integrated Marketplace operations. The content covers rate structures for the Western Farmers Electric Cooperative (WFEC) rate zone, point-to-point transmission service compensation mechanisms, and Day-Ahead Market execution procedures including must-offer requirements and resource commitment protocols. This appears to be regulatory filing or tariff language describing operational and financial mechanisms for transmission service and market operations.

## 2. Key Topics

- **Point-to-Point Transmission Service Rates**: Detailed rate structures for the WFEC rate zone including multiple transmission owners
- **Revenue Requirements Calculation**: Monthly, weekly, daily, and hourly delivery rates based on Annual Transmission Revenue Requirements
- **Balanced Portfolio Reallocation**: Adjustment mechanisms for point-to-point rates
- **Revenue Crediting**: Schedule 7 and 8 revenue adjustments under Attachment AU
- **Firm vs. Non-Firm Transmission Service**: Different compensation structures and delivery periods
- **Must-Offer Requirements**: Compliance obligations for Market Participants in Day-Ahead Market
- **Day-Ahead Market Execution**: SCUC (Security-Constrained Unit Commitment) algorithm processes
- **Resource Commitment**: Procedures for committing/decommitting resources based on system needs
- **Local Reliability Issues**: Manual intervention protocols for transmission system security

## 3. Decisions or Actions

- Market Participants must offer all available Resources or maintain net resource capacity ≥90% of load to comply with must-offer requirements
- Non-compliance with must-offer requirements results in penalty assessment per Section 3.9 of Attachment AF
- Market Monitor will monitor Load, Operating Reserve obligations, and offered Resources for compliance
- Transmission Provider may manually commit/decommit Resources when security constraints cannot be addressed within Day-Ahead Market SCUC algorithm
- In capacity shortage situations, the algorithm will: (1) curtail non-firm Export Interchange Transaction Bids, and (2) incorporate emergency capacity limits
- In capacity surplus situations, the algorithm will: (1) curtail non-firm Import Interchange Transaction Offers, and (2) incorporate minimum emergency limits
- Manual commitments must be selected in a non-discriminatory manner, verified by Market Monitor

## 4. Important Dates

No specific future dates are mentioned in this content. The document references:
- Monthly, weekly, daily, and hourly rate periods
- Operating Day (referenced throughout for market operations)
- 730 hours per month (rate calculation standard)
- 52 weeks per year (rate calculation standard)

## 5. Organizations and People Mentioned

**Organizations:**
- **Transmission Owners in UMZ Rate Zone**: Basin Electric, Heartland, MRES, MRES Members, East River, Corn Belt, NWPS, NIPCO, HMU, Western-UGP, Central Power, Mountrail-Williams, Mor-Gran-Sou, Roughrider, LOPC
- **WFEC Rate Zone Entities**: Western Farmers Electric Cooperative (WFEC), People's Electric Cooperative (PEC)
- **SPP (Southwest Power Pool)** - Transmission Provider
- **Market Monitor** - Compliance oversight entity
- **Reliability Coordinator** - (SPP acting in this capacity)

**People:** None specifically mentioned

## 6. Links or References

**Internal Tariff References:**
- Attachment T (Point-To-Point Transmission Service rates)
- Attachment J, Section IV.A (Balanced Portfolio Reallocation)
- Attachment AU (Revenue distribution and allocation)
- Section 34.1(2) of Tariff
- Attachment H, Addendum 39 (WFEC Formula Rate)
- Attachment H, Addendum 51 (PEC Formula Rate)
- Attachment AE (Integrated Marketplace)
- Attachment AF, Section 3.9 (Penalty provisions)
- Sections 4.1(10)(a), 4.1(10)(b), 4.1(10)(c) (Commitment status)
- Section 8.5.9 and 8.5.10 (Compensation and recovery)
- Section 6.1.2.1 (Market Monitor verification process)

**External References:**
- RRR File (Revenue Requirements and Rates File) posted on SPP website
- Commission approved rates (FERC)
- "WFEC PTP Rate Att T" tab

## 7. Suggested Tags

- Point-to-Point Transmission Service
- Transmission Rates
- WFEC Rate Zone
- Day-Ahead Market
- Must-Offer Requirement
- SCUC Algorithm
- Market Compliance
- Revenue Requirements
- Resource Commitment
- Local Reliability
- Integrated Marketplace
- Formula Rates
- Operating Reserves
- Capacity Management
- SPP Tariff

## 8. Items That May Need Follow-Up

1. **Penalty Assessment Process**: Section 3.9 of Attachment AF referenced for must-offer non-compliance penalties - actual penalty amounts/methodology not detailed in this chunk
2. **Market Monitor Verification**: Process described under Section 6.1.2.1 for verifying non-discriminatory manual commitments - full procedure not included
3. **Local Reliability Issue Definition**: Referenced multiple times but complete definition/criteria may be located elsewhere in tariff
4. **RRR File Updates**: Current rates set forth in posted file - frequency of updates and notification process unclear
5. **Manual Commitment Compensation**: Section 8.5.9 and 8.5.10 referenced for cost recovery - detailed calculation methodology not provided
6. **90% Compliance Threshold**: Basis for 90% net resource capacity threshold for must-offer compliance not explained
7. **Non-Conforming Load Definition**: Term appears in Glossary section but definition is cut off
8. **Multi-Day Reliability Assessment**: Referenced in market execution but process details not included in this chunk
9. **MSR (Multi-Configuration Resource) Transitions**: Rules for regulation service eligibility during configuration transitions mentioned but details incomplete
10. **Emergency Capacity Limits**: Multiple references to Maximum/Minimum Emergency Operating Limits - criteria for declaring emergencies not specified

---

# Chunk 17 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary

This document chunk (17 of 24) from RR696 SPP Comments dated July 11, 2025, details operational procedures for Day-Ahead Market processes, Day-Ahead Reliability Unit Commitment (RUC), and Intra-Day Reliability Unit Commitment. The content focuses on how the Transmission Provider handles Local Reliability Issues, manual resource commitments, compensation mechanisms, and the execution of Security-Constrained Unit Commitment (SCUC) and Security-Constrained Economic Dispatch (SCED) algorithms. Key themes include non-discriminatory resource selection, Market Monitor verification processes, and cost recovery methodologies for both regional and local reliability commitments.

## 2. Key Topics

- **Local Reliability Issue Management**: Procedures for manual commitments by Transmission Provider or local transmission operators
- **Day-Ahead Market Clearing Process**: SCUC and SCED algorithm operations for resource commitment and dispatch
- **Resource Compensation**: Uniform compensation methods regardless of commitment source
- **Cost Recovery Mechanisms**: Regional vs. local cost collection under Sections 8.6.7(A) and 8.6.44
- **Operating Guides Development**: Collaboration between Transmission Provider, local operators, and Resource owners
- **Capacity Adequacy Analysis**: System-wide and local reliability assessments
- **Virtual Resource Limits (VRLs)**: Application in SCED when constraints result in infeasible solutions
- **Multi-Configuration Resources (MCRs)**: Operating limitations during configuration transitions
- **Operating Reserve Requirements**: Co-optimization logic and marginal clearing prices
- **Emergency Procedures**: Priority order for addressing capacity shortages and surpluses

## 3. Decisions or Actions

### Defined Actions:
1. **Manual Resource Commitments**: Transmission Provider must select resources in non-discriminatory manner, verified by Market Monitor (Section 6.1.2.1)
2. **SCUC Re-runs**: Transmission Provider will re-run Day-Ahead SCUC after manual commitments, time permitting
3. **Market Participant Notification**: Required when units are manually committed
4. **Operating Guide Development**: Collaborative development between Transmission Provider, local operators, and Resource owners
5. **Priority Order Actions for Capacity Shortages**:
   - Curtail non-firm fixed Export Interchange Transaction Bids
   - Incorporate emergency capacity limits
   - Commit reliability-only resources
   - De-commit charging resources
6. **Priority Order Actions for Capacity Surplus**:
   - Curtail non-firm fixed Import Interchange Transaction Offers
   - Incorporate minimum emergency limits
   - Commit charging-capable reliability resources
   - De-commit market-committed resources
   - De-commit self-committed resources

## 4. Important Dates

- **Operating Day**: Referenced throughout as the timeframe for Day-Ahead Market and RUC processes
- **July 11, 2025**: Source document date (RR696 SPP Comments)

*Note: No specific future deadlines or milestones are mentioned in this chunk.*

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)**: Implied Transmission Provider
- **Transmission Provider**: Primary operating entity
- **Local Transmission Operators**: Request commitments for Local Reliability Issues
- **Market Monitor**: Verification authority for non-discriminatory resource selection
- **Market Participants**: Recipients of manual commitment notifications
- **Resource Owners**: Collaborate on operating guide development
- **Reliability Coordinator**: Authority role referenced for manual commitments

### People:
*No specific individuals named in this content chunk.*

## 6. Links or References

### Internal Document References:
- **Section 3.3.1**: SCED algorithm description
- **Section 4.1(10)(b)**: Market commitment status
- **Section 4.1(10)(c)**: Reliability-only use resources
- **Section 6.1.1**: Intra-Day RUC inputs
- **Section 6.1.2.1**: Market Monitor verification process
- **Section 8.3.2**: VRL application in SCED
- **Section 8.5.9**: Day-Ahead Market resource compensation
- **Section 8.6.5**: Day-Ahead RUC compensation
- **Section 8.6.7(A)**: Regional cost recovery
- **Section 8.6.44**: Local cost recovery

### Referenced Concepts:
- **Attachment AE**: Main tariff attachment containing these provisions
- **SCUC (Security-Constrained Unit Commitment) algorithm**
- **SCED (Security-Constrained Economic Dispatch) algorithm**
- **RTBM (Real-Time Balancing Market) Offers**

## 7. Suggested Tags

- Day-Ahead Market
- Reliability Unit Commitment (RUC)
- Local Reliability Issues
- Resource Commitment
- SCUC Algorithm
- SCED Algorithm
- Market Monitor
- Cost Recovery
- Operating Reserves
- Transmission System Security
- Manual Commitments
- Non-Discriminatory Selection
- Multi-Configuration Resources (MCR)
- Virtual Resource Limits (VRL)
- Capacity Adequacy
- SPP Markets
- Intra-Day Operations
- Emergency Procedures

## 8. Items That May Need Follow-Up

### Clarification Needed:
1. **Market Monitor Verification Process**: Section 6.1.2.1 referenced multiple times but not detailed in this chunk—requires review of that section
2. **VRL Pricing Methodology**: Reference to "appropriately priced VRL" without specification of pricing details
3. **30-Minute Transition Threshold**: Rationale for MCR 30-minute threshold for Operating Reserve eligibility
4. **Operating Guide Content**: Specific requirements or templates for operating guides not detailed

### Process Questions:
5. **"Time Permitting" Standard**: No defined timeframe for when SCUC re-runs are feasible
6. **Local vs. Regional Cost Allocation**: Criteria for determining which reliability issues result in local vs. regional cost recovery
7. **Self-Commitment Priority**: Implications of de-committing self-committed resources in surplus situations

### Potential Compliance Concerns:
8. **Non-Discriminatory Selection Verification**: Process and documentation requirements for Market Monitor verification
9. **Coordination Protocols**: Formal communication requirements between Transmission Provider and local operators
10. **Resource Compensation Uniformity**: Verification that "same manner as any other Resource" is consistently applied

### Implementation Details:
11. **Shadow Price Calculation**: Technical details of how lost opportunity costs are incorporated
12. **Marginal Loss Sensitivity Factors**: Update frequency and accuracy verification
13. **Instantaneous Load Capacity Requirements**: Definition and calculation methodology (upper/lower bounds referenced)

---

# Chunk 18 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary

This document contains technical specifications from SPP (Southwest Power Pool) regarding the Intra-Day Reliability Unit Commitment Process, Non-Conforming Load requirements, and Must-Offer obligations for Market Participants. The content focuses on market operations protocols, including procedures for handling capacity surpluses/shortages, local reliability issues, resource commitments, and load forecasting requirements. Key provisions address coordination between transmission providers and local transmission operators, compensation mechanisms for committed resources, and Market Participant obligations for the Day-Ahead Market.

## 2. Key Topics

- **Capacity Management**: Procedures for addressing system-wide capacity surpluses through curtailment of non-firm imports and resource de-commitment
- **Manual Resource Commitment**: Protocols for manual commitment/decommitment of resources to address transmission system reliability issues
- **Local Reliability Issues**: Specific procedures for handling local reliability issues and Local Emergency Conditions
- **Non-Conforming Load**: Load forecasting requirements for non-conforming loads, including ESRs (Energy Storage Resources) not registered as MSRs (Market Storage Resources)
- **Must-Offer Requirement**: Obligations for Market Participants to offer available resources to Day-Ahead Market, RUC, and RTBM
- **Compensation and Cost Recovery**: Regional vs. local cost allocation for resource commitments

## 3. Decisions or Actions

**Required Actions by Market Participants:**
- Submit hourly load forecasts for Non-Conforming Load before SPP begins Day-Ahead RUC process
- Submit forecasts for Operating Day plus six (6) days following
- Submit rolling 15-minute ahead basis forecasts
- Update forecasts up to thirty minutes before Operating Hour
- Submit actual Non-Conforming Load data or estimates

**Transmission Provider Actions:**
- Must manually commit/decommit resources in non-discriminatory manner
- Must minimize commitment costs while adhering to security constraints
- Must coordinate with local transmission operators
- Must log all manual commitments and decommitments

**Local Transmission Operator Actions:**
- May issue instructions during Local Emergency Conditions when time doesn't permit coordination
- Must notify Transmission Provider of instructions given
- Must log such instructions
- Must coordinate with Transmission Provider for subsequent instructions

## 4. Important Dates

- **30 minutes before Operating Hour**: Final deadline for Non-Conforming Load forecast submissions
- **Operating Day**: Day for which forecasts must be submitted
- **6 days following Operating Day**: Extended forecast period required
- **15-minute intervals**: Rolling forecast submission basis
- **2 hours following current interval**: Encouraged forecast period for deviations

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)**: Transmission Provider and market operator
- **Transmission Provider**: Primary market operator entity
- **Local Transmission Operators**: Regional operators coordinating with Transmission Provider
- **Market Monitor**: Oversight entity verifying non-discriminatory practices
- **Market Participants**: Entities participating in SPP markets
- **Asset Owners**: Entities owning generation or load assets

**Roles Referenced:**
- Resource owners
- Load-serving Market Participants

## 6. Links or References

**Document References:**
- **Attachment AE**: Primary tariff attachment containing multiple sections:
  - Section 4.1(10)(b) - Resource commitment status
  - Section 4.1(10)(c) - Reliability-only resources
  - Section 4.1.2.1.2 - Non-Conforming Load
  - Section 4.1.3(4) - Operating Reserve calculations
  - Section 4.2.1 - Must-Offer Requirement
  - Section 4.2.1.1 - Day-Ahead Market requirements
  - Section 4.2.2.5.4 - JOU Individual Resource Option
  - Section 6.1.2.1 - Market Monitor verification process
  - Section 6.1.14 - Combined Interest Resource modeling
  - Section 6.2.2 - Non-Conforming Load description
  - Section 6.2.8 - Bilateral contract load registration
  - Section 8.6.5 - Resource compensation
  - Section 8.6.7(A) - Regional cost recovery
  - Section 8.6.44 - Local cost recovery

**Other References:**
- Market Protocols Glossary
- Market Monitor website
- Operating guides (to be developed)

## 7. Suggested Tags

- SPP_Markets
- Reliability_Unit_Commitment
- Day-Ahead_Market
- Resource_Commitment
- Load_Forecasting
- Non-Conforming_Load
- Energy_Storage_Resources
- Must-Offer_Obligation
- Local_Reliability
- Market_Protocols
- Transmission_Operations
- Market_Monitor
- RTBM
- Emergency_Operations
- Cost_Recovery
- RUC_Process

## 8. Items That May Need Follow-Up

1. **Operating Guides Development**: Section references that Transmission Provider, local transmission operators, and Resource owners "must develop operating guides" for manual commitments - status and timeline unclear

2. **Market Monitor Verification Process**: Multiple references to Section 6.1.2.1 verification standards and procedures - need to review this section for completeness

3. **Documentation Requirements**: Supporting documentation "must be provided to the Market Monitor upon request" for firm power purchases/sales - clarification needed on documentation standards

4. **Market Monitor Website**: Market Participants have option to input firm power purchase/sale information - need to verify website availability and functionality

5. **Incomplete Sentence**: Document ends mid-sentence at "A Market Participant that does not have any registered Resources for an Asset Owner has met the must-offer requirement for that Asset Owner becaus" - missing content from chunk 19

6. **Non-Discriminatory Selection**: Multiple references to "non-discriminatory manner" for resource selection - need detailed criteria definition

7. **Affiliated Resource Compensation**: Provision denying compensation if Market Monitor determines discriminatory selection of affiliated resources - enforcement procedures need clarification

8. **ESR/MSR Registration**: Load modeling for ESRs not registered as MSRs must be considered Non-Conforming Load - potential registration gap or compliance issues

9. **Cost Allocation Disputes**: Regional vs. local cost recovery mechanisms (Section 8.6.7(A) vs. 8.6.44) - potential for allocation disputes

10. **Forecast Interpolation**: SPP will interpolate when 15-minute forecast unavailable - methodology and accuracy concerns

---

# Chunk 19 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document section (chunk 19 of 24) from RR696 SPP Comments details the Day-Ahead Market execution processes and Resource Utilization and Commitment (RUC) procedures. It primarily covers must-offer compliance requirements, market clearing methodologies, SCUC (Security Constrained Unit Commitment) and SCED (Security Constrained Economic Dispatch) algorithms, manual commitment procedures for reliability issues, and capacity adequacy analysis. The content establishes operational rules for market participants, specifying commitment statuses, capacity thresholds (notably the 90% compliance threshold), and procedures for addressing transmission system constraints and local reliability issues.

## 2. Key Topics

- **Must-Offer Compliance Requirements**: 90% net resource capacity threshold for deemed compliance
- **GFA Carve Out Treatment**: Requirements for resources used as source of GFA Carve Out schedules
- **DA Market SCUC/SCED Algorithms**: Simultaneous co-optimization methodology for resource commitment
- **Resource Commitment Statuses**: Market, Self, and Reliability commitment categories
- **Capacity Limits**: Maximum/Minimum Economic, Emergency, Regulation, Charge/Discharge limits
- **Manual Commitments**: Procedures for addressing transmission system security constraints
- **Local Reliability Issues vs. Local Emergency Conditions**: Different treatment and compensation mechanisms
- **Operating Guides**: Development requirements for manual commitments
- **Violation Relaxation Limits (VRLs)**: Application in SCED when constraints create infeasible solutions
- **Multi-Configuration Resources (MCRs)**: Restrictions during transition periods
- **Day-Ahead RUC Execution**: Capacity adequacy analysis using SCUC algorithm

## 3. Decisions or Actions

- Market Participants with ≥90% net resource capacity deemed compliant with must-offer requirements
- Market Participants not meeting conditions will be assessed penalties per Section 4.2.1.1.1
- Market Monitor will monitor compliance with must-offer obligations for each Asset Owner/hour
- DA Market SCUC will prioritize actions: (1) curtail non-firm exports, (2) incorporate emergency capacity
- SPP may manually commit/decommit resources for transmission system security constraints
- Manual commitments must be selected in non-discriminatory manner, verified by Market Monitor
- SPP will re-run Day-Ahead SCUC after manual commitments (time permitting)
- Local transmission operators can request SPP to issue instructions for Local Reliability Issues
- SPP, local transmission operators, and resource owners will develop operating guides
- MCRs with transition times >30 minutes ineligible for Contingency Reserve during transitions

## 4. Important Dates

- **Operating Day**: Referenced throughout as the timeframe for market execution and compliance
- **Upcoming Operating Day**: Target for Day-Ahead Market clearing and RUC analysis
- No specific calendar dates mentioned in this section

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)**: Primary market operator and reliability coordinator
- **Market Monitor**: Compliance monitoring and verification entity
- **Market Participants**: Generic reference to entities participating in the market
- **Local Transmission Operators**: Entities requesting commitments for local reliability issues

**People:**
- **SPP Operators**: Receive advisory information from capacity adequacy analysis
- No individual names mentioned

## 6. Links or References

**Internal Document References:**
- Section 4.2.1.1 (must-offer obligation)
- Section 4.2.1.1.1 (penalty assessment)
- Section (B)(1) and (2) (compliance conditions)
- Section (A)(1) (load requirements)
- Section 4.3.1.2 (DA Market Execution)
- Section 6.1.7.1 (MCR registration options)
- Section 3.1.1 (resource constraints)
- Section 4.1.3.3 (VRL application)
- Section 4.5.9.12 (resource compensation)
- Section 4.5.9.13 (regional cost recovery)
- Section 4.5.8.12 (alternative compensation reference)
- Section 4.5.9.10(1) (local cost recovery)
- Section 6.1.2.1 of Attachment AE to the Tariff (Market Monitor verification process)

**Referenced Systems/Processes:**
- Multi-Day Reliability Assessment process
- RTBM Offers (Real-Time Balancing Market)
- SPP Mid-Term Load Forecast

## 7. Suggested Tags

- Day-Ahead Market
- SCUC Algorithm
- SCED Algorithm
- Must-Offer Compliance
- Resource Commitment
- Market Clearing
- Local Reliability Issues
- Manual Commitments
- Operating Reserves
- Capacity Adequacy
- RUC (Resource Utilization and Commitment)
- GFA Carve Out
- Multi-Configuration Resources
- Market Monitor
- Transmission Constraints
- Emergency Capacity
- Violation Relaxation Limits
- Shadow Pricing
- Lost Opportunity Costs
- Non-Discriminatory Selection

## 8. Items That May Need Follow-Up

1. **Penalty Assessment Details**: Section 4.2.1.1.1 penalties for must-offer non-compliance not fully described
2. **90% Threshold Justification**: Rationale for the 90% deemed compliance threshold may need clarification
3. **Manual Commitment Process**: Specific procedures and timelines for "time permitting" SCUC re-runs
4. **Operating Guide Development**: Status and timeline for developing operating guides between SPP, local transmission operators, and resource owners
5. **Market Monitor Verification**: Detailed process under Section 6.1.2.1 of Attachment AE referenced but not detailed
6. **MCR Transition Time Definition**: How 30-minute threshold for MCR eligibility was determined
7. **VRL Pricing Methodology**: "Appropriately priced VRL" requires definition and validation
8. **Local vs. Regional Cost Recovery**: Allocation methodology differences between Sections 4.5.9.13 and 4.5.9.10(1)
9. **Non-Firm Transaction Curtailment**: Priority order criteria and notification requirements
10. **Emergency Limit Incorporation**: Conditions triggering emergency capacity use and associated compensation
11. **Shadow Price Calculation**: Methodology ensuring market participant indifference between Energy and Operating Reserve clearing
12. **Reliability Coordinator Authority**: Scope and limits of SPP's manual commitment authority
13. **GFA Carve Out Compliance**: Monitoring and enforcement mechanisms for sufficient capacity coverage
14. **Self-Committed Capacity**: Treatment of Resources with Self commitment status during manual decommitment

---

# Chunk 20 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document contains detailed technical specifications for SPP's (Southwest Power Pool) Reliability Unit Commitment (RUC) processes, specifically focusing on Security Constrained Unit Commitment (SCUC) algorithms for both Day-Ahead and Intra-Day market operations. The content outlines the hierarchical decision-making processes for resource commitment and de-commitment, procedures for handling capacity surplus and shortage situations, protocols for manual commitments during reliability issues, and compensation recovery mechanisms. The document emphasizes non-discriminatory resource selection, Market Monitor oversight, and distinguishes between regional and local reliability issues with corresponding cost allocation methodologies.

## 2. Key Topics

- **SCUC Algorithm Operations**: Detailed priority orders for resource commitment/de-commitment in capacity shortage and surplus scenarios
- **Resource Commitment Hierarchy**: Market vs. Self vs. Reliability commit statuses and their treatment in optimization
- **Emergency Capacity Limits**: Procedures for incorporating Maximum/Minimum Emergency Capacity Operating Limits
- **Manual Commitments**: Protocols for SPP-initiated and local transmission operator-requested commitments
- **Local Reliability Issues**: Distinction from transmission system-wide issues, including Local Emergency Conditions
- **Compensation and Cost Recovery**: Regional vs. local cost allocation for committed resources (Section 4.5.9.8 and 4.5.9.10)
- **Market Monitor Oversight**: Non-discriminatory selection verification under Section 6.1.2.1 of Attachment AE
- **Multi-Configuration Resources (MCRs)**: Regulation eligibility restrictions during configuration transitions
- **Interchange Transactions**: Treatment of firm and non-firm Import/Export transactions in capacity balancing

## 3. Decisions or Actions

### Algorithm-Driven Actions (Priority Order):

**Capacity Shortage Response:**
1. Curtail non-firm Export Interchange Transactions
2. Incorporate capacity up to Maximum Emergency limits; commit Reliability Resources
3. De-commit charging Resources from DA Market (Market status)
4. De-commit self-committed charging Resources

**Capacity Surplus Response:**
1. Curtail non-firm fixed Import Interchange Transactions
2. Incorporate capacity down to Minimum Emergency limits
3. Commit available Reliability Resources capable of charging
4. De-commit Resources from DA Market (Market status)
5. De-commit self-committed Resources

### Manual Intervention Actions:
- SPP may manually commit/de-commit Resources for Transmission System reliability issues not addressable by SCUC
- Local transmission operators may request SPP commitments for Local Reliability Issues
- In time-constrained Local Emergency Conditions, local operators may issue direct instructions with subsequent SPP coordination
- Operating guides must be developed for known/recurring Local Reliability Issues

## 4. Important Dates

- **Operating Day**: References throughout for Day-Ahead and Intra-Day RUC processes
- **No specific calendar dates mentioned** in this excerpt

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)**: Primary market operator and reliability coordinator
- **Market Monitor**: Oversight entity verifying non-discriminatory resource selection
- **Local Transmission Operators**: Entities managing local transmission systems with authority to identify Local Reliability Issues
- **Resource Owners**: Entities owning generation/storage resources participating in markets

### Roles Referenced:
- SPP RUC Operators
- Day-Ahead RUC Operators
- Intra-Day RUC Operators
- Reliability Coordinator (SPP role)
- Transmission Operators

## 6. Links or References

### Internal Tariff References:
- **Section 4.5.9.8**: Compensation provisions for committed Resources
- **Section 4.5.9.10**: Cost recovery and allocation methodology (regional vs. local)
- **Section 6.1.2.1 of Attachment AE**: Market Monitor process for non-discriminatory selection verification
- **Section 6.1.7.1**: Multi-Configuration Resource registration options
- **Attachment AE to the Tariff**: Market monitoring provisions

### Document Reference:
- **Source**: RR696 SPP Comments 20250711.docx.txt (chunk 20 of 24)

## 7. Suggested Tags

- RUC Process
- SCUC Algorithm
- Resource Commitment
- Emergency Operations
- Local Reliability Issues
- Market Monitor
- Cost Allocation
- Manual Commitments
- Reliability Coordinator
- Day-Ahead Market
- Intra-Day Market
- Operating Reserves
- Transmission Constraints
- Non-Discriminatory Selection
- Multi-Configuration Resources
- Interchange Transactions
- Emergency Capacity Limits

## 8. Items That May Need Follow-Up

### Policy/Procedural Items:
1. **Operating Guides Development**: Requirement for SPP, local transmission operators, and Resource owners to develop operating guides for recurring Local Reliability Issues - status and completion timeline unclear
2. **Market Monitor Verification Process**: Details of Section 6.1.2.1 verification procedures should be reviewed for consistency with manual commitment protocols
3. **Affiliated Resource Treatment**: Criteria for determining discriminatory selection and compensation denial for affiliated Resources needs clarification

### Technical Clarifications Needed:
4. **MCR Regulation Eligibility**: Implementation details for preventing regulation selection during configuration transitions
5. **Time Constraints Definition**: No specific timeframes defined for "time permitting" vs. emergency situations requiring direct local operator action
6. **Coordination Protocols**: Specific procedures for transitioning from local operator instructions to SPP instructions need documentation

### Compliance/Monitoring Items:
7. **Non-Discriminatory Selection Standards**: Ongoing monitoring of manual commitment selection by Market Monitor
8. **Cost Allocation Disputes**: Potential for disagreements between regional vs. local cost allocation determinations
9. **Documentation Requirements**: Logging requirements for manual commitments, particularly those initiated by local operators

### Stakeholder Coordination:
10. **Local Transmission Operator Relationships**: Formal agreements or protocols between SPP and local operators for reliability issue identification and response
11. **Resource Owner Participation**: Engagement in operating guide development process

### Data/Reporting Needs:
12. **Frequency Analysis**: Tracking of manual commitments, Local Reliability Issues, and emergency capacity utilization to identify systemic issues

---

# Chunk 21 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document excerpt (chunk 21 of 24) from SPP's (Southwest Power Pool) regulatory revision RR696 contains detailed operational, planning, and business practice requirements. The content focuses on three main areas: (1) compensation mechanisms for manual resource commitments during local emergencies, (2) technical connectivity requirements for data communication systems (ICCP nodes), and (3) planning criteria definitions for transmission system modifications. The document establishes specific thresholds for Non-Conforming Load identification (50 MW or greater), ICCP node reconnection times (240 seconds), and transmission modification criteria (20% rating changes, 30% impedance changes). Multiple cross-references are made to NERC standards and SPP OATT attachments.

## 2. Key Topics

- **Manual Resource Commitment Compensation**: Operating guides for manual commitments during Local Emergency Conditions in Intra-Day RUC, with local cost recovery mechanisms
- **Non-Conforming Load Registration**: Requirements for identifying loads ≥50 MW at specific PNodes or Aggregate PNodes
- **Emergency Operating Plans (EOPs)**: Guidelines for operator-controlled load shedding with rotation provisions and protection of critical natural gas loads
- **ICCP Node Connectivity**: Dual-node requirements for TOPs and GOPs, with specific capacity thresholds and reconnection timeframes
- **Transmission Planning Criteria**: Definitions of Transmission Material Modification and Qualified Change for evaluating permanent system changes
- **Non-Jurisdictional Facility Studies**: Procedures for generator interconnection studies outside SPP jurisdiction

## 3. Decisions or Actions

- **Required Actions for Market Participants**: Identify and register any Non-Conforming Load assets ≥50 MW
- **TOP Requirements**: Configure ICCP nodes to connect to both SPP primary and backup sites concurrently with identical Block 1 and Block 2 data
- **GOP Requirements**: 
  - Configure two ICCP nodes with 240-second reconnection capability
  - GOPs with >1500 MW or 15+ capacity resources must configure dual nodes for set point instructions
- **Transmission Owner Responsibilities**: 
  - Conduct impact studies for generator interconnection requests
  - Complete Network Upgrades before Generating Facility operation (unless mitigations approved)
- **SPP Responsibilities**: Perform studies for non-jurisdictional facilities and determine additional coordination study requirements

## 4. Important Dates

- **240 seconds**: Maximum reconnection time for alternate ICCP nodes after failure
- **12 months**: Typical duration threshold for defining "permanent change" in Qualified Change and Transmission Material Modification definitions
- No specific calendar dates or deadlines mentioned in this excerpt

## 5. Organizations and People Mentioned

**Organizations:**
- SPP (Southwest Power Pool) - Regional Transmission Organization
- NERC (North American Electric Reliability Corporation)
- Associated Electric Cooperatives, Inc.
- California Independent System Operator Corporation
- Electric Reliability Council of Texas (ERCOT)
- Midcontinent Independent System Operator, Inc. (MISO)
- Peak
- Public Service Company of Colorado
- Saskatchewan Power Corporation
- Southwestern Power Administration
- Tennessee Valley Authority

**Roles/Positions (no specific individuals named):**
- Market Participants
- Transmission Owners (TOs)
- Transmission Operators (TOPs)
- Generator Operators (GOPs)
- Balancing Authorities (BAs)
- Resource owners
- Planning Coordinator

## 6. Links or References

**SPP Documents:**
- SPP Open Access Transmission Tariff (OATT)
- Attachment V (Generator Interconnection Procedures)
- Attachment O (Transmission Planning Process)
- Attachment AB (Retirement processes)
- Attachment AQ (Delivery points)
- SPP Business Practices (7250, 7850)
- SPP Operating Criteria (Section 3.6, 5.2)
- SPP Planning Criteria (Section 5)
- SPP Disturbance Performance Requirements
- SPP Quarterly Project Tracking Report
- ITP Manual
- SPP Model Development Procedure Manual
- Request Management System

**NERC Standards:**
- NERC Reliability Standards (general)
- NERC Glossary of Terms
- FAC-002-041 (Qualified Change requirements)

**Other:**
- Seams Agreements (various ISOs/utilities)
- Inter-Control Center Communications Protocol (ICCP)
- RDS (Telemetering and Control System Status)

## 7. Suggested Tags

- SPP
- NERC-Compliance
- Transmission-Planning
- Generator-Interconnection
- ICCP-Connectivity
- Emergency-Operations
- Load-Shedding
- Market-Operations
- Non-Conforming-Load
- Network-Upgrades
- OATT
- Reliability-Standards
- Transmission-Material-Modification
- RUC (Reliability Unit Commitment)
- EOP (Emergency Operating Plan)
- BES (Bulk Electric System)
- TOP (Transmission Operator)
- GOP (Generator Operator)
- Planning-Criteria

## 8. Items That May Need Follow-Up

1. **Operating Guide Development**: Coordination required between SPP, local transmission operators, and Resource owners to develop operating guides for manual commitments during Local Emergency Conditions

2. **Non-Conforming Load Registration**: Market Participants need to complete identification and registration of loads ≥50 MW - unclear if this is a new requirement or existing compliance item

3. **ICCP Node Compliance**: TOPs and GOPs may need to verify their current configurations meet the dual-node and 240-second reconnection requirements, particularly for GOPs with >1500 MW capacity

4. **Third-Party ICCP Contracts**: TOPs/GOPs with third-party ICCP providers need to ensure contractual provisions support the 240-second reconnection requirement

5. **Critical Natural Gas Load Prioritization**: Implementation details needed for how critical gas loads will be identified and protected from load shedding procedures

6. **Non-Jurisdictional Generator Studies**: Process clarification needed regarding which party (Transmission Owner vs. Interconnection Customer) will be financially responsible for SPP-required studies

7. **Network Upgrade Completion**: Tracking mechanism needed to ensure all Network Upgrades are completed before Generating Facility operation, with exception process for approved mitigations

8. **Transmission Material Modification Thresholds**: Training/guidance may be needed for applying the specific percentage thresholds (20% rating, 30% impedance) consistently across the organization

9. **Cost Recovery Mechanism**: Section 4.5.9.10 local cost recovery methodology referenced but not fully detailed in this excerpt - may need clarification

10. **Document References**: Several reference documents listed at end need to be verified as current versions and accessible to relevant stakeholders

---

# Chunk 22 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document contains regulatory content from SPP (Southwest Power Pool) regarding three key business practices and manual procedures:

1. **Attachment AQ and AX Processes**: Establishes planning processes for evaluating Delivery Point Additions, Modifications, and Retirements under the SPP Open Access Transmission Tariff (OATT)
2. **Business Practice 8100**: Defines Resource Adequacy requirements for Demand Response Programs and Behind-The-Meter Generation
3. **ITP Manual Sections**: Covers Load Forecasts and Persistent Operational Needs Assessment procedures

The content primarily focuses on clarifying evaluation processes for transmission service delivery points and establishing requirements for demand response programs in meeting resource adequacy obligations.

## 2. Key Topics

- **Delivery Point Management**
  - Attachment AQ process for assessing impacts of Delivery Point Additions, Modifications, and Retirements
  - Attachment AX process for assessing Delivery Point Additions with planned generation
  - Network Integration Transmission Service (NITS) requirements

- **Local Delivery Facilities**
  - Definition and classification of facilities used for NITS
  - Modification and retirement procedures

- **Resource Adequacy**
  - Demand Response Programs requirements
  - Behind-The-Meter Generation (less than 10 MW) treatment
  - Load Responsible Entity (LRE) obligations
  - Winter Season Obligation compliance

- **Study Processes**
  - Delivery Point Network Study (DPNS)
  - Provisional Load Process Study (PLPS)
  - Integrated Transmission Planning Assessment
  - Request aggregation methodology

- **Load Forecasting**
  - 50-50 forecast probability requirements
  - Non-coincident peak conditions
  - Historical hourly demand data usage

## 3. Decisions or Actions

**Procedural Requirements:**
- Transmission Customers must submit all Delivery Point change requests through Attachment AQ, AX, or other specified processes to Host Transmission Owner and Transmission Provider
- Transmission Customers are responsible for notifying SPP to update NITS Agreements or Provisional Load Process Agreements after review completion
- LREs must report projected MW level of Peak Demand reduction as an informational line item in the Workbook

**Study Aggregation:**
- Transmission Provider may aggregate multiple Delivery Point requests within relative proximity into single DPNS or PLPS analysis
- Transmission Provider must propose aggregated study approach to all Parties and evaluate feedback before deciding to aggregate

**Resource Classification:**
- Non-dispatchable and non-controllable Demand Response Programs may only be considered in LRE's forecasted Peak Demand
- Behind-The-Meter Generation resources that are non-controllable and non-dispatchable (e.g., rooftop solar) receive same treatment

## 4. Important Dates

**No specific dates mentioned in this content chunk.**

Reference made to:
- Study timeframe requirements pursuant to standardized project timelines in BP 7060
- SPP determined Network Upgrade need dates
- Seasonal demand determinations (Summer/Winter Season Obligations referenced)

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)** - Transmission Provider
- **Transmission Customers** - Service recipients
- **Host Transmission Owner** - Infrastructure owner
- **Load Responsible Entity (LRE)** - Entity responsible for load obligations
- **Market Participant** - General market entity
- **Network Customer** - Specific customer type under NITS
- **ESWG (Economic Studies Working Group)** - Review body
- **TWG (Transmission Working Group)** - Review body

**No individual people mentioned.**

## 6. Links or References

**Referenced Documents:**
- SPP Open Access Transmission Tariff (OATT)
- Attachment AQ (Delivery Point evaluation process)
- Attachment AX (Delivery Point Additions with planned generation)
- Attachment AA (Resource Adequacy Requirements and Winter Season Obligation)
- BP 7060 (Business Practice containing standardized project timelines)
- Business Practice 8100 (Resource Adequacy requirements)
- NITS Agreement (Network Integration Transmission Service Agreement)
- Provisional Load Process Agreement
- Model Development Procedure Manual
- Integrated Transmission Planning (ITP) Manual
- The Workbook (reporting document for LREs)

## 7. Suggested Tags

- Transmission Planning
- Delivery Points
- Resource Adequacy
- Demand Response
- Network Integration
- SPP OATT
- Load Forecasting
- Behind-The-Meter Generation
- Transmission Service
- Network Upgrades
- Local Delivery Facilities
- Attachment AQ
- Attachment AX
- Business Practice 8100
- ITP Assessment
- NITS Agreement
- Provisional Load Process

## 8. Items That May Need Follow-Up

**Definitional Gaps:**
- Terms defined in this Business Practice are "not currently defined in the SPP OATT" - may require formal tariff amendments to incorporate these definitions

**Process Clarifications Needed:**
- Specific criteria for determining when Transmission Provider deems aggregation "appropriate"
- Exact threshold for "relative proximity" when aggregating multiple requests
- Timeline expectations for Transmission Customer notifications to update Service Agreements

**Incomplete Information:**
- Business Practice 8100 section appears truncated (shows "…" indicating missing content)
- Section 2.0 of Attachment AQ referenced but not included in this chunk
- Complete list of Demand Response Programs requirements not shown (section 1.0 shows "…")

**Cross-Reference Verification:**
- BP 7060 standardized project timelines need to be reviewed for consistency
- Interface between Attachment AQ/AX processes and Integrated Transmission Planning Assessment timeframes
- Criteria thresholds for Persistent Operational Needs Assessment not fully detailed

**Stakeholder Coordination:**
- ESWG and TWG endorsement process for additional operational needs requires defined procedures
- Feedback mechanism for aggregated study approach proposals needs clarity

**Technical Specifications:**
- Method for establishing "adequate system survey" for seasonal demand reduction
- Requirements for "historical hourly demand data sufficient" need quantification
- Behind-The-Meter Generation threshold of 10 MW rationale and treatment above this threshold

---

# Chunk 23 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary
This document (chunk 23 of 24) from RR696 SPP Comments dated January 7, 2025, contains detailed revenue requirement tables for the Southwest Power Pool (SPP) transmission cost allocation. The content presents five interconnected tables outlining transmission owner revenue requirements, point-to-point revenue credits, zonal Annual Transmission Revenue Requirements (ATRR), and region-wide cost allocation methodologies. All specific dollar amounts reference external RRR Files, with limited specific values provided for certain cooperative entities.

## 2. Key Topics
- **Revenue Requirements for Through And Out Transactions** across 24 transmission owners
- **Schedule 1 Point-to-Point (PTP) Revenue Credits** with most entities showing N/A or $0
- **Zonal ATRR allocation** across 20 zones within SPP territory
- **Base Plan vs. Balanced Portfolio cost allocation** methodologies
- **Region-wide ATRR calculations** including interregional planning costs
- **Post-June 19, 2010 tariff changes** affecting cost allocation
- **Upgrade Sponsor payment mechanisms**
- **JTIQ (Joint Transmission Interconnection Queue) ATRR balances**

## 3. Decisions or Actions
- Revenue requirements have been established and filed in RRR Files for all major transmission owners
- Specific PTP revenue credits determined for select entities:
  - Multiple cooperatives assigned $0 credits
  - Several utilities designated N/A status
- Cost reallocation from zonal to Balanced Portfolio Region-wide ATRR has been implemented
- Integration of interregional planning costs (SPP and Other regions) into total ATRR

## 4. Important Dates
- **June 19, 2010**: Critical threshold date distinguishing Base Plan ATRR allocation methodologies (referenced in Tables 3, 4, and 5)
  - Separate calculations for NTC (Network Transmission Cost) prior to and on/after this date

## 5. Organizations and People Mentioned

### Transmission Owners/Utilities (24 entities):
- AEP West Transmission Companies (AEP Oklahoma Transmission Company, Inc. and AEP Southwestern Transmission Company, Inc.)
- American Electric Power (Public Service Company of Oklahoma and Southwestern Electric Power Company)
- Arkansas Electric Cooperative Corporation (zones 1 and 7)
- City Utilities of Springfield
- Corn Belt Power Cooperative
- Empire District Electric Company
- Evergy entities (Kansas Central, Metro, Missouri West)
- Grand River Dam Authority
- Kansas City Board of Public Utilities
- Lincoln Electric System
- Midwest Energy, Inc.
- Missouri Joint Municipal Electric Utility Commission
- Nebraska Public Power District
- Oklahoma Gas and Electric
- Omaha Public Power District
- Southwestern Power Administration
- Southwestern Public Service Company
- Sunflower Electric Power Corporation
- Tri-State G&T Association
- Western Farmers Electric Cooperative
- Western-UGP

### Additional Sub-zone Entities (Table 3):
- East Texas Electric Cooperative, Inc. ($14,567,983)
- Deep East Texas Electric Cooperative, Inc. ($2,576,698)
- Oklahoma Municipal Power Authority ($768,624 and $368,501 in different zones)
- Coffeyville Municipal Light and Power (CMLP) ($391,790)
- Transource Oklahoma, LLC
- City of Independence, Missouri ($7,043,930)
- People's Electric Cooperative
- NextEra Energy Transmission Southwest, LLC
- Transource Missouri, LLC
- South Central MCN LLC
- Lea County Electric Cooperative, Inc.
- ITC Great Plains, LLC
- Prairie Wind Transmission, LLC
- Kansas Power Pool
- Central Nebraska Public Power and Irrigation District ($327,891)
- Basin Electric Power Cooperative
- Heartland Consumers Power District
- Missouri River Energy Services (with 8 sub-members)
- East River Electric Power Cooperative, Inc.
- NorthWestern Energy Public Service Corporation
- Northwest Iowa Power Cooperative
- Harlan Municipal Utilities
- Central Power Electric Cooperative
- Mountrail-Williams Electric Cooperative
- Mor-Gran-Sou Electric Cooperative, Inc.
- Roughrider Electric Cooperative, Inc.
- L and O Power Cooperative

## 6. Links or References
- **RRR File**: Primary reference document containing actual revenue requirement values (referenced throughout all tables)
- **Attachment H tab**: Specific tab within posted RRR File containing detailed calculations
- **Section II.2 and II.3**: Cross-references for American Electric Power entities
- **Posted RRR File**: Publicly available file containing complete revenue data

## 7. Suggested Tags
- SPP (Southwest Power Pool)
- Revenue Requirements
- Transmission Cost Allocation
- ATRR (Annual Transmission Revenue Requirements)
- Point-to-Point Revenue
- Base Plan
- Balanced Portfolio
- Zonal Allocation
- Through and Out Transactions
- Interregional Planning
- Network Transmission Cost
- RR696
- Tariff Filing

## 8. Items That May Need Follow-Up

### High Priority:
1. **Access to RRR File**: Verify availability and accuracy of referenced RRR File containing all actual revenue requirement values
2. **Attachment H tab validation**: Confirm all posted values in Attachment H match table references
3. **June 19, 2010 methodology change**: Clarify rationale and impact of allocation methodology changes post-this date
4. **N/A designations**: Determine reason for N/A status for PTP Revenue Credits for multiple entities

### Medium Priority:
5. **Reserved zones**: Follow up on zones reserved for future use (1c, 11b, 15)
6. **JTIQ ATRR Balance**: Understand calculation methodology and reconciliation (Table 5, Line 9)
7. **Interregional cost allocation**: Verify coordination with other planning regions for cost recovery
8. **Sub-zone allocations**: Confirm accuracy of specific dollar amounts listed for smaller cooperatives and municipal utilities

### Administrative:
9. **Document completeness**: This is chunk 23 of 24; review final chunk for any additional context or summaries
10. **Cross-reference verification**: Validate Section II.2 and II.3 references for AEP entities
11. **Upgrade Sponsor payment tracking**: Establish monitoring mechanism for Column 7 payments

---

# Chunk 24 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary
This document appears to be the final chunk (24 of 24) of SPP (Southwest Power Pool) regulatory comments dated July 11, 2025, reference number RR696. The content consists primarily of detailed transmission service schedules, zonal transmission owner information, and industry acronyms. The document outlines transmission request timelines, response requirements, and energy scheduling procedures for various service types ranging from long-term firm to next-hour market transactions. It also includes a comprehensive list of transmission zones and their associated owners/operators across multiple states.

## 2. Key Topics

### Transmission Service Types and Timelines
- **Long-Term Firm Service** (1 year or more) with open season processes
- **Short-Term Firm Service** (ranging from monthly to daily)
- **Non-Firm Service** (monthly to hourly)
- **Next Hour Market** operations

### Transmission Zones and Owners
- 19 major transmission zones covering multiple states (Oklahoma, Texas, Kansas, Missouri, Nebraska, Iowa, South Dakota, North Dakota)
- Multiple transmission owners including investor-owned utilities, cooperatives, municipal utilities, and public power entities

### Key Processes
- Open season procedures (referenced in Attachment Z1)
- Aggregate Transmission Service Study
- Expedited designation process (Section 30.2.2)
- System capacity impact studies
- Energy scheduling changes

## 3. Decisions or Actions

### Standardized Timeline Requirements
- **Long-Term Firm (1+ year):** Applications processed according to open season schedules in Attachment Z1
- **Short-Term Firm (monthly):** 31 days prior request deadline, 24-hour response, 4-day customer response
- **Short-Term Firm (daily):** 10:00 day prior request deadline, 24-hour response times vary
- **Non-Firm (hourly):** 30 minutes prior request, best effort response for requests <1 hour to start
- **Next Hour Market:** 20 minutes prior request, best effort processing

### Energy Scheduling Standards
- Most service types: Changes no later than 12:00 day prior
- Non-Firm services: Changes no later than 15:00 day prior
- All services: Final changes 20 minutes prior to schedule start

## 4. Important Dates

### General Timing Requirements
- **90 days prior:** Long-term firm alternative submission deadline
- **120 days prior:** Maximum advance request for monthly short-term firm
- **60 days prior:** Study completion timeframe for short-term firm
- **10:00 day prior:** Critical deadline for daily firm and non-firm requests
- **20 minutes prior:** Universal final scheduling change deadline

### Response Timeframes
- 10 days for long-term firm provider response
- 3 days for long-term firm customer response
- 24 hours for most short-term firm responses
- 30 minutes for hourly non-firm responses

## 5. Organizations and People Mentioned

### Major Transmission Owners/Zones

**Zone 1 - AEP West:**
- American Electric Power (PSO and SWEPCO)
- East Texas Electric Cooperative, Inc.
- Deep East Texas Electric Cooperative, Inc.
- Oklahoma Municipal Power Authority
- Coffeyville Municipal Light and Power
- Arkansas Electric Cooperative Corporation
- Transource Oklahoma, LLC

**Zone 6 & 9 - Evergy Companies:**
- Evergy Metro, Inc.
- Evergy Missouri West, Inc.
- Evergy Kansas Central/South, Inc.
- City of Independence, Missouri

**Zone 7 - OG&E:**
- Oklahoma Gas and Electric
- NextEra Energy Transmission Southwest, LLC
- People's Electric Cooperative

**Zone 10 - Federal Power:**
- Southwestern Power Administration

**Zone 11 - Xcel Energy:**
- Southwestern Public Service Company
- Lea County Electric Cooperative

**Zone 12 - Sunflower:**
- Sunflower Electric Power Corporation
- ITC Great Plains, LLC
- Prairie Wind Transmission, LLC

**Zone 19 - Upper Missouri:**
- Basin Electric Power Cooperative
- Heartland Consumers Power District
- East River Electric Power Cooperative
- Corn Belt Power Cooperative
- NorthWestern Energy
- Multiple municipal utilities (Moorhead, Orange City, Pierre, Sioux Center, Watertown, Denison, Vermillion)
- Multiple rural electric cooperatives

**Other Named Entities:**
- Kansas City Board of Public Utilities
- City Utilities of Springfield, Missouri
- Empire District Electric Company
- Grand River Dam Authority
- Midwest Energy, Inc.
- Western Farmers Electric Cooperative
- Lincoln Electric System
- Nebraska Public Power District
- Omaha Public Power District

## 6. Links or References

### Document References
- **Attachment Z1:** Open season specifications and procedures
- **Section II of Attachment Z1:** Specific open season schedules
- **Section II.3:** AEP-specific provisions
- **Section 19.4:** Response schedule specifications
- **Section 32.4:** Alternative response schedule specifications
- **Section 30.2.2:** Expedited designation process requirements

### Regulatory References
- **FERC (Federal Energy Regulatory Commission):** Regulatory authority
- **NERC (North American Electric Reliability Corporation):** Reliability standards
- **OATT (Open Access Transmission Tariff):** Governing tariff document
- **TPL [NERC] Transmission System Planning Performance Requirement**

## 7. Suggested Tags
- Transmission Services
- SPP (Southwest Power Pool)
- OATT (Open Access Transmission Tariff)
- Scheduling Requirements
- Long-Term Firm Transmission
- Short-Term Firm Transmission
- Non-Firm Transmission
- Generator Interconnection
- Transmission Zones
- Energy Markets
- Regulatory Compliance
- FERC
- Transmission Owners
- Open Season Process
- System Impact Studies

## 8. Items That May Need Follow-Up

### Clarification Needed
1. **Reserved Zones:** Multiple zones marked "Reserved for Future Use" (1c, 11b, 15) - monitor for future assignments
2. **"N/A" Entries:** Numerous N/A entries in Columns 3 and 4 of Table 6 - confirm whether these indicate inapplicability or missing data
3. **Schedule 11 Credit:** Most entities show "$0" or "N/A" - verify intent and applicability
4. **Empty Tables:** Tables 11-28 and 30-45 appear empty - determine if this is intentional or data is missing

### Process Questions
5. **Best Effort Standards:** Next Hour Market and some short-term requests use "best effort" - may need performance metrics or accountability measures
6. **Open Season Coordination:** Multiple references to Attachment Z1 open season process - ensure consistency across document
7. **Zonal Subdivisions:** Complex zone structures (e.g., Zone 1a-1i, Zone 19a-19n) - verify reporting and billing implications

### Regulatory Compliance
8. **FERC Filing Status:** Confirm if this represents final filed tariff language or comments for consideration
9. **Effective Date:** Document dated July 11, 2025 - verify implementation timeline
10. **Cross-References:** Multiple section references - ensure all referenced sections are included in complete document

### Operational Concerns
11. **Timing Conflicts:** Verify 20-minute scheduling deadlines are operationally feasible across all service types
12. **Study Timeframes:** 30-day and 60-day study periods for short-term requests - confirm resource availability
13. **Queue Management:** Different treatment for requests queued more/less than specific timeframes before service start - ensure clear customer communication