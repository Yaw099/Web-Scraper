# Final Combined Report

# COMPREHENSIVE REGULATORY ANALYSIS REPORT
## RR696 MMU Comments - High Impact Large Load Integration

---

## 1. EXECUTIVE SUMMARY

This comprehensive report analyzes SPP Market Monitoring Unit (MMU) comments submitted July 29, 2025, regarding Revision Request 696 (RR696), which proposes to integrate and operate High Impact Large Loads (HILLs) within the SPP marketplace. The MMU provides critical advisory feedback identifying significant risks to market integrity, open access principles, and system reliability.

**Core Proposal**: RR696 establishes frameworks for HILLs (large loads with supporting generation) and CHILLs (Conditional HILLs subject to curtailment), including expedited interconnection processes through HILLGA (High Impact Large Load Generation Assessment) and new interconnection service types.

**MMU Position**: While acknowledging the accelerated timeline limited comprehensive assessment, the MMU divides recommendations into mandatory pre-implementation changes (required before approval) and post-implementation commitments (future RTO obligations). Key concerns center on open access violations, market manipulation risks, inadequate oversight mechanisms, insufficient forecasting incentives, and cost allocation inequities.

**Critical Issues**: 
- Removal of HILLGA-DA (Deliverability Area) option due to potential queue jumping
- Need for automatic market mitigation for CHILL resources
- Enhanced tariff language for data accuracy and MMU oversight
- Grandfathering concerns for existing HILLs
- Integration with LTCR Netting Policy (RR697)
- RUC make-whole payment allocation reforms

**Document Scope**: Three-chunk analysis covering MMU policy recommendations, detailed tariff language revisions, and technical interconnection requirements/forms.

---

## 2. KEY TOPICS

### A. High Impact Large Load Framework
- **HILLs (High Impact Large Loads)**: Large electricity consumers required to pair with supporting generation resources
- **CHILLs (Conditional HILLs)**: Load arrangements subject to curtailment and interruption with no planning obligation by Transmission Provider
- **HILLGA (High Impact Large Load Generation Assessment)**: Expedited study process for generation paired with large loads
- **HILLGA-DA (Deliverability Area Option)**: Controversial proposal allowing generation in same deliverability area rather than local interconnection (MMU recommends removal)

### B. Interconnection and Service Types
- **LLRIS (Load Limited Resource Interconnection Service)**: New interconnection service type specifically for HILL-supporting generation
- **Local Interconnection Requirements**: No more than two substations from HILL Local Delivery Facilities
- **Maximum Injection Capability**: Capped at HILL load × (100% + Summer Planning Reserve Margin) × 125%
- **Joint HILLGA Requests**: Multiple HILLs evaluated simultaneously with five-substation limit for generating facilities

### C. Market Integrity and Oversight
- **Open Access Compliance**: FERC Order 719 and 18 C.F.R. § 35.28(g)(3)(ii) requirements
- **Market Manipulation Prevention**: Automatic mitigation when CHILL resources dispatched above load levels
- **Common Bus Arrangements**: Behind-the-meter generation restrictions to prevent grid injection violations
- **Queue Management**: Concerns about preferential treatment and interconnection prioritization

### D. Operational Requirements
- **Non-Conforming Load Forecasts**: Mandatory accuracy requirements and update obligations
- **Real-Time Telemetry**: Required for BES reliability visibility
- **Remote Disconnect Capability**: Operational control requirements
- **Validation Checks**: Automated monitoring for CHILLs exceeding reserved capacity

### E. Financial and Cost Allocation
- **RUC Make-Whole Payments**: Need to include non-conforming load forecast deviations in allocation
- **Penalty Structures**: 100% of Non-Firm Point-to-Point Transmission Service charges for excess capacity usage
- **Revenue Distribution**: Penalty revenues distributed to reduce Schedule 1-A1 charges (excluding penalized party) within 15 calendar days
- **Credit Requirements**: Recommended increases due to CHILL-related congestion risk patterns

### F. Related Policy Issues
- **LTCR (Long-Term Congestion Rights) Netting Policy (RR697/RR698)**: Requires reevaluation considering HILL/CHILL congestion patterns
- **Demand Response Framework**: Integration and alignment with HILL framework, including opportunity cost definitions
- **2023 ASOM Recommendation 2023-2**: Alignment of planning, markets, and operational processes for large loads with run-limited generation
- **Grandfathering Policy**: MMU recommends future effective dates rather than permanent exemptions for existing HILLs

---

## 3. DECISIONS OR ACTIONS

### A. Pre-Implementation Requirements (Mandatory Before Approval)

**1. Strengthen Tariff Language**
- **Action**: Incorporate RR655 language regarding data accuracy requirements into Part VII, Attachment BA, and Attachment BB
- **Rationale**: Enable effective MMU oversight and monitoring
- **Target Sections**: New Appendix AG on data accuracy requirements

**2. Remove HILLGA-DA Option**
- **Action**: Eliminate pathway allowing generation in same Deliverability Area rather than local interconnection
- **Rationale**: Prevents open access violations, queue jumping, and preferential treatment
- **Impact**: Requires all HILL generation to meet local interconnection standards (≤2 substations from load)

**3. Implement Automatic Market Mitigation**
- **Action**: Create new Section 3.10 of Attachment AF requiring mitigation for CHILL-supporting resources when dispatched above CHILL load levels
- **Mechanism**: Automatic triggers when generation exceeds paired load consumption
- **Purpose**: Prevent market manipulation and inappropriate market participation

**4. Establish Clear Common Bus Offer Rules**
- **Action**: Prevent behind-the-meter generation from dispatching above CHILL load or injecting onto grid in violation of interconnection limits
- **Scope**: Prohibit reserve clearing that would violate interconnection service limits
- **Enforcement**: Clear tariff language with operational monitoring

**5. Implement Validation Checks and Penalties**
- **Action**: Monitor CHILLs exceeding reserved capacity with automated alerts
- **Penalty Structure**: 100% of Non-Firm Point-to-Point Transmission Service charges
- **Revenue Distribution**: Pro-rata to customers via Schedule 1-A1 charge reductions within 15 days

### B. Post-Implementation Commitments (Future RTO Actions)

**1. Address 2023 ASOM Recommendation 2023-2**
- **Commitment**: Align planning, markets, and operational processes for large loads with run-limited generation
- **Timeline**: To be established by RTO
- **Coordination**: Cross-functional integration across departments

**2. Develop Two-Step CHILL Curtailment Process**
- **Step 1**: Operator trigger mechanism
- **Step 2**: Market clearing engine deployment based on shift factors
- **Enhancement**: Explore demand curve for curtailment optimization
- **Objective**: Efficient, market-based curtailment coordination

**3. Revise RUC Make-Whole Payment Allocation**
- **Change**: Include non-conforming load forecast deviations in cost distribution calculations
- **Impact**: More equitable cost allocation reflecting forecast accuracy
- **Beneficiaries**: All market participants bearing RUC costs

**4. Enhance Demand Response Framework**
- **Elements**: 
  - Opportunity cost definitions
  - Performance measurement standards
  - Peak load assessment methodologies
- **Integration**: Align with HILL/CHILL framework
- **Timeline**: Upcoming DR revision request

**5. Reevaluate LTCR Netting Policy (RR697)**
- **Issue**: Current five-year holding requirement may not address HILL/CHILL congestion patterns
- **Example**: FSE-GFA path allocation concerns
- **Action**: Rethink policy in context of new load/generation patterns

### C. Technical Requirements (From Tariff Revisions)

**1. HILLGA Application Requirements**
- Submit applicable deposit and application fee per Section 8.2
- Execute HILL Delivery Point Study (HDPS) Agreement
- Provide comprehensive technical documentation:
  - Preliminary one-line diagrams
  - Collector System Feeder Spreadsheet and layouts
  - PSS/E User Defined Model files (.dll, .lib, .obj, .dyr)
  - Geographic coordinates and mapping
  - Equipment configuration descriptions

**2. Site Control Documentation

---

# Partial Chunk Reports

# Chunk 1 Analysis

# REGULATORY ANALYSIS REPORT
**RR696 Integrate and Operate High Impact Large Load**

---

## 1. Executive Summary

This document contains comments from SPP's Market Monitoring Unit (MMU) on Revision Request 696, which proposes integrating and operating High Impact Large Loads (HILLs). Submitted on July 29, 2025, the MMU provides advisory feedback identifying significant risks to the Integrated Marketplace and other market participants. The MMU divides recommendations into two categories: pre-implementation changes needed before approval and post-implementation commitments the RTO should make. Key concerns include open access principles, market manipulation risks, inadequate oversight mechanisms, and insufficient incentives for accurate forecasting. The MMU emphasizes that the accelerated timeline has limited full risk assessment, with potential for additional recommendations.

---

## 2. Key Topics

- **High Impact Large Loads (HILLs)** - New requirements for connecting large loads with supporting generation
- **HILLGA (High Impact Large Load Generation Agreement)** - Expedited study process for paired generation
- **Conditional HILLs (CHILLs)** - Load arrangements subject to curtailment
- **HILLGA-DA (Deliverability Area option)** - Proposed pathway allowing generation in the same deliverability area
- **Open Access Principles** - Concerns about preferential treatment and queue jumping
- **Market Mitigation** - Need for offer mitigation when CHILL resources exceed reserved capacity
- **Common Bus Arrangements** - Behind-the-meter generation configurations
- **Non-conforming Load Forecasts** - Accuracy requirements and financial incentives
- **RUC (Reliability Unit Commitment) Make-Whole Payments** - Cost allocation issues
- **Tariff Language Strengthening** - Enhanced oversight and compliance requirements
- **Demand Response Framework** - Integration with HILL framework

---

## 3. Decisions or Actions

### Pre-Implementation Recommendations (Changes Required):

1. **Strengthen tariff language** - Incorporate language from RR655 regarding data accuracy requirements for MMU oversight in Part VII, Attachment BA, and Attachment BB

2. **Remove HILLGA-DA option** - Eliminate the pathway allowing generation in the same Deliverability Area due to open access concerns and potential queue prioritization issues

3. **Implement automatic mitigation** - Create new section 3.10 of Attachment AF requiring mitigation for CHILL-supporting resources when dispatched above CHILL load levels

4. **Establish clear offer rules for common bus** - Prevent behind-the-meter generation from being dispatched above CHILL load or injecting onto grid in violation of interconnection limits

5. **Implement validation checks** - Monitor CHILLs exceeding reserved capacity with associated penalties

### Post-Implementation Commitments (Future Actions):

1. **Address 2023 ASOM Recommendation 2023-2** - Align planning, markets, and operational processes for large loads with run-limited generation

2. **Develop two-step CHILL curtailment process** - Operator trigger followed by market clearing engine deployment based on shift factors; explore demand curve for curtailment

3. **Revise RUC make-whole payment allocation** - Include non-conforming load forecast deviations in cost distribution calculations

4. **Enhance Demand Response framework** - Address opportunity cost definitions, performance measurements, and peak load assessments

---

## 4. Important Dates

- **July 29, 2025** - MMU comment submission date
- **Mid-June (2025)** - MMU began engagement with RTO on proposal
- **June (2025)** - MWG approved Revision Request 655 Outage Criteria (referenced for language incorporation)

---

## 5. Organizations and People Mentioned

### Organizations:
- **Market Monitoring Unit (MMU)** - Submitting advisory comments
- **SPP (Southwest Power Pool)** - RTO implementing the revision
- **FERC (Federal Energy Regulatory Commission)** - Regulatory authority (Order 719 referenced)
- **MWG (Markets and Operations Policy Committee Working Group)** - Approval body for RR655
- **SPP Board** - Decision-making authority

### People:
- **Michael Redlinger** - MMU representative, submitter (email: mredlinger@spp.org)

---

## 6. Links or References

### Regulatory References:
- **FERC Order 719**
- **18 C.F.R. § 35.28(g)(3)(ii)** - MMU advisory role regulation
- **SPP OATT Attachment AG, §1.3** - MMU role definition

### Related Documents/Processes:
- **Revision Request 655 (RR655)** - Outage Criteria (approved June 2025)
- **Appendix AG** - New section on data accuracy requirements
- **Part VII, Attachment BA, Attachment BB** - Tariff sections for language incorporation
- **Attachment AF, Section 3.10** - Proposed new mitigation measures section
- **2023 Annual State of the Market (ASOM)** - Recommendation 2023-2 on large loads
- **DSIS (Definitive System Impact Study)** - Generation interconnection queue process
- **ERAS (Generator Interconnection Request)** - Another queue process

---

## 7. Suggested Tags

`RR696`, `High-Impact-Large-Loads`, `HILL`, `CHILL`, `Market-Monitoring-Unit`, `MMU`, `HILLGA`, `SPP`, `Open-Access`, `Market-Mitigation`, `Tariff-Revision`, `Generation-Interconnection`, `Queue-Management`, `RUC-Make-Whole-Payments`, `Non-Conforming-Load`, `Demand-Response`, `Common-Bus`, `Deliverability-Area`, `Load-Forecasting`, `Market-Oversight`, `FERC-Order-719`

---

## 8. Items That May Need Follow-Up

### Immediate Follow-Up (Pre-Implementation):

1. **HILLGA-DA Removal Decision** - Track whether SPP accepts MMU recommendation to remove Deliverability Area option and rationale for decision

2. **Tariff Language Incorporation** - Verify inclusion of RR655 language in Part VII, Attachment BA, and Attachment BB

3. **Section 3.10 of Attachment AF** - Confirm creation and specific language for automatic mitigation provisions

4. **Common Bus Offer Rules** - Ensure final tariff includes clear rules preventing grid injection and reserve clearing violations

5. **Validation Check Implementation** - Confirm SPP commitment and timeline for automated monitoring of CHILL capacity exceedances

### Medium-Term Follow-Up (Post-Implementation):

6. **2023 ASOM Recommendation 2023-2 Implementation** - Track RTO's plan and timeline to address planning process alignment for run-limited generation

7. **Two-Step Curtailment Process Development** - Monitor progress on operator trigger and market clearing engine deployment mechanism; demand curve exploration

8. **RUC Make-Whole Payment Revision** - Follow development of revised cost allocation methodology including non-conforming load deviations

9. **Demand Response Framework Updates** - Track upcoming DR revision request and MMU input incorporation

### Ongoing Monitoring:

10. **Additional MMU Risk Identification** - Monitor for supplemental MMU recommendations given stated limitations of accelerated timeline

11. **Market Participant Compliance** - Track implementation of oversight mechanisms and validation processes

12. **Open Access Compliance** - Monitor for potential discriminatory practices or queue prioritization issues

13. **Common Bus Generation Behavior** - Watch for market manipulation or inappropriate dispatch/reserve clearing

14. **Non-Conforming Load Forecast Accuracy** - Track HILL forecasting performance and RUC commitment impacts

15. **Stakeholder Process Resolution** - Monitor progression through SPP forums, Board approval, and potential FERC filing

---

**Document Status:** Chunk 1 of 3 - Additional content may modify or expand these findings.

---

# Chunk 2 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document is chunk 2 of 3 from RR696 MMU (Market Monitoring Unit) Comments dated January 29, 2025. The content focuses on proposed revisions to SPP's (Southwest Power Pool) tariff regarding High Impact Large Loads (HILLs) and Conditional High Impact Large Loads (CHILLs). The MMU provides recommendations on regulatory requirements for large loads, particularly concerning metering, telemetry, and resource adequacy. The document includes detailed tariff language revisions with redlined edits covering CHILL transmission service terms, HILL Generation Assessment (HILLGA) procedures, and interconnection requirements.

## 2. Key Topics

- **HILL Requirements and Grandfathering**: MMU recommendation to apply new HILL requirements to existing HILLs with a future effective date rather than permanent grandfathering
- **Reliability and Visibility**: Requirements for real-time telemetry, remote disconnect capability, and mandatory non-conforming load forecast updates to protect Bulk Electric System (BES) reliability
- **LTCR Netting Policy (RR697)**: Reevaluation needed in context of HILL/CHILL congestion patterns
- **CHILL Transmission Service**: Conditional service terms, capacity reservations, curtailment provisions, and penalty structures
- **HILLGA (High Impact Large Load Generation Assessment)**: Requirements, procedures, and study agreements for generation facilities supporting HILLs
- **Load Limited Resource Interconnection Service (LLRIS)**: New interconnection service type for HILL-supporting generation
- **Billing and Penalties**: Excess capacity usage penalties and revenue distribution mechanisms

## 3. Decisions or Actions

**MMU Recommendations:**
1. Set a future effective date (not permanent grandfathering) for existing HILLs to comply with new requirements
2. Rethink RR697 LTCR Netting policy considering HILL/CHILL congestion impacts
3. Increase credit requirements due to increased risk from CHILL-related congestion patterns

**Proposed Tariff Revisions:**
- CHILLS classified under Part VII of the Tariff with no planning obligation by Transmission Provider
- CHILLS subject to curtailment and interruption
- Penalties for exceeding reserved capacity: 100% of Non-Firm Point-to-Point Transmission Service charges
- Penalty revenues to be distributed to reduce Schedule 1-A1 charges (excluding penalized party)
- HILLGA Maximum Injection Capability capped at HILL load request × (100% + Summer Planning Reserve Margin) × 125%
- Local Interconnection defined as no more than two substations from HILL Local Delivery Facilities
- Joint HILLGA Interconnection Requests allowed for multiple HILLs evaluated simultaneously

## 4. Important Dates

- **January 29, 2025**: Date of MMU Comments (RR696)
- **Five-year holding requirement**: For LTCR awards under RR697 (unless grandfathered)
- **15 calendar days**: Minimum period before penalty revenue distribution to customers after collection
- No specific implementation dates provided for new HILL requirements (MMU recommends establishing future effective dates)

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)**: The RTO (Regional Transmission Organization)
- **MMU (Market Monitoring Unit)**: Commenting entity
- **Transmission Provider**: SPP in its transmission provider role
- **Transmission Owners**: Entities owning transmission facilities
- **Transmission Customers/Network Customers**: Service recipients
- **HILLGA Customer**: Entity requesting HILL Generation Assessment
- **FSE and GFA**: Entities with certain transmission paths (context: LTCR allocation)

**People:**
No individual names mentioned in this chunk.

## 6. Links or References

**Internal SPP Documents:**
- SPP Open Access Transmission Tariff, Part VII
- Schedules 1-A1, 8, 11, and 15
- Attachments AQ, AX, BA, and BB
- Appendix 1 to Attachment BB
- SPP Business Practice 7250 (Sections 6.3 and 7.8)
- SPP Planning Criteria (Summer Season Planning Reserve Margin)

**Related Revision Requests:**
- **RR696**: Subject revision request (HILL requirements)
- **RR697**: LTCR Netting of Flows
- **RR698**: Referenced in context (appears to be same as RR697 based on context)

**Referenced Concepts:**
- Large Load Integration project
- Bulk Electric System (BES) reliability standards

## 7. Suggested Tags

- High Impact Large Load (HILL)
- Conditional High Impact Large Load (CHILL)
- HILLGA (High Impact Large Load Generation Assessment)
- Load Limited Resource Interconnection Service (LLRIS)
- Transmission Service
- Resource Adequacy
- Market Monitoring Unit (MMU)
- SPP Tariff Revisions
- Congestion Management
- LTCR (Long-Term Congestion Rights)
- Interconnection Requirements
- Real-Time Telemetry
- Capacity Reservation
- Penalty Structures
- RR696
- RR697

## 8. Items That May Need Follow-Up

1. **Determination of future effective date** for applying new HILL requirements to existing HILLs (MMU recommends this but no date specified)

2. **RR697 stakeholder process status** and how HILL/CHILL congestion impacts will be incorporated into LTCR Netting policy

3. **Credit requirement adjustments** needed to reflect increased risk from CHILL-related congestion patterns

4. **Complete chunk 3 review** to understand full context of RR696 MMU comments (this is chunk 2 of 3)

5. **Coordination between RR696, RR697, and RR698** - clarify relationship and ensure consistent treatment of HILL/CHILL issues

6. **Implementation timeline** for HILLGA procedures and study agreements

7. **Definition clarification** for "Local Delivery Area" referenced in section 3.1.1

8. **Emergency operation procedures** for when NRIS analysis indicates issues with HILLGA-Local Interconnections

9. **Maximum capacity calculation methodology** - verification that the formula (HILL load × (100% + Reserve Margin) × 125%) is appropriate

10. **Non-jurisdictional generator interconnection procedures** (Section 6.3 of BP 7250) - ensure compatibility with HILLGA requirements

11. **Penalty revenue distribution mechanics** - operationalization of the 15-day distribution timeline and pro-rata allocation

12. **Five-substation limit** for HILL Generating Facilities supporting multiple HILLs - technical justification and enforcement mechanism

---

# Chunk 3 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document is chunk 3 of 3 from "RR696 MMU Comments 20250729.docx.txt" and contains detailed technical requirements and forms for a High Impact Large Load Assessment Generator Interconnection Agreement (HILLGIA) process. The content appears to be part of SPP (Southwest Power Pool) Tariff Attachment BB, providing standardized forms and requirements for generator interconnection requests. It outlines comprehensive data requirements including technical specifications, site control documentation, contact information, and fee structures necessary for initiating interconnection studies.

## 2. Key Topics

- **Generator Interconnection Application Requirements**: Detailed data requirements for HILLGA (High Impact Large Load Assessment Generator) requests
- **Technical Specifications**: Equipment configuration, one-line diagrams, collector systems, and PSS/E modeling requirements
- **Network Resource Deliverability**: Maximum injection capability and network resource deliverability measurements
- **Site Control Requirements**: Documentation showing control of generating facility and 75% of high voltage tie line to POI
- **Point of Interconnection (POI) Details**: Location, coordinates, voltage levels, and configuration specifications
- **Fuel Types and Prime Movers**: Various generation technologies including battery/storage, hybrid, hydro, nuclear, solar, thermal, and wind
- **Interconnection Service Types**: Stand-alone, shared, and contingent network upgrades
- **Long-Term Congestion Rights (LTCR)**: Candidate incremental rights and terms
- **JTIQ (Joint Targeted Interconnection Queue) Upgrades**: Security amounts and generator charges

## 3. Decisions or Actions

**Required Actions by Interconnection Customer:**
- Submit applicable deposit amount and application fee per Section 8.2 of Attachment BB
- Provide evidence of site control for generating facility
- Demonstrate site control for at least 75% of high voltage tie line to POI
- Submit HILLGA Request per specifications in "Generator Interconnection Business Guide and Practice" manual
- Execute HILL Delivery Point Study (HDPS) Agreement
- Provide comprehensive technical documentation including:
  - Preliminary one-line diagrams
  - Collector System Feeder Spreadsheet and Layout Diagrams
  - PSS/E User Defined Model files
  - Geographic coordinates and mapping
  - Equipment configuration descriptions

**Documentation Requirements:**
- Complete Appendix 1 form with all required fields
- Specify construction option selected
- Identify any shared interconnection facilities
- Provide contact representative information

## 4. Important Dates

- **Commercial Operation Date**: Required field (month/day/year format) but specific date not provided in this chunk
- **LTCR Term**: Years from in-service date of Network Upgrade (to be specified)
- **Document Date**: Reference to 20250729 (July 29, 2025) in source filename

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)**: Transmission Provider
- **MISO (Midcontinent Independent System Operator)**: Referenced in JTIQ Security section
- **Transmission Owner**: Party to interconnection agreement
- **Interconnection Customer/HILLGA Customer**: Applicant party

**Roles/Positions Referenced:**
- Interconnection Customer's contact person
- Representative of Interconnection Customer
- Transmission Provider

**Note**: No specific individual names are mentioned in this chunk; all references are to organizational roles and positions.

## 6. Links or References

**Internal Document References:**
- Attachment BB of the Tariff (Section 8.2)
- Attachment AV of the SPP Tariff
- Appendix 1 to Attachment BB
- Appendix 2 to Attachment BB
- Appendix A to GIA (Generator Interconnection Agreement)
- Appendix I of GIA

**External Resources:**
- "Generator Interconnection Business Guide and Practice" manual (posted on Transmission Provider's Generator Interconnection Study posting page on OASIS)
- Transmission Provider's OASIS posting page

**Model/Technical References:**
- PSS/E User Defined Model files (.dll, .lib, .obj)
- Stability model files (.dyr)
- Collector System Feeder Spreadsheet

## 7. Suggested Tags

- Generator Interconnection
- HILLGA (High Impact Large Load Assessment Generator)
- SPP Tariff
- Attachment BB
- Network Upgrades
- Point of Interconnection (POI)
- Site Control
- Generator Interconnection Agreement (GIA)
- HDPS (HILL Delivery Point Study)
- Network Resource Deliverability
- Maximum Injection Capability
- JTIQ (Joint Targeted Interconnection Queue)
- Long-Term Congestion Rights (LTCR)
- Interconnection Facilities
- Distribution Upgrades
- Renewable Energy Integration
- Transmission Planning
- RR696
- MMU Comments

## 8. Items That May Need Follow-Up

**Critical Information Gaps:**
1. **Specific deposit amounts and application fees**: Referenced but not detailed in this chunk
2. **Commercial Operation Date**: Template field requires completion
3. **JTIQ Security amounts**: Fields for Transmission Provider and MISO amounts are blank
4. **Project-specific technical data**: All template fields (nameplate capacity, injection capability, etc.) require completion
5. **Site control documentation**: Evidence required but format/specifics not detailed in this chunk

**Procedural Clarifications Needed:**
1. **Section 1 of Generator Interconnection Business Guide**: Submission procedures referenced but not included
2. **Section 8.2 of Attachment BB details**: Fee structure and site control specifics
3. **HDPS Agreement requirements**: Agreement identifier process
4. **Shared Interconnection Facilities coordination**: Process for identifying and coordinating with other projects

**Technical Documentation Requirements:**
1. **PSS/E model file standards**: Specific modeling requirements and validation procedures
2. **Collector System documentation format**: Spreadsheet and diagram specifications
3. **Primary frequency response operating range**: Specific requirements for storage resources
4. **Construction option selection criteria**: Options available and selection implications

**Stakeholder Coordination:**
1. **Higher-Queued Interconnection Customers**: Process for identifying and coordinating
2. **Transmission Owner responsibilities**: Division of interconnection facilities responsibilities
3. **MISO coordination**: For projects involving JTIQ upgrades

**Regulatory/Compliance Items:**
1. **Permits, Licenses, and Authorizations**: Specific requirements to be determined
2. **Point of Change of Ownership**: Legal and technical descriptions needed
3. **Contingent Facilities**: Conditions and contingencies to be defined