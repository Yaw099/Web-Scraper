# Final Combined Report

# CONSOLIDATED REGULATORY ANALYSIS REPORT
## RR696 SPP Comments 20250728.docx.txt - Combined Analysis

---

## 1. EXECUTIVE SUMMARY

This document represents SPP's comprehensive comments on Revision Request 696 (RR696), submitted by Caroline Chapman on July 28, 2025. RR696 proposes a transformative framework for integrating High Impact Large Loads (HILL) and establishing a new Conditional High Impact Large Load (CHILL) Service to enable faster large load interconnection while maintaining grid reliability.

**Key Framework Elements:**
- New HILL and CHILL definitions and service structures
- Accelerated interconnection processes for large loads (data centers, industrial facilities)
- Integration with Energy Storage Resources (ESRs), explicitly excluding ESRs from HILL classification
- Comprehensive amendments to SPP Open Access Transmission Tariff (OATT) across multiple attachments
- Detailed capacity accreditation methodology using projected MW values rather than nameplate capacity
- Special provisions for Western Area Power Administration (WAPA) Division interconnections

**Document Context:**
The comments span 25 chunks comprising tariff amendments, rate schedules, operational procedures, planning processes, and comprehensive reference tables. Updates highlighted in yellow (July 11, 2025) and teal (August 1, 2025) reflect iterative stakeholder feedback and MOPC alignment efforts.

---

## 2. KEY TOPICS

### A. HILL/CHILL Framework (Chunks 1, 22-23)
- **High Impact Large Load (HILL)** integration with expedited assessment procedures
- **Conditional High Impact Large Load (CHILL) Service** allowing conditional transmission service
- **Energy Storage Resource (ESR) Treatment**: Explicit exclusion from HILL classification; separate load assessment pending MOPC approval
- **HILLGA (High Impact Legacy Generation)** network studies and procedures
- **Short-circuit analysis** consistent with HILL methodology
- **Generator Interconnection Agreement (GIA)** requirements with special WAPA appendix

### B. Capacity and Resource Management (Chunks 1, 17-20, 23)
- **Capacity Accreditation Methodology**: Maximum injection limits based on projected capacity accreditation MW values
- **Resource Day Ahead Must-Offer Requirements**: Alignment with Attachment AE provisions
- **Energy Storage Resource Load Assessment**: Integration pending MOPC approval (July 2025)
- **Multi-Configuration Resources (MCRs)**: Operating reserve eligibility restrictions during transitions (>30 minutes)
- **Resource Commitment Procedures**: Market vs. Self vs. Reliability status categories
- **Demand Response Classification**: Dispatchable vs. non-dispatchable treatment for resource adequacy

### C. Market Operations (Chunks 16-20)
- **Day-Ahead Market SCUC Algorithm**: Security Constrained Unit Commitment with co-optimization
- **Real-Time Balancing Market (RTBM)**: Operating procedures and resource dispatch
- **Must-Offer Requirements**: 90% threshold compliance monitoring by Market Monitor
- **Manual Commitment Authority**: Reliability Coordinator procedures for security constraints
- **Local Reliability Issues vs. Local Emergency Conditions**: Distinct compensation mechanisms
- **Reliability Unit Commitment (RUC)**: Day-Ahead and Intra-Day capacity adequacy processes
- **Non-Conforming Load**: Registration requirements for loads ≥50 MW with hourly forecasting obligations

### D. Transmission Planning (Chunks 7-8, 21-23)
- **SPP Transmission Expansion Plan (STEP)**: Comprehensive planning framework with 10+ proposal sources
- **Stakeholder Engagement**: 10-day notice requirements, quarterly reporting, annual Board presentations
- **Transmission Material Modification**: Criteria for evaluating permanent facility changes (>12 months)
- **Non-Jurisdictional Generator Interconnections**: Study procedures and affected system analysis
- **ITP (Integrated Transmission Planning)**: Load forecasting (50-50 probability), persistent operational needs assessment
- **Delivery Point Management** (BP 7850): Addition, Modification, and Retirement evaluation processes
- **Aggregation of Requests**: Consolidation of proximity-based delivery point requests

### E. Revenue Requirements and Rate Structures (Chunks 2-6, 9-15, 23-25)
- **Schedule 1**: Scheduling, System Control and Dispatch Service rates
- **Schedule 2**: Reactive Supply and Voltage Control compensation ($2.26/MVArh)
- **Schedule 11**: Base Plan Zonal and Region-wide Charges
- **Point-to-Point Transmission Service**: Firm and Non-Firm rates across all zones
- **Network Integration Transmission Service**: Rate structures and Load Ratio Share calculations
- **Zonal ATRR (Annual Transmission Revenue Requirements)**: 19+ zones with sub-zone allocations
- **Formula Rate Protocols**: Multiple transmission owner formula rates with annual update schedules
- **Balanced Portfolio Reallocation**: Adjustments to Point-to-Point rates
- **Revenue Crediting**: Schedule 7 and 8 revenue adjustments and Attachment AU distributions

### F. Operational Requirements (Chunks 16-17, 21)
- **Meter Agent Requirements**: Attachment AM agreement execution prior to performing functions
- **ICCP Node Connectivity**: Dual-node requirements for TOPs and GOPs (240-second reconnection capability)
- **Emergency Operating Plans (EOPs)**: Load shedding procedures and natural gas prioritization
- **Transmission Service Timing**: Next-Hour Market to long-term firm service request/response deadlines
- **Peak Period Definitions**: HE 0700-2200 Central Time (excluding weekends and NERC holidays)

### G. Cost Recovery and Compensation (Chunks 4-5, 17-18, 20)
- **Canceled Project Cost Recovery**: 12-month recovery periods for AEP ($414,465), Sunflower ($718,359)
- **ILTCR (Incremental Long-Term Congestion Rights)**: 10-20 year compensation for various upgrade types
- **Creditable Upgrades**: Revenue allocation to Upgrade Sponsors
- **Regional vs. Local Cost Collection**: Distinct mechanisms for reliability-driven commitments
- **Interregional Project Compensation**: Revenue distribution to planning regions
- **JTIQ ATRR Balance**: Monthly charges/credits based on one-twelfth annual amounts

### H. Loss Compensation and Allocation (Chunk 7)
- **Injection Loss Factor (ILF) and Delivery Loss Factor (DLF)** methodologies
- **Network Integration Transmission Service** loss responsibility
- **Point-to-Point Transmission Service** loss calculations
- **Integration with Energy and Operating Reserve Markets** (Attachment AE)

---

## 3. DECISIONS OR ACTIONS

### A. Approved/Implemented Changes

1. **HILL/CHILL Framework Amendments**
   - Amendment of Attachment BB language for Energy Storage Resource Load Assessment (pending July 2025 MOPC approval)
   - Modification of maximum injection limit calculation to use projected capacity accreditation MW value
   - Addition of Attachment BB Appendix 3 for WAPA Division GIA scenarios
   - Exclusion of ESRs from HILL definition

2. **Rate Calculation and Posting**
   - Reactive Compensation Rate established at **$2.26 per MVArh**
   - Formula rate posting deadlines:
     - **September 1**: Prairie Wind Formula Rate ATRR
     - **October 1**: South Central MCN, Kansas Power Pool, NEET Southwest, SPS Formula Rates
     - **October 15**: Evergy Kansas Central Formula Rate
     - **December 15**: NPPD Formula Rate
     - **June 15**: Tri-State Formula Rate
   - Effective dates: January 1 (most) or July 1 (Tri-State) following year

3. **Cost Recovery Authorization**
   - **American Electric Power**: $3,264,402.55 recovery (April 1, 2018 commencement) plus $414,465 (March 1, 2019)
   - **Sunflower Electric**: $718,359 recovery (January 1, 2024 commencement)
   - 12-month equal monthly installments with interest per 18 C.F.R. § 35.19a(a)(2)(iii)

4. **Market Operations Procedures**
   - Market Monitor verification required for all manual commitments (Section 6.1.2.1)

---

# Partial Chunk Reports

# Chunk 1 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document contains SPP's comments on Revision Request 696 (RR696), which aims to establish a framework for integrating and operating High Impact Large Loads (HILL) and a new Conditional High Impact Large Load (CHILL) Service. The submission, dated July 28, 2025, by Caroline Chapman of SPP, proposes comprehensive changes to SPP's governing documents to enable faster interconnection of large loads while maintaining grid reliability. The framework addresses planning, market, and operational aspects through amendments to the SPP Open Access Transmission Tariff, including new definitions, assessment procedures, and service provisions. Updates highlighted include language amendments from July 11 and August 1, 2025, covering Energy Storage Resource Load Assessment integration, capacity accreditation methodology, and alignment with NERC standards.

## 2. Key Topics

- **High Impact Large Load (HILL) Integration Framework**: Accelerated interconnection process for large loads with integrated design, study, registration, and operations
- **Conditional High Impact Large Load (CHILL) Service**: New service allowing large loads to interconnect with conditional transmission service
- **Energy Storage Resource (ESR) Treatment**: Clarification that ESRs are not considered HILLs; separate load assessment language pending MOPC approval
- **Capacity Accreditation Methodology**: Maximum injection limit based on projected capacity accreditation MW value rather than generator nameplate value for HILLGA
- **Western Area Power Administration Integration**: Special GIA appendix (Attachment BB Appendix 3) for when WAPA Division is a party
- **Resource Day Ahead Must Offer Requirements**: Alignment with existing requirements for Resources in Attachment AE
- **Cost Recovery and Rate Structures**: Updates to Schedule references (7 vs. 8) throughout tariff provisions
- **Load Ratio Share Calculations**: Monthly demand charges for network loads across different zones

## 3. Decisions or Actions

### Approved Changes:
- Amendment of Attachment BB language to include Energy Storage Resource Load Assessment (pending July 2025 MOPC approval)
- Modification of maximum injection limit calculation methodology to use projected capacity accreditation MW value
- Addition of Attachment BB Appendix 3 for WAPA Division GIA scenarios
- Updates to "shall" usage for regulatory compliance precision
- Grammatical corrections and enhancements throughout documentation

### Pending Actions:
- MOPC approval of Energy Storage Resource Load Assessment language (July 2025)
- Implementation of new CHILL Service provisions
- Integration of revised HILL definition excluding ESRs
- Alignment of Resource Day Ahead Must Offer requirements

## 4. Important Dates

- **July 11, 2025**: SPP Comments highlighted in yellow submitted
- **July 2025**: MOPC meeting for Energy Storage Resource Load Assessment language approval
- **July 28, 2025**: Caroline Chapman submission date for this comment form
- **August 1, 2025**: SPP Comments highlighted in Teal submitted
- **Calendar Year References**: Various provisions reference "previous calendar year" for revenue adjustments and billing determinants

## 5. Organizations and People Mentioned

### People:
- **Caroline Chapman**: Submitter, SPP (cchapman@spp.org)

### Organizations:
- **SPP (Southwest Power Pool)**: Transmission Provider and primary organization
- **Western Area Power Administration (WAPA) Division**: Mentioned for special GIA requirements
- **MOPC (Markets and Operations Policy Committee)**: Approval body for pending language
- **NERC**: Referenced for standards compliance
- **American Electric Power**: Specific revenue requirement calculation methodology (Zone 1)
- **Southwestern Public Service**: Specific revenue requirement calculation methodology (Zone 11)
- **FERC/Commission**: Referenced as regulatory filing authority
- **Transmission Owners**: Various entities with zone-specific rate structures

## 6. Links or References

### Internal Document References:
- **Attachment BB**: HILL/HILLGA language and assessment procedures
- **Attachment BB Appendix 3**: New appendix for WAPA Division GIA
- **Attachment AE**: Resource Day Ahead Must Offer requirements
- **Attachment H**: Zonal Annual Transmission Revenue Requirement (ATRR) specifications and tables
- **Attachment J**: Section IV.A reallocation provisions
- **Attachment L**: Schedule 7/8 revenue distribution
- **Attachment AU**: Revenue distribution and allocation provisions
- **Schedule 1-A**: Tariff Administration Services
- **Schedule 1-A1**: Transmission Administration Service
- **Addendum 1 (Attachment H)**: American Electric Power rate calculations
- **Addendum 5 (Attachment H)**: Southwestern Public Service rate calculations
- **Addendum 1 (Schedule 1-A)**: Formula rate template

### Tariff Sections:
- Part I: Common Service Provisions (Section 1.1 Definitions)
- Part II: Point-to-Point Transmission Service
- Part III: Network Integration Transmission Service (Section 34.1, 34.2, 34.3)
- Part IV: Referenced but not detailed

### External References:
- NERC standards (mentioned for compliance)

## 7. Suggested Tags

- RR696
- High Impact Large Load (HILL)
- Conditional High Impact Large Load (CHILL)
- Load Interconnection
- Energy Storage Resources (ESR)
- Generator Interconnection Agreement (GIA)
- Capacity Accreditation
- Transmission Service
- WAPA
- Grid Reliability
- Market Efficiency
- NERC Compliance
- Tariff Amendment
- MOPC
- Network Integration Transmission Service
- Point-to-Point Transmission Service
- Revenue Requirement
- Load Ratio Share
- Transmission Planning

## 8. Items That May Need Follow-Up

### Immediate Follow-Up Required:
1. **MOPC Approval Status**: Verify approval of Energy Storage Resource Load Assessment language from July 2025 MOPC meeting
2. **Schedule Numbering Inconsistency**: Document shows changes between "Schedule 7" and "Schedule 8" - clarify correct schedule reference throughout tariff
3. **CHILL Service Definition Completion**: The definition references "as defined in Attachment" but appears incomplete - verify full definition location

### Technical Clarifications Needed:
4. **ESR vs. HILL Distinction**: Confirm operational impacts of excluding Energy Storage Resources from HILL definition
5. **Capacity Accreditation Methodology**: Details on how "projected capacity accreditation MW value" will be calculated and updated for HILLGA
6. **WAPA Division GIA Process**: Operational procedures for Attachment BB Appendix 3 implementation
7. **Incomplete Text**: Section 34.1 shows "and of this Tariff" with apparent missing reference - verify correct part number

### Administrative Follow-Up:
8. **Cost-Benefit Quantification**: The RR lists several quantitative benefits (reduced planning reserves, avoided upgrades, curtailment reduction, study efficiency) - verify if supporting data/analysis exists
9. **Regulatory Filing Timeline**: Confirm FERC filing schedule for these tariff amendments
10. **Stakeholder Comment Integration**: Track if additional stakeholder comments beyond SPP's submission need incorporation

### Compliance Verification:
11. **NERC Standards Alignment**: Verify specific NERC standards referenced and ensure full compliance mapping
12. **Grandfathered Agreements**: Confirm treatment of existing agreements under new HILL/CHILL framework (referenced in Schedule 1-A1 billing determinants)
13. **Rate Cap Compliance**: Schedule 1-A mentions $0.515 rate cap - confirm if HILL/CHILL impacts this calculation

---

**Document Notes**: This appears to be chunk 1 of 25, suggesting substantial additional content exists that may contain critical details, implementation procedures, and technical specifications not visible in this excerpt.

---

# Chunk 2 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document is chunk 2 of 25 from SPP (Southwest Power Pool) comments regarding regulatory filing RR696, dated January 28, 2025. The content details technical tariff provisions for transmission service pricing and billing, specifically covering:

- **Schedule 1**: Scheduling, System Control and Dispatch Service rates and calculations
- **Schedule 2**: Reactive Supply and Voltage Control from Generation compensation methodology
- **Schedule 11**: Base Plan Zonal Charge and Region-wide Charge structure

The content is highly technical, establishing formulas, billing determinants, and rate structures for various transmission service types, including Point-to-Point and Network Integration services. It differentiates between on-peak and off-peak periods and establishes compensation mechanisms for Qualifying Generators (QGs) providing reactive power services.

## 2. Key Topics

1. **Transmission Service Rate Structures**
   - Point-to-Point Transmission Service (Firm and Non-Firm)
   - Network Integration Transmission Service
   - Through and Out vs. Sinking transactions

2. **Schedule 1 Billing Methodology**
   - Calculation based on capacity reserved (MW) and zonal rates
   - Different rates for on-peak/off-peak periods and various timeframes (hourly, daily, weekly, monthly, yearly)
   - Multi-owner zone rate calculations

3. **Reactive Power Compensation (Schedule 2)**
   - Reactive Compensation Rate (RCR) set at $2.26 per MVArh
   - Qualifying Generator (QG) compensation methodology
   - Dead Band power factor of 0.95

4. **Rate Periods Definition**
   - On-Peak: HE 0700-2200 Central Prevailing Time on weekdays (excluding NERC holidays)
   - Off-Peak: Saturdays, Sundays, NERC holidays, and non-peak hours

5. **Revenue Distribution and Adjustments**
   - Point-to-Point revenue credits
   - Zonal revenue allocation
   - Treatment of jointly owned units

6. **Base Plan Charges (Schedule 11)**
   - Zonal and Region-wide charges
   - Application to Eastern Interconnection only
   - Western-UGP exemptions

## 3. Decisions or Actions

**Established Rates:**
- Reactive Compensation Rate: $2.26 per MVArh (subject to periodic review)

**Billing Determinations:**
- Schedule 2 charges to be billed in the next billing cycle after sufficient data collection
- Monthly charges based on actual data with no true-ups

**Exemptions:**
- Western-UGP exempt from Region-wide Charge under Schedule 11 per Section 39.3(e)
- Federal Power-Western-UGP Statutory Load Obligations excluded from Zone 19 calculations

**Rate Adjustment Protocols:**
- Transmission Provider shall adjust Schedule 1 revenue requirements for Point-to-Point revenues
- Exception for Transmission Owners with formula rates that auto-update annually

## 4. Important Dates

**No specific calendar dates are mentioned in this chunk**, but the following timeframes are referenced:

- **Calendar year** basis for various calculations
- **Monthly** billing cycles
- **12 monthly peaks** used for yearly rate calculations
- **Prior calendar year** data used for Schedule 1 rate computations
- **Same month** data requirements for RPOD and RC calculations

**Peak Definitions:**
- **On-Peak Hours**: HE 0700 through HE 2200 Central Prevailing Time
- **260 days** (on-peak days per year)
- **365 days** (total days for off-peak daily rate)
- **4160 hours** (on-peak hours per year)
- **8760 hours** (total hours per year)

## 5. Organizations and People Mentioned

**Organizations:**

1. **SPP (Southwest Power Pool)** - Transmission Provider
2. **Transmission Owners** - Multiple entities operating tariff facilities
3. **Transmission Customers** - Service recipients
4. **Network Customers** - Specific customer class
5. **NERC** (North American Electric Reliability Corporation) - Referenced for holiday definitions
6. **Commission** (likely FERC - Federal Energy Regulatory Commission) - Regulatory approval authority
7. **Western-UGP** - Specific transmission zone/entity with exemptions

**Entities/Roles:**
- Qualifying Generators (QGs)
- Balancing Authority Area operators
- Zone 19 operators

**No individual people are mentioned in this content.**

## 6. Links or References

**Internal Document References:**

1. **Revenue Requirements and Rates File (RRR File)**
   - Schedule 1 tab
   - Zonal Sch 1 tab
   - Posted on SPP website

2. **Tariff Sections:**
   - Section 31.4 (Network Load designation)
   - Section 39.3(e) (Western-UGP exemption)
   - Part V (Base Plan charges)
   - Attachment J (allocation methodology)

3. **Schedule Cross-References:**
   - Schedule 1 Table 1 and Table 2
   - Schedule 2 (Reactive Supply and Voltage Control)
   - Schedule 11 (Base Plan Zonal and Region-wide Charges)

4. **External References:**
   - NERC holidays
   - Commission-approved filings

**Website:** SPP website (specific URL not provided)

**Source Document:** RR696 SPP Comments 20250728.docx.txt

## 7. Suggested Tags

**Primary Tags:**
- Transmission Tariff
- Rate Structures
- SPP
- RR696
- Regulatory Filing

**Technical Tags:**
- Schedule 1
- Schedule 2
- Schedule 11
- Point-to-Point Service
- Network Integration Service
- Reactive Power
- Revenue Requirements

**Functional Tags:**
- Billing Determinants
- Zonal Rates
- Peak/Off-Peak Pricing
- Generator Compensation
- Formula Rates

**Regulatory Tags:**
- FERC
- Tariff Amendment
- Revenue Distribution
- Cost Recovery

## 8. Items That May Need Follow-Up

### Critical Follow-Up Items:

1. **Reactive Compensation Rate Review**
   - Schedule 2 states RCR "may be periodically reviewed" to ensure it reflects upper end of reasonable costs
   - **Action needed:** Establish review timeline/trigger criteria

2. **Schedule 11 Incomplete Text**
   - Section II.A. ("Calculation of Annual Transmission Revenue Requirement") text cuts off mid-sentence
   - **Action needed:** Obtain complete text for subsections 1 and 2 limitations

3. **Western-UGP Exemption Details**
   - Reference to Section 39.3(e) for exemption rationale
   - **Action needed:** Review cited section for exemption justification and potential impacts

### Administrative Follow-Up:

4. **RRR File Website Posting**
   - Verify current posting and accessibility on SPP website
   - Confirm all referenced tabs are available and current

5. **Schedule 2 Billing Cycle Implementation**
   - "Next billing cycle" timing after data collection
   - **Action needed:** Clarify specific timing requirements for data availability and billing

6. **Multi-Owner Zone Rate Calculations**
   - Complex summation methodology in Schedule 1.C
   - **Action needed:** Verify calculation procedures and ensure transparency

### Technical Clarifications Needed:

7. **Dead Band Calculation Methodology**
   - Power factor of 0.95 for RPID calculations
   - **Action needed:** Confirm metering and calculation accuracy requirements

8. **Zonal Revenue Mismatch Resolution**
   - Schedule 2.D.2 addresses revenue collection discrepancies
   - **Action needed:** Establish tolerance thresholds and reconciliation procedures

9. **Joint Ownership Compensation Distribution**
   - Schedule 2.E designates single entity for payment
   - **Action needed:** Ensure clear contractual obligations among joint owners

10. **Formula Rate Update Coordination**
    - Schedule 1.D.1 exemption for auto-updating formula rates
    - **Action needed:** Track which Transmission Owners qualify and ensure consistency

### Data/Documentation Follow-Up:

11. **Point-to-Point Revenue Credits**
    - Table 2 posting requirements for existing credits
    - **Action needed:** Verify Table 2 accuracy and update frequency

---

# Chunk 3 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary
This document chunk (3 of 25) from RR696 SPP Comments (dated January 28, 2025) contains detailed tariff language governing transmission revenue requirements, billing mechanisms, and rate structures within the SPP (Southwest Power Pool) system. The content primarily addresses:
- Revenue adjustments for transmission owners based on point-to-point transmission service revenues
- Base Plan Zonal Charges and Region-wide Charges for network customers and transmission owners
- FERC Assessment Charge methodology (Schedule 12)
- Annual Transmission Revenue Requirement framework (Attachment H)

The text appears to be regulatory tariff language defining how transmission costs are allocated and recovered across different zones and customer classes within the SPP footprint.

## 2. Key Topics
- **Revenue Requirement Adjustments**: Methodology for reducing transmission revenue requirements based on previous calendar year point-to-point revenues
- **Formula Rate vs. Stated Rate Treatment**: Different adjustment mechanisms for transmission owners using formula rates versus stated rates
- **Zonal Charging Mechanisms**: Base Plan Zonal Charges calculated using Load Ratio Shares and monthly resident load determinations
- **Region-wide Charges**: Allocation methodology across SPP regions with specific provisions for Zones 1-19
- **Special Provisions for Western-UGP**: Federal service exemptions and statutory load obligations
- **FERC Assessment Recovery**: Schedule 12 mechanism for recovering FERC regulatory assessments
- **Base Plan Upgrades**: Cost recovery distinction between upgrades with NTC (Notification to Construct) issued before vs. after June 19, 2010
- **SATOA Dispatches**: Revenue treatment for dispatches into Energy and Operating Reserve Markets

## 3. Decisions or Actions
No specific decisions or action items are explicitly identified in this content chunk. This appears to be existing tariff language rather than meeting minutes or decision documents. However, the document structure suggests:
- Implementation of revenue requirement calculations must follow prescribed formulas
- Transmission Provider must post FACR calculations on SPP website prior to March 1 annually
- Billing procedures must follow Section 7 of the Tariff

## 4. Important Dates
- **June 19, 2010**: Critical date distinguishing Base Plan Upgrades treatment (NTC issued before vs. after this date affects zonal charge allocation)
- **March 1 (annually)**: Deadline for Transmission Provider to calculate and post FERC Assessment Charge Rate (FACR) on SPP website; effective date for FACR
- **Previous calendar year**: Reference period for point-to-point revenue adjustments
- **October 1, 2015**: Separation date for Region-wide ATRR for Network Upgrades (Table 2-A vs. Table 2-B)

## 5. Organizations and People Mentioned
### Organizations:
- **SPP (Southwest Power Pool)**: Transmission Provider
- **FERC (Federal Energy Regulatory Commission)**: Regulatory authority assessing charges under Part 382
- **Western-UGP**: Entity with Federal Service Exemptions and Statutory Load Obligations
- **Transmission Owners**: Multiple entities across various zones (specific identities referenced in external tables)
- **Network Customers**: Service recipients subject to charges
- **Upgrade Sponsors**: Entities referenced in Attachment Z2

### People:
None specifically mentioned in this chunk.

## 6. Links or References
### Internal Tariff References:
- **Schedule 9**: Network Integration Transmission Service
- **Schedule 11**: Base Plan Upgrades charges (Sections II.A, III, Section III.C.1.a, Section III.C.3)
- **Schedule 12**: FERC Assessment Charge
- **Section 7**: Tariff billing procedures
- **Section 31.3**: Network Load not physically interconnected provisions
- **Section 34.5**: Transmission System load determination
- **Section 34.9**: Federal-Power Southwestern identification
- **Section 39.2**: Bundled Retail and Grandfathered Loads applicability
- **Attachment AU**: Revenue distribution (Sections IV and V)
- **Attachment H**: Annual Transmission Revenue Requirement tables (Table 1, Table 2-A, Table 2-B, Table 3 Section 1)
- **Attachment J**: Reallocation provisions (Section IV.A)
- **Attachment Z2**: Upgrade Sponsor payment provisions

### External References:
- **FERC Form 582**: Annual report of megawatt-hours transmitted in interstate commerce
- **FERC Part 382**: Regulations governing FERC assessments
- **RRR File (Revenue Requirements and Rates File)**: Posted on SPP website containing specific ATRR values
- **SPP website**: Public posting location for rates and calculations

## 7. Suggested Tags
- Transmission_Revenue_Requirements
- Rate_Design
- SPP_Tariff
- FERC_Assessment
- Zonal_Charges
- Network_Integration_Service
- Point-to-Point_Service
- Base_Plan_Upgrades
- Formula_Rates
- Load_Ratio_Share
- Western_UGP
- Cost_Allocation
- Revenue_Crediting
- NTC_Notification_to_Construct
- Region-wide_Charges
- ATRR
- Schedule_11
- Schedule_12
- Attachment_H

## 8. Items That May Need Follow-Up
1. **Table References**: Multiple tables referenced (Table 1, Table 2-A, Table 2-B, Table 3) but not included in this chunk—need to verify actual values and ensure consistency
2. **RRR File Updates**: Annual updates to Revenue Requirements and Rates File require monitoring and verification
3. **FACR Calculation Verification**: Annual March 1 posting requires verification that calculation follows prescribed formula correctly
4. **Western-UGP Federal Service Exemption**: Special provisions require clarification on scope and applicability criteria
5. **June 19, 2010 NTC Date Bifurcation**: Need to verify all Base Plan Upgrades are correctly classified as pre- or post-this date
6. **Section II.A.1 vs II.A.2 Application**: Verification needed that each Transmission Owner is correctly classified as formula rate with/without annual update or stated rate
7. **Zone 10 and Zone 19 Special Calculations**: Unique load determination methods require verification of implementation
8. **Balance Reconciliation**: Schedule 12 balance true-up mechanism (FECy – Balancey-1) requires annual reconciliation audit
9. **Missing Content**: Document indicates this is "chunk 3 of 25"—need complete document for full context
10. **SATOA Revenue Treatment**: Clarification may be needed on how SATOA (Service Agreement for Transmission Owner's Attachment) dispatch revenues are tracked and credited

---

# Chunk 4 Analysis

# REGULATORY ANALYSIS REPORT
## RR696 SPP Comments 20250728.docx.txt - Chunk 4 of 25

---

## 1. Executive Summary

This document section details the Southwest Power Pool's (SPP) Annual Transmission Revenue Requirements (ATRR) calculation methodology and recovery procedures under their tariff. It establishes formulas for region-wide and zonal transmission cost allocation, specifies procedures for formula rate updates, and outlines special provisions for specific transmission owners (particularly Southwestern Public Service Company and American Electric Power). The content includes detailed requirements for cost recovery of canceled transmission projects and coordination agreements.

---

## 2. Key Topics

- **Region-wide ATRR Calculation Components:**
  - Base Plan Region-wide ATRR
  - Balanced Portfolio Region-wide ATRR
  - Upgrade Sponsor payments (pre and post October 1, 2015)
  - Interregional Planning Region ATRR
  - JTIQ (Joint Transmission Investment Queue) Upgrades
  - Coordination agreement transmission upgrades

- **Revenue Requirement Update Procedures:**
  - Commission filing requirements
  - Formula rate processes for Transmission Owners
  - Annual update procedures and website posting requirements

- **Cost Allocation and Recovery:**
  - Schedule 7, 8, 9, and 11 revenue treatment
  - Point-to-Point Transmission Service revenues
  - Energy and Operating Reserve Markets dispatch revenues
  - Base Plan Upgrade allocation per Attachment J

- **Specific Transmission Owner Provisions:**
  - SPS (Zone 11) formula rate specifications
  - American Electric Power canceled project cost recovery

---

## 3. Decisions or Actions

### Cost Recovery Approvals:

1. **American Electric Power Canceled Projects Recovery:**
   - Approved recovery of $3,264,402.55 for canceled projects:
     - $3,068,489.38 for Multi-Shipe Road - East Rogers - Kings River 345 kV project (Network Upgrades 10656, 10659, 10660)
     - $195,913.17 for Line - Georgia Pacific - Keatchie 138 kV Ckt 1 project (Network Upgrade 10616)
   - Recovery period: 12 months in equal monthly installments with interest
   - Interest calculated per 18 C.F.R. § 35.19a(a)(2)(iii)

2. **Additional AEP Canceled Project:**
   - $414,465 for Line – Chapel Hill REC – Welsh Reserve 138 kV Ckt 1 project (Network Upgrade 50697) and Line – Welsh Reserve - Wilkes 138 kV Ckt 1

### Process Requirements:

- Transmission Provider must follow special procedures for updating Transmission Owner revenue requirements
- Revenue requirements must be posted on SPP website
- Joint informational filings required between SPP and AEP upon full cost recovery
- Property sale/disposition revenues must be credited against ATRR

---

## 4. Important Dates

| Date | Event/Requirement |
|------|-------------------|
| **October 1, 2015** | Dividing line for transmission service treatment and Upgrade Sponsor payment methodology |
| **October 1 (annual)** | SPS formula calculation results posting deadline |
| **October 31 (annual)** | American Electric Power ATRR posting deadline |
| **January 1 (annual)** | Effective date for new ATRR calculations (following year) |
| **April 1, 2018** | Commencement of AEP recovery for canceled Multi-Shipe Road and Georgia Pacific projects ($3,264,402.55) |
| **March 1, 2019** | Commencement of AEP recovery for canceled Chapel Hill REC – Welsh Reserve project ($414,465) |

---

## 5. Organizations and People Mentioned

### Organizations:

**Primary Entities:**
- Southwest Power Pool, Inc. (SPP) - Transmission Provider
- American Electric Power (AEP) - Transmission Owner
- Southwestern Public Service Company (SPS) - Transmission Owner
- Associated Electric Cooperative, Inc.

**Regulatory:**
- Federal Energy Regulatory Commission (FERC/Commission)

**Corporate:**
- Xcel Energy Operating Companies

### Zones Referenced:
- Zones 1 through 19 (transmission service zones)
- Zone 11 (specific to SPS)

### No Individual Names Mentioned

---

## 6. Links or References

### Tariff Attachments and Schedules:
- Attachment H (current document)
- Attachment Z2 (Upgrade Sponsor payment determinations)
- Attachment O (coordination agreements, Addendum 1)
- Attachment J (Base Plan Upgrade allocation, Section VIII)
- Attachment L (Point-to-Point transmission revenue allocation)
- Attachment AU (revenue distribution, Sections IV and V)
- Attachment O – SPS of Xcel Energy OATT
- Addendum 1 to Attachment H (AEP formula rate)
- Schedule 7, 8, 9, 11 (various transmission service schedules)

### Files and Data Sources:
- RRR File (Revenue Requirement File) posted on SPP website
- SPS OASIS website
- SPP website

### Regulatory References:
- 18 C.F.R. § 35.19a(a)(2)(iii) (interest rate regulations)

### Specific Projects/Agreements:
- Morgan Transformer Project (Cost Sharing and Usage Agreement)
- Blackberry Substation Upgrade (Cost and Usage Agreement)
- Network Upgrades: 10656, 10659, 10660, 10616, 50697

---

## 7. Suggested Tags

### Primary Tags:
- Transmission Revenue Requirements
- Cost Recovery
- Formula Rates
- FERC Tariff
- Annual Transmission Revenue Requirements (ATRR)

### Secondary Tags:
- Southwest Power Pool
- American Electric Power
- Southwestern Public Service Company
- Canceled Projects
- Network Upgrades
- Point-to-Point Transmission
- Revenue Allocation
- Interregional Planning
- JTIQ Upgrades
- Base Plan Upgrades
- Balanced Portfolio

### Regulatory Tags:
- FERC Compliance
- Rate Filing
- Cost Allocation
- Informational Filing

---

## 8. Items That May Need Follow-Up

### Immediate Follow-Up Required:

1. **AEP Canceled Project Recovery Tracking:**
   - Monitor 12-month recovery period completion for $3,264,402.55 (from April 1, 2018)
   - Monitor recovery for $414,465 (from March 1, 2019)
   - Verify joint informational filings made to FERC upon full recovery
   - Confirm RRR File updates replacing recovered amounts with $0

2. **Property Disposition Credits:**
   - Track any sales/dispositions of property related to canceled projects
   - Ensure revenue credits applied to AEP ATRR
   - Verify joint informational filings for property sales

### Periodic Monitoring:

3. **Annual Update Deadlines:**
   - SPS formula results posting by October 1 each year
   - AEP ATRR posting by October 31 each year
   - Effective date implementation on January 1

4. **Website Posting Compliance:**
   - Verify RRR File updates on SPP website
   - Confirm SPS postings on OASIS website
   - Check public review and comment availability

### Regulatory Compliance:

5. **Commission Filing Requirements:**
   - Track any new or amended revenue requirement filings
   - Monitor simultaneous filings by Transmission Owners and Provider
   - Verify cost support documentation accompanies filings

6. **Formula Rate Process Verification:**
   - Confirm successful completion of approved annual formula rate update procedures
   - Review populated formula rates for public comment compliance
   - Verify applicable protocols and procedures followed

### Documentation Review:

7. **Coordination Agreement Implementation:**
   - Verify revenue requirements for Morgan Transformer Project
   - Confirm Blackberry Substation Upgrade costs
   - Review Cost Sharing and Usage Agreements with Associated Electric Cooperative

8. **Interest Calculation Accuracy:**
   - Verify interest rates applied per 18 C.F.R. § 35.19a(a)(2)(iii)
   - Confirm monthly installment calculations for canceled project recovery

---

# Chunk 5 Analysis

# Structured Analysis Report: RR696 SPP Comments (Chunk 5 of 25)

## 1. Executive Summary

This document section details cost recovery mechanisms for canceled network upgrade projects by multiple utilities under SPP's tariff structure. It outlines specific recovery amounts, timelines, and filing requirements for American Electric Power ($414,465), Sunflower Electric Power Corporation ($718,359), and establishes protocols for Southwestern Power Administration's capacity calculations. The section also defines various types of network upgrades (Sponsored, Service, Generation Interconnection, Zonal Reliability, and JTIQ) and their associated cost allocation and compensation mechanisms, including ILTCR (Incremental Long-Term Congestion Rights) eligibility.

## 2. Key Topics

- **Canceled Project Cost Recovery**: Mechanisms for recovering costs from canceled network upgrade projects over 12-month periods
- **ATRR (Annual Transmission Revenue Requirement)**: Specific amounts and allocation methods for multiple utilities
- **Network Upgrade Classifications**: Five categories with distinct cost allocation methods:
  - Sponsored Upgrades
  - Service Upgrades
  - Generation Interconnection Related Network Upgrades
  - Zonal Reliability Upgrades
  - JTIQ Upgrades
- **ILTCR Compensation**: Eligibility criteria and terms (10-20 years) for various upgrade types
- **Revenue Credits**: Allocation for Creditable Upgrades
- **Property Disposition**: Credit mechanisms if property is sold during recovery period

## 3. Decisions or Actions

- **AEP Recovery**: $414,465 to be recovered in equal monthly installments over 12 months for two canceled projects (Network Upgrades 50697 and 11423)
- **Sunflower Recovery**: $718,359 to be recovered over 12 months for canceled Device – Russell 115 kV (Network Upgrade 122803), commencing January 1, 2024
- **Joint Informational Filings**: Required by SPP and respective utilities to notify Commission of:
  - Final recovery amounts (including interest)
  - Property sale/disposition and associated credits
- **RRR File Updates**: Amounts to be reflected until fully recovered, then replaced with $0
- **SWPA NITS Calculation**: Ratio-based formula using 872,000 kilowatts total capacity benchmark

## 4. Important Dates

- **January 1, 2024**: Commencement date for Sunflower Electric Power Corporation ATRR recovery
- **April 2017**: Reference date for Formula Rate Posting Information Notification List
- **January 1, 2008**: Cutoff date for Zonal Reliability Upgrades included in 2005 SPP Transmission Expansion Plan
- **12-month recovery period**: Standard timeline for cost recovery
- **20-year periods**: Standard plant life for Sponsored Upgrade calculations
- **10-20 years**: Range for ILTCR term specifications

## 5. Organizations and People Mentioned

### Organizations:
- **American Electric Power (AEP)**
- **Sunflower Electric Power Corporation**
- **Southwestern Power Administration (SWPA)**
- **Western-UGP**
- **Southwest Power Pool (SPP)** - Transmission Provider
- **Federal Energy Regulatory Commission (FERC/Commission)**

### Roles Referenced:
- Transmission Provider
- Transmission Owner
- Transmission Customer
- Project Sponsor
- Interconnection Customer
- JTIQ Generation Interconnection Customer
- Market Participant

## 6. Links or References

### External Links:
- **http://www.spp.org/stakeholder-center/exploder-lists/** - Formula Rate Posting Information Notification List access

### Internal Document References:
- **Attachment H** (Table 1, Column 3, various sections)
- **Attachment J** (Sections V, VII, VIII)
- **Schedule 11** - Recovery mechanism
- **Attachment Z1** - Service Upgrade cost allocation
- **Attachment Z2** - ILTCR and revenue credit provisions (Sections I, II, IV)
- **Attachment V** - Generation interconnection Network Upgrade allocation
- **Attachment L** - Treatment of Revenues
- **Attachment AV** - JTIQ ATRR Balance calculations
- **Attachment AH** - Market Participant requirements
- **Schedule 1 of Attachment J** - Sponsored Upgrade Agreement details
- **Addendum 20 of Attachment H**
- **Rate Schedule NFTS-13A** (Section 2.3.3)

### Regulatory References:
- Federal Power Act
- Commission policy on periodic charges
- 2005 SPP Transmission Expansion Plan

## 7. Suggested Tags

`cost-recovery`, `canceled-projects`, `ATRR`, `network-upgrades`, `SPP-tariff`, `FERC-filing`, `revenue-credits`, `ILTCR`, `American-Electric-Power`, `Sunflower-Electric`, `Southwestern-Power-Administration`, `transmission-revenue`, `sponsored-upgrades`, `service-upgrades`, `generation-interconnection`, `zonal-reliability`, `JTIQ`, `RRR-file`, `attachment-J`, `attachment-H`

## 8. Items That May Need Follow-Up

### Cost Recovery Tracking:
- Monitor completion of 12-month recovery period for AEP's $414,465
- Monitor completion of 12-month recovery period for Sunflower's $718,359 (starting January 1, 2024)
- Verify joint informational filings to Commission upon full recovery
- Track actual interest amounts recovered versus projections

### Property Disposition:
- Monitor for any sale/disposition of canceled project property during recovery periods
- Ensure proper crediting against ATRR if disposition occurs
- Verify joint informational filings for property sales

### Documentation Requirements:
- Confirm SWPA provides supporting documentation for revised NITS ATRR calculations
- Verify posting on SPP website
- Ensure electronic notification through Formula Rate Posting Information Notification List

### Agreement Execution:
- Track completion of Sponsored Upgrade Agreements with Project Sponsors
- Verify ILTCR specifications (MW amounts, source-to-sink paths, term length) in agreements
- Ensure Attachment AH execution for Project Sponsors receiving ILTCRs who aren't Market Participants

### Cost True-Ups:
- Monitor Sponsored Upgrade completion for true-up calculations
- Verify actual construction costs versus good faith estimates

### Compliance Verification:
- Confirm FERC acceptance/approval of any ratio changes to Sunflower's Addendum 20
- Verify allocation compliance with specified Attachments (Z1, Z2, V, J)
- Ensure grandfathered agreement revenue treatments are honored

---

# Chunk 6 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document (chunk 6 of 25) is a detailed section from SPP's (Southwest Power Pool) tariff Attachment L, focusing on transmission revenue distribution mechanisms. It outlines complex procedures for distributing revenues from Network Integration Transmission Service (NITS) and Point-to-Point Transmission Service among transmission owners in both single-owner and multi-owner zones. The document establishes formulas and procedures for handling Grandfathered Agreements, Owner-Specific Zonal Annual Revenue Requirements (OZRR), and special treatments for specific zones (notably Zone 1 and Zone 19). This appears to be part of SPP's regulatory filing or comments dated January 28, 2025 (based on filename RR696 SPP Comments 20250728).

## 2. Key Topics

- **Revenue Distribution Methodologies**: Detailed formulas for distributing transmission service revenues
- **Network Integration Transmission Service (NITS)**: Revenue allocation for network service
- **Point-to-Point Transmission Service**: Revenue distribution under Schedules 7 and 8
- **Single-Owner vs. Multi-Owner Zones**: Different treatment based on zone ownership structure
- **Grandfathered Agreements**: Special handling of pre-existing transmission agreements
- **Owner-Specific Zonal Annual Revenue Requirements (OZRR)**: Individual transmission owner revenue requirements
- **MW-Mile Impacts**: Usage-based revenue distribution methodology
- **Creditable Upgrades**: Revenue credits for transmission upgrades (Attachment Z2)
- **Load Ratio Shares**: Calculation methodology for revenue allocation
- **Base Plan Upgrades**: Regional transmission planning revenue distribution
- **Zone-Specific Provisions**: Special rules for Zone 1 (American Electric Power) and Zone 19

## 3. Decisions or Actions

- Revenue distribution to transmission owners based on OZRR percentages in multi-owner zones
- Adjustment of OZRR for Grandfathered Agreement revenues (sellers reduce, purchasers increase)
- Calculation of hypothetical NITS payments for transmission owners not taking service
- Settlement payments between transmission owners and the Transmission Provider based on calculated amounts
- 50/50 split of Point-to-Point revenues between OZRR-based and MW-mile impact-based distribution
- First distribution of revenues to Upgrade Sponsors for Creditable Upgrades before other allocations
- Dispute resolution procedures for unresolved Grandfathered Agreement treatments
- Special revenue distribution formula for Zone 1 subsequent transmission owners
- Exemption for Zone 19 pre-October 1, 2015 designated loads from standard revenue distribution

## 4. Important Dates

- **October 1, 2015**: Cutoff date for grandfathered treatment of Zone 19 Network Load designated outside the Transmission System

## 5. Organizations and People Mentioned

**Organizations:**
- SPP (Southwest Power Pool) - Transmission Provider
- American Electric Power - Primary Zone 1 Transmission Owner
- FERC (Federal Energy Regulatory Commission) - Regulatory authority for dispute resolution
- Transmission Owners (multiple, unnamed) - Various entities owning transmission facilities
- Network Customers - Service recipients
- Transmission Customers - General service recipients
- Upgrade Sponsors - Entities sponsoring Creditable Upgrades

**People:**
- None specifically mentioned

## 6. Links or References

**Internal Tariff References:**
- Attachment L (this document)
- Attachment H - Contains OZRR and ZRR information
- Attachment J, Section IV.A - Reallocation of Zonal ATRRs
- Attachment S - MW-mile impact calculation procedures
- Attachment Z2 - Creditable Upgrades provisions
- Attachment AU - Revenue distribution and allocation
- Schedule 7 - Point-to-Point rates (short-term)
- Schedule 8 - Point-to-Point rates (long-term)
- Schedule 9 - Network Integration Transmission Service rates
- Schedule 11 - Base Plan/Region-wide charges
- Section 31.4 - Network Load designation provisions
- Section 34.1(2) - OZRR adjustment provisions
- Section 34.4 - Load Ratio Share calculations
- Section 39 - Service provisions for Transmission Owners

**External References:**
- FERC - For dispute determinations
- Grandfathered Agreements (various, unnamed)

## 7. Suggested Tags

- Revenue Distribution
- Transmission Service
- NITS (Network Integration Transmission Service)
- Point-to-Point Service
- OZRR (Owner-Specific Zonal Annual Revenue Requirement)
- Grandfathered Agreements
- Multi-Owner Zones
- MW-Mile Methodology
- Creditable Upgrades
- Load Ratio Share
- Base Plan Upgrades
- Tariff Attachment L
- SPP Tariff
- Zone 1
- Zone 19
- Transmission Owners
- Revenue Credits
- FERC Compliance

## 8. Items That May Need Follow-Up

1. **Dispute Resolution Mechanism**: The document references dispute resolution for Grandfathered Agreement treatments when parties cannot reach agreement - need to verify the specific procedures referenced in the Tariff

2. **Zone 1 Special Treatment**: American Electric Power's unique position in Zone 1 and the formula for subsequent transmission owners may require coordination and clarification

3. **Zone 19 Grandfather Provision**: The October 1, 2015 cutoff for special treatment of designated loads outside the system needs verification of affected customers

4. **Creditable Upgrades Revenue Priority**: First claim on Point-to-Point revenues by Upgrade Sponsors under Attachment Z2 requires cross-reference verification

5. **OZRR Adjustments**: The complex adjustments described in Section 34.1(2) for OZRR calculations need to be verified for consistency across all references

6. **Hypothetical NITS Calculations**: The methodology for calculating hypothetical payments for transmission owners not taking service may require supporting documentation

7. **MW-Mile Impact Calculations**: The procedures in Attachment S for determining MW-mile impacts should be reviewed for accuracy and consistency

8. **Multi-Owner Zone Identification**: Clarification needed on which zones are multi-owner and how this status changes over time

9. **Network Load Outside Transmission System**: The treatment of loads designated under Section 31.4 and their impact on Load Ratio Share calculations requires verification

10. **Base Plan Revenue Distribution**: The text cuts off mid-sentence at the end regarding revenue distribution for Base Plan Upgrades - needs continuation from next chunk

11. **Grandfathered Agreement Inventory**: A comprehensive list of active Grandfathered Agreements and their treatment under these provisions may be needed for implementation

12. **Revenue Settlement Timing**: No specific timing or frequency mentioned for revenue distributions and settlements between Transmission Provider and Transmission Owners

---

# Chunk 7 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document is chunk 7 of 25 from SPP's (Southwest Power Pool) tariff comments (RR696), dated July 28, 2025. It primarily contains detailed tariff language covering revenue distribution mechanisms, loss compensation procedures, and transmission planning processes. The content describes how transmission revenues are allocated among various parties, how transmission losses are calculated and assigned, and the comprehensive framework for SPP's Transmission Expansion Plan (STEP). Key mechanisms include the Region-wide Charge, JTIQ (Joint Targeted Interconnection Queue) ATRR Balance calculations, and multiple pathways for transmission facility proposals.

## 2. Key Topics

- **Revenue Distribution Mechanisms**
  - Zonal Annual Transmission Revenue Requirements (ATRR) reallocation
  - Point-to-point transmission service revenue distribution
  - Creditable Upgrades revenue allocation to Upgrade Sponsors
  - Interregional Project revenue compensation
  - JTIQ ATRR Balance calculations and distributions

- **Loss Compensation Procedures**
  - Injection Loss Factor (ILF) and Delivery Loss Factor (DLF) methodologies
  - Network Integration Transmission Service loss responsibility
  - Point-to-Point Transmission Service loss calculations
  - Integration with Energy and Operating Reserve Markets (Attachment AE)

- **Transmission Planning Process**
  - SPP Transmission Expansion Plan (STEP) development
  - Multiple sources for transmission facility proposals (10 different processes listed)
  - Stakeholder review and approval procedures
  - Integration of regional and interregional planning

## 3. Decisions or Actions

- **Revenue Distribution Actions:**
  - Monthly charges/credits to Resident Load and Transmission Owners based on JTIQ ATRR Balance
  - Distribution of revenues to Interregional Planning Regions per cost allocation agreements
  - Revenue allocation to other transmission providers per coordination agreements

- **Planning Process Requirements:**
  - Transmission Provider must prepare draft project lists for stakeholder review
  - Transmission Provider must post draft lists on SPP website
  - Transmission Provider must invite written comments from stakeholders
  - Review process with stakeholder working groups and Regional State Committee required

- **Disclosure Requirements:**
  - Equal access for all stakeholders to planning summits and meetings
  - Meeting handouts must be contemporaneously available on SPP website

## 4. Important Dates

- **Monthly Calculations:** One-twelfth of JTIQ ATRR Balance charged/credited each month
- **Annual Requirements:** Annual transmission revenue requirements referenced throughout for various upgrade categories
- **Hourly Determinations:** Network Customer loss responsibility based on hourly metered load coincident with Zone monthly peak load hour

**Note:** No specific calendar dates are mentioned in this chunk.

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)** - Transmission Provider
- **Transmission Owners** - Recipients of credits/charges
- **Network Customers** - Responsible for transmission losses
- **Transmission Customers** - Responsible for real power losses under Schedules 7 and 8
- **Upgrade Sponsors** - Recipients of Creditable Upgrade revenues
- **Interregional Planning Regions** - Recipients of approved Interregional Project revenues
- **Federal Power-Western-UGP** - Specific power delivery entity
- **Regional State Committee** - Review body for planning processes
- **Stakeholder Working Groups** - Participants in planning review process

**No specific individual names mentioned.**

## 6. Links or References

**Internal Tariff References:**
- Schedule 11 (multiple sections referenced)
- Schedule 7 and 8 (Point-to-Point Transmission Service)
- Schedule 9 (Network Integration charges)
- Attachment J, Section IV.A (Zonal ATRR reallocation)
- Attachment L, Sections II.C, II.D, III.A, III.C.2
- Attachment Z2, Sections II.D and III.C.2
- Attachment O and Addendum(s) (interregional cost allocation)
- Attachment O, Addendum 1 (coordination agreements)
- Attachment AU (revenue distribution/allocation)
- Attachment AE (Energy and Operating Reserve Markets settlement)
- Attachment AQ and AX (transmission facility requests)
- Attachment V (Generator Interconnection Requests)
- Attachment Y (Competitive Upgrades definition)
- Attachment AV and Appendix 2 (JTIQ Formula Rate template)
- Attachment M, Appendix 1 (loss factors)

**External References:**
- RRR File posted on SPP website
- SPP Transmission Expansion Plan (STEP)
- Figure 1 (planning processes illustration - referenced but not shown in chunk)

## 7. Suggested Tags

- Revenue Distribution
- Transmission Loss Compensation
- JTIQ (Joint Targeted Interconnection Queue)
- Transmission Planning
- SPP STEP (Transmission Expansion Plan)
- Point-to-Point Transmission Service
- Network Integration Service
- Interregional Planning
- Tariff Attachment L
- Tariff Attachment M
- Tariff Attachment O
- ATRR (Annual Transmission Revenue Requirements)
- Load Ratio Share
- Stakeholder Process
- Creditable Upgrades
- Balanced Portfolios

## 8. Items That May Need Follow-Up

1. **JTIQ ATRR Balance Calculation Verification**
   - Confirm proper implementation of monthly one-twelfth charge/credit mechanism
   - Verify RRR File posting requirements on SPP website are being met
   - Review Attachment AV and Appendix 2 formula rate template for consistency

2. **Loss Factor Updates**
   - Verify current Appendix 1 to Attachment M contains accurate ILF and DLF values for all Zones
   - Confirm Zone 19 DLF for Federal Power-Western-UGP calculations

3. **Stakeholder Process Compliance**
   - Ensure equal access provisions are being met for all planning summits and meetings
   - Verify website posting requirements for meeting materials
   - Confirm written comment submission process is operational

4. **Revenue Distribution Tracking**
   - Monitor actual revenue flows to Interregional Planning Regions
   - Track revenue distributions to other transmission providers under coordination agreements
   - Verify Creditable Upgrade revenue allocations to Upgrade Sponsors

5. **Planning Process Integration**
   - Confirm all 10 sources of transmission facility proposals are properly integrated into STEP
   - Verify Generator Retirement Process integration (item #10 in list)
   - Review coordination between various planning processes to avoid conflicts

6. **Cross-Reference Verification**
   - Ensure consistency between referenced sections across multiple tariff attachments
   - Verify Section V.7 of Attachment O regarding Competitive Upgrades causing reliability violations

7. **Competitive Upgrades Reporting**
   - Confirm process for identifying when Competitive Upgrades cause reliability violations on adjacent systems
   - Verify reporting requirements are being met in STEP documentation

---

# Chunk 8 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary

This document is chunk 8 of 25 from RR696 SPP Comments dated January 28, 2025. The content primarily consists of procedural and regulatory text from SPP's tariff concerning the transmission expansion planning process, specifically focusing on approval processes, website posting requirements, plan updates, and transmission service timing requirements. Key themes include the governance structure involving the Markets and Operations Policy Committee and SPP Board of Directors, stakeholder engagement processes, and detailed transmission service scheduling procedures.

## 2. Key Topics

- **Approval and Endorsement Process for Transmission Upgrades**: Multi-step process involving Markets and Operations Policy Committee recommendations and SPP Board of Directors approval for various upgrade types (ITP Upgrades, Balanced Portfolios, high priority upgrades, 20-Year Assessment upgrades, Sponsored Upgrades, Generator Retirement Upgrades, JTIQ Upgrades)

- **Transmission Expansion Plan Website Posting Requirements**: Detailed requirements for posting study results, data, and plans on SPP website with password protection for confidential/CEII information

- **Stakeholder Notification Process**: 10-day notice requirement via posting and email before Board action on project lists

- **Plan Updates and Modifications**: Quarterly posting of modifications, out-of-cycle adjustments for reliability and business opportunities

- **Transmission Service Timing Requirements**: Detailed scheduling deadlines and procedures for various service types (Next-Hour Market, daily, hourly services)

- **Adjacent System Impacts**: SPP responsibilities and limitations regarding reliability violations on adjacent transmission systems

## 3. Decisions or Actions

- **Required Approvals**: SPP Board of Directors approval required for inclusion of all major upgrade categories in the Transmission Expansion Plan

- **Quarterly Reporting**: Transmission Provider must report upgrade status to Markets and Operations Policy Committee, Regional State Committee, and SPP Board of Directors quarterly

- **Quarterly Website Updates**: Modifications to the Transmission Expansion Plan must be posted quarterly

- **Annual Board Presentation**: SPP Transmission Expansion Plan must be presented to Board at least once yearly

- **Upgrade Removal**: Transmission Provider may remove upgrades from approved plan in consultation with stakeholders, with reimbursement for incurred costs

## 4. Important Dates

- **10-day notice requirement**: Prior to SPP Board of Directors meetings where action on project lists is expected

- **Quarterly basis**: For posting modifications to the Transmission Expansion Plan and status reporting

- **Annual**: Minimum frequency for presenting Transmission Expansion Plan to SPP Board of Directors

- **Transmission Service Timing** (referenced but specific times cut off in excerpt):
  - Next-Hour Market requests
  - 15:00 day prior for non-firm schedules
  - 09:55:00 a.m. to 10:05:00 a.m. CPT window for DC tie requests
  - 5-minute window for simultaneous request processing

## 5. Organizations and People Mentioned

**Organizations:**
- SPP (Southwest Power Pool)
- SPP Board of Directors
- Markets and Operations Policy Committee
- Regional State Committee
- Transmission Provider
- Transmission Owner(s)
- Transmission Customer(s)
- NERC (North American Electric Reliability Corporation)
- Commission (Federal Energy Regulatory Commission - implied)
- NAESB (North American Energy Standards Board)

**Stakeholder Groups:**
- Stakeholder working groups
- Stakeholders (general)

## 6. Links or References

**Tariff Sections Referenced:**
- Attachment O (this document) - Sections IV.7, V, VII
- Attachment Z1 - Transmission service upgrades approval
- Attachment V - Generator Interconnection Service
- Attachment J, Section VIII - Cost reimbursement
- Attachment AB - Generator Retirement Upgrades
- Attachment T - Transmission service rates
- Attachment P - Transmission Service Timing Requirements
- Attachment R-1 - NAESB standards incorporation
- Sections 13.2 and 14.2 of SPP OATT

**External Standards:**
- NAESB Wholesale Electric Quadrant (WEQ-001) Business Practice Standards
- SPP Membership Agreement

**Other References:**
- CEII (Critical Energy Infrastructure Information) requirements
- NERC TLR (Transmission Loading Relief)
- SPP website and OASIS (Open Access Same-Time Information System)

## 7. Suggested Tags

- Transmission Planning
- SPP Transmission Expansion Plan (STEP)
- Governance Process
- ITP Upgrades
- Balanced Portfolio
- Markets and Operations Policy Committee
- SPP Board of Directors
- Stakeholder Engagement
- CEII Compliance
- Transmission Service Scheduling
- Regulatory Compliance
- NERC Standards
- Generator Interconnection
- Cost Recovery
- Website Posting Requirements
- Quarterly Reporting

## 8. Items That May Need Follow-Up

1. **Complete Transmission Service Timing Table**: The content appears to cut off mid-sentence regarding service increments - complete timing requirements table needed

2. **Specific Board Meeting Schedule**: While 10-day notice is required, actual scheduled Board meeting dates would be relevant for tracking approval timelines

3. **Current Transmission Expansion Plan Status**: Understanding what projects are currently in the plan and their status

4. **Password Access Protocol**: Details on how stakeholders obtain password-protected access to confidential information on SPP website

5. **Lottery System Details**: Specifics of the lottery system used to assign priorities for simultaneous reservation requests

6. **Adjacent System Agreements**: Any existing agreements with adjacent transmission systems regarding cost responsibility for violations

7. **CEII Redaction Standards**: Specific criteria used to determine what information requires CEII protection and redaction procedures

8. **Stakeholder Comment Process**: Details on how written comments submitted via the website link are processed and incorporated

9. **Reimbursement Process**: Detailed procedures for Transmission Owners to claim reimbursement for removed upgrade costs (Attachment J, Section VIII reference)

10. **Out-of-Cycle Adjustment Criteria**: Specific circumstances that trigger out-of-cycle plan modifications beyond the quarterly update schedule

---

# Chunk 9 Analysis

# Regulatory Analysis Report
## RR696 SPP Comments - Chunk 9 of 25

---

## 1. Executive Summary

This document section contains detailed rate schedules and tariff provisions for Point-To-Point (PTP) Transmission Service within the Southwest Power Pool (SPP) system. It establishes service duration definitions, rate calculation methodologies, and specific rate sheets for multiple transmission zones including American Electric Power - West (AEPW), City Utilities of Springfield Missouri, and The Empire District Electric Company. The document outlines both Firm and Non-Firm transmission service rates, revenue crediting mechanisms, and special discount provisions for ERCOT-related transactions.

---

## 2. Key Topics

- **Transmission Service Duration Classifications**
  - Extended Weekly, Monthly, and Yearly service definitions
  - Central Prevailing Time as operational standard
  - 24-hour clock convention

- **Rate Structure Components**
  - Balanced Portfolio Reallocation Adjustments
  - Point-To-Point Transmission Service Revenue Crediting
  - Formula rate calculations for multiple transmission owners
  - Firm vs. Non-Firm service rate differentials

- **AEP-West Rate Zone Provisions**
  - Multiple transmission owner rate formulas (AEP, AEP-West Transco, AECC, TROK)
  - Specific rates for Texas Electric Cooperatives, OMPA, and CMLP
  - On-Peak vs. Off-Peak rate calculations

- **ERCOT Transaction Discounts**
  - 45.27% discount for specific ERCOT Regional Transmission Service scenarios
  - Planned vs. Unplanned Resource definitions

---

## 3. Decisions or Actions

- **Rate Calculation Methodology**: Established divisor formulas for converting yearly rates to monthly (÷12), weekly (÷52), daily On-Peak (÷260), daily Off-Peak (÷365), hourly On-Peak (÷4,160), and hourly Off-Peak (÷8,760)

- **Peak Period Definitions**: 
  - Daily delivery: Off-Peak includes weekends and six holidays (New Year's Day, Memorial Day, Independence Day, Labor Day, Thanksgiving Day, Christmas Day)
  - Hourly delivery: On-Peak defined as HE 0700-2200 Central Time, excluding Sundays and NERC holidays

- **Revenue Requirements and Rates File (RRR File)**: Designated as the official source for current rates posted on SPP website

- **Discount Implementation**: 45.27% zonal rate reduction for Load Serving Entities meeting specific ERCOT criteria

---

## 4. Important Dates

No specific dates are mentioned in this content section. The document references ongoing service periods and rate structures but does not include implementation dates or deadlines.

---

## 5. Organizations and People Mentioned

### Organizations:

**Transmission Owners in AEPW Rate Zone:**
- American Electric Power (AEP)
- East Texas Electric Cooperative, Inc.
- Deep East Electric Cooperative, Inc. (collectively "Texas Electric Cooperatives")
- Oklahoma Municipal Power Authority (OMPA)
- AEP West Transmission Companies (AEP-West Transco)
- Coffeyville Municipal Light and Power (CMLP)
- Arkansas Electric Cooperative Corporation (AECC)
- Transource Oklahoma (TROK)

**Other Transmission Zones:**
- City Utilities of Springfield, Missouri
- The Empire District Electric Company

**Related Entities:**
- Southwest Power Pool (SPP)
- Electric Reliability Council of Texas (ERCOT)
- AEP Texas Central Company (TCC)
- AEP Texas North Company (TNC)
- Public Service Company of Oklahoma
- Southwestern Electric Power Company
- NERC (North American Electric Reliability Corporation)
- Federal Energy Regulatory Commission (implied as "Commission")

### People:
None specifically mentioned

---

## 6. Links or References

### Tariff Attachments Referenced:
- **Attachment X**: Defines Central Prevailing Time
- **Attachment T**: Rate Sheets for Point-To-Point Transmission Service
- **Attachment J, Section IV.A**: Balanced Portfolio Reallocation methodology
- **Attachment AU**: Revenue distribution and allocation
- **Attachment H, Addendum 4**: AEP Formula Rate
- **Attachment H, Addendum 12**: AEP-West Transco Formula Rate
- **Attachment H, Addendum 38**: AECC Formula Rate
- **Attachment H, Addendum 48**: TROK Formula Rate
- **Attachment H, Addendum 17**: City Utilities of Springfield Formula Rate

### Tariff Sections Referenced:
- **Section 34.1(2)**: Revenue crediting implementation
- **Schedules 7 and 8**: Revenue adjustments and discount applications
- **Part II**: SPP Tariff transmission service provisions
- **Part IV**: AEP Operating Companies' Tariff (ERCOT Regional Transmission Service)

### External Files:
- **Revenue Requirements and Rates File (RRR File)**: Posted on SPP website with specific tabs:
  - "AEP-West PTP Rate Att T"
  - "Empire PTP Rate Att T"

---

## 7. Suggested Tags

`Point-To-Point Transmission Service`, `Rate Schedules`, `SPP Tariff`, `AEPW`, `Transmission Rates`, `Formula Rates`, `ERCOT`, `Revenue Crediting`, `Balanced Portfolio`, `Firm Transmission Service`, `Non-Firm Transmission Service`, `On-Peak Rates`, `Off-Peak Rates`, `AEP`, `FERC`, `Attachment T`, `RRR File`, `Transmission Service Discounts`, `Load Serving Entity`, `Central Prevailing Time`

---

## 8. Items That May Need Follow-Up

1. **Rate Verification**: Confirm current rates in the RRR File on SPP website match the formulas and specific rates cited (e.g., $2,053.993/MW for Texas Electric Cooperatives)

2. **Formula Rate Updates**: Track annual updates to formula rates in Attachment H (Addendums 4, 12, 17, 38, and 48)

3. **ERCOT Discount Application**: Verify proper application of 45.27% discount and eligibility criteria for Load Serving Entities

4. **Peak Period Definition Consistency**: Confirm On-Peak/Off-Peak definitions align with NERC holiday calendar updates

5. **Balanced Portfolio Reallocation**: Monitor adjustments to ensure proper reflection in Point-To-Point rates per Attachment J

6. **Revenue Crediting Calculations**: Verify Schedule 7 and 8 revenue adjustments are correctly implemented per Section 34.1(2)

7. **Time Zone Compliance**: Ensure all transmission service products properly utilize Central Prevailing Time as defined in Attachment X

8. **Missing Content**: This appears to be chunk 9 of 25, and the City Utilities of Springfield section is incomplete (cuts off mid-section on "Point-To-Point Transmission Service Revenue Crediting for P...")

9. **Planned vs. Unplanned Resource Designation**: Clarify process for ERCOT Power Suppliers to designate resources for discount eligibility

10. **Multi-Owner Rate Coordination**: Track coordination among seven transmission owners in AEPW zone to ensure consistent rate application

---

# Chunk 10 Analysis

# REGULATORY ANALYSIS REPORT
## Source: RR696 SPP Comments 20250728.docx.txt - Chunk 10 of 25

---

## 1. EXECUTIVE SUMMARY

This document section contains detailed tariff language governing Point-To-Point (PTP) Transmission Service rates and charges within the Southwest Power Pool (SPP) system. It covers multiple utility rate zones including The Empire District Electric Company, Evergy Kansas Central, Inc., and Evergy Metro, Inc. The content specifies rate calculation methodologies, delivery charges (firm and non-firm service), revenue crediting mechanisms, and balanced portfolio reallocation adjustments. All rates are calculated using formulas referenced in various Attachment H Addendums and are posted in the Revenue Requirements and Rates (RRR) File on the SPP website.

---

## 2. KEY TOPICS

- **Point-To-Point Transmission Service Rate Structures** (Firm and Non-Firm)
- **Zonal Annual Transmission Revenue Requirements (Zonal ATRR)**
- **Rate Calculation Methodologies** for various delivery periods (yearly, monthly, weekly, daily, hourly)
- **Balanced Portfolio Reallocation Adjustments**
- **Schedule 7 and 8 Revenue Crediting**
- **Peak vs. Off-Peak Rate Differentials**
- **Reserved Capacity Compensation Structures**
- **Multiple Transmission Owner Rate Zones** (Empire District, Evergy Kansas Central, Evergy Metro)
- **Formula Rate Protocols** referenced in various Attachment H Addendums

---

## 3. DECISIONS OR ACTIONS

**No explicit decisions or actions are stated in this content.** This appears to be existing tariff language describing established rate structures and calculation methodologies. However, the document implies:

- Rates are calculated and updated according to specified formula rates
- Rates are posted on the SPP website per established schedules
- Adjustments for revenue crediting and portfolio reallocation are implemented per tariff sections

---

## 4. IMPORTANT DATES

### Annual Posting Deadlines (for rates effective January 1 of following year):

- **September 1**: Prairie Wind Formula Rate (Addendum 15) ATRR posting
- **October 1**: 
  - South Central MCN Formula Rate (Addendum 43) ATRR posting
  - Kansas Power Pool Formula Rate (Addendum 16) ATRR posting
  - NEET Southwest Formula Rate (Addendum 44) ATRR posting
- **October 15**: Evergy Kansas Central, Inc. Formula Rate (Addendum 3) ATRR posting

### Rate Effective Date:
- **January 1**: Annual effective date for all formula rate updates

---

## 5. ORGANIZATIONS AND PEOPLE MENTIONED

### Transmission Owners/Utilities:
1. **The Empire District Electric Company**
2. **Evergy Kansas Central, Inc.** (formerly Evergy Kansas South, Inc. and Evergy Kansas Central, Inc.)
3. **Evergy Metro, Inc.** ("EMe")
4. **City of Independence, Missouri** ("INDP")
5. **Prairie Wind Transmission LLC**
6. **South Central MCN LLC**
7. **Kansas Power Pool**
8. **NextEra Energy Transmission Southwest, LLC** ("NEET Southwest")

### Entities:
- **Southwest Power Pool (SPP)** - Regional Transmission Organization
- **Transmission Provider** (generic reference)
- **Transmission Customer** (generic reference)

### No individuals mentioned

---

## 6. LINKS OR REFERENCES

### Tariff Attachments Referenced:
- **Attachment T** - Point-To-Point rate sheets
- **Attachment H** - Formula rate specifications
  - Addendum 3: Evergy Kansas Central Formula Rate
  - Addendum 10, Parts 1 and 2: EMe Formula Rate
  - Addendum 15: Prairie Wind Formula Rate
  - Addendum 16: Kansas Power Pool Formula Rate
  - Addendum 18: Empire District Formula Rate
  - Addendum 43: South Central MCN Formula Rate
  - Addendum 44: NEET Southwest Formula Rate
- **Attachment J, Section IV.A** - Balanced Portfolio Reallocation
- **Attachment AU** - Revenue distribution and allocation
- **Section 34.1(2)** - Revenue crediting implementation

### Other References:
- **Schedule 7 and 8** - Revenue sources for rate adjustments
- **Revenue Requirements and Rates File (RRR File)** - Posted on SPP website
- **SPP website** - Location for rate postings (specific URL not provided)

---

## 7. SUGGESTED TAGS

`Point-To-Point Transmission` `SPP Tariff` `Transmission Rates` `Formula Rates` `Revenue Requirements` `Evergy` `Empire District Electric` `ATRR` `Firm Service` `Non-Firm Service` `Reserved Capacity` `Rate Zones` `Transmission Service` `Schedule 7` `Schedule 8` `Balanced Portfolio` `Peak Rates` `Off-Peak Rates` `FERC Tariff` `Transmission Owners` `Kansas Power Pool` `Prairie Wind` `NEET Southwest` `RRR File`

---

## 8. ITEMS THAT MAY NEED FOLLOW-UP

### Verification/Clarification Needed:
1. **Confirm current status**: Is this proposed tariff language or existing approved tariff text? (Document name suggests comments on RR696)
2. **Merger/Name Changes**: Document notes "Evergy Kansas South, Inc. and Evergy Kansas Central, Inc." in parentheses - verify current corporate structure
3. **Rate Posting Compliance**: Verify whether posting deadlines (Sept 1, Oct 1, Oct 15) are being met by all transmission owners
4. **INDP Fixed Rate**: City of Independence shows fixed rate of $2,442.048 - confirm if this requires updating or is permanently fixed

### Potential Issues:
5. **Formula Rate Consistency**: Multiple formula rates with different posting deadlines could create coordination challenges
6. **Peak/Off-Peak Definition**: Document doesn't define peak vs. off-peak hours - ensure consistency across all rate zones
7. **Rate Cap Provisions**: Verify the rate cap calculations (daily not exceeding weekly, hourly not exceeding daily) are functioning as intended

### Documentation Gaps:
8. **SPP Website URL**: No specific URL provided for RRR File location - may need to be specified
9. **Calculation Examples**: Complex rate calculations may benefit from worked examples for stakeholder clarity
10. **Effective Date Coordination**: Multiple transmission owners with different posting dates but same effective date (Jan 1) - confirm coordination procedures

### Stakeholder Communication:
11. **Rate Transparency**: Confirm all transmission customers have clear access to and understanding of RRR File contents
12. **Formula Rate Challenges**: Verify if any transmission customers have challenged or requested modifications to existing formula rates

---

**Analysis Note**: This appears to be chunk 10 of 25 from a larger document. Full context may require review of additional chunks, particularly those containing decisions, comments, or proposed modifications to this tariff language.

---

# Chunk 11 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document (chunk 11 of 25) from RR696 SPP Comments contains detailed rate schedules and transmission service tariff provisions for multiple transmission zones within the Southwest Power Pool (SPP) territory. It establishes the rate structures for Point-to-Point Transmission Service for three transmission zones: Evergy Missouri West, Inc., Grand River Dam Authority, and Kansas City Board of Public Utilities. The content specifies both Firm and Non-Firm transmission service rates, calculation methodologies, revenue crediting procedures, and rate adjustment mechanisms.

## 2. Key Topics

- **Point-to-Point Transmission Service Rate Structures** for multiple delivery periods (yearly, monthly, weekly, daily, hourly)
- **Firm vs. Non-Firm Transmission Service** pricing differentials and capacity reservation requirements
- **Formula Rate Calculations** referenced in multiple Attachment H addenda
- **Balanced Portfolio Reallocation Adjustments** affecting zonal transmission revenue requirements
- **Revenue Crediting Mechanisms** for Schedule 7 and 8 revenues and Attachment AU distributions
- **Demand Charge Caps** limiting total charges within day/week periods
- **Reserved Capacity Pricing** measured in MW or kW depending on utility zone
- **On-Peak vs. Off-Peak Rate Differentials** for different delivery timeframes

## 3. Decisions or Actions

- Rates must be posted in the Revenue Requirements and Rates File (RRR File) on the SPP website
- Rate adjustments must reflect Balanced Portfolio reallocations per Section IV.A of Attachment J
- Revenue crediting adjustments must be implemented per Section 34.1(2) of the Tariff
- Transmission Customers must compensate Transmission Providers monthly for Reserved Capacity
- Rate calculations must follow specific formula rates in designated Attachment H addenda:
  - Evergy Missouri West: Addendum 11, Parts 1 and 2
  - Transource Missouri, LLC: Addendum 21
  - Grand River Dam Authority: Addendum 13
  - Kansas City BPU: Addendum 46

## 4. Important Dates

No specific dates are mentioned in this content chunk. The document references "currently effective rates" but does not specify effective dates or revision schedules.

## 5. Organizations and People Mentioned

**Organizations:**
- **Evergy Missouri West, Inc.** - Transmission Owner
- **Transource Missouri, LLC** - Transmission Owner in Evergy Missouri West zone
- **Grand River Dam Authority (GRDA)** - Transmission zone operator
- **Kansas City Board of Public Utilities (BPU)** - Transmission zone operator
- **Southwest Power Pool (SPP)** - Regional transmission organization (implied)
- **Commission** - Federal Energy Regulatory Commission (FERC) (implied by context)

**People:**
None specifically mentioned.

## 6. Links or References

**Internal Tariff References:**
- Attachment H (Formula Rates):
  - Addendum 10, Parts 1 and 2 (referenced for EMe zone)
  - Addendum 11, Parts 1 and 2 (Evergy Missouri West)
  - Addendum 13 (Grand River Dam Authority)
  - Addendum 21 (Transource Missouri, LLC)
  - Addendum 46 (Kansas City BPU)
- Attachment J, Section IV.A (Balanced Portfolio Reallocation)
- Attachment T (Point-to-Point Transmission Service Rates)
- Attachment AU (Revenue Distribution and Allocation)
- Section 34.1(2) of the Tariff (Revenue Crediting Implementation)

**External References:**
- Revenue Requirements and Rates File (RRR File) posted on SPP website
- Specific tabs referenced: "EMW PTP Rate Att T," "GRDA PTP Rate Att T," "BPU PTP Rate Att T"

## 7. Suggested Tags

- Transmission Rates
- Point-to-Point Service
- SPP Tariff
- Formula Rates
- Revenue Requirements
- Evergy Missouri West
- Grand River Dam Authority
- Kansas City BPU
- Firm Transmission Service
- Non-Firm Transmission Service
- Reserved Capacity
- Rate Schedules
- FERC Compliance
- Balanced Portfolio
- Revenue Crediting
- Demand Charges

## 8. Items That May Need Follow-Up

1. **Rate Formula Verification**: Confirm that all referenced Attachment H addenda (10, 11, 13, 21, 46) are current and properly cross-referenced in the complete document

2. **RRR File Accessibility**: Verify that all referenced tabs in the RRR File are publicly accessible on the SPP website and contain current rates

3. **Rate Calculation Inconsistencies**: Note that Grand River Dam Authority uses kW measurements while other zones use MW - confirm this is intentional and properly documented

4. **Schedule 7 and 8 Revenue Details**: The revenue crediting references need clarification regarding specific calculation methodologies

5. **Transource Missouri, LLC Integration**: Verify the dual transmission owner structure in the Evergy Missouri West zone and confirm rate coordination

6. **Commission Approval Status**: Confirm all transmission owners have current Commission-approved rates as stated

7. **Balanced Portfolio Reallocation Methodology**: Review Section IV.A of Attachment J for consistency with rate adjustments described

8. **Document Completeness**: As this is chunk 11 of 25, review preceding and following chunks for contextual dependencies, particularly regarding EMe zone references at the beginning

9. **Hourly Rate Caps**: Verify the mathematical consistency of demand charge caps across different delivery timeframes (daily not exceeding weekly, etc.)

10. **Text Truncation**: The document appears to cut off mid-sentence at the end ("shall not exceed the rate specifi") - requires completion review

---

# Chunk 12 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document (chunk 12 of 25) from SPP Comments filed on January 28, 2025, contains detailed tariff rate schedules for Point-To-Point (PTP) Transmission Service across multiple transmission zones. The content specifies rate structures, calculation methodologies, and billing procedures for both Firm and Non-Firm transmission service across Lincoln Electric System, Midwest Energy Inc., and Nebraska Public Power District zones. All rates are published in Revenue Requirements and Rates Files (RRR Files) on the SPP website and are subject to adjustments for revenue crediting and portfolio reallocation.

## 2. Key Topics

- **Point-To-Point Transmission Service Rate Structures** for multiple utility zones
- **Firm vs. Non-Firm Transmission Service** pricing differentiation
- **Time-based Delivery Rate Schedules**: Yearly, Monthly, Weekly, Daily, and Hourly
- **On-Peak vs. Off-Peak Rate Distinctions** (HE 0700-2200, excluding Sundays/holidays)
- **Balanced Portfolio Reallocation Adjustments** per Attachment J, Section IV.A
- **Revenue Crediting Mechanisms** for Schedule 7 and 8 revenues
- **Formula Rate References** to various Attachment H Addenda
- **Demand Charge Caps** to prevent weekly charges from exceeding specified limits
- **NERC Holiday Definitions** (New Year's Day, Memorial Day, Independence Day, Labor Day, Thanksgiving, Christmas)

## 3. Decisions or Actions

- Rates must be posted on the SPP website in the RRR File
- NPPD formula calculations must be posted by **December 15** annually (effective January 1)
- Tri-State formula calculations must be posted by **June 15** annually (effective July 1)
- NPPD website must also post rates in an accessible location
- Total demand charges have specified weekly caps that cannot be exceeded
- Revenue adjustments for Schedule 7 and 8 must be implemented per Section 34.1(2)

## 4. Important Dates

- **December 15**: Annual deadline for NPPD formula calculation posting
- **January 1**: Effective date for NPPD rates (following year)
- **June 15**: Annual deadline for Tri-State formula calculation posting
- **July 1**: Effective date for Tri-State rates (same year)
- **On-Peak Hours**: HE 0700 - HE 2200 (Central Time Zone)
- **NERC Holidays**: New Year's Day, Memorial Day, Independence Day, Labor Day, Thanksgiving Day, Christmas Day

## 5. Organizations and People Mentioned

### Organizations:
- **Lincoln Electric System (LES)**
- **Midwest Energy, Inc.**
- **Nebraska Public Power District (NPPD)**
- **The Central Nebraska Public Power and Irrigation District (CNPPID)**
- **Tri-State** (transmission provider)
- **SPP (Southwest Power Pool)** - platform administrator
- **NERC (North American Electric Reliability Corporation)** - holiday definition authority

### People:
None specifically mentioned

## 6. Links or References

### Internal Tariff References:
- **Attachment T** - Point-To-Point Transmission Service rates
- **Attachment H** (multiple addenda):
  - Addendum 6 (Lincoln Electric System formula rate)
  - Addendum 14 (Midwest Energy, Inc. formula rate)
  - Addendum 7 (NPPD Formula Rate)
  - Addendum 36 (Tri-State Formula Rate)
- **Attachment J, Section IV.A** - Balanced Portfolio Reallocation
- **Attachment AU** - Revenue distribution and allocation
- **Section 34.1(2)** - Revenue crediting implementation

### External References:
- **SPP Website** - RRR File repository
- **NPPD Website** - rate posting location
- **Tri-State Website** - rate posting location
- Specific RRR File tabs:
  - "LES PTP Rate Att T"
  - "Midwest PTP Rate Att T"
  - "NPPD PTP Rate Att T"

### Specific CNPPID Rates Referenced:
- Annual: $128.961 per MW
- Monthly: $10.747 per MW
- Weekly: $2.480 per MW
- Daily On-Peak: $0.496 per MW
- Daily Off-Peak: $0.353 per MW

## 7. Suggested Tags

- Point-To-Point Transmission
- Transmission Rates
- SPP Tariff
- Lincoln Electric System
- Midwest Energy
- Nebraska Public Power District
- CNPPID
- Firm Transmission Service
- Non-Firm Transmission Service
- Formula Rates
- Revenue Requirements
- Balanced Portfolio
- Revenue Crediting
- On-Peak/Off-Peak Rates
- Reserved Capacity
- Attachment T
- Attachment H
- RRR File

## 8. Items That May Need Follow-Up

### Rate Implementation & Posting:
- Verify December 15 NPPD rate posting occurred and January 1 implementation
- Confirm June 15 Tri-State rate posting and July 1 implementation
- Ensure all RRR File tabs are current on SPP website
- Confirm NPPD and Tri-State websites have rates in accessible locations

### Rate Calculation Verification:
- Validate that weekly caps on demand charges are being properly applied
- Confirm Schedule 7 and 8 revenue adjustments are correctly implemented
- Verify Attachment AU revenue distributions are properly reflected in rates
- Check that Balanced Portfolio Reallocation adjustments are current

### Tariff Consistency:
- Review consistency of on-peak/off-peak definitions across all zones
- Verify NERC holiday list is current (document states "currently" implying potential changes)
- Check for potential typographical error in Non-Firm hourly off-peak rate for Lincoln Electric (shows "week" instead of "hour")

### Compliance Monitoring:
- Ensure formula rate calculations align with referenced Attachment H addenda
- Verify CNPPID fixed rates ($128.961, $10.747, etc.) are current
- Confirm transmission customers are being billed correctly under these rate structures

### Documentation Gaps:
- Content ends mid-word ("Servi") suggesting incomplete section
- May need to review complete document for full NPPD section and any additional zones

---

# Chunk 13 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document (chunk 13 of 25) contains detailed tariff rate schedules for Point-To-Point Transmission Service within the SPP (Southwest Power Pool) system. It specifically covers rate structures for three transmission providers: NPPD (Nebraska Public Power District)/CNPPID, Oklahoma Gas and Electric Company (OG&E), and Omaha Public Power District (OPPD). The content outlines comprehensive pricing structures for both Firm and Non-Firm transmission services across various delivery timeframes (yearly, monthly, weekly, daily, and hourly), including specific rate formulas, calculation methodologies, and peak/off-peak definitions.

## 2. Key Topics

- **Point-To-Point Transmission Service Rate Structures** for multiple utilities
- **Firm vs. Non-Firm Transmission Service** pricing distinctions
- **On-Peak and Off-Peak Hour Definitions** (HE 0700-2200, Central Time, excluding weekends and NERC-defined holidays)
- **Formula Rate Calculations** referencing Attachment H addendums
- **Revenue Requirements and Rates File (RRR File)** posting requirements
- **Balanced Portfolio Reallocation Adjustments**
- **Point-To-Point Transmission Service Revenue Crediting** (Schedules 7 and 8)
- **Zonal Annual Transmission Revenue Requirement (Zonal ATRR)** calculations
- **Capacity Reservation Charges** across various delivery periods
- **NERC-Defined Holidays**: New Year's Day, Memorial Day, Independence Day, Labor Day, Thanksgiving Day, Christmas Day

## 3. Decisions or Actions

- **Rate Posting Requirements**: 
  - OG&E rates to be posted by September 1 annually, effective January 1 following year
  - OPPD rates to be posted by July 20 annually, effective August 1 of same year
- **Charge Calculations**: All rates to be calculated using specific formula rate templates in Attachment H
- **Service Direction Policy**: Service in opposite direction of original schedule considered new/separate service requiring separate charge
- **Demand Charge Caps**: Total charges capped at higher-tier rates (e.g., weekly charges cannot exceed weekly rate times highest MW)
- **Revenue Crediting**: Adjustments for Schedule 7 and 8 revenues and Attachment AU allocations to be implemented per Section 34.1(2)

## 4. Important Dates

- **September 1**: Deadline for posting OG&E Formula Rate results on SPP website (annual)
- **January 1**: Effective date for OG&E rates (following year after September 1 posting)
- **July 20**: Deadline for posting OPPD Formula Rate results on SPP website (annual)
- **August 1**: Effective date for OPPD rates (same year as July 20 posting)
- **On-Peak Hours**: HE 0700 to HE 2200 (7:00 AM to 10:00 PM), Central Time Zone
- **NERC Holidays**: New Year's Day, Memorial Day, Independence Day, Labor Day, Thanksgiving Day, Christmas Day

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)** - Regional transmission organization
- **NPPD (Nebraska Public Power District)** - Transmission provider
- **CNPPID (Central Nebraska Public Power and Irrigation District)** - Transmission provider
- **Oklahoma Gas and Electric Company (OG&E)** - Transmission provider
- **OPPD (Omaha Public Power District)** - Transmission provider
- **Tri-State** - Referenced in formula rates
- **AECC (Arkansas Electric Cooperative Corporation)** - Rate formula referenced
- **PEC (People's Electric Cooperative)** - Rate formula referenced
- **NEET Southwest (NextEra Energy Transmission Southwest, LLC)** - Rate formula referenced
- **Oklahoma Municipal Power Authority (OMPA)** - Additional charges specified
- **NERC (North American Electric Reliability Corporation)** - Holiday definition authority

### People:
None specifically mentioned

## 6. Links or References

### Tariff Attachments Referenced:
- **Attachment H** - Formula Rate templates
  - Addendum 2-A: OG&E Formula Rate
  - Addendum 2-B: OG&E Formula Rate Implementation Protocols
  - Addendum 7: NPPD Formula Rate Template
  - Addendum 8: OPPD Formula Rate Template
  - Addendum 38: AECC Formula Rate
  - Addendum 44: NEET Southwest Formula Rate
  - Addendum 51: PEC Formula Rate
- **Attachment J, Section IV.A**: Balanced Portfolio Reallocation
- **Attachment T**: Point-To-Point Transmission Service rates
- **Attachment AU**: Revenue distribution and allocation
- **Section 34.1(2)**: Revenue crediting implementation
- **Schedule 7 and 8**: Revenue adjustments
- **RRR File (Revenue Requirements and Rates File)**: Posted on SPP website

### Specific Rate Tabs:
- "OGE PTP Rate Att T" tab
- "OPPD PTP Rate Att T" tab

## 7. Suggested Tags

- Point-To-Point Transmission Service
- Rate Schedule
- Tariff
- Transmission Pricing
- SPP
- NPPD
- OG&E
- OPPD
- Formula Rates
- Firm Transmission
- Non-Firm Transmission
- On-Peak/Off-Peak
- Reserved Capacity
- Revenue Requirements
- Zonal ATRR
- Balanced Portfolio
- FERC Regulation
- Transmission Tariff
- Energy Markets

## 8. Items That May Need Follow-Up

1. **Annual Rate Updates**: Monitor SPP website for timely posting of:
   - OG&E rates by September 1
   - OPPD rates by July 20

2. **Formula Rate Compliance**: Verify that all referenced Attachment H addendums are current and properly implemented

3. **Revenue Crediting Reconciliation**: Track Schedule 7 and 8 revenue adjustments and Attachment AU allocations per Section 34.1(2)

4. **Balanced Portfolio Reallocation**: Monitor adjustments to Zonal ATRR and impact on Point-To-Point rates

5. **Capacity Designation Verification**: Confirm that capacity designations at Point(s) of Receipt include losses as specified

6. **Rate Caps Enforcement**: Ensure demand charge caps are properly calculated (daily not exceeding weekly, hourly not exceeding daily, etc.)

7. **NERC Holiday Updates**: Monitor for any changes to NERC-defined holidays that would affect On-Peak/Off-Peak designations

8. **Multiple Entity Rate Coordination**: Track interactions between NPPD, CNPPID, Tri-State, AECC, PEC, NEET Southwest, and OMPA rates

9. **RRR File Accessibility**: Verify SPP website posting and accessibility of Revenue Requirements and Rates File

10. **Separate Service Billing**: Ensure proper billing for service in opposite direction as new/separate service requiring separate charges

11. **Time Zone Consistency**: Confirm all transmission customers aware that times are Central Time Zone

12. **Document Continuity**: Review preceding and following chunks (12/25 and 14/25) for context and potential cross-references

---

# Chunk 14 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary
This document (chunk 14 of 25) contains detailed tariff rate schedules for Point-To-Point Transmission Service from three major transmission providers: OPPD (Omaha Public Power District), Southwestern Power Administration, and Southwestern Public Service Company. The content specifies compensation structures for both Firm and Non-Firm transmission services across various delivery timeframes (monthly, weekly, daily, hourly). Each provider's rates are calculated using specific formula rates referenced in various Attachments and Addendums, with results published in the Revenue Requirements and Rates (RRR) File on the SPP website.

## 2. Key Topics
- **Point-To-Point Transmission Service Rates**: Detailed rate structures for reserved capacity
- **Formula-Based Rate Templates**: Multiple referenced formula rates for different organizations
- **Service Classifications**: 
  - Firm Point-To-Point Transmission Service
  - Non-Firm Point-To-Point Transmission Service
- **Delivery Timeframes**: Yearly, Monthly, Weekly, Daily, and Hourly options
- **On-Peak vs. Off-Peak Pricing**: Different rates based on time of day and day of week
- **Rate Calculations and Adjustments**: Revenue crediting, Schedule 7 and 8 adjustments
- **Balanced Portfolio Reallocation**: Adjustments to Point-To-Point rates
- **NERC Holiday Definitions**: Impact on peak/off-peak designations

## 3. Decisions or Actions
- Transmission Customers must compensate Transmission Providers according to specified rate structures
- Rate formulas posted on SPP website in RRR File
- For SPS rates: Results must be posted by **October 1** of each calendar year
- SPS rates become effective on **January 1** of the following calendar year
- Revenue crediting adjustments to be implemented per Section 34.1(2) of Tariff
- Demand charge caps applied to prevent weekly/daily charges from exceeding longer-term rates

## 4. Important Dates
- **October 1** (annually): Deadline for posting SPS formula calculation results on SPP and SPS OASIS websites
- **January 1** (annually): Effective date for SPS Point-To-Point rates
- **NERC Holidays** (affecting peak/off-peak designations):
  - New Year's Day
  - Memorial Day
  - Independence Day
  - Labor Day
  - Thanksgiving Day
  - Christmas Day

## 5. Organizations and People Mentioned

### Organizations:
- **OPPD** (Omaha Public Power District)
- **Southwestern Power Administration** (Southwestern)
- **South Central MCN LLC** (South Central MCN)
- **Missouri Joint Municipal Electric Utility Commission** (MEUC)
- **People's Electric Cooperative** (PEC)
- **Southwestern Public Service Company** (SPS)
- **Xcel Energy Operating Companies**
- **Lea County Electric Cooperative, Inc.** (LCEC)
- **SPP** (Southwest Power Pool) - website host for RRR File
- **NERC** (North American Electric Reliability Corporation)

### People:
None specifically mentioned

## 6. Links or References

### Attachments and Addendums Referenced:
- **Attachment H, Addendum 8**: OPPD Formula Rate
- **Attachment H, Addendum 43**: South Central MCN Formula Rate
- **Attachment H, Addendum 50**: MEUC Formula Rate
- **Attachment H, Addendum 51**: PEC Formula Rate
- **Attachment H, Addendum 5**: Southwestern Public Service Company Formula Rate
- **Attachment H, Addendum 52**: LCEC Formula Rate
- **Attachment T**: Point-To-Point Transmission Service specifications
- **Attachment J, Section IV.A**: Balanced Portfolio Reallocation provisions
- **Attachment O - SPS**: Xcel Energy OATT rate formula
- **Attachment AU**: Revenue distribution and allocation
- **Section 34.1(2)**: Revenue crediting implementation provisions

### Files/Locations:
- **RRR File** (Revenue Requirements and Rates File) - Posted on SPP website
- **"SPA PTP Rate Att T" tab**: Southwestern rates in RRR File
- **"SPS PTP Rate Att T" tab**: SPS rates in RRR File
- **SPS OASIS website**: Accessible location for rate postings
- **Xcel Energy OATT**: Joint Open Access Transmission Tariff

## 7. Suggested Tags
- Transmission Tariff
- Point-To-Point Service
- Rate Schedules
- OPPD
- Southwestern Power Administration
- SPS
- Formula Rates
- Firm Transmission
- Non-Firm Transmission
- Peak Pricing
- Reserved Capacity
- Revenue Requirements
- NERC Standards
- Transmission Service Agreements
- Energy Regulation
- RRR File

## 8. Items That May Need Follow-Up

### Rate Verification:
1. **Confirm October 1 deadline compliance** for SPS rate formula postings
2. **Verify RRR File accessibility** on SPP website for all listed transmission providers
3. **Validate formula calculations** match referenced Attachments and Addendums

### Contractual Clarifications:
4. **Clarify "longest term agreement" provisions** for Southwestern customers directly connected to system
5. **Confirm Secondary Transmission Service limitations** methodology for non-control area customers
6. **Verify peak demand measurement and rounding protocols** (nearest whole megawatt)

### Documentation Issues:
7. **Complete text on line item 1 for SPS Firm Service** - document appears cut off ("plus LCEC's yearly delivery cha")
8. **Cross-reference all Attachment citations** to ensure accuracy across tariff document
9. **Verify consistency of On-Peak hour definitions** (HE 0700 through HE 2200) across all providers

### Policy Questions:
10. **Review demand charge cap methodology** for daily/hourly reservations
11. **Clarify Balanced Portfolio Reallocation** impact on individual customer rates
12. **Confirm Schedule 7 and 8 revenue crediting** calculation methodology
13. **Verify coordination between multiple formula rates** in Southwestern Zone (Southwestern + South Central MCN + MEUC + PEC)

### Compliance Monitoring:
14. **Track annual rate updates** for compliance with effective date requirements
15. **Monitor changes to NERC holiday definitions** that could affect peak/off-peak designations

---

# Chunk 15 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document is chunk 15 of 25 from SPP (Southwest Power Pool) comments document RR696, dated January 28, 2025. The content primarily consists of detailed tariff rate schedules for Point-To-Point Transmission Service across multiple utility zones and transmission owners. It specifies rate structures for both Firm and Non-Firm transmission services with various delivery timeframes (yearly, monthly, weekly, daily, and hourly), including distinctions between On-Peak and Off-Peak periods. The document covers rate schedules for the Southwestern Public Service Company (SPS), Sunflower Electric Power Corporation, and Upper Missouri Zone (UMZ), detailing calculation methodologies and referencing multiple formula rates and attachments.

## 2. Key Topics

- **Point-To-Point Transmission Service Rate Structures**
  - Firm Point-To-Point Transmission Service rates
  - Non-Firm Point-To-Point Transmission Service rates
  - Monthly, weekly, daily, and hourly delivery rate calculations

- **On-Peak/Off-Peak Definitions**
  - On-Peak: Hours HE 0700 to HE 2200 (Central Time Zone), excluding Sundays and NERC holidays
  - Off-Peak: All other hours
  - NERC holidays: New Year's Day, Memorial Day, Independence Day, Labor Day, Thanksgiving Day, Christmas Day

- **Rate Zone Specifications**
  - Southwestern Public Service Company (SPS) Zone
  - Sunflower Electric Power Corporation Zone
  - Upper Missouri Zone (UMZ)

- **Balanced Portfolio Reallocation Adjustments**
  - Adjustments reflecting Zonal Annual Transmission Revenue Requirements
  - Implementation per Attachment J, Section IV.A

- **Revenue Crediting Mechanisms**
  - Schedule 7 and 8 revenue adjustments
  - Attachment AU revenue distribution and allocation
  - Implementation per Section 34.1(2) of Tariff

- **Lamar Tie Line Special Provisions**
  - Discounted rate of one-half applicable rate for service across Lamar Tie Line between SPS and PSCo

## 3. Decisions or Actions

- Transmission Customers must compensate Transmission Providers according to specified rate schedules in the RRR (Revenue Requirements and Rates) File
- Service in opposite direction of original schedule requires separate charges as new service
- Total demand charges capped at weekly rates (for daily reservations) and daily rates (for hourly reservations)
- Capacity designations at Point(s) of Receipt inclusive of losses
- Rates posted on SPP website in RRR File with specific tabs for each zone

## 4. Important Dates

- **No specific dates mentioned in this chunk**, though the source document is dated **January 28, 2025**
- Time periods referenced for rate calculations:
  - 12 months (yearly)
  - 52 weeks (yearly to weekly conversion)
  - 6 days (weekly to daily on-peak conversion)
  - 7 days (weekly to daily off-peak conversion)
  - 16 hours (daily on-peak to hourly conversion)
  - 24 hours (daily off-peak to hourly conversion)

## 5. Organizations and People Mentioned

### Transmission Providers/Owners:
- **Xcel Energy** (with OATT - Open Access Transmission Tariff)
- **LCEC** (entity with formula rate)
- **Southwestern Public Service Company (SPS)**
- **Public Service Company of Colorado (PSCo)**
- **Sunflower Electric Power Corporation (SECC)**
- **ITC Great Plains, LLC**
- **Prairie Wind Transmission, LLC**

### Upper Missouri Zone (UMZ) Transmission Owners:
- **Basin Electric Power Cooperative**
- **Heartland Consumers Power District**
- **Missouri River Energy Services (MRES)** and MRES Members:
  - Moorhead Public Service
  - Orange City Municipal Utilities
  - City of Pierre, South Dakota
  - City of Sioux Center, Iowa
  - Watertown Municipal Utility Department
  - Denison Municipal Utilities
  - Vermillion Light & Power
- **East River Electric Power Cooperative, Inc.**
- **Corn Belt Power Cooperative**
- **NorthWestern Energy Public Service Corporation (NWPS)**
- **Northwest Iowa Power Cooperative (NIPCO)**
- **Harlan Municipal Utilities (HMU)**
- **Western Area Power Administration, Upper Great Plains Region (Western-UGP)**
- **Central Electric Power Cooperative, Inc.**
- **Mountrail-Williams Electric Cooperative**
- **Mor-Gran-Sou Electric Cooperative, Inc.**
- **Roughrider Electric Cooperative, Inc.**
- **L and O Power Cooperative (LOPC)**

### Regulatory Bodies:
- **SPP (Southwest Power Pool)**
- **NERC (North American Electric Reliability Corporation)**
- **FERC (Federal Energy Regulatory Commission)** - implied through "Commission approved rate(s)"

## 6. Links or References

### Tariff Attachments Referenced:
- **Attachment O – SPS** of Xcel Energy OATT (specific lines: 11, 12, 13, 14)
- **Attachment H** (Formula Rates):
  - Addendum 5 (Southwestern Public Service Company)
  - Addendum 9 (ITC Great Plains, LLC)
  - Addendum 15 (Prairie Wind Transmission, LLC)
  - Addendum 20 (Sunflower Electric Power Corporation)
  - Addendums 22-35, 37, 40-42, 45, 47, 49 (UMZ entities)
- **Attachment J, Section IV.A** (Balanced Portfolio Reallocation)
- **Attachment T** (Point-To-Point Transmission Service Rate Sheet)
- **Attachment AU** (Revenue distribution and allocation)
- **Section 34.1(2)** of Tariff

### Files/Databases:
- **RRR File (Revenue Requirements and Rates File)** posted on SPP website
  - "SECC PTP Rate Att T" tab
  - "UMZ PTP Rate Att T" tab

### Schedules:
- **Schedule 7 and 8** (revenues)

## 7. Suggested Tags

- Point-To-Point Transmission Service
- Transmission Rates
- Firm Transmission
- Non-Firm Transmission
- SPP Tariff
- OATT (Open Access Transmission Tariff)
- Formula Rates
- Revenue Requirements
- SPS Zone
- Sunflower Electric
- Upper Missouri Zone
- On-Peak/Off-Peak Rates
- Reserved Capacity
- Transmission Revenue Crediting
- Balanced Portfolio Reallocation
- Lamar Tie Line
- RR696

## 8. Items That May Need Follow-Up

1. **RRR File Verification**: Confirm all referenced rates in the Revenue Requirements and Rates File on SPP website are current and accurate for all zones

2. **Formula Rate Updates**: Verify all Attachment H Addendums (5, 9, 15, 20, 22-35, 37, 40-42, 45, 47, 49) are properly referenced and current

3. **UMZ Rate Calculation Completeness**: Document appears truncated at "Daily delivery: the UMZ Weekly deli" - need complete text for daily delivery calculation methodology

4. **LCEC Formula Rate Details**: The LCEC Formula Rate is mentioned but not fully described; determine if additional documentation exists

5. **Attachment AU Implementation**: Clarify implementation status of Attachment AU revenue distribution and allocation mechanisms

6. **Lamar Tie Line Discount Justification**: Review rationale for one-half discount rate for Lamar Tie Line service between SPS and PSCo zones

7. **Holiday Schedule Verification**: Confirm NERC holiday definitions remain current

8. **Capacity Loss Calculations**: Verify methodology for including losses in capacity designations at Point(s) of Receipt

9. **Cross-Reference Validation**: Ensure all line references to Page 1 of Attachment O-SPS correspond to correct rate values

10. **Coordination Among UMZ Members**: Verify coordination mechanisms among 15+ transmission owners in Upper Missouri Zone for rate calculation consistency

11. **Document Continuity**: Review chunks 14 

---

# Chunk 16 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document contains detailed tariff language related to transmission service rates and integrated marketplace operations within the Southwest Power Pool (SPP). The content covers Point-To-Point Transmission Service rate structures for two primary rate zones: the UMZ (Upper Missouri Zone) involving multiple transmission owners, and the Western Farmers Electric Cooperative (WFEC) zone. Additionally, it includes technical amendments to Attachment AE concerning the Integrated Marketplace, specifically addressing must-offer requirements, meter agent functions, and Day-Ahead Market execution procedures.

## 2. Key Topics

- **Non-Firm Point-To-Point Transmission Service Rates** for UMZ rate zone
- **WFEC Rate Zone Point-To-Point Transmission Service** (both Firm and Non-Firm)
- **Balanced Portfolio Reallocation Adjustment** of Point-To-Point Rates
- **Revenue Crediting** for Point-To-Point Transmission Service
- **Meter Agent Requirements and Agreements** (Attachment AM)
- **Must-Offer Requirement Compliance** for Market Participants and Asset Owners
- **Day-Ahead Market SCUC Algorithm** execution and co-optimization methodology
- **Resource Commitment Procedures** including reliability-only resources
- **Emergency Capacity Operating Limits** and curtailment priorities

## 3. Decisions or Actions

- Market Participants must submit actual Resource output and load consumption data (or estimates if unavailable) through designated Meter Agents
- Meter Agents must execute the Meter Agent Agreement (Attachment AM) prior to performing functions
- Market Participants must comply with must-offer requirements at 90% threshold or face penalties under Section 3.9 of Attachment AF
- Market Monitor will monitor compliance with must-offer obligations for each hour of the Operating Day
- Day-Ahead Market SCUC algorithm will curtail non-firm transactions in priority order when capacity is insufficient
- Transmission Provider may manually commit/decommit Resources to address security constraints as Reliability Coordinator

## 4. Important Dates

No specific dates are mentioned in this content chunk. References are made to:
- Operating Day (general operational timeframe)
- Monthly, weekly, daily, and hourly delivery timeframes for rate calculations

## 5. Organizations and People Mentioned

**Organizations:**
- **Basin Electric**
- **Heartland**
- **MRES (Missouri River Energy Services)** and MRES Members
- **East River**
- **Corn Belt**
- **NWPS (Northwestern Public Service)**
- **NIPCO**
- **HMU**
- **Western-UGP**
- **Central Power**
- **Mountrail-Williams**
- **Mor-Gran-Sou**
- **Roughrider**
- **LOPC**
- **Western Farmers Electric Cooperative (WFEC)**
- **People's Electric Cooperative (PEC)**
- **SPP (Southwest Power Pool)** - Transmission Provider
- **Market Monitor**

**Roles Referenced:**
- Transmission Customer
- Transmission Provider
- Market Participant
- Asset Owner
- Meter Agent
- Reliability Coordinator

## 6. Links or References

**Internal Tariff References:**
- RRR File (Revenue Requirements and Rates File) - posted on SPP website
- "WFEC PTP Rate Att T" tab
- Attachment T (Point-To-Point Transmission Service)
- Attachment J, Section IV.A (Balanced Portfolio Reallocation)
- Attachment H, Addendum 39 (WFEC Formula Rate)
- Attachment H, Addendum 51 (PEC Formula Rate)
- Attachment AU (revenue distribution)
- Attachment AE (Integrated Marketplace)
- Attachment AF, Section 3.9 (penalty provisions)
- Attachment AM (Meter Agent Agreement)
- Section 34.1(2) of Tariff
- Section 4.1(10)(a), (b), (c) (commitment status descriptions)
- Section 2.11.1 (must-offer requirements)
- Section 5.1 (Day-Ahead Market)

**External References:**
- Schedule 7 and 8 revenues
- Market Protocols

## 7. Suggested Tags

- Transmission_Rates
- Point-To-Point_Service
- WFEC_Rate_Zone
- UMZ_Rate_Zone
- Day-Ahead_Market
- Must-Offer_Requirement
- Market_Participant_Compliance
- SCUC_Algorithm
- Meter_Agent
- Revenue_Requirements
- Formula_Rates
- Resource_Commitment
- Operating_Reserves
- Tariff_Amendment
- SPP_Integrated_Marketplace
- Reliability_Coordinator
- Emergency_Capacity

## 8. Items That May Need Follow-Up

1. **Meter Agent Agreement Execution**: Verify that all entities performing Meter Agent functions have executed Attachment AM agreements prior to performing duties

2. **Must-Offer Compliance Monitoring**: Confirm Market Monitor has systems in place to track hourly compliance with the 90% threshold for all Asset Owners

3. **Penalty Assessment Process**: Review Section 3.9 of Attachment AF to understand penalty calculation methodology for must-offer requirement violations

4. **RRR File Updates**: Ensure Revenue Requirements and Rates File on SPP website reflects current rates for all transmission owners in both UMZ and WFEC rate zones

5. **Manual Commitment Authority**: Clarify procedures and documentation requirements when Transmission Provider manually commits/decommits Resources for security constraints

6. **Formula Rate Protocols**: Verify current status of formula rates and protocols in Attachment H, Addendums 39 and 51

7. **Market Protocol Alignment**: Confirm timelines specified in Market Protocols for data submission align with operational requirements

8. **Emergency Capacity Limits**: Review operational procedures for incorporating Maximum/Minimum Emergency Capacity Operating Limits in Day-Ahead Market SCUC

9. **Non-Firm Transaction Curtailment**: Establish clear communication protocols for curtailment priority execution

10. **Multi-Day Reliability Assessment Integration**: Verify how Resources committed in Multi-Day Reliability Assessment flow into Day-Ahead Market SCUC algorithm

---

# Chunk 17 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document chunk (17 of 25) from SPP (Southwest Power Pool) comments dated January 28, 2025, contains detailed tariff language regarding Day-Ahead Market operations and Reliability Unit Commitment (RUC) processes. The content focuses on procedures for manual resource commitments, handling local reliability issues and emergency conditions, compensation mechanisms, and cost recovery allocation (regional vs. local). The document outlines specific algorithmic processes (SCUC and SCED) used for unit commitment and dispatch, including provisions for addressing transmission constraints and capacity adequacy requirements.

## 2. Key Topics

- **Manual Resource Commitments**: Procedures for manual commitment/decommitment of resources by Transmission Provider outside automated processes
- **Local Reliability Issues vs. Local Emergency Conditions**: Distinct treatment and compensation mechanisms for different reliability scenarios
- **Day-Ahead Market Process**: SCUC (Security Constrained Unit Commitment) and SCED (Security Constrained Economic Dispatch) algorithms
- **Day-Ahead Reliability Unit Commitment (RUC)**: Capacity adequacy analysis and resource commitment procedures
- **Intra-Day Reliability Unit Commitment**: Real-time capacity adequacy processes
- **Cost Recovery Allocation**: Regional vs. local cost collection mechanisms
- **Market Monitor Verification**: Non-discriminatory commitment verification process
- **Operating Guides**: Development of guides for known and recurring local reliability issues
- **Virtual Resource Limits (VRLs)**: Application when constraints cannot be resolved at acceptable shadow prices
- **Multi-Configuration Resources (MCRs)**: Eligibility restrictions for operating reserves during transitions

## 3. Decisions or Actions

- **Market Monitor verification required** for all manual commitments through Section 6.1.2.1 process
- **Operating guides to be developed** by Transmission Provider, local transmission operators, and Resource owners for manual commitments addressing recurring Local Reliability Issues
- **SCUC algorithm re-run required** after manual commitments (time permitting) if not included in initial run
- **Market Participants must be notified** when units are manually committed
- **Priority order established** for capacity shortfalls:
  1. Curtail non-firm fixed Export Interchange Transaction Bids
  2. Incorporate emergency capacity limits
  3. Commit reliability-only resources
  4. De-commit charging resources
- **Priority order established** for capacity surplus:
  1. Curtail non-firm fixed Import Interchange Transaction Offers
  2. Incorporate minimum emergency capacity limits
  3. Commit available reliability charging resources
  4. De-commit market-committed resources
  5. De-commit self-committed resources

## 4. Important Dates

- **Reference to "upcoming Operating Day"** (multiple instances) - indicates day-ahead planning horizon
- **30 minutes threshold** - MCRs with Transition State Time greater than 30 minutes not eligible to clear Operating Reserve during transition hours
- **Document date**: January 28, 2025 (from filename RR696 SPP Comments 20250728)

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)** - Transmission Provider and Reliability Coordinator
- **Market Monitor** - Verification entity for non-discriminatory commitments
- **Local transmission operators** - Request commitments for local reliability issues
- **Resource owners** - Develop operating guides with Transmission Provider
- **Market Participants** - Entities receiving notifications of manual commitments

### People:
- No specific individuals mentioned

## 6. Links or References

### Internal Document References:
- **Section 6.1.2.1** (Attachment AE) - Market Monitor verification process
- **Section 8.5.9** (Attachment AE) - Resource compensation
- **Section 8.5.10** (Attachment AE) - Regional cost recovery
- **Section 8.6.44** (Attachment AE) - Local cost recovery
- **Section 3.3.1** (Attachment AE) - SCED algorithm description
- **Section 8.3.2** (Attachment AE) - VRL application
- **Section 4.1(10)(c)** (Attachment AE) - Reliability-only resource designation
- **Section 4.1(10)(b)** (Attachment AE) - Market commitment status
- **Section 8.6.5** (Attachment AE) - RUC resource compensation
- **Section 8.6.7(A)** (Attachment AE) - Regional RUC cost recovery

### Document Reference:
- **RR696** - Revision Request number (from filename)

## 7. Suggested Tags

- SPP
- Day-Ahead Market
- Reliability Unit Commitment
- SCUC Algorithm
- SCED Algorithm
- Manual Commitment
- Local Reliability Issues
- Market Monitor
- Cost Allocation
- Operating Reserves
- Transmission System Security
- Market Settlement
- Multi-Configuration Resources
- Virtual Resource Limits
- Capacity Adequacy
- Tariff Language
- RR696

## 8. Items That May Need Follow-Up

1. **Operating Guides Development**: Status of operating guide development between Transmission Provider, local transmission operators, and Resource owners for recurring Local Reliability Issues

2. **Market Monitor Verification Process**: Details of Section 6.1.2.1 verification process for ensuring non-discriminatory manual commitments

3. **Cost Allocation Methodology**: Clarification on criteria distinguishing when costs are collected regionally (Section 8.5.10, 8.6.7(A)) versus locally (Section 8.6.44)

4. **MCR Transition State Limitations**: Impact assessment of 30-minute threshold on MCR operating reserve eligibility and market efficiency

5. **VRL Application Frequency**: Monitoring of how often Virtual Resource Limits must be applied when constraint solutions aren't feasible

6. **Local vs. System Reliability Distinction**: Clear criteria defining when an issue is classified as "Local Reliability Issue" versus general transmission system constraint

7. **Manual Commitment Frequency**: Tracking of manual commitment frequency to assess whether SCUC/SCED algorithms need enhancement

8. **Self-Committed Resource De-commitment**: Implications and stakeholder concerns regarding authority to de-commit self-committed resources during capacity surplus situations

9. **Implementation Timeline**: If RR696 represents proposed changes, implementation schedule and effective dates need clarification

10. **Coordination with Local Transmission Operators**: Process and communication protocols when local operators request manual commitments

---

# Chunk 18 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary

This document appears to be a portion of SPP's (Southwest Power Pool) Market Protocols and Attachment AE, specifically addressing Security Constrained Unit Commitment (SCUC) algorithms, resource commitment procedures, local reliability issues, non-conforming load requirements, and must-offer obligations for market participants. The content focuses on Day-Ahead Market operations, Real-Time Balancing Market (RTBM) procedures, and the handling of various resource types including Energy Storage Resources (ESRs) and Multi-Configuration Resources (MCRs). Key provisions address manual commitments for reliability purposes, compensation mechanisms, and load forecasting requirements.

## 2. Key Topics

- **SCUC Algorithm Operations**: Procedures for resource commitment considering Maximum/Minimum Economic Capacity Operating Limits, Regulation Services, and emergency capacity limits
- **Capacity Shortage/Surplus Management**: Priority order for curtailing transactions and committing/decommitting resources
- **Manual Commitments for Reliability**: Transmission Provider authority to manually commit/decommit resources for reliability issues not addressable within SCUC
- **Local Reliability Issues**: Procedures for local transmission operators to address Local Emergency Conditions, including manual commitment authority
- **Non-Conforming Load**: Forecasting and submission requirements for loads that don't follow predictable patterns, including ESR charging capabilities
- **Must-Offer Requirements**: Obligations for Market Participants to offer available resources to Day-Ahead Market, RUC, and RTBM
- **Compensation and Cost Recovery**: Regional vs. local cost allocation for reliability commitments under Section 8.6.5 and 8.6.44

## 3. Decisions or Actions

### Mandatory Actions for Market Participants:
- Submit hourly load forecasts for Non-Conforming Load before Day-Ahead RUC process begins
- Submit forecasts for six days following the Operating Day
- Submit updates up to 30 minutes before Operating Hour
- Submit rolling 15-minute ahead forecasts (encouraged for 2 hours ahead)
- Submit actual Non-Conforming Load data or estimates
- Satisfy must-offer obligations based on maximum hourly Reported Load for Asset Owners

### Transmission Provider Actions:
- May manually commit/decommit resources for reliability issues in non-discriminatory manner
- Must minimize commitment costs while adhering to security constraints
- Must log manual commitments and coordinate with local transmission operators
- Develop operating guides for manual commitments addressing recurring Local Reliability Issues

### Priority Order for Capacity Shortages:
1. Curtail non-firm fixed Export Interchange Transaction Bids
2. Incorporate emergency capacity limits and/or commit reliability-only resources
3. De-commit market-committed charging resources
4. De-commit self-committed charging resources

### Priority Order for Capacity Surplus:
1. Curtail non-firm fixed Import Interchange Transaction Offers
2. Incorporate emergency capacity limits and/or commit reliability MSRs
3. De-commit non-self-committed resources
4. De-commit self-committed resources

## 4. Important Dates

- **Before Day-Ahead RUC**: Initial Non-Conforming Load forecasts due
- **Up to 30 minutes before Operating Hour**: Final updates for Non-Conforming Load forecasts allowed
- **15-minute intervals**: Rolling forecasts required
- **Operating Day**: Must-offer obligations apply based on maximum hourly Reported Load
- **6 days following Operating Day**: Forecast horizon for Non-Conforming Load submissions

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)** - Transmission Provider
- **Market Monitor** - Verification entity for non-discriminatory resource selection (Section 6.1.2.1)
- **Local Transmission Operators** - May request commitments or issue instructions during Local Emergency Conditions
- **Market Participants** - Entities with load and resource obligations
- **Asset Owners** - Entities associated with registered load

### Roles Referenced:
- Transmission Provider
- Local transmission operator
- Resource owners
- Market Participants (load-serving)

## 6. Links or References

### Internal Document References:
- **Section 4.1(10)(c)** - Attachment AE (reliability only use designation)
- **Section 4.1(10)(b)** - Attachment AE (market commitment status)
- **Section 6.1.2.1** - Attachment AE (Market Monitor verification process)
- **Section 6.2.2** - Non-Conforming Load description
- **Section 6.2.8** - Load registration under bilateral contracts
- **Section 4.1.3(4)** - Operating Reserve obligation calculation
- **Section 8.6.5** - Attachment AE (compensation provisions)
- **Section 8.6.7(A)** - Attachment AE (regional cost recovery)
- **Section 8.6.44** - Attachment AE (local cost recovery)

### Referenced Concepts:
- SCUC (Security Constrained Unit Commitment) algorithm
- Day-Ahead Market
- Intra-Day Reliability Unit Commitment Process
- RTBM (Real-Time Balancing Market)
- Energy Resource Interconnection Service
- Network Resource Interconnection Service

## 7. Suggested Tags

- Market Operations
- Unit Commitment
- Resource Scheduling
- Reliability Procedures
- Day-Ahead Market
- Real-Time Market
- Load Forecasting
- Non-Conforming Load
- Must-Offer Obligation
- Manual Commitments
- Local Reliability
- Energy Storage Resources
- Market Monitor
- Cost Allocation
- SPP Market Protocols
- Attachment AE
- SCUC Algorithm
- Operating Reserves
- Transmission System Security
- Compensation Mechanisms

## 8. Items That May Need Follow-Up

### Clarification Needed:
1. **Incomplete text**: Section appears to cut off mid-sentence at "such shares have not been re..." - full must-offer calculation appears incomplete
2. **"at risk" notation**: Appears in document without context (after Section 8.3)
3. **"Reserved" section**: Market Protocols Glossary section marked as "Reserved" - content pending?
4. **Section numbering inconsistency**: References to sections 6.3 and 8.2 appear without clear context

### Operational Questions:
1. **Timeline coordination**: How is the 30-minute submission deadline enforced when local transmission operators need to act during emergencies?
2. **Affiliation determination**: What constitutes "affiliation" between resources and local transmission operators for compensation eligibility?
3. **Non-discriminatory verification**: Specific criteria and timeframes for Market Monitor verification under Section 6.1.2.1
4. **Operating guides development**: Timeline and process for developing operating guides for recurring Local Reliability Issues

### Potential Implementation Issues:
1. **MSR Self-Charging calculation**: Method for determining Self-Charging MW during maximum Reported Load hour
2. **Interpolation methodology**: Specific method for interpolating 15-minute forecasts from hourly Non-Conforming Load data
3. **Bilateral contract load registration**: Coordination between buyers and sellers to avoid double-counting in must-offer calculations
4. **Emergency capacity limits**: Criteria for when emergency limits may be invoked vs. normal operating limits

### Monitoring Requirements:
1. **Manual commitment frequency**: Track frequency and reasons for manual commitments to identify systemic issues
2. **Cost allocation impacts**: Monitor regional vs. local cost recovery amounts and distribution
3. **Non-Conforming Load forecast accuracy**: Evaluate accuracy to determine if submission requirements are adequate
4. **Local Emergency Condition frequency**: Track how often local operators must act without Transmission Provider coordination

---

# Chunk 19 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document chunk (19 of 25) from SPP's regulatory revision RR696 details must-offer obligations for Market Participants and Day-Ahead Market execution procedures. It covers compliance requirements for Asset Owners, resource registration and verification processes, market clearing algorithms (SCUC and SCED), and handling of reliability issues. The content focuses on technical market operations including how SPP commits resources, manages capacity shortages/surpluses, and addresses transmission system constraints while maintaining system reliability.

## 2. Key Topics

- **Must-Offer Obligation Compliance**: Requirements for Market Participants to offer available resources for Asset Owners
- **Net Resource Capacity Calculations**: Including firm power purchases/sales verification through Market Monitor
- **Day-Ahead Market Clearing**: SCUC and SCED algorithm processes for resource commitment
- **Resource Commitment Hierarchy**: Market, Self, and Reliability commitment statuses
- **Capacity Management**: Procedures for handling capacity shortages and surpluses
- **GFA Carve Out Requirements**: Resources must be offered with sufficient capacity to cover schedules
- **Local Reliability Issues**: Manual commitment/decommitment procedures
- **Operating Reserve Requirements**: Co-optimization with energy dispatch
- **Multi-Configuration Resources (MCRs)**: Limitations during configuration transitions
- **Emergency Limits**: Application during capacity constraints

## 3. Decisions or Actions

- Market Monitor will contact Market Participants if firm power purchase/sale information not provided via website
- Market Monitor may confirm firm purchases/sales with counterparties
- Disputed firm purchases/sales will not be used in net Resource capacity calculations
- SPP may manually commit/decommit Resources for transmission system security constraints
- Manual commitments must be selected in non-discriminatory manner, verified by Market Monitor
- SPP will re-run Day-Ahead SCUC algorithm after manual commitments (time permitting)
- SPP, local transmission operators, and Resource owners will develop operating guides for manual commitments
- DA Market SCUC will curtail non-firm exports/imports in priority order during capacity issues

## 4. Important Dates

- Operating Day (referenced throughout for hourly compliance and market execution)
- No specific calendar dates mentioned in this chunk

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)**: Market operator and Reliability Coordinator
- **Market Monitor**: Oversight and verification entity
- **Market Participants**: Load-serving entities and resource owners
- **Asset Owners**: Entities with registered resources
- **Local transmission operators**: Request SPP instructions for local reliability issues

**People:**
- None specifically mentioned

## 6. Links or References

**Internal Document References:**
- Section 4.2.2.5.4 (JOU Individual Resource Option)
- Section 6.1.14 (Combined Interest Resource modeling)
- Section 4.2.1.1 B (must-offer obligation requirements)
- Section 4.2.1.1.1 (penalty assessments)
- Section 6.1.7.1 (MCR registration options)
- Section 6.1.2.1 of Attachment AE to the Tariff (Market Monitor verification process)
- Section 4.5.9.12 (compensation for committed Resources)
- Section 4.5.9.13 (regional cost recovery)
- Section 4.5.8.12 (compensation provisions)
- Section 4.5.9.10(1) (local cost recovery)
- Section 3.1.1 (SCED algorithm description)
- Section 4.1.3.3 (Violation Relaxation Limits)

**External References:**
- Market Monitor website (for firm power transaction data entry)

## 7. Suggested Tags

- Must-Offer Obligation
- Day-Ahead Market
- SCUC Algorithm
- SCED Algorithm
- Market Monitor
- Resource Commitment
- Capacity Adequacy
- Local Reliability Issues
- GFA Carve Out
- Net Resource Capacity
- Emergency Limits
- Multi-Configuration Resources
- Operating Reserves
- Market Compliance
- Firm Power Transactions
- Manual Commitment
- Transmission Constraints

## 8. Items That May Need Follow-Up

1. **Compliance Threshold Verification**: 90% net Resource capacity threshold for must-offer compliance - verify if this percentage is appropriate and being consistently applied
2. **Market Monitor Website Functionality**: Confirm the Market Monitor website for firm power transaction input is operational and accessible to all Market Participants
3. **Dispute Resolution Process**: Need clarity on timeline and formal process when counterparties dispute firm purchases/sales
4. **Operating Guide Development**: Status of operating guides being developed by SPP, local transmission operators, and Resource owners for manual commitments
5. **Non-Discriminatory Selection Verification**: Process and documentation for Market Monitor verification of manual commitment selections
6. **MCR Transition Time Threshold**: 30-minute threshold for MCR regulation eligibility - verify technical justification
7. **Cost Recovery Allocation**: Confirm proper allocation between regional (Section 4.5.9.13) and local (Section 4.5.9.10(1)) cost recovery
8. **VRL Application**: Documentation of situations where Violation Relaxation Limits are applied in SCED
9. **Emergency Limit Activation**: Tracking and reporting when emergency limits are incorporated into market clearing
10. **GFA Carve Out Compliance**: Monitoring mechanism to ensure Resources used for GFA Carve Out are properly offered with sufficient capacity

---

# Chunk 20 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document chunk (20 of 25) from RR696 SPP Comments contains detailed technical specifications for the Security Constrained Unit Commitment (SCUC) algorithm used in both Day-Ahead and Intra-Day Reliability Unit Commitment (RUC) processes. The content outlines the systematic approach SPP takes to commit generation resources to meet load forecasts and operating reserve requirements while minimizing costs and maintaining transmission system security. Key provisions cover priority orders for addressing capacity shortfalls and surpluses, manual commitment authority, and compensation recovery mechanisms for reliability-driven resource commitments.

## 2. Key Topics

- **SCUC Algorithm Objectives**: Committing resources to meet SPP load forecasts, export transactions, and operating reserves while minimizing commitment costs
- **Commitment Cost Definition**: Start-Up Offer, No-Load Offer, and incremental cost to operate at minimum output
- **Resource Commitment Hierarchy**: Market vs. Self vs. Reliability commit status categories
- **Capacity Operating Limits**: Maximum/Minimum Economic, Emergency, Regulation, and Charge/Discharge limits
- **Capacity Shortfall Mitigation**: Priority order including curtailing non-firm exports, incorporating emergency capacity, and de-committing charging resources
- **Capacity Surplus Management**: Priority order including curtailing imports, using emergency limits, committing charging-capable reliability resources
- **Manual Commitment Authority**: SPP's Reliability Coordinator authority to manually commit/de-commit resources
- **Local Reliability Issues**: Procedures for addressing transmission operator-specific reliability concerns
- **Multi-Configuration Resources (MCRs)**: Regulation eligibility restrictions during configuration transitions
- **Compensation and Cost Recovery**: Regional vs. local collection mechanisms based on issue type

## 3. Decisions or Actions

**SCUC Algorithm Actions (Priority Order for Capacity Shortfall):**
1. Curtail non-firm Export Interchange Transactions
2. Incorporate capacity up to Maximum Emergency Operating Limits and commit Reliability Status Resources
3. De-commit charging Resources committed in DA Market with Market status
4. De-commit self-committed charging Resources

**SCUC Algorithm Actions (Priority Order for Capacity Surplus):**
1. Curtail non-firm fixed Import Interchange Transactions
2. Incorporate capacity down to Minimum Emergency Operating Limits
3. Commit available Reliability Status Resources capable of charging
4. De-commit Resources committed in DA Market with Market status
5. De-commit self-committed Resources

**Manual Commitment Requirements:**
- SPP may manually commit/de-commit resources as Reliability Coordinator
- Selection must be non-discriminatory (verified by Market Monitor per Section 6.1.2.1)
- Must minimize commitment costs while adhering to constraints
- Operating guides shall be developed for known and recurring Local Reliability Issues

## 4. Important Dates

- **Operating Day**: Referenced throughout as the timeframe for RUC execution and resource commitments
- No specific calendar dates mentioned in this chunk

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)**: Grid operator and Reliability Coordinator
- **Market Monitor**: Oversight entity verifying non-discriminatory resource selection
- **Local Transmission Operators**: Entities that may request manual commitments for Local Reliability Issues

**Roles Referenced:**
- SPP RUC Operators
- Day-Ahead RUC Operators
- Intra-Day RUC Operators
- Resource owners
- Reliability Coordinator

## 6. Links or References

**Internal Document References:**
- Section 6.1.7.1 (MCR registration options for regulation selection)
- Section 6.1.2.1 of Attachment AE to the Tariff (Market Monitor non-discriminatory verification process)
- Section 4.5.9.8 (Resource compensation provisions)
- Section 4.5.9.10 (Regional and local compensation recovery mechanisms)
- Day-Ahead and Intra-Day RUC Results sections

**Referenced Technical Elements:**
- RTBM (Real-Time Balancing Market) Offers
- DA (Day-Ahead) Market
- Tariff Attachment AE

## 7. Suggested Tags

- SCUC Algorithm
- Reliability Unit Commitment (RUC)
- Resource Commitment
- Day-Ahead Market
- Intra-Day RUC
- Capacity Adequacy
- Operating Reserves
- Manual Commitment
- Local Reliability Issues
- Transmission Security
- Market Monitor
- Cost Recovery
- Emergency Operating Limits
- Non-Discriminatory Selection
- Reliability Coordinator Authority
- Import/Export Interchange
- Multi-Configuration Resources
- Regulation Services

## 8. Items That May Need Follow-Up

1. **Market Monitor Verification Process**: The specific procedures under Section 6.1.2.1 of Attachment AE for verifying non-discriminatory resource selection should be reviewed for consistency

2. **Operating Guide Development**: The requirement to develop operating guides for known and recurring Local Reliability Issues between SPP, local transmission operators, and resource owners needs implementation timeline and standards

3. **Compensation Recovery Allocation**: Clarification needed on the criteria distinguishing "regional" vs. "local" cost recovery under Section 4.5.9.10, particularly for borderline cases

4. **MCR Regulation Eligibility**: The interaction between Section 6.1.7.1 registration options and intra-hour regulation selection restrictions may require operational guidance

5. **Advisory vs. Binding Information**: The distinction between SCUC algorithm outputs providing "advisory information" versus binding commitment decisions by RUC Operators may need clearer operational protocols

6. **Transmission Constraint/Excess Capacity Simultaneity**: The conditions under which SCUC may commit additional resources when transmission constraints coincide with excess capacity events needs clearer definition of "not aggravating"

7. **Time-Critical Local Reliability Issues**: The phrase "Time permitting, the local transmission operator will request..." suggests cases where time doesn't permit—procedures for those scenarios need clarification

8. **Self-Committed Resource De-commitment Authority**: The extent of SPP's authority to de-commit self-committed resources and potential market participant concerns should be assessed

9. **Document Continuity**: This is chunk 20 of 25—text appears truncated mid-sentence at the end; continuation needed for complete context

---

# Chunk 21 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary
This document chunk contains sections from SPP's (Southwest Power Pool) regulatory tariff and operational documents covering three main areas: (1) manual commitment and dispatch procedures for resources during local reliability issues, including compensation mechanisms and non-discriminatory selection standards; (2) operational and planning criteria including ICCP node connectivity requirements, emergency operating plans, and transmission system planning standards; and (3) business practices for non-jurisdictional facility interconnections. The content emphasizes coordination between SPP and local transmission operators, data system redundancy requirements, and procedures for evaluating transmission system modifications.

## 2. Key Topics

- **Manual Commitment & Dispatch Procedures**: Coordination between SPP and local transmission operators for resource commitments during Local Emergency Conditions
- **Compensation Recovery**: Local collection mechanisms under Section 4.5.9.10 for resources committed during reliability issues
- **Non-Conforming Load**: Registration requirements for loads 50 MW or greater
- **ICCP Node Connectivity**: Dual-node requirements for TOPs and GOPs to ensure system reliability and data availability
- **Emergency Operating Plans (EOPs)**: Guidelines for operator-controlled load shedding and natural gas load prioritization
- **Transmission Material Modification**: Definitions and criteria for evaluating permanent changes to transmission facilities (>12 months duration)
- **Qualified Change Standards**: Requirements for transmission, generation, and electricity end-user facility changes
- **Non-Jurisdictional Generator Interconnections**: Study procedures and affected system analysis requirements

## 3. Decisions or Actions

- **Market Monitor Review**: Must determine if resource selection was discriminatory for affiliated resources; non-compliant resources ineligible for Section 4.5.9.8 compensation
- **Operating Guide Development**: SPP, local transmission operators, and resource owners must develop operating guides for manual commitments
- **Non-Conforming Load Registration**: Market participants must identify any Non-Conforming Load assets ≥50 MW and associated PNode/APNode locations
- **ICCP Node Configuration Requirements**:
  - All TOPs must connect to both SPP primary and backup sites concurrently
  - TOPs and GOPs must configure two ICCP nodes with 240-second reconnection capability
  - GOPs with >1500 MW or 15+ capacity resources must read setpoint instructions from both primary and secondary nodes concurrently
- **Study Requirements**: Non-jurisdictional generator interconnection customers may be required to enter study agreements with SPP

## 4. Important Dates

- **240 seconds**: Maximum reconnection time required for alternate ICCP nodes following failure
- **12 months**: Duration threshold for defining "permanent changes" under Qualified Change and Transmission Material Modification definitions

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)**: Regional Transmission Organization and Transmission Provider
- **Market Monitor**: Entity responsible for determining discriminatory resource selection
- **Local transmission operators**: Coordinate with SPP on reliability issues
- **NERC (North American Electric Reliability Corporation)**: Standards authority
- **TOPs (Transmission Operators)**: Required to meet ICCP connectivity standards
- **GOPs (Generator Operators)**: Subject to ICCP node requirements
- **Transmission Owners**: Responsible for conducting impact studies
- **Market Participants**: Subject to Non-Conforming Load registration requirements

### Specific Roles Referenced:
- SPP Reliability Coordinator
- Planning Coordinator
- Resource owners
- Interconnection customers
- Third-party ICCP contractors

## 6. Links or References

### SPP Tariff Sections:
- Section 4.5.9.8 (compensation provisions)
- Section 4.5.9.10 (local recovery collection)
- Section 6.1.2.1 of Attachment AE (Intra-Day Reliability Unit Commitment standards)
- Section 6.2.2 (Non-Conforming Load requirements)

### SPP OATT Attachments:
- Attachment O (Transmission Planning Process)
- Attachment V (generation interconnection and replacement)
- Attachment AB (retirement assessment)
- Attachment AQ (delivery point establishment)

### Standards Referenced:
- NERC Reliability Standards (general reference)
- NERC Standard FAC-002-041 (Qualified Change compliance)
- NERC Glossary of Terms
- SPP Operating Criteria Section 3.6 (EOP Reviews)
- SPP Operating Criteria Section 5.2 (Node Connectivity)
- SPP Planning Criteria Section 5 (transmission system definitions)
- SPP Business Practice 7250, Section 6.3

### Other References:
- Inter-Control Center Communications Protocol (ICCP)
- RDS (Telemetering and Control System Status) Outage Scheduling Information

## 7. Suggested Tags

- Manual Commitment
- Resource Dispatch
- Local Reliability Issues
- Emergency Operations
- ICCP Connectivity
- Data Redundancy
- Transmission Planning
- Material Modification
- Generator Interconnection
- Non-Jurisdictional Facilities
- Load Shedding
- Market Monitor
- Compensation Recovery
- System Impact Studies
- BES (Bulk Electric System)
- Reliability Coordination
- Non-Conforming Load
- Critical Infrastructure
- Natural Gas Coordination
- Affiliated Resources

## 8. Items That May Need Follow-Up

1. **Operating Guide Development Status**: Verify completion status of operating guides to be developed by SPP, local transmission operators, and resource owners for manual commitments

2. **ICCP Node Compliance**: Confirm all TOPs and GOPs meeting the specified thresholds (>1500 MW or 15+ capacity resources) have implemented dual-node configurations with 240-second reconnection capability

3. **Non-Conforming Load Registration**: Ensure all Market Participants have completed registration for Non-Conforming Loads ≥50 MW with appropriate PNode/APNode designations

4. **Market Monitor Procedures**: Clarify implementation procedures for Market Monitor determinations regarding discriminatory resource selection, particularly for affiliated resources

5. **Third-Party ICCP Contracts**: Review existing third-party ICCP contracts to ensure 240-second reconnection requirements are contractually enforceable

6. **Transmission Material Modification Criteria**: Establish tracking mechanism for changes meeting the 20% rating reduction or 30% impedance change thresholds

7. **Non-Jurisdictional Study Agreements**: Develop template study agreements for non-jurisdictional generator interconnection customers

8. **EOP Critical Load Prioritization**: Confirm all TOPs have updated EOPs to prioritize critical natural gas loads as recommended

9. **Compensation Recovery Mechanism**: Verify Section 4.5.9.10 local collection procedures are operational and properly implemented

10. **RDS Outage Scheduling Compliance**: Ensure all entities are following Outage Scheduling Information procedures for planned and forced ICCP node outages

---

# Chunk 22 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary

This document chunk contains technical procedures from SPP's (Southwest Power Pool) regulatory manual regarding network upgrades, generator interconnection procedures (HILLGA/HILL), and delivery point processes. The content covers three main areas: (1) network upgrade requirements for generating facilities, (2) technical procedures for HILLGA (High Impact Legacy Generation) network studies and short-circuit analysis, and (3) Business Practice 7850 defining processes for evaluating Delivery Point Additions, Modifications, and Retirements under Attachments AQ and AX. The document establishes procedural requirements for interconnection studies, model development, and transmission planning assessments.

## 2. Key Topics

- **Network Upgrades for Generation Interconnection**: Requirements for distribution system and transmission system upgrades; facilities agreement options between Transmission Owners and interconnection customers
- **HILLGA Network Studies**: Serial vs. parallel processing based on Electrically-Equivalent status; queue position determination
- **Model Development**: Base and Change Models for HILLGA requests; incorporation of ITP Non-Legacy generation with GIAs
- **Short-Circuit Fault Current Calculations**: Methodology consistent with HILL Short-Circuit Analysis; refinement in Interconnection Facility Study
- **Delivery Point Processes (BP 7850)**: Evaluation procedures for Delivery Point Additions, Modifications, and Retirements
- **Attachment AQ vs. Attachment AX**: Different processes based on whether Transmission Customer has sufficient Designated Resources
- **Aggregation of Requests**: Multiple delivery point requests in proximity may be consolidated

## 3. Decisions or Actions

- Network Upgrades must be completed **prior to operation of Generating Facility** (unless SPP approves other mitigations)
- Transmission Owners have the **option** to enter facilities agreements directly with SPP or require interconnection customers to do so
- HILLGA Requests will be studied **serially if Electrically-Equivalent** or **in parallel if not Electrically-Equivalent**
- Network Upgrades from HILL and HILLGA studies are **not included** in SCRCCT analysis starting models
- Transmission Customers are **responsible for notifying SPP** to update NITS Agreements for Delivery Point changes
- Transmission Provider **must approve** aggregation of multiple delivery point requests
- Transmission Provider shall **propose aggregated study approach to all Parties** and evaluate feedback before proceeding

## 4. Important Dates

No specific dates are mentioned in this content chunk. References are made to:
- "Prior to operation of the Generating Facility" (timing requirement)
- Study timelines (referenced but not specified)
- SPP Quarterly Project Tracking Report (periodic reporting)

## 5. Organizations and People Mentioned

**Organizations:**
- SPP (Southwest Power Pool) - Transmission Provider
- Transmission Owners/Distribution Providers
- Associated Electric Cooperatives, Inc.
- California Independent System Operator Corporation (CAISO)
- Electric Reliability Council of Texas (ERCOT)
- Midcontinent Independent System Operator, Inc. (MISO)
- Peak
- Public Service Company of Colorado
- Saskatchewan Power Corporation
- Southwestern Power Administration
- Tennessee Valley Authority (TVA)

**Roles Referenced:**
- Interconnection Customers
- Transmission Customers
- Network Customers

## 6. Links or References

**Referenced Documents:**
- SPP Open Access Transmission Tariff (OATT)
- Generator Interconnection Procedures (Attachment V)
- SPP Business Practices
- Attachment BB (multiple section references: 4.1.1, 8.4.1)
- Attachment AQ (Delivery Point evaluation process)
- Attachment AX (Provisional Load Process)
- Business Practice 7850
- Business Practice 7060 (BP 7060 - standardized project timelines)
- SPP ITP Manual (Short-Circuit Analysis section)
- SPP Model Development Procedure Manual
- SPP Disturbance Performance Requirements
- SPP Quarterly Project Tracking Report
- Request Management System
- Seams Agreements (various entities listed)

**Online Resources Mentioned (locations not provided in text):**
- ITP Manual location
- SPP Model Development Procedure Manual location

## 7. Suggested Tags

- Network Upgrades
- Generator Interconnection
- HILLGA/HILL Studies
- Short-Circuit Analysis
- Transmission Planning
- Delivery Point Management
- Business Practice 7850
- Attachment AQ
- Attachment AX
- NITS Agreement
- Facilities Agreement
- ITP Models
- Queue Position
- Model Development
- SPP OATT
- Distribution System
- Transmission System

## 8. Items That May Need Follow-Up

1. **Incomplete Sections**: Multiple "(Placeholder)" notations and "wi" fragments suggest document is in draft form
2. **Model Timeline Clarification**: Need to establish specific timelines for when preliminary vs. final HILL model analysis must be completed
3. **Aggregation Criteria**: No clear criteria provided for determining "relative proximity" for aggregating delivery point requests
4. **Missing Links**: Reference document locations are listed but actual URLs/links not provided for ITP Manual and Model Development Procedure Manual
5. **Electrically-Equivalent Definition**: Critical term for determining study methodology but definition not provided in this chunk
6. **Cost Assignment Details**: Referenced for short-circuit analysis but methodology not detailed
7. **NITS Agreement Update Process**: Specific procedural steps for updating agreements not fully detailed
8. **Mitigation Approval Process**: What constitutes acceptable "other mitigations" allowing operation before Network Upgrades completion?
9. **Study Fee Structure**: No mention of costs or fee schedules for HILLGA studies or Delivery Point evaluations
10. **Dispute Resolution**: No process mentioned for disagreements between parties regarding aggregation or study results
11. **Missing Definitions**: "Maximum Injection Capability," "Electrically-Equivalent," "Local Delivery Facilities" definitions needed for complete understanding

---

# Chunk 23 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary
This document chunk (23 of 25) from SPP Comments dated January 28, 2025, contains excerpts from multiple SPP regulatory documents including Business Practice 8100, the Integrated Transmission Planning (ITP) Manual, and revenue requirement tables. The content addresses delivery point definitions, resource adequacy requirements for demand response programs and behind-the-meter generation, load forecasting procedures, and transmission owner revenue requirements. Key focus areas include the treatment of demand response resources and the distinction between dispatchable and non-dispatchable resources for resource adequacy purposes.

## 2. Key Topics

- **Delivery Point Additions**: Definitions and exclusions for the Attachment AX evaluation process
- **Resource Adequacy (Business Practice 8100)**: Requirements for demand response programs and behind-the-meter generation under 10 MW
- **Demand Response Classification**: 
  - Dispatchable vs. non-dispatchable programs
  - Treatment as load modifiers vs. resource capacity
- **Behind-the-Meter Generation**: Treatment of non-controllable resources (e.g., rooftop solar)
- **Load Forecasting**: Requirements for 50-50 peak demand forecasts in the ITP assessment
- **Persistent Operational Needs**: Economic and reliability-related criteria assessment
- **Revenue Requirements**: Allocation for through and out transactions across transmission owners

## 3. Decisions or Actions

- Non-controllable and non-dispatchable demand response programs may **only** be considered in the LRE's forecasted Peak Demand (not as resource capacity)
- LREs must report projected MW level of Peak Demand reduction as an informational line item in the Workbook
- Load forecasts must represent 50-50 probability (50% chance of being too high, 50% chance of being too low)
- Seasonal demand reduction must be determined using historical hourly demand data
- SPP may propose additional operational needs beyond criteria thresholds for ESWG and TWG review and endorsement
- Load forecasts must represent individual load-serving entity's peak conditions without losses per season (non-coincident conditions)

## 4. Important Dates
- **January 28, 2025**: Date referenced in source file name (RR696 SPP Comments 20250728)
- No other specific dates mentioned in this content chunk

## 5. Organizations and People Mentioned

### Organizations (Transmission Owners):
- AEP West Transmission Companies (AEP Oklahoma Transmission Company, Inc. and AEP Southwestern Transmission Company, Inc.)
- American Electric Power (Public Service Company of Oklahoma and Southwestern Electric Power Company)
- Arkansas Electric Cooperative Corporation (1 and 7)
- City Utilities of Springfield
- Corn Belt Power Cooperative
- Empire District Electric Company
- Evergy Kansas Central, Inc. (including Evergy Kansas South, Inc.)
- Evergy Metro, Inc.
- Evergy Missouri West, Inc.
- Grand River Dam Authority
- Kansas City Board of Public Utilities
- Lincoln Electric System
- Midwest Energy, Inc.
- Missouri Joint Municipal Electric Utility Commission
- Nebraska Public Power District
- Oklahoma Gas and Electric
- Omaha Public Power District
- Southwestern Power Administration
- Southwestern Public Service Company
- Sunflower Electric Power Corporation
- Tri-State G&T Association
- Western Farmers Electric Cooperative
- Western-UGP

### SPP Groups/Entities:
- Load Responsible Entity (LRE)
- Market Participant
- Transmission Provider
- SPP Transmission Owners (TOs)
- ESWG (Economics Studies Working Group)
- TWG (Transmission Working Group)

### People:
None specifically named

## 6. Links or References

- **Attachment AX**: Process for evaluating Delivery Point Additions
- **Attachment AA**: Resource Adequacy Requirement and Winter Season Obligation
- **Business Practice 8100**: Resource Adequacy requirements for Demand Response Programs and Behind-The-Meter Generation
- **ITP Manual**: Integrated Transmission Planning Manual (Sections 2.1.3 and 4.4 referenced)
- **Model Development Procedure Manual**: Referenced for load forecast submission process
- **RRR File**: Referenced multiple times in revenue requirement tables
- **Workbook**: Document where LREs report Peak Demand reduction projections
- **TABLE 1**: Revenue Requirements for the Allocation of Through And Out Transactions
- **TABLE 2**: Schedule 1 Point-to-Point ("PTP") Revenue Credit

## 7. Suggested Tags

- Resource Adequacy
- Demand Response
- Behind-the-Meter Generation
- Load Forecasting
- Integrated Transmission Planning
- ITP Manual
- Business Practice 8100
- Delivery Point Additions
- Revenue Requirements
- Transmission Owners
- Peak Demand
- SPP Tariff
- Non-Dispatchable Resources
- Load Responsible Entity
- Through and Out Transactions
- Attachment AX
- Attachment AA

## 8. Items That May Need Follow-Up

1. **Clarification Needed**: Definition of "adequate system survey" for determining seasonal demand reduction for non-dispatchable resources
2. **Implementation Details**: Process for LREs to report MW level of Peak Demand reduction in the Workbook - format and frequency requirements
3. **Revenue Requirement Values**: All tables reference "See RRR File" - actual numerical values not provided in this chunk
4. **Threshold Criteria**: Specific criteria thresholds for identifying persistent operational needs mentioned but not detailed in this excerpt
5. **ESWG and TWG Process**: Review and endorsement procedures for additional operational needs proposed by SPP
6. **Historical Data Requirements**: Specific time period for "sufficient" historical hourly demand data not defined
7. **BTM Generation Size Threshold**: Rationale for the 10 MW threshold for behind-the-meter generation treatment
8. **Section II.3 Reference**: American Electric Power has a notation "See Section II.3" - content not included in this chunk
9. **Schedule 1 PTP Revenue Credit**: Several entries show "$0" while others show "N/A" - distinction and implications unclear

---

# Chunk 24 Analysis

# REGULATORY ANALYSIS REPORT
## Source: RR696 SPP Comments 20250728.docx.txt - chunk 24 of 25

---

## 1. Executive Summary

This document contains detailed financial allocation tables related to SPP (Southwest Power Pool) Regional Revenue Requirement (RRR) filings. The content presents three comprehensive tables outlining Zonal Annual Transmission Revenue Requirements (ATRR) across 19+ zones, Base Plan Region-wide ATRR components, and various ATRR allocation categories. Most specific dollar amounts reference "Att. H tab, posted RRR File" for detailed values, with only a few specific amounts disclosed in the tables (ranging from approximately $327,891 to $15,533,800). The tables track transmission cost allocations across multiple utilities, cooperatives, and transmission companies throughout the SPP region.

---

## 2. Key Topics

- **Annual Transmission Revenue Requirements (ATRR)** - Zonal and Region-wide allocations
- **Base Plan vs. Balanced Portfolio** - Different ATRR allocation methodologies
- **Upgrade Sponsor Payments** - Base Plan Zonal ATRR designated for upgrade sponsors
- **Zonal Structure** - 19 defined zones plus sub-zones covering SPP territory
- **Interregional Planning** - SPP and Other Interregional Planning Region ATRR
- **JTIQ ATRR Balance** - Joint Transmission Investment Queue cost allocation
- **Network Transmission Cost (NTC)** - Pre- and post-June 19, 2010 allocations

---

## 3. Decisions or Actions

- **Reference to External File**: All detailed ATRR amounts directed to "Att. H tab, posted RRR File" (standardized across most entries)
- **Reserved Zones**: Zones 1c, 11b, and 15 designated as "Reserved for Future Use"
- **ATRR Reallocation**: Mechanism established to reallocate ATRR from zonal to region-wide balanced portfolio
- **Specific ATRR Allocations Disclosed**:
  - East Texas Electric Cooperative: $14,567,983
  - Deep East Texas Electric Cooperative: $2,576,698
  - Oklahoma Municipal Power Authority (Zone 1e): $768,624
  - Coffeyville Municipal Light and Power: $391,790
  - City of Independence, Missouri: $7,043,930
  - Oklahoma Municipal Power Authority (Zone 7b): $368,501
  - Southwestern Power Administration: $15,533,800
  - Central Nebraska Public Power and Irrigation District: $327,891

---

## 4. Important Dates

- **June 19, 2010** - Critical transition date for Base Plan Zonal ATRR and Base Plan Region-wide ATRR (NTC) calculations
  - Column (4): Base Plan Zonal ATRR
  - Column (5): Base Plan Zonal ATRR after June 19, 2010
  - Table 4 & 5, Line 1: Base Plan Region-wide ATRR (NTC prior to June 19, 2010)
  - Table 4 & 5, Line 2: Base Plan Region-wide ATRR (NTC on or after June 19, 2010)

---

## 5. Organizations and People Mentioned

### **Zone 1 - AEP West (and sub-zones):**
- American Electric Power – West
- Public Service Company of Oklahoma
- Southwestern Electric Power Company
- East Texas Electric Cooperative, Inc.
- Deep East Texas Electric Cooperative, Inc.
- Oklahoma Municipal Power Authority
- AEP Oklahoma Transmission Company, Inc
- AEP Southwestern Transmission Company, Inc
- Coffeyville Municipal Light and Power (CMLP)
- Arkansas Electric Cooperative Corporation (AECC)
- Transource Oklahoma, LLC

### **Zones 2-5:**
- Kansas City Board of Public Utilities
- City Utilities of Springfield, Missouri
- Empire District Electric Company
- Grand River Dam Authority

### **Zone 6 - Evergy Metro:**
- Evergy Metro, Inc.
- City of Independence, Missouri

### **Zone 7 - Oklahoma Gas and Electric:**
- Oklahoma Gas and Electric
- Oklahoma Municipal Power Authority
- Arkansas Electric Cooperative Corporation
- People's Electric Cooperative
- NextEra Energy Transmission Southwest, LLC

### **Zones 8-9:**
- Midwest Energy, Inc.
- Evergy Missouri West, Inc.
- Transource Missouri, LLC

### **Zone 10 - Southwestern Power Administration:**
- Southwestern Power Administration
- South Central MCN LLC
- Missouri Joint Municipal Electric Utility Commission
- People's Electric Cooperative

### **Zone 11 - Southwestern Public Service:**
- Southwestern Public Service Company
- Lea County Electric Cooperative, Inc.

### **Zone 12 - Sunflower Electric:**
- Sunflower Electric Power Corporation
- ITC Great Plains, LLC
- Prairie Wind Transmission, LLC

### **Zone 13 - Western Farmers:**
- Western Farmers Electric Cooperative
- People's Electric Cooperative

### **Zone 14 - Evergy Kansas:**
- Evergy Kansas Central, Inc.
- Evergy Kansas South, Inc.
- Prairie Wind Transmission, LLC
- Kansas Power Pool
- South Central MCN LLC
- NextEra Energy Transmission Southwest, LLC

### **Zones 16-18:**
- Lincoln Electric System
- Nebraska Public Power District
- Central Nebraska Public Power and Irrigation District
- Tri-State G&T Association
- Omaha Public Power District

### **Zone 19 - Upper Missouri (extensive sub-zones):**
- Western-UGP
- Basin Electric Power Cooperative
- Heartland Consumers Power District
- Missouri River Energy Services
- Moorhead Public Service
- Orange City Municipal Utilities
- City of Pierre, South Dakota
- City of Sioux Center, Iowa
- Watertown Municipal Utility Department
- Denison Municipal Utilities
- Vermillion Light & Power
- East River Electric Power Cooperative, Inc.
- Corn Belt Power Cooperative
- NorthWestern Energy Public Service Corporation
- Northwest Iowa Power Cooperative
- Harlan Municipal Utilities
- Central Power Electric Cooperative
- Mountrail-Williams Electric Cooperative
- Mor-Gran-Sou Electric Cooperative, Inc.
- Roughrider Electric Cooperative, Inc.
- L and O Power Cooperative

---

## 6. Links or References

- **Attachment H tab, posted RRR File** - Primary reference document containing detailed ATRR values (referenced extensively throughout all three tables)
- **Section II.2** - Referenced for American Electric Power (Public Service Company of Oklahoma and Southwestern Electric Power Company)
- **Column (6), Section I, Table 1** - Referenced in Tables 4 and 5 for ATRR reallocation amounts
- **RR696** - Implied regulatory filing identifier from source filename

---

## 7. Suggested Tags

`ATRR`, `SPP`, `Southwest Power Pool`, `Transmission Revenue Requirements`, `Zonal Allocation`, `Base Plan`, `Balanced Portfolio`, `Network Transmission Cost`, `NTC`, `Regional Revenue Requirement`, `RRR`, `Upgrade Sponsors`, `Interregional Planning`, `JTIQ`, `Zone Pricing`, `Transmission Cost Allocation`, `FERC`, `Attachment H`, `Rate Design`, `Electric Utilities`

---

## 8. Items That May Need Follow-Up

1. **Attachment H Access**: Verify accessibility and completeness of "Att. H tab, posted RRR File" which contains the majority of actual ATRR dollar values
2. **Reserved Zones Status**: Confirm whether Zones 1c, 11b, and 15 ("Reserved for Future Use") have been allocated or remain available
3. **June 19, 2010 Transition**: Clarify the regulatory or operational change that occurred on this date affecting ATRR calculations
4. **Section II.2 Reference**: Locate and review Section II.2 for context on AEP entities in Zone 1a
5. **ATRR Reallocation Formula**: Understand the methodology for reallocating zonal ATRR to region-wide balanced portfolio (Column 6)
6. **JTIQ Balance**: Clarify what constitutes the "JTIQ ATRR Balance" in Table 5,

---

# Chunk 25 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary
This document (chunk 25 of 25) appears to be the final section of SPP (Southwest Power Pool) comments document RR696, dated January 28, 2025. The content consists primarily of reference tables including: (1) a comprehensive listing of transmission zones and owners with associated credits, (2) detailed transmission service request and response timelines for various service types, and (3) a glossary of acronyms and technical terms used throughout the document. This section serves as an operational reference guide for SPP's transmission service procedures and organizational structure.

## 2. Key Topics

- **Transmission Zone Structure**: Detailed breakdown of 19 major zones with sub-zones, covering multiple states (Oklahoma, Kansas, Missouri, Nebraska, South Dakota, Iowa, North Dakota, Texas, Arkansas, New Mexico)
- **Transmission Service Types**: Long-term firm (1+ years), short-term firm (daily to monthly), and non-firm services including next-hour market
- **Service Request Timelines**: Specific deadlines for transmission requests, provider responses, study processes, and customer responses
- **Energy Scheduling Requirements**: Timing requirements ranging from 20 minutes to 12 hours prior to schedule start
- **Zonal ATRR and Schedule 11 Credits**: Credit allocations (mostly N/A or $0) across transmission owners
- **Technical Terminology**: Comprehensive acronym glossary defining industry-standard terms

## 3. Decisions or Actions

No specific decisions or action items are documented in this section. The content is entirely reference material consisting of:
- Established zone designations and transmission owner assignments
- Pre-defined service request and response timeframes
- Standardized terminology definitions

## 4. Important Dates

**Transmission Service Request Timelines:**

*Long-Term Firm Service (1+ years):*
- In accordance with open season specified in Attachment Z1
- Alternative: No later than 90 days prior to service start

*Short-Term Firm Service:*
- Monthly (>1 month): 31 days prior minimum
- Monthly (1 month): 8 days prior minimum
- Weekly: 8 days prior (>1 week up to 1 month) or 2 days prior (1 week)
- Daily: 2 days prior or 10:00 day prior

*Response Times:*
- Provider responses: 10-24 hours for most services
- Customer responses: 2 hours to 4 days depending on service type
- Energy scheduling changes: 20 minutes prior to start (most services)
- Study completion: 30-60 days for short-term firm services

## 5. Organizations and People Mentioned

**Major Organizations (Transmission Owners/Operators):**

*Zone 1 - AEP West:*
- American Electric Power (PSO and SWEPCO)
- East Texas Electric Cooperative, Inc.
- Deep East Texas Electric Cooperative, Inc.
- Oklahoma Municipal Power Authority
- AEP Oklahoma Transmission Company, Inc.
- AEP Southwestern Transmission Company, Inc.
- Coffeyville Municipal Light and Power (CMLP)
- Arkansas Electric Cooperative Corporation (AECC)
- Transource Oklahoma, LLC

*Other Major Entities:*
- Kansas City Board of Public Utilities
- City Utilities of Springfield, Missouri
- Empire District Electric Company
- Grand River Dam Authority
- Evergy Metro, Inc. / Evergy Missouri West, Inc. / Evergy Kansas Central, Inc.
- Oklahoma Gas and Electric
- Midwest Energy, Inc.
- Southwestern Power Administration
- Southwestern Public Service Company
- Sunflower Electric Power Corporation
- ITC Great Plains, LLC
- Prairie Wind Transmission, LLC
- Western Farmers Electric Cooperative
- Lincoln Electric System
- Nebraska Public Power District
- Omaha Public Power District
- Basin Electric Power Cooperative
- Missouri River Energy Services
- NorthWestern Energy

**Regulatory Bodies:**
- Southwest Power Pool (SPP)
- Federal Energy Regulatory Commission (FERC)
- North American Electric Reliability Corporation (NERC)

**No individual names mentioned**

## 6. Links or References

**Internal Document References:**
- Attachment Z1 (referenced multiple times for open season specifications)
- Section II.3
- Section II of Attachment Z1
- Section 19.4 (Aggregate Transmission Service Study schedule)
- Section 32.4 (Aggregate Transmission Service Study schedule)
- Section 30.2.2 (Expedited designation process)

**External Standards:**
- NERC TPL Standards (Transmission System Planning Performance Requirement)
- OATT (Open Access Transmission Tariff)
- GIP (Generator Interconnection Procedures)

**Software:**
- PSS/E (Power System Simulator for Engineering)
- RMS (Request Management System)

## 7. Suggested Tags

- SPP-Transmission-Zones
- OATT-Tariff
- Transmission-Service-Timelines
- Zonal-ATRR-Credits
- Schedule-11-Credits
- Long-Term-Firm-Service
- Short-Term-Firm-Service
- Non-Firm-Service
- Generator-Interconnection
- Transmission-Owners
- Energy-Scheduling
- RR696
- Southwest-Power-Pool
- Transmission-Service-Requests
- FERC-Compliance
- NERC-Standards

## 8. Items That May Need Follow-Up

1. **Reserved Zones**: Multiple zones marked "Reserved for Future Use" (Zone 1c, Zone 11b, Zone 15) - may require monitoring for future assignments

2. **Credit Allocations**: Most entities show "N/A" for both Zonal ATRR and Schedule 11 credits - verification needed on whether this is intentional or incomplete data

3. **$0 Credit Entities**: Several entities explicitly show $0 credits - may need verification:
   - East Texas Electric Cooperative (Zone 1b)
   - Deep East Texas Electric Cooperative (Zone 1d)
   - Oklahoma Municipal Power Authority (Zones 1e, 7b)
   - Various others in Zones 4, 6b, 9b, 10, 17b, 19b, 19g

4. **Cross-Reference Verification**: Need to verify consistency with:
   - Attachment Z1 open season specifications
   - Sections 19.4 and 32.4 study schedules
   - Section 30.2.2 expedited designation process requirements

5. **Timeframe Compliance**: "Best effort" service for queued requests <24 hours or <1 hour may need monitoring for reliability and compliance

6. **Multi-State Operations**: Several entities operate across state lines - coordination requirements may need review

7. **Document Completeness**: This is chunk 25 of 25, but Tables 11-28 and 30-45 appear empty - confirm if this is intentional or represents missing data

8. **Study Process Timelines**: Some study periods span 30-60 days - may need tracking mechanism to ensure compliance