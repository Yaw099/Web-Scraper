# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

**Source File:** RR696 OPPD Comments 20250804.docx.txt

---

## 1. EXECUTIVE SUMMARY

This document contains comments from Omaha Public Power District (OPPD) regarding Revision Request 696 (RR696), which proposes to establish a framework for integrating High Impact Large Loads (HILL) and Curtailable High Impact Large Loads (CHILL) into SPP's grid. While OPPD supports the concept of streamlining large load approvals, they express significant procedural and technical concerns. Key issues include: the potential requirement to allow curtailable loads contrary to OPPD's traditional practices, possible mandate to use Remedial Action Schemes, and cost-shifting concerns due to increased congestion. OPPD advocates for enhanced stakeholder participation through Working Groups before final approval.

---

## 2. KEY TOPICS

- **High Impact Large Load (HILL) Integration Framework** - Accelerated interconnection process for large loads
- **Curtailable High Impact Large Loads (CHILL) Service** - New service category for loads that can be curtailed
- **Stakeholder Process Concerns** - Request for more Working Group involvement before Board approval
- **Transmission Owner Autonomy** - Concerns about policy overriding TO standards and practices
- **Cost Allocation and Shifting** - Potential for non-cost causers to bear congestion costs
- **Grid Reliability Standards** - NERC compliance and system stability considerations
- **Market Efficiency** - Speed to market versus reliability and cost concerns
- **Remedial Action Schemes (RAS)** - Potential forced implementation contrary to TO policies

---

## 3. DECISIONS OR ACTIONS

**No final decisions documented** - This is a comment submission document

**Requested Actions:**
- Route RR696 through appropriate Working Group review before MOPC (Market and Operations Policy Committee)
- Consider "Expedited" RR stakeholder process with additional WG opportunities
- Address technical concerns regarding:
  - Curtailable load requirements
  - Remedial Action Scheme mandates
  - Cost allocation mechanisms
  - Congestion management impacts

**Proposed Solution from OPPD:**
- CHILLs should utilize generation to reduce their load
- Both load and generation should have upgrades in place before operation begins
- Generation should reduce CHILL's transmission system impact during strenuous grid conditions

---

## 4. IMPORTANT DATES

- **July 29, 2025** - Date of comment submission (Note: This appears to be a future date, possibly a typo for 2024)
- **Prior to Board of Directors meeting** - Working Groups getting review opportunity (timing not specified)
- **Before MOPC** - Requested timing for WG review

---

## 5. ORGANIZATIONS AND PEOPLE MENTIONED

**Organizations:**
- **Omaha Public Power District (OPPD)** - Commenting entity, Transmission Owner
- **SPP (Southwest Power Pool)** - Grid operator and market administrator
- **NERC** - North American Electric Reliability Corporation (standards body)
- **MOPC** - Market and Operations Policy Committee
- **Working Groups (WGs)** - Stakeholder technical groups (specific groups not named)
- **Board of Directors** - SPP governing body

**People:**
- **Adam Schieffer** - OPPD representative submitting comments
  - Email: ajschieffer@oppd.com
  - Phone: 531-226-5612

---

## 6. LINKS OR REFERENCES

**Governing Documents Referenced:**
- SPP Open Access Transmission Tariff
- Market Protocols
- NERC Standards (referenced generally, no specific standards cited)

**Related Processes:**
- RR (Revision Request) Form and submission process
- "Expedited" RR stakeholder process
- Working Group review pathway
- MOPC approval process

**No URLs or external links provided**

---

## 7. SUGGESTED TAGS

- RR696
- High Impact Large Loads
- HILL
- CHILL
- Curtailable Loads
- OPPD
- Transmission Owner Concerns
- Cost Allocation
- Stakeholder Process
- Grid Reliability
- Remedial Action Schemes
- RAS
- Market Integration
- SPP
- Load Interconnection
- Congestion Management
- NERC Compliance
- Generator Integration
- Transmission Planning

---

## 8. ITEMS THAT MAY NEED FOLLOW-UP

**Critical Issues Requiring Resolution:**

1. **Procedural Pathway** - Clarify whether RR696 will go through full Working Group review before MOPC and Board approval

2. **Curtailable Load Policy Conflict** - Reconcile OPPD's traditional prohibition on curtailable loads with potential CHILL requirements
   - Need TO opt-in/opt-out provisions?
   - Need alternative compliance mechanisms?

3. **Remedial Action Scheme Requirements** - Determine if policy will mandate RAS usage contrary to TO standards
   - Can TOs maintain existing RAS policies?
   - What flexibility exists for different TO practices?

4. **Cost Allocation Methodology** - Address concern about cost-shifting to non-cost causers
   - How will congestion costs be allocated?
   - What protections exist for existing ratepayers?

5. **Generation Pairing Requirement** - Evaluate OPPD's proposed solution requiring CHILLs to pair with generation
   - Is this technically feasible?
   - Should this be mandatory or optional?
   - Timing of upgrades vs. operation

6. **Stakeholder Engagement Timeline** - Establish clear timeline for:
   - Working Group review periods
   - Comment cycles
   - MOPC presentation
   - Board decision date

7. **Date Verification** - Confirm actual submission date (document shows 7/29/2025, likely should be 2024)

8. **Redline Provisions** - Document notes sections for "SPP Open Access Transmission Tariff" and "Market Protocols" but contains no actual redlined language - obtain complete submission

9. **Quantitative Analysis** - RR claims multiple quantifiable benefits but provides no data:
   - Planning reserve margin reduction calculations
   - Transmission upgrade cost avoidance estimates
   - Congestion cost projections
   - Emergency procedure cost savings

10. **Transmission Owner Coordination** - Determine if other TOs share OPPD's concerns or have similar restrictions

---

**Priority Level:** HIGH - Involves significant policy changes affecting grid reliability, market operations, and cost allocation across SPP footprint