# REGULATORY MEETING ANALYSIS REPORT

## 1. Executive Summary

This document is a stakeholder feedback memo to the SPP Board of Directors regarding Revision Request 696 (RR696), which addresses the integration and operation of high-impact large loads. Basin Electric Power Cooperative submitted strong opposition to RR696 in its current form, citing concerns about inadequate stakeholder process, reliability risks, cost impacts to members, and potential unintended consequences. Basin Electric's primary concerns center on the "CHILL" (Critical High Impact Large Load) concept to "fill in the valley," which they believe could create significant reliability risks and operational challenges. They propose eliminating CHILLs entirely and only retaining the HILLGA-Common Bus option, noting that existing solutions (Attachments AQ and AX) already exist for accommodating large loads.

## 2. Key Topics

- **RR696 (Integrate & Operate High Impact Large Loads)**: Core revision request under review
- **Stakeholder Process Concerns**: Inadequate review time for 500+ page document
- **CHILL (Critical High Impact Large Load) Concept**: "Fill in the valley" approach criticized
- **HILLGA (High Impact Large Load Generation Availability)**: Multiple types including HILLGA-DA and HILLGA-Common Bus
- **System Reliability Risks**: Concerns about voltage, thermal risks, and pressure on dispatchable generation
- **Generation Resource Impacts**: Environmental limits, increased maintenance needs, decreased accreditation
- **Planning Model Integrity**: CHILLs excluded from Base Reliability models
- **Market and Operational Issues**: Curtailment protocols, metering requirements, LMP impacts, congestion
- **Cost Allocation**: Stranded costs if loads leave after interconnection
- **Transmission Service Products**: Impact on ability to assist neighboring systems
- **Existing Alternatives**: Attachment AQ and Attachment AX (pending FERC approval)

## 3. Decisions or Actions

**Requested Actions:**
- Basin Electric requests the SPP Board **reject RR696 in its current form**
- **Eliminate the CHILLs option entirely**
- **Eliminate HILLGA-DA** (described as "queue jumping")
- **Retain only HILLGA-Common Bus** as an option for HILLS
- Prioritize DISIS (Generation Interconnection) and ERAS processes

**Concerns Requiring Board Consideration:**
- Need for studies on load magnitude impacts, congestion, and LMP effects
- Clarification on curtailment frequency expectations for CHILLs
- Determination of what happens if generation comes online after 5-year threshold
- How Reliability Coordinator will handle increased loads
- How SPP will determine curtailment priorities
- Congestion management approach

## 4. Important Dates

- **July 28, 2025**: Deadline for formal RR696 comment period (via SPP Request Management System)
- **July 28, 2025**: Deadline for submitting board feedback memos (end of business)
- **August 5, 2025**: SPP Board of Directors meeting to consider RR696
- **5-year timeframe**: Referenced regarding generation coming online (concern raised about what happens at "5 years plus one day")

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)**: RTO managing the revision request process
- **Basin Electric Power Cooperative**: Submitting organization (opposition position)
- **SPP Board of Directors**: Decision-making body
- **Reliability Coordinator**: Entity that would handle increased loads

**Working Groups Referenced:**
- MWG (Markets and Operations Policy Committee Working Group)
- ORWG (Operating Reliability Working Group)
- SAWG (Seams and Accreditation Working Group)
- TWG (Transmission Working Group)

**People:**
- **Jason Mazigian**: Basin Electric representative submitting comments
- **Erin Cathey** (ecathey@spp.org): SPP contact for memo submission

## 6. Links or References

**Regulatory/Process References:**
- **SPP Revision Request Process**: Formal mechanism for technical comments
- **SPP Request Management System**: Portal for submitting formal RR696 comments
- **Attachment AQ**: Existing solution for large load accommodation
- **Attachment AX**: Recently filed solution at FERC for large loads (pending approval)

**Technical Concepts:**
- **DISIS**: Generation Interconnection Study process
- **ERAS**: (Process referenced but not fully defined)
- **LOLE studies**: Loss of Load Expectation studies
- **LMPs**: Locational Marginal Prices
- **Base Reliability models**: Planning models that exclude CHILLs

## 7. Suggested Tags

- RR696
- High Impact Large Loads
- CHILL (Critical High Impact Large Load)
- HILLGA (High Impact Large Load Generation Availability)
- Basin Electric Power Cooperative
- System Reliability
- Resource Adequacy
- Transmission Planning
- Generation Interconnection
- SPP Board of Directors
- Stakeholder Process
- Cost Allocation
- Market Operations
- Curtailment Protocols
- Queue Reform
- Load Growth
- Data Centers (implied)

## 8. Items That May Need Follow-Up

**Process Issues:**
1. **Stakeholder Process Review**: Whether SPP followed adequate stakeholder engagement procedures for 500+ page document with limited review time
2. **Study Gaps**: Need for comprehensive studies on load magnitude impacts, congestion effects, and LMP impacts on existing generation dispatch
3. **Annual Curtailment Analysis**: Expected frequency and duration of CHILL curtailments throughout the year

**Technical/Operational Clarifications Needed:**
4. **Five-Year Generation Timeline**: What consequences occur if required generation comes online after the 5-year threshold
5. **Reliability Coordinator Procedures**: How increased loads will be managed operationally
6. **Curtailment Hierarchy**: Clear protocols for determining what gets cut and when
7. **Congestion Management**: Specific approach for handling increased congestion
8. **Planning Model Treatment**: Why CHILLs are excluded from Base Reliability models and implications

**Market/Cost Issues:**
9. **Demand Response Mechanism**: Concerns about how CHILLs function as demand response resources
10. **Stranded Cost Risk**: Protection mechanisms if loads leave after interconnection investments
11. **Real Customer Cost Impact**: Comprehensive cost-benefit analysis for existing customers
12. **Environmental Limits**: Impact analysis of increased dispatch on generation environmental permits

**Alternatives to Consider:**
13. **Attachment AX Status**: Timeline for FERC approval of recently filed alternative
14. **Attachment AQ Adequacy**: Whether existing Attachment AQ provisions are sufficient
15. **HILLGA-Common Bus Only**: Viability of proceeding with only this option instead of full RR696

**Policy Concerns:**
16. **Neighboring System Assistance**: Impact on SPP's ability to provide emergency support to neighboring RTOs
17. **Advisory Fatigue**: Whether frequent advisories are losing effectiveness and how large loads exacerbate this
18. **Generation Maintenance Windows**: Impact on planned outage schedules for existing generation
19. **Smaller Load Impact**: Risk assessment for residential and small commercial/industrial load connections being jeopardized