# Final Combined Report

# COMPREHENSIVE REGULATORY ANALYSIS REPORT
## RR696 SPP Comments - Full Document Analysis (27 Chunks Combined)

---

## 1. EXECUTIVE SUMMARY

This comprehensive analysis covers SPP's (Southwest Power Pool) Revision Request 696 (RR696), a major tariff revision proposal dated August 14, 2025. The document spans 27 chunks and underwent three rounds of revisions (July 11, July 28, and August 15, 2025) based on stakeholder feedback.

**Major Developments:**

1. **Significant Scope Reduction**: Based on August 15, 2025 stakeholder feedback, SPP **removed the proposed Conditional High Impact Large Load (CHILL) and CHILL Service concepts** from the revision request, representing a major retreat from the original proposal.

2. **Primary Purpose**: Establish a comprehensive framework for integrating High Impact Large Loads (HILL) into the transmission system, accelerating large load interconnections while maintaining grid reliability.

3. **Comprehensive Tariff Updates**: The document encompasses extensive modifications across multiple attachments covering:
   - Transmission service rate structures and billing
   - Day-Ahead Market and Real-Time Market operations
   - Reliability Unit Commitment (RUC) processes
   - Delivery Point Assessment procedures
   - Generator interconnection protocols
   - Revenue allocation methodologies
   - Resource adequacy requirements

4. **Financial Structure**: Detailed revenue requirement allocations across 20 transmission zones with references to the Revenue Requirements and Rates (RRR) File for specific dollar amounts.

---

## 2. KEY TOPICS (CONSOLIDATED)

### A. High Impact Large Load (HILL) Framework
- **HILL Integration Process**: Standardized assessment framework for large load interconnections
- **CHILL Service Removal**: Originally proposed conditional transmission service eliminated based on stakeholder concerns
- **Energy Storage Resource Load Assessment**: Language integration pending MOPC approval
- **Capacity Accreditation Methodology**: Shift from nameplate capacity to projected accredited capacity values for HILLGA
- **Day-Ahead Must Offer Requirements**: Alignment with existing resource requirements
- **Metering Requirements**: Specification of HILL metering protocols
- **Study Process Clarification**: Updates to Attachments AQ and AX

### B. Transmission Service and Rates
- **Point-To-Point Service Rate Structures**: Comprehensive rates for Firm and Non-Firm services across all zones
- **Service Increments**: Fixed Hourly, Extended Daily, Weekly, Monthly, and Yearly options
- **On-Peak/Off-Peak Definitions**: HE 0700-2200 Central Prevailing Time (weekdays excluding NERC holidays)
- **Formula Rate Mechanisms**: Multiple formula rates across Attachment H addendums
- **ERCOT Interface Provisions**: 45.27% discount for qualifying Load Serving Entities
- **Balanced Portfolio Reallocation**: Adjustments to Zonal Annual Transmission Revenue Requirements
- **Schedule 1-A Tariff Administration Services**: Rate recovery mechanisms and billing determinants

### C. Market Operations
- **Day-Ahead Market Execution**: SCUC (Security Constrained Unit Commitment) algorithm methodology
- **Day-Ahead Reliability Unit Commitment (RUC)**: Capacity adequacy analysis procedures
- **Intra-Day RUC**: Real-time capacity management
- **Must-Offer Requirements**: 90% threshold of net resource capacity to load ratio
- **Manual Commitment Authority**: Procedures for addressing local reliability issues
- **Multi-Configuration Resources (MCRs)**: Transition state time restrictions (>30 minutes)
- **Virtual Resource Limits (VRLs)**: Application in SCED when Shadow Price exceeds thresholds

### D. System Planning and Studies
- **Delivery Point Assessment Process (Attachment AQ)**: Procedures for modifying delivery points with sufficient resources
- **Provisional Load Process (Attachment AX)**: Procedures for load increases without adequate designated resources
- **Load Connection Studies (LCS)**: 90-day completion timeline with deposit requirements
- **Transmission System Studies**: Impact assessments using power flow and short circuit analyses
- **HILLGA Network Studies**: Queue position determination and study methodologies
- **Integrated Transmission Planning (ITP)**: Coordination of network upgrades with planning assessments

### E. Cost Recovery and Revenue Allocation
- **Annual Transmission Revenue Requirements (ATRR)**: Complex calculations across multiple zones
- **Regional vs. Local Cost Allocation**: Differentiated recovery mechanisms based on issue nature
- **Revenue Credits**: Schedule 7 and 8 adjustments, Attachment AU distributions
- **JTIQ (Joint Transmission Injection Queue) ATRR Balance**: Generator vs. resident load cost allocation
- **FERC Assessment Charges**: Recovery mechanism under Schedule 12
- **Canceled Project Cost Recovery**: Specific provisions for AEP and Sunflower Electric projects

### F. Resource Adequacy and Compliance
- **Non-Conforming Load Requirements**: Registration and forecasting obligations for loads ≥50 MW
- **Demand Response Programs**: Controllable/dispatchable vs. non-controllable/non-dispatchable treatment
- **Behind-The-Meter Generation**: Treatment of resources less than 10 MW
- **GFA Carve Out Requirements**: Resource offering obligations for Generation Forced Availability
- **Winter Season Obligation**: Meeting Attachment AA requirements

### G. Operational Procedures
- **Emergency Operating Plans (EOPs)**: Load shedding guidelines and critical natural gas load protection
- **ICCP Node Connectivity**: Inter-Control Center Communications Protocol requirements
- **Local Reliability Issues**: Out-of-merit commitment and dispatch procedures
- **Market Monitor Verification**: Non-discriminatory resource selection oversight
- **Meter Agent Functions**: Data submission requirements for load and generation

---

## 3. DECISIONS AND ACTIONS (CONSOLIDATED)

### Major Strategic Decisions

**August 15, 2025 - Scope Reduction:**
- **REMOVED**: CHILL, CHILLS, and Deliverability Area path for generation
- **REVISED**: Attachment BB Section 3.1.1 based on stakeholder feedback
- **MODIFIED**: HILL definition in Part 1, Common Service Provisions
- **UPDATED**: Attachments AE, AQ, and AX to make HILL independent of Non-Conforming Load

**July 28, 2025 - Refinements:**
- Added Attachment BB Appendix 3 for HILLGA GIA when Western Area Power Administration Division is a party
- Aligned Resource Day-Ahead Must Offer with existing requirements
- Updated capacity limits to use accredited capacity basis
- Specified metering requirements in Protocols

**July 11, 2025 - Initial Amendments:**
- Amended Attachment BB to include Energy Storage Resource Load Assessment language
- Modified maximum injection limit calculation methodology
- Updated "shall" terminology for consistency

### Rate and Revenue Decisions

**Established Rates:**
- **Reactive Compensation Rate**: $2.26 per MVArh (subject to periodic review)
- **Schedule 1-A1**: Annual determination with specific divisors for monthly, weekly, daily, and hourly rates
- **ERCOT Discount**: 45.27% reduction in zonal rates under Schedules 7 and 8 for qualifying transactions

**Specific Cost Recoveries Approved:**
- **AEP Canceled Projects**: $3,264,402.55 over twelve months (April 1, 2018 start)
- **AEP Chapel Hill/Welsh Reserve Projects**: $414,465 recovery (March 1, 2019 start)
- **Sunflower Electric Russell Project**: $718,359 recovery (January 1, 2024 start)

**Formula Rate Posting Deadlines:**
- **October 1**: NPPD, Tri-State (Zone 19), South Central MCN, Kansas Power Pool, NEET Southwest, SPS
- **October 15**: Evergy Kansas Central
- **September 1**: Prairie Wind
- **December 15**: NPPD (alternative)
- **July 20**: OPPD
- **June 15**: Tri-State (alternative)

### Operational Procedures Established

**Transmission Service Request Timelines:**
- **Long-term Firm (≥1 year)**: 90 days prior; 10-day response
- **Short-term Firm (monthly)**: 31 days prior; 24-hour response
- **Short-term Firm (weekly)**: 8 days prior; 24-hour response
- **Short-term

---

# Partial Chunk Reports

# Chunk 1 Analysis

# Regulatory Analysis Report: RR696 SPP Comments

## 1. Executive Summary

This document presents SPP's (Southwest Power Pool) comments on Revision Request 696 (RR696), which proposes to establish a framework for integrating High Impact Large Loads (HILL) into the transmission system. The document tracks multiple rounds of revisions dated July 11, July 28, and August 15, 2025. 

**Major Development:** Based on stakeholder feedback received by August 15, 2025, SPP has removed the proposed Conditional High Impact Large Load (CHILL) and CHILL Service concepts from the revision request, representing a significant scope change from the original proposal.

The RR696 aims to create a standardized assessment framework that accelerates large load interconnections while maintaining grid reliability, balancing expedited timelines with cost-effectiveness and operational efficiency.

## 2. Key Topics

### Primary Topics:
- **High Impact Large Load (HILL) Integration Framework**: Comprehensive process for studying, registering, and operating large loads
- **Removal of CHILL Service**: Originally proposed conditional transmission service for portions of HILL eliminated based on stakeholder feedback
- **Energy Storage Resource Load Assessment**: Language integration pending MOPC approval (July 2025)
- **Capacity Accreditation Methodology**: Shift from nameplate capacity to projected accredited capacity values for HILLGA (High Impact Large Generation Area)
- **Day-Ahead Must Offer Requirements**: Alignment with existing resource requirements
- **Metering Requirements**: Specification of HILL and CHILL metering protocols
- **Study Process Clarification**: Updates to Attachments AQ and AX regarding HILL study procedures
- **Tariff Administration Services**: Rate recovery mechanisms and billing determinants

### Technical Areas Addressed:
- Transmission system planning and operations
- Market integration and efficiency
- Reliability coordination
- Load forecasting and predictability
- System modeling and stability

## 3. Decisions or Actions

### Completed Actions (by revision date):

**July 11, 2025:**
- Amended Attachment BB to include Energy Storage Resource Load Assessment language
- Modified maximum injection limit calculation methodology to use projected capacity accreditation MW values
- Updated use of "shall" terminology for consistency

**July 28, 2025:**
- Added Attachment BB Appendix 3 for HILLGA GIA when Western Area Power Administration Division is a party
- Aligned Resource Day-Ahead Must Offer with existing requirements
- Updated capacity limits to use accredited capacity basis
- Specified metering requirements in Protocols

**August 15, 2025:**
- **Removed CHILL, CHILLS, and Deliverability Area path for generation** (major scope reduction)
- Updated Attachment BB Section 3.1.1 based on stakeholder feedback
- Revised HILL definition in Part 1, Common Service Provisions
- Modified Attachment AE and Marketplace Protocols to make HILL independent of Non-Conforming Load
- Modified Attachments AQ and AX for HILL study process clarity

### Pending Actions:
- Energy Storage Resource Load Assessment language approval at July 2025 MOPC meeting
- Implementation of revised tariff language across multiple attachments

## 4. Important Dates

| Date | Event/Milestone |
|------|----------------|
| **July 11, 2025** | First round of SPP comments submitted (highlighted in yellow) |
| **July 2025** | MOPC meeting for Energy Storage Resource Load Assessment approval (pending) |
| **July 28, 2025** | Second round of SPP comments submitted (highlighted in teal) |
| **August 14, 2025** | Comment form submission date |
| **August 15, 2025** | Third round of SPP comments submitted (highlighted in green) |

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)** - Transmission Provider and comment submitter
- **MOPC** - Markets and Operations Policy Committee (approval authority)
- **NERC** - North American Electric Reliability Corporation (standards reference)
- **Western Area Power Administration Division** - Federal power marketing entity (specific GIA provisions)
- **FERC/Commission** - Federal Energy Regulatory Commission (filing authority)
- **Transmission Owners** - Various entities in different zones (Zone 1, Zone 11)
- **American Electric Power** - Zone 1 Transmission Owner
- **Southwestern Public Service** - Zone 11 Transmission Owner

### Individuals:
- **Caroline Chapman** - SPP representative, comment submitter (cchapman@spp.org)

## 6. Links or References

### Referenced Documents/Attachments:
- **Attachment BB** - Modified multiple times; includes Appendix 3 for Western Area Power Administration
- **Attachment AE** - Resource Day-Ahead Must Offer requirements
- **Attachment AQ** - HILL study process provisions
- **Attachment AX** - HILL study process provisions
- **Attachment J** - Revenue reallocation provisions
- **Attachment L** - Revenue distribution mechanisms
- **Attachment AU** - Revenue distribution and allocation
- **Attachment H** - Zonal ATRR and revenue requirements (includes Addendum 1 and Addendum 5)
- **Part I, Common Service Provisions** - Definitions section
- **Part II, Part III, Part IV of Tariff** - Transmission service provisions
- **Schedule 1-A** - Tariff Administration Services
- **Marketplace Protocols** - Market operational procedures

### Standards Referenced:
- NERC standards (for reliability alignment)

## 7. Suggested Tags

**Primary Tags:**
- RR696
- High Impact Large Load (HILL)
- Load Interconnection
- Transmission Planning
- SPP Tariff Revisions

**Secondary Tags:**
- CHILL Service (removed)
- Energy Storage
- Capacity Accreditation
- MOPC
- Stakeholder Process
- Grid Reliability
- Market Integration
- Western Area Power Administration
- Generator Interconnection Agreement
- Day-Ahead Must Offer
- Metering Requirements
- Study Process

**Administrative Tags:**
- Comment Period
- August 2025
- Regulatory Compliance
- Tariff Administration

## 8. Items That May Need Follow-Up

### Critical Follow-Up Items:

1. **MOPC Approval Status** (HIGH PRIORITY)
   - Energy Storage Resource Load Assessment language pending approval at July 2025 MOPC
   - Need confirmation of approval status and any conditions

2. **Stakeholder Feedback Analysis** (HIGH PRIORITY)
   - Document reasoning behind CHILL Service removal
   - Identify stakeholder concerns that led to August 15 scope reduction
   - Assess impact of removing conditional service option on market participants

3. **Definition Consistency** (MEDIUM PRIORITY)
   - Verify revised HILL definition in Part 1 aligns with all attachment references
   - Confirm independence from Non-Conforming Load definition is implemented consistently

4. **Western Area Power Administration Coordination** (MEDIUM PRIORITY)
   - Track implementation of new Attachment BB Appendix 3
   - Coordinate with WAPA Division on GIA terms

5. **Impact Assessment** (MEDIUM PRIORITY)
   - Quantify benefits claims (reserve margin reduction, curtailment reduction, cost savings)
   - Validate administrative efficiency improvements
   - Document study efficiency metrics

6. **Metering Requirements Implementation** (MEDIUM PRIORITY)
   - Ensure Protocol specifications are complete for HILL metering
   - Verify technical requirements are feasible

7. **Study Process Updates** (LOW-MEDIUM PRIORITY)
   - Confirm Attachments AQ and AX modifications provide sufficient clarity
   - Review stakeholder feedback on study process improvements

8. **Rate Impact Analysis** (LOW PRIORITY)
   - Assess Schedule 1-A rate cap compliance ($0.515 limit)
   - Review billing determinant calculations for HILL loads

### Questions Requiring Clarification:

- What specific stakeholder feedback drove the removal of CHILL Service?
- How will loads originally anticipated to use CHILL Service now interconnect?
- What is the timeline for final approval and implementation?
- Are there transitional provisions for loads already in the study queue?
- How does HILL independence from Non-Conforming Load affect existing contracts?

### Recommended Actions:

1. Request stakeholder feedback summary from SPP
2. Obtain MOPC meeting minutes from July 2025
3. Schedule follow-up discussion on scope changes
4. Review impact on pending interconnection requests
5. Monitor for additional comment rounds or

---

# Chunk 2 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document is chunk 2 of 27 from SPP (Southwest Power Pool) comments regarding regulatory rate schedules (RR696) dated August 14, 2025. The content consists of detailed tariff provisions for transmission service billing, including:

- **Schedule 1-A1**: Point-of-Delivery transmission service rates and billing determinants
- **Schedule 1**: Scheduling, System Control and Dispatch Service for through/out and sinking transactions
- **Schedule 2**: Reactive Supply and Voltage Control compensation methodology
- **Schedule 11**: Base Plan Zonal Charge and Region-wide Charge provisions

The content outlines complex rate formulas, billing methodologies, and compensation mechanisms for various transmission services within the SPP Region, with specific provisions for different customer types (Network Customers vs. Point-to-Point Transmission Customers) and transaction types.

## 2. Key Topics

1. **Point-to-Point Transmission Service Billing**
   - MW hours reserved as billing determinants
   - Zone-specific rate calculations
   - Schedule 1-A1 service rates

2. **Scheduling, System Control and Dispatch Service (Schedule 1)**
   - Through and out transactions
   - Transactions sinking within the Transmission System
   - Multi-owner zone calculations
   - On-Peak vs. Off-Peak rate structures

3. **Reactive Power Compensation (Schedule 2)**
   - Qualified Generator (QG) compensation methodology
   - Reactive Compensation Rate (RCR) set at $2.26 per MVArh
   - Dead Band calculations for reactive power
   - Zonal revenue allocation

4. **Rate Period Definitions**
   - On-Peak: Monday-Friday, HE 0700-2200 Central Prevailing Time
   - Off-Peak: Saturdays, Sundays, NERC holidays, and off-peak hours

5. **Base Plan Charges (Schedule 11)**
   - Zonal and Region-wide charges
   - Western-UGP exemption provisions
   - Eastern Interconnection applicability

## 3. Decisions or Actions

1. **Reactive Compensation Rate Established**: RCR set at $2.26 per MVArh (subject to periodic review)

2. **Rate Calculation Methodologies Defined**:
   - Annual determination of Schedule 1-A1 rates
   - Monthly, weekly, daily, and hourly rate divisors specified
   - Zonal rate aggregation for multi-owner zones

3. **Revenue Requirement Adjustments**:
   - Schedule 1 revenue requirements adjusted for Point-to-Point revenues
   - Different treatment for stated rates vs. formula rates with annual updates

4. **Exemptions Granted**:
   - Western-UGP exempt from Region-wide Charge under Schedule 11
   - Federal Power-Western-UGP excluded from transmission load calculations

5. **Compensation Distribution Rules**:
   - QG compensation based on Reactive Power Outside Dead Band (RPOD)
   - Pro-rata revenue distribution when collections don't match zone revenue requirements

## 4. Important Dates

**No specific calendar dates are mentioned in this chunk.** However, time-based operational definitions include:

- **On-Peak Hours**: HE 0700 through HE 2200 Central Prevailing Time
- **Annual Rate Determinations**: Schedule 1-A1 rates determined yearly
- **Monthly Billing Cycles**: RPOD calculations and billing based on monthly data
- **Periodic Reviews**: RCR subject to periodic review (frequency not specified)

**Temporal calculation periods**:
- Yearly rate divisors: 52 (weeks), 260 (on-peak days), 365 (off-peak days), 4160 (on-peak hours), 8760 (off-peak hours)
- Monthly calculations based on prior calendar year's 12-month average

## 5. Organizations and People Mentioned

### Organizations:

1. **SPP (Southwest Power Pool)** - The Transmission Provider
2. **Transmission Owners** - Multiple entities owning transmission facilities
3. **Transmission Customers** - Entities taking Point-to-Point service
4. **Network Customers** - Entities taking Network Integration Transmission Service
5. **NERC (North American Electric Reliability Corporation)** - Referenced for holiday definitions
6. **Western-UGP** - Specifically mentioned as exempt entity
7. **Qualified Generators (QGs)** - Generators eligible for reactive power compensation

### People:
**None specifically mentioned** - Document is regulatory/technical in nature

## 6. Links or References

### Internal References:
1. **Addendum 1 of Schedule 1-A** - Rate formula details
2. **Revenue Requirements and Rates File (RRR File)** - Posted on SPP website
3. **Schedule 1 tab** - Within RRR File
4. **Zonal Sch 1 tab** - Within RRR File
5. **Table 1 ("Schedule 1 RR")** - Revenue requirements listing
6. **Table 2 of Schedule 1** - Point-to-Point revenues already credited
7. **Section 31.4** - Network Load designation provisions
8. **Part V of this Tariff** - Base Plan charge provisions
9. **Section 39.3(e)** - Western-UGP exemption details

### External References:
- **NERC holidays** - Used for Off-Peak day definitions
- **Eastern Interconnection** - Geographic applicability limit
- **Central Prevailing Time** - Time zone reference

### Posted Information:
- **SPP website** - Location of RRR File

## 7. Suggested Tags

- Transmission Tariff
- Rate Schedules
- SPP Tariff
- Point-to-Point Transmission Service
- Network Integration Transmission Service
- Scheduling System Control and Dispatch
- Reactive Power Compensation
- Qualified Generators
- Zonal Rates
- Revenue Requirements
- On-Peak/Off-Peak Rates
- Base Plan Charges
- FERC Regulatory
- Transmission Service Billing
- RR696
- Western-UGP
- Multi-Owner Zones
- Formula Rates

## 8. Items That May Need Follow-Up

### Clarification Needed:

1. **Reactive Compensation Rate Review Timeline**
   - Issue: "The Transmission Provider may periodically review the RCR" - no specific frequency defined
   - Action: Determine review schedule and criteria for adjustments

2. **Schedule 1-A1 Rate Formula Details**
   - Issue: Referenced in "Addendum 1 of this Schedule 1-A" but not included in this chunk
   - Action: Review Addendum 1 for complete rate calculation methodology

3. **Point-to-Point Revenue Credits**
   - Issue: Table 2 amounts not provided in this chunk
   - Action: Verify accuracy of pre-credited amounts for each Transmission Owner

4. **Multi-Owner Zone Rate Aggregation**
   - Issue: Complexity in summing rates for zones with multiple Transmission Owners
   - Action: Verify calculation accuracy in RRR File postings

### Potential Issues:

5. **Revenue Mismatch Provisions (Schedule 2)**
   - Issue: Section III.D.2 allows pro-rata adjustment when collected revenue doesn't match ZRC
   - Action: Monitor frequency of mismatches and investigate systematic causes

6. **Western-UGP Exemption Impact**
   - Issue: Exemption from Region-wide Charge may affect cost allocation to other zones
   - Action: Quantify financial impact on non-exempt zones

7. **Dead Band Calculation Complexity**
   - Issue: RPOD calculation methodology in Schedule 2 is complex and could lead to disputes
   - Action: Ensure adequate documentation and audit trails for QG compensation

8. **Joint Ownership Compensation**
   - Issue: Section III.E states SPP "not responsible for disbursing revenue to other owners"
   - Action: Verify designated entities have proper agreements for internal revenue distribution

### Documentation Gaps:

9. **Formula Rate Annual Update Criteria**
   - Issue: Section D.1 references different treatment based on whether formula rates have "annual update"
   - Action: Obtain list of which Transmission Owners fall into each category

10. **RRR File Posting Timeliness**
    - Issue: Multiple references to data "posted on SPP website" without posting deadlines
    - Action: Establish and verify compliance with posting

---

# Chunk 3 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document is chunk 3 of 27 from SPP (Southwest Power Pool) tariff comments (RR696) dated August 14, 2025. The content consists of detailed tariff provisions covering:
- Calculation methodologies for transmission revenue requirements
- Base Plan Zonal Charges and Region-wide Charges for both resident load and point-to-point transmission service
- FERC Assessment Charge recovery mechanisms (Schedule 12)
- Annual Transmission Revenue Requirements for Network Integration Transmission Service (Attachment H)

The material is highly technical and regulatory in nature, establishing formulas and procedures for cost allocation among transmission customers, network customers, and transmission owners across multiple zones within the SPP system.

## 2. Key Topics

- **Annual Transmission Revenue Requirement (ATRR) Calculations**: Methodologies for calculating Base Plan Zonal and Region-wide ATRRs with adjustments for point-to-point revenue
- **Revenue Credit Adjustments**: Treatment of point-to-point revenues, Attachment AU distributions, and SATOA dispatch revenues in ATRR calculations
- **Zonal Charge Structures**: Different calculation methods for Zones 1-9, Zone 10 (with Federal-Power Southwestern adjustments), Zone 11-18, and Zone 19 (Western Interconnection)
- **Load Ratio Share Methodology**: Determination of monthly resident loads and load ratio shares for network customers and transmission owners
- **Federal Service Exemptions**: Special provisions for Western-UGP's Statutory Load Obligations and Federal Service Exemptions
- **FERC Assessment Charges**: Recovery mechanism for FERC regulatory assessments under Part 382
- **Formula vs. Stated Rates**: Differential treatment for transmission owners using formula rates versus stated rates

## 3. Decisions or Actions

- **Annual FACR Calculation**: Transmission Provider must calculate and post FERC Assessment Charge Rate (FACR) prior to March 1 of each year
- **Revenue Requirement Adjustments**: Transmission Provider shall adjust annual transmission revenue requirements by previous calendar year revenues from point-to-point service, Attachment AU distributions, and SATOA dispatches
- **Monthly Billing**: Transmission Provider shall bill customers according to procedures in Section 7 of the Tariff
- **RRR File Updates**: Revenue adjustments for previous calendar year point-to-point revenue shall be documented in the RRR File
- **Website Posting**: FACR calculation results must be posted on the SPP website

## 4. Important Dates

- **June 19, 2010**: Critical date distinguishing Base Plan Upgrades issued Notification to Construct (NTC) before versus on/after this date (different treatment in Column 4 vs. Column 5 of Table 1)
- **March 1 (Annual)**: Deadline for Transmission Provider to calculate, post, and implement FERC Assessment Charge Rate
- **Previous Calendar Year**: Reference period for point-to-point revenue adjustments in ATRR calculations
- **Annual Basis**: Formula rate credits updated annually

## 5. Organizations and People Mentioned

### Organizations:
- **Commission/FERC**: Federal Energy Regulatory Commission (regulatory authority)
- **SPP (Southwest Power Pool)**: The Transmission Provider
- **Transmission Owners**: Various entities owning transmission facilities (not individually named in this chunk)
- **Network Customers**: Entities receiving network integration transmission service
- **Western-UGP**: Entity with Federal Service Exemption and Statutory Load Obligations
- **Federal-Power Southwestern**: Referenced in Zone 10 calculations
- **SATOA** (Settlements and Transmission Operations Agreement entities): With dispatch revenues into Energy and Operating Reserve Markets

### People:
- None specifically mentioned in this chunk

## 6. Links or References

### Internal Tariff References:
- **Schedule 9**: Network Integration Transmission Service
- **Schedule 11**: Base Plan cost recovery schedule (Sections II, III, IV, V)
- **Schedule 12**: FERC Assessment Charge
- **Attachment H**: Annual Transmission Revenue Requirement specifications (Tables 1, 2-A, 2-B, 3; Sections I, II)
- **Attachment J**: Cost allocation methodology (Sections IV.A)
- **Attachment AU**: Revenue distribution provisions (Sections IV, V)
- **Section 7 of Tariff**: Billing procedures
- **Section 31.3**: Provisions for Network Load not physically interconnected
- **Section 34.5**: Transmission Provider's monthly Transmission System load determination
- **Section 34.9**: Federal-Power Southwestern identification
- **Section 39.2**: Bundled Retail and Grandfathered Loads provisions

### External References:
- **FERC Part 382**: Regulations governing FERC Assessment charges
- **FERC Form 582**: Reporting form for megawatt-hours transmitted in interstate commerce
- **Commission-approved annual transmission revenue requirements**: Filed with and approved by FERC

### Documents Referenced:
- **RRR File**: Revenue Requirement file containing revenue adjustment details
- **SPP website**: Platform for posting FACR calculations

## 7. Suggested Tags

- Transmission Rates
- Revenue Requirements
- FERC Assessment
- Cost Allocation
- Zonal Charges
- Region-wide Charges
- Point-to-Point Service
- Network Integration
- Formula Rates
- SPP Tariff
- Base Plan Upgrades
- Load Ratio Share
- Western Interconnection
- Federal Service Exemption
- RR696
- Schedule 11
- Schedule 12
- Attachment H

## 8. Items That May Need Follow-Up

### Clarifications Needed:
1. **Incomplete Section**: Section III beginning "Base Plan Zonal Charge and Region-wide Charge for Point-To-Point Transmission Service" is cut off with ellipsis - full content needed
2. **Table References**: Multiple references to Tables 1, 2-A, 2-B, and 3 in Attachment H but actual table contents not included in this chunk
3. **SATOA Definition**: Acronym used but not defined in this chunk
4. **Zone Boundaries**: Geographic or organizational boundaries of Zones 1-19 not specified
5. **Formula Rate Details**: Specific formula rate structures for Transmission Owners not provided

### Policy Questions:
1. **Revenue Credit Timing**: Why are previous calendar year revenues used for current year adjustments rather than more contemporaneous data?
2. **Differential Treatment**: Rationale for different treatment of Base Plan Upgrades before/after June 19, 2010
3. **Western Interconnection Exclusion**: Basis for excluding Western Interconnection load from Zone 19 Region-wide Charges
4. **True-up Mechanism**: How are FACR estimate variances reconciled in subsequent years?

### Compliance Monitoring:
1. **March 1 Deadline**: Verification that FACR calculations are completed and posted timely
2. **Formula Rate Updates**: Confirmation that Transmission Owners with formula rates properly credit Schedule 11 revenues annually
3. **FERC Form 582 Accuracy**: Validation of reported MWh data used for FERC Assessment calculations
4. **RRR File Maintenance**: Ensuring revenue adjustment documentation is current and accurate

### Potential Issues:
1. **Double Counting Risk**: Complex revenue credit mechanism across multiple schedules and attachments could result in double counting or omissions
2. **Stated Rate Obsolescence**: Transmission Owners using stated rates without annual updates may have outdated revenue credits
3. **Zone 19 Complexity**: Special load exclusions for Western Interconnection could create allocation disputes
4. **Federal Exemption Verification**: Tracking when Western-UGP's load qualifies for Federal Service Exemption versus when Region-wide Charges apply

---

# Chunk 4 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document is chunk 4 of 27 from SPP (Southwest Power Pool) tariff comments dated August 14, 2025 (file: RR696 SPP Comments 20250814.docx.txt). The content consists of detailed technical provisions from Attachment H regarding Annual Transmission Revenue Requirements (ATRR) calculations, allocation methodologies, and Transmission Owner-specific requirements. Key focus areas include Region-wide ATRR calculations for Network Upgrades before and after October 1, 2015, formula rate processes, and specific requirements for Southwestern Public Service Company and American Electric Power. The document also addresses cost recovery for canceled projects and regulatory filing procedures with the Federal Energy Regulatory Commission (FERC).

## 2. Key Topics

- **Annual Transmission Revenue Requirements (ATRR) Structure:**
  - Region-wide ATRR calculations and components
  - Base Plan Zonal ATRR allocations
  - Distinction between Network Upgrades needed before/after October 1, 2015

- **Revenue Requirement Components:**
  - Base Plan Region-wide ATRR
  - Balanced Portfolio Region-wide ATRR
  - Interregional Planning Region ATRR
  - JTIQ (Joint Transmission Impact Queue) Upgrades
  - Upgrade Sponsor payments per Attachment Z2

- **Formula Rate Processes:**
  - Commission-approved formula rate update procedures
  - Annual update mechanisms for Transmission Owners
  - Regulatory acceptance requirements

- **Transmission Owner-Specific Requirements:**
  - Southwestern Public Service Company (SPS) - Zone 11 calculations
  - American Electric Power ATRR formulations
  - Canceled project cost recovery ($3,264,402.55)

- **Revenue Credits and Allocations:**
  - Schedule 7, 8, and 11 revenues
  - Attachment AU revenue distributions
  - SATOA (Stand-Alone Transmission Owner Agreement) dispatch revenues

## 3. Decisions or Actions

- **Formula Rate Updates:** Transmission Providers authorized to update revenue requirements upon successful completion of approved annual formula rate update procedures without additional Commission filing
- **Cost Recovery for Canceled AEP Projects:** Approved recovery of $3,264,402.55 for canceled projects (Multi-Shipe Road - East Rogers - Kings River 345 kV and Line - Georgia Pacific - Keatchie 138 kV Ckt 1) over twelve months with interest
- **Posting Requirements:** Revenue requirement results must be posted on SPP website by specified deadlines (October 1 or October 31, depending on Transmission Owner)
- **RRR File Updates:** Transmission Provider shall update RRR File posted on SPP website with accepted or approved revenue requirements

## 4. Important Dates

- **October 1, 2015:** Dividing line for Network Upgrade categorization (before vs. on/after this date affects ATRR calculation methodology)
- **April 1, 2018:** Commencement date for American Electric Power ATRR inclusion of canceled project costs
- **October 1 (annually):** Deadline for posting SPS formula calculation results on SPP and OASIS websites
- **October 31 (annually):** Deadline for posting American Electric Power ATRR calculations on SPP website
- **January 1 (following year):** Effective date for posted ATRR calculations
- **Twelve-month recovery period:** Timeline for AEP canceled project cost recovery with monthly installments

## 5. Organizations and People Mentioned

### Organizations:
- **Southwest Power Pool, Inc. (SPP)** - Transmission Provider
- **Federal Energy Regulatory Commission (FERC/Commission)** - Regulatory authority
- **Southwestern Public Service Company (SPS)** - Transmission Owner for Zone 11
- **Xcel Energy Operating Companies** - Parent organization of SPS
- **American Electric Power (AEP)** - Transmission Owner
- **Associated Electric Cooperative, Inc.** - Party to cost sharing agreements

### Zones Referenced:
- Zones 1 through 19 (specific zones within SPP territory)
- Zone 11 (SPS territory)

### No Individual Names Mentioned

## 6. Links or References

### Internal Tariff References:
- **Attachment J** - ATRR allocation methodology
- **Attachment Z2** - Upgrade Sponsor payment provisions
- **Attachment H** - Main attachment being described (this document)
- **Attachment AU** - Revenue distribution provisions (Sections IV and V)
- **Attachment O** - General reference
- **Addendum 1 to Attachment O** - Coordination agreements
- **Attachment O - SPS of Xcel Energy OATT** - SPS formula rate specifications
- **Addendum 1 to this Attachment H** - American Electric Power formula rate
- **Attachment L** - Point-to-Point transmission revenue allocation
- **Schedule 7, 8, 9, and 11** - Various transmission service schedules

### Regulatory References:
- **18 C.F.R. § 35.19a(a)(2)(iii)** - Commission regulations regarding interest rates

### Posted Resources:
- **Revenue Requirements and Rates File (RRR File)** - Posted on SPP website
- **SPS OASIS website** - Accessible location for formula calculations

### Specific Agreements:
- Cost Sharing and Usage Agreement Between SPP and Associated Electric Cooperative, Inc. (Morgan Transformer Project)
- Cost and Usage Agreement Between SPP and Associated Electric Cooperative, Inc. (Blackberry Substation Upgrade)

### Network Upgrade References:
- Network Upgrades 10656, 10659, and 10660 (Multi-Shipe Road - East Rogers - Kings River 345 kV)
- Network Upgrade 10616 (Line - Georgia Pacific - Keatchie 138 kV Ckt 1)

## 7. Suggested Tags

- Annual Transmission Revenue Requirements (ATRR)
- Formula Rates
- SPP Tariff
- Attachment H
- Transmission Owner Requirements
- Cost Recovery
- Network Upgrades
- FERC Regulations
- Revenue Allocation
- Southwestern Public Service Company
- American Electric Power
- Zone-Specific Charges
- Canceled Projects
- Base Plan Upgrades
- Balanced Portfolio
- Interregional Planning
- JTIQ Upgrades
- Schedule 11
- Point-to-Point Transmission
- Network Integration Transmission Service

## 8. Items That May Need Follow-Up

### Immediate Monitoring Required:
1. **AEP Canceled Project Recovery Completion:** Track the twelve-month recovery period for $3,264,402.55 to ensure proper accounting and final joint informational filing with Commission upon completion
2. **Revenue Disposal Obligation:** Monitor if property associated with canceled AEP projects is sold or disposed of during recovery period - revenues must be credited appropriately

### Annual Compliance Items:
3. **Annual Posting Deadlines:** Verify compliance with October 1 and October 31 posting requirements for SPS and AEP respectively
4. **January 1 Effective Dates:** Confirm timely implementation of updated ATRRs
5. **Formula Rate Update Procedures:** Ensure all Transmission Owners with Commission-approved formula rates complete annual update procedures

### Documentation and Filing:
6. **RRR File Updates:** Confirm regular updates to Revenue Requirements and Rates File on SPP website
7. **Public Review and Comment Requirements:** Verify Transmission Owners post populated formula rates for public review as required under applicable protocols
8. **Commission Filings:** Track any required filings for new or amended revenue requirements with necessary cost support

### Clarification Needed:
9. **Table References:** Document indicates Tables 1, 2-A, 2-B, and 3 with various columns, but actual table content not visible in this chunk - may need to reference complete document
10. **Section 34.1 Reference:** SPS provisions reference "section 34.1" for adjustments - confirm this cross-reference is accurate
11. **JTIQ ATRR Balance Definition:** Referenced as defined in "Part I, Section 1 of the Tariff" - may need to cross-reference for complete understanding
12. **Incomplete Paragraph:** Document ends mid-sentence regarding property sale/disposition revenues - requires review of subsequent content

### Coordination Requirements:
13. **Multi-Party Agreements:** Monitor compliance with Cost Sharing and Usage Agreements between SPP and

---

# Chunk 5 Analysis

# Regulatory Document Analysis Report

## 1. Executive Summary

This document is chunk 5 of 27 from SPP (Southwest Power Pool) regulatory comments dated August 14, 2025 (file RR696). The content details cost recovery mechanisms for canceled transmission network upgrade projects and outlines procedures for various types of transmission system upgrades. Three main entities have specific cost recovery arrangements: American Electric Power (AEP), Sunflower Electric Power Corporation, and Southwestern Power Administration. The document also provides detailed guidance on Sponsored Upgrades, Service Upgrades, Generation Interconnection Related Network Upgrades, and Zonal Reliability Upgrades.

## 2. Key Topics

- **Canceled Project Cost Recovery**: Recovery of costs for canceled transmission infrastructure projects through Annual Transmission Revenue Requirements (ATRR)
- **AEP Cost Recovery**: $414,465 recovery for canceled Line projects (Chapel Hill REC – Welsh Reserve and Welsh Reserve - Wilkes 138 kV circuits)
- **Sunflower Electric Cost Recovery**: $718,359 recovery for canceled Device – Russell 115 kV project
- **Southwestern Power Administration Rate Calculations**: NITS ATRR component calculation methodology
- **Sponsored Upgrades**: Voluntary cost-bearing arrangements by Project Sponsors
- **Service Upgrades**: Cost allocation per Attachment Z1
- **Generation Interconnection Network Upgrades**: Cost allocation per Attachment V
- **Candidate ILTCRs**: Incremental Long-Term Congestion Rights compensation mechanisms
- **RRR File Reporting**: Requirements for joint informational filings to FERC

## 3. Decisions or Actions

- **Monthly Recovery Installments**: Costs are recovered in equal monthly installments over 12-month periods
- **Joint Informational Filings Required**: SPP and respective utilities must file with Commission upon:
  - Full cost recovery completion
  - Sale or disposition of property during or after recovery period
- **Credit Requirements**: Revenues from property sales must be credited against respective ATRRs
- **ILTCR Terms**: Must be specified in agreements with minimum 10 years and maximum 20 years
- **Payment Options for Sponsored Upgrades**: Lump sum or periodic charges over 20 years (except Western-UGP which requires lump sum only)
- **True-Up Process**: Transmission Provider must true-up estimated construction costs to actual costs upon completion

## 4. Important Dates

- **March 1, 2019**: AEP ATRR inclusion of $414,465 commenced
- **January 1, 2024**: Sunflower Electric Power Corporation ATRR inclusion of $718,359 commenced
- **April 2017**: Reference date for Formula Rate Posting Information Notification List access
- **January 1, 2008**: Cut-off date for 2005 SPP Transmission Expansion Plan Zonal Reliability Upgrades allocation methodology
- **12-month recovery periods**: Standard recovery timeframe for canceled project costs

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)** - Transmission Provider
- **American Electric Power (AEP)**
- **Sunflower Electric Power Corporation**
- **Southwestern Power Administration**
- **Western-UGP**
- **FERC (Federal Energy Regulatory Commission)** - "the Commission"

### Roles Referenced (no specific individuals named):
- Project Sponsor
- Transmission Owner
- Transmission Customer
- Interconnection Customer
- JTIQ Generation Interconnection Customer
- Market Participant

## 6. Links or References

### External Reference:
- **http://www.spp.org/stakeholder-center/exploder-lists/** - Formula Rate Posting Information Notification List (as of April 2017: "Formula Rate Posting Information Notification")

### Internal Document References:
- Attachment J (multiple sections, especially Section VIII)
- Attachment H (including Addendum 20, Table 1, Column 3)
- Schedule 11
- Attachment Z1
- Attachment Z2 (Sections I, II, and IV)
- Attachment V
- Attachment AH
- Attachment L
- Attachment AV
- Section 2.3.3 of Rate Schedule NFTS-13A (Southwestern Power Administration)
- Federal Power Act

### Specific Network Upgrade Project References:
- Network Upgrade 50697 (Line – Chapel Hill REC – Welsh Reserve 138 kV Ckt 1)
- Network Upgrade 11423 (Line – Welsh Reserve - Wilkes 138 kV Ckt 1)
- Network Upgrade 122803 (Device – Russell 115 kV)

## 7. Suggested Tags

- Cost Recovery
- Transmission Revenue Requirements
- ATRR
- Canceled Projects
- Network Upgrades
- SPP Tariff
- FERC Compliance
- Sponsored Upgrades
- Service Upgrades
- ILTCRs
- Generation Interconnection
- Rate Design
- Zonal Reliability
- American Electric Power
- Sunflower Electric
- Southwestern Power Administration
- Transmission Planning
- Revenue Credits
- RRR File

## 8. Items That May Need Follow-Up

1. **AEP Cost Recovery Status**: Verify completion of 12-month recovery period that began March 1, 2019 (should have concluded by March 1, 2020) and confirm joint informational filing was submitted
   
2. **Sunflower Electric Recovery Status**: Track recovery period commencing January 1, 2024 through December 31, 2024; confirm completion filing

3. **Property Disposition Tracking**: Monitor any sales or dispositions of property related to:
   - AEP canceled projects (Network Upgrades 50697 and 11423)
   - Sunflower canceled project (Network Upgrade 122803)

4. **RRR File Updates**: Verify that RRR File reflects $0 upon full recovery completion for both entities

5. **Interest Recovery Calculations**: Confirm final total recovery amounts include all interest recovered as specified

6. **Website Link Verification**: Confirm Formula Rate Posting Information Notification List is still accessible at referenced URL or obtain updated link

7. **Southwestern Power Administration Documentation**: Verify supporting documentation for NITS ATRR calculations is posted on SPP website as required

8. **ILTCR Agreement Monitoring**: Track terms and execution of candidate ILTCR agreements (10-20 year terms)

9. **True-Up Filing Requirements**: Confirm Sponsored Upgrade cost true-ups are filed upon project completion

10. **Attachment AH Execution**: Verify Project Sponsors receiving candidate ILTCRs who are not Market Participants have executed Attachment AH

---

# Chunk 6 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary

This document is **Attachment L** from the SPP (Southwest Power Pool) Tariff, specifically addressing the treatment and distribution of transmission service revenues. The content establches detailed methodologies for allocating revenues from Network Integration Transmission Service and Point-To-Point Transmission Service among Transmission Owners based on their Zonal Annual Transmission Revenue Requirements (ZRR) and Owner-Specific Zonal Annual Revenue Requirements (OZRR). The attachment includes special provisions for Grandfathered Agreements, single-owner versus multi-owner zones, and specific treatments for Zone 1 and Zone 19.

## 2. Key Topics

- **Revenue Distribution Methodologies**: Detailed allocation formulas for transmission service revenues
- **Grandfathered Agreements**: Protection of existing agreements between parties with no claim by Transmission Provider
- **Single-Owner vs. Multi-Owner Zones**: Different revenue distribution approaches based on zone ownership structure
- **Network Integration Transmission Service (NITS)**: Revenue allocation under Schedule 9
- **Point-To-Point Transmission Service**: Revenue distribution under Schedules 7 and 8
- **Load Ratio Shares**: Calculation methodology for zones with network loads outside the Transmission System
- **Creditable Upgrades**: Revenue credits attributed to Upgrade Sponsors per Attachment Z2
- **MW-mile Impacts**: Distribution methodology based on transmission facility usage impacts
- **Zone-Specific Provisions**: Special rules for Zone 1 (American Electric Power) and Zone 19

## 3. Decisions or Actions

- **Grandfathered Agreement Revenue Treatment**: Transmission Provider has no claim to revenues; customers pay Transmission Owners directly
- **Single-Owner Zone Distribution**: Revenues go to the Transmission Owner where Network Load is located (Schedule 9)
- **Multi-Owner Zone Adjustments**: 
  - OZRR reductions for Grandfathered Agreement sellers
  - OZRR increases for Grandfathered Agreement purchasers
  - Calculation of hypothetical NITS payments for owners not taking service
- **Point-To-Point Revenue Split**: 50% distributed by OZRR proportion, 50% by MW-mile impacts
- **Dispute Resolution**: Parties unable to reach agreement may invoke Tariff dispute resolution procedures or seek FERC determination
- **Zone 1 Special Treatment**: Subsequent Transmission Owners entitled to revenue based on formula: (1 - Load Ratio Share) × OZRR

## 4. Important Dates

- **October 1, 2015**: Cutoff date for Network Load designation outside Transmission System for Zone 19 (Section II.B.2(h))

## 5. Organizations and People Mentioned

### Organizations:
- **Transmission Provider** (SPP)
- **Transmission Owners** (multiple, various zones)
- **Network Customers**
- **FERC** (Federal Energy Regulatory Commission)
- **American Electric Power** (specifically mentioned for Zone 1)
- **Upgrade Sponsors** (for Creditable Upgrades)

### Zones Referenced:
- **Zone 1** (American Electric Power zone with special provisions)
- **Zone 19** (with specific Network Load designation rules)
- **Multi-owner Zones** (general)
- **Single-owner Zones** (general)

## 6. Links or References

### Internal Tariff References:
- **Schedule 7** (Point-To-Point Transmission Service)
- **Schedule 8** (Point-To-Point Transmission Service)
- **Schedule 9** (Network Integration Transmission Service)
- **Schedule 11** (Base Plan and Region-wide charges)
- **Section 31.4** (Network Load designation outside Transmission System)
- **Section 34.1(2)** (OZRR adjustments)
- **Section 34.4** (Load Ratio Share calculations)
- **Section 39** (Transmission service for Transmission Owners)
- **Attachment H** (Zonal Annual Transmission Revenue Requirements)
- **Attachment L** (this document - Treatment of Revenues)
- **Attachment S** (MW-mile impact calculation procedures)
- **Attachment Z2** (Creditable Upgrades provisions)

## 7. Suggested Tags

- Revenue Distribution
- Transmission Service
- Tariff Attachment L
- Network Integration Transmission Service (NITS)
- Point-To-Point Transmission Service
- Grandfathered Agreements
- Zonal Annual Transmission Revenue Requirement (ZRR)
- Owner-Specific Zonal Annual Revenue Requirement (OZRR)
- Load Ratio Share
- MW-mile Impacts
- SPP Tariff
- Multi-Owner Zones
- Creditable Upgrades
- FERC Regulated
- Revenue Allocation Methodology

## 8. Items That May Need Follow-Up

1. **Dispute Resolution Mechanisms**: The document references dispute resolution procedures for Grandfathered Agreements but doesn't detail the specific process - may need to reference main Tariff sections

2. **Attachment Z2 Details**: Multiple references to Creditable Upgrades and Upgrade Sponsors revenue distribution per Attachment Z2 - recommend reviewing that attachment for complete understanding

3. **MW-mile Calculation Methodology**: References Attachment S for MW-mile impact procedures - should be reviewed to understand 50% revenue distribution component

4. **Hypothetical NITS Payment Calculations**: Section II.B.2(c) mentions calculating hypothetical payments for Transmission Owners not taking service - methodology may need clarification

5. **Zone 1 Exception Rationale**: Sections II.B.2(a)-(e) explicitly don't apply to Zone 1 with different formula - understand historical/regulatory basis for this exception

6. **Zone 19 Grandfathering Date**: October 1, 2015 cutoff for Network Load designation - verify any pending loads near this date for proper revenue treatment

7. **Load Outside Transmission System**: Revenue treatment for Network Loads not physically connected to Transmission System (Sections 31.4, II.B.1(b), II.B.2(f)) - may need operational clarification

8. **OZRR Adjustment Process**: Section 34.1(2) adjustments referenced multiple times - review for proper revenue calculation

9. **Incomplete Section III**: Document cuts off mid-sentence in Section III.A regarding exclusions - need complete text for Base Plan and Region-wide revenue distribution

10. **FERC Determination Process**: When parties invoke FERC for Grandfathered Agreement disputes - understand timing and procedural requirements

---

# Chunk 7 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary

This document contains tariff provisions (Attachment L, M, and O) from SPP (Southwest Power Pool) governing revenue distribution for transmission services, loss compensation procedures, and the transmission planning process. The content primarily addresses revenue allocation mechanisms for various transmission upgrades, procedures for calculating and allocating transmission losses, and the comprehensive transmission planning framework including the SPP Transmission Expansion Plan (STEP). Key provisions cover distribution of point-to-point revenues, JTIQ (Joint Targeted Interconnection Queue) upgrade revenue settlements, and multiple pathways for transmission planning approval.

## 2. Key Topics

- **Revenue Distribution Mechanisms**: Distribution of revenues from point-to-point transmission service to Transmission Owners based on various upgrade categories (Base Plan, Balanced Portfolios, Interregional Projects)
- **JTIQ ATRR Balance**: Calculation and settlement of revenue requirements for JTIQ Upgrades between generators and resident load
- **Loss Compensation**: Procedures for quantifying real power losses using Injection Loss Factors (ILF) and Delivery Loss Factors (DLF)
- **Transmission Planning Framework**: Multiple pathways for transmission facility proposals including service requests, generator interconnections, Integrated Transmission Planning Assessment, Balanced Portfolios, and Sponsored Upgrades
- **SPP Transmission Expansion Plan (STEP)**: Comprehensive regional plan consolidating all transmission projects across various approval processes
- **Interregional Coordination**: Revenue distribution to Interregional Planning Regions and other transmission providers

## 3. Decisions or Actions

- **Monthly Revenue Charges/Credits**: One-twelfth of JTIQ ATRR Balance charged/credited monthly to Resident Load through Region-wide Charge
- **Stakeholder Review Process**: Draft project lists must be posted on SPP website for written stakeholder comments
- **Regional State Committee Review**: Transmission Provider must review draft project lists with stakeholder working groups and Regional State Committee
- **Revenue Distribution Adjustments**: Revenues reduced by Schedule 11 point-to-point revenue and amounts distributed/allocated under Attachment AU
- **Recommended Project List**: Transmission Provider prepares final recommended list considering stakeholder input

## 4. Important Dates

- **Monthly Settlement**: JTIQ ATRR Balance distributed monthly (one-twelfth per month)
- **Annual Calculations**: Annual transmission revenue requirements form basis for revenue distribution
- **Planning Horizon**: SPP Transmission Expansion Plan covers defined planning horizon (specific duration not stated in this excerpt)

*Note: No specific calendar dates are mentioned in this content chunk*

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)** - Transmission Provider
- **Transmission Owners** - Recipients of revenue distributions
- **Network Customers** - Responsible for transmission losses
- **Transmission Customers** - Service recipients under various schedules
- **Upgrade Sponsors** - Recipients of Creditable Upgrade revenues
- **Interregional Planning Regions** - Recipients of interregional project revenues
- **Regional State Committee** - Review body for transmission projects
- **Western-UGP** - Federal Power entity serving Statutory Load Obligations
- **Stakeholder Working Groups** - Project review participants

### People:
*No specific individuals mentioned in this content*

## 6. Links or References

### Internal Tariff References:
- **Attachment J** - Section IV.A (Zonal Annual Transmission Revenue Requirements reallocation)
- **Attachment L** - Sections II.A, II.C, II.D, III.A, III.C, III.F (revenue distribution provisions)
- **Attachment Z2** - Sections II.D and III.C.2 (Creditable Upgrades)
- **Attachment O** - Addendum(s), Addendum 1 (interregional cost allocation, coordination agreements)
- **Attachment AV** - Appendix 2 (JTIQ Formula Rate template)
- **Attachment M** - Appendix 1 (loss factors)
- **Attachment AE** - Energy and Operating Reserve Markets settlement procedures
- **Attachment AQ** - Delivery point facility changes
- **Attachment V** - Generator Interconnection Requests
- **Attachment AX** - Upgrade requests
- **Attachment Y** - Competitive Upgrades definition
- **Attachment AU** - Revenue distribution and allocation

### Schedules Referenced:
- **Schedule 7** - Point-to-Point Transmission Service
- **Schedule 8** - Point-to-Point Transmission Service
- **Schedule 9** - Network Integration Transmission Service charges
- **Schedule 11** - Various rate provisions

### External References:
- **SPP website** - RRR File posting location and draft project list posting
- **Section 39.3(e)(ii)** - Federal Power-Western-UGP provisions

## 7. Suggested Tags

`SPP` `transmission-planning` `revenue-distribution` `JTIQ` `ATRR` `loss-compensation` `transmission-expansion-plan` `STEP` `interregional-projects` `balanced-portfolios` `point-to-point-service` `network-integration` `tariff-provisions` `base-plan-upgrades` `creditable-upgrades` `sponsored-upgrades` `generator-interconnection` `transmission-owners` `regional-state-committee` `stakeholder-process` `cost-allocation` `transmission-losses` `DLF` `ILF` `RRR-file`

## 8. Items That May Need Follow-Up

### Clarification Needed:
1. **JTIQ ATRR Balance Calculation Methodology** - Specific formula and components require detailed review of Attachment AV Appendix 2
2. **Zone-Specific Loss Factors** - Actual ILF and DLF values require review of Attachment M Appendix 1
3. **Stakeholder Comment Period Duration** - Timeline for written comment submission not specified
4. **Revenue Distribution Formula Components** - Proportionality calculations may need verification with actual examples

### Potential Issues:
5. **Negative JTIQ ATRR Balance Treatment** - Implications of charging Transmission Owners when balance is negative
6. **Coordination with Adjacent Systems** - Process for addressing reliability violations on neighboring transmission systems from Competitive Upgrades (mentioned but not detailed)
7. **Federal Power-Western-UGP Special Treatment** - Unique loss energy calculation may require separate tracking and validation

### Procedural Follow-Up:
8. **Draft Project List Posting Timeline** - When in the annual cycle does posting occur?
9. **Regional State Committee Decision Authority** - Extent of influence versus advisory role unclear
10. **RRR File Update Frequency** - How often are JTIQ ATRR Balance components updated on SPP website?
11. **Multi-Zone Network Customer Allocation** - How losses are allocated when Network Load spans multiple zones
12. **Interregional Revenue Distribution Mechanics** - Actual payment/settlement timing and mechanisms between SPP and other regions

### Compliance Monitoring:
13. **Schedule 11 Revenue Tracking** - Mechanism to ensure proper reduction of revenues in distribution calculations
14. **Generator Retirement Process Integration** - How retired generation facilities affect transmission planning and revenue requirements (process mentioned but not detailed in this excerpt)

---

**Document Reference**: RR696 SPP Comments 20250814.docx.txt - chunk 7 of 27

---

# Chunk 8 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document excerpt is from SPP's (Southwest Power Pool) Tariff Attachment O, specifically addressing the transmission expansion planning process. The content outlines comprehensive procedures for disclosure of planning information, stakeholder engagement, approval processes for various types of upgrades, and ongoing management of the SPP Transmission Expansion Plan (STEP). It establishes governance structures involving the Markets and Operations Policy Committee, SPP Board of Directors, and stakeholder working groups. The excerpt transitions into Attachment P, which covers transmission service timing requirements and scheduling protocols.

## 2. Key Topics

- **Planning Information Disclosure**: Requirements for transparency in sharing planning studies, recommended upgrades, and supporting documentation
- **Stakeholder Engagement Process**: Equal access to planning summits, working group meetings, and sub-regional meetings
- **Approval Hierarchy**: Multi-tiered approval process involving Markets and Operations Policy Committee recommendations and SPP Board of Directors final approval
- **Types of Upgrades**: ITP Upgrades, Balanced Portfolios, high priority upgrades, 20-Year Assessment upgrades, Sponsored Upgrades, Generator Retirement Upgrades, JTIQ Upgrades, and Interregional Projects
- **CEII and Confidentiality**: Password-protected access protocols and redaction requirements for Critical Energy Infrastructure Information
- **Plan Modifications**: Quarterly updates and out-of-cycle adjustments to maintain system reliability
- **Upgrade Tracking**: Quarterly status reporting requirements for planned system upgrades
- **Adjacent System Impacts**: Evaluation and responsibility determination for reliability violations on neighboring systems
- **Transmission Service Timing**: Scheduling deadlines and protocols for various service types

## 3. Decisions or Actions

### Required Actions:
- **Transmission Provider must**:
  - Disclose planning information and recommended upgrades to all stakeholders
  - Post study results, criteria, assumptions, and data on SPP website
  - Provide electronic links to Transmission Owner-specific local plans
  - Post list of projects for Board action at least 10 days prior to meetings
  - Post quarterly modifications to the SPP Transmission Expansion Plan
  - Track and report status of planned upgrades quarterly
  - Evaluate impacts of Competitive Upgrades on adjacent systems

- **Markets and Operations Policy Committee shall**:
  - Make recommendations on ITP Upgrades, Balanced Portfolios, high priority upgrades, 20-Year Assessment upgrades, and Sponsored Upgrades
  
- **SPP Board of Directors**:
  - Provide final approval for all upgrade categories
  - May modify approved upgrade lists throughout the year
  - Must review SPP Transmission Expansion Plan at least once annually
  - Must explain any deviations from Committee recommendations

### Approval Process:
- Stakeholder review → Markets and Operations Policy Committee recommendation → SPP Board of Directors approval

## 4. Important Dates

- **At least 10 days prior**: Notice requirement before SPP Board of Directors meetings on project action items
- **Quarterly basis**: 
  - Posting of modifications to SPP Transmission Expansion Plan
  - Status reporting to Markets and Operations Policy Committee, Regional State Committee, and Board
  - Posting of upgrade status on SPP website
- **Annual**: SPP Transmission Expansion Plan presentation to Board of Directors (minimum frequency)
- **Timing for transmission service requests**: Various deadlines specified (09:55:00-10:05:00 a.m. CPT for certain non-firm requests)
- **Five-minute window**: All requests within first five minutes after deadline deemed simultaneous

## 5. Organizations and People Mentioned

### Organizations:
- **Southwest Power Pool (SPP)** - Regional Transmission Organization
- **Markets and Operations Policy Committee** - Recommendation body for upgrades
- **SPP Board of Directors** - Final approval authority
- **Regional State Committee** - Review body for modifications
- **Stakeholder working groups** - Endorsement role
- **Transmission Provider** (SPP in operational capacity)
- **Transmission Owners** - Individual transmission system owners
- **Transmission Customers** - Service recipients
- **NERC** (North American Electric Reliability Corporation) - Referenced for holidays and priorities
- **Federal Energy Regulatory Commission (Commission/FERC)** - Regulatory filing authority

### People:
- No specific individuals mentioned in this excerpt

## 6. Links or References

### Internal Cross-References:
- **Attachment O**: 
  - Section II (stakeholder meetings)
  - Section IV.7 (Interregional Projects)
  - Section V (approval processes)
  - Section VII (Transmission Owner local plans)
  - Section VIII (upgrade removal and reimbursement)
- **Attachment J, Section VIII** (reimbursement for removed upgrades)
- **Attachment Z1** (transmission service upgrades)
- **Attachment V** (Generator Interconnection Service)
- **Attachment AB** (Generator Retirement Upgrades)
- **Attachment P** (Transmission Service Timing Requirements)
- **Attachment T** (transmission service rates)
- **SPP Tariff** (general)
- **SPP Membership Agreement** (confidentiality provisions)
- **SPP OATT Sections 13.2 and 14.2** (capacity allocation principles)
- **SPP Transmission Expansion Plan (STEP)** - Main planning document

### External References:
- **FERC regulations** (implied through Commission filings)
- **NERC TLR** (Transmission Loading Relief)
- **CEII requirements** (Critical Energy Infrastructure Information)
- **OASIS** (Open Access Same-Time Information System)

## 7. Suggested Tags

- Transmission Planning
- Upgrade Approval Process
- SPP Governance
- Stakeholder Engagement
- STEP (SPP Transmission Expansion Plan)
- Markets and Operations Policy Committee
- Board Approval
- ITP Upgrades
- Balanced Portfolios
- High Priority Upgrades
- 20-Year Assessment
- Sponsored Upgrades
- Generator Retirement
- Interregional Projects
- CEII Compliance
- Confidentiality Requirements
- Quarterly Reporting
- Transmission Service Timing
- Non-Firm Service
- NERC Priorities
- Adjacent System Impacts
- Plan Modifications
- Out-of-Cycle Updates
- Regional Planning

## 8. Items That May Need Follow-Up

### Procedural Clarifications Needed:
1. **10-day notice requirement**: Verify whether this is sufficient time for stakeholder review of complex project portfolios
2. **Lottery system details**: Request full documentation of lottery procedures for simultaneous transmission service requests
3. **Out-of-cycle modifications**: Clarify threshold criteria for when modifications require out-of-cycle updates vs. quarterly updates
4. **Board deviation explanations**: Review historical instances where Board deviated from Committee recommendations

### Policy/Compliance Items:
5. **CEII redaction standards**: Confirm consistency of redaction practices across all Transmission Owners
6. **Password-protected access**: Verify stakeholder access procedures and identify any access barriers
7. **Adjacent system cost allocation**: Clarify dispute resolution process when adjacent systems disagree on violation causation
8. **Affiliated customer definition**: Request clear definition for "affiliated Transmission Customers" referenced in DC tie limitation rule

### Operational Tracking:
9. **Quarterly status reports**: Monitor for on-time filing and completeness
10. **Upgrade removal reimbursements**: Track instances and amounts under Section VIII of Attachment J
11. **Website posting compliance**: Verify all required documents are posted within specified timeframes
12. **Balanced Portfolio requirement**: Confirm SPP's rationale when no Balanced Portfolio is proposed in a given year

### Strategic Considerations:
13. **Stakeholder comment process**: Evaluate effectiveness of electronic link comment submission process
14. **Meeting participation**: Assess whether equal access to planning summits is being achieved in practice
15. **20-Year Assessment integration**: Review how long-term assessments are being incorporated into near-term planning
16. **Competitive Upgrade evaluation**: Monitor adjacent system impact assessments for thoroughness

### Document Management:
17. **Version control**: Ensure latest versions of local plans are accessible via SPP website links
18. **Instructions for unredacted versions**: Verify clarity and accessibility of process to obtain complete CEII versions
19. **Source file reference**: Note this is chunk 8 of 27 from "RR696 SPP Comments 20250814.docx.txt" - context from surrounding chunks may be needed for complete understanding

---

# Chunk 9 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document is chunk 9 of 27 from SPP (Southwest Power Pool) tariff comments dated August 14, 2025 (RR696). The content details transmission service rate structures and billing methodologies for Point-to-Point Transmission Service across multiple rate zones within the SPP region. It specifies service increments (hourly, daily, weekly, monthly, yearly), rate calculation formulas, and special provisions including discounts for ERCOT-related transactions. The document covers multiple transmission owners including American Electric Power-West zone entities, City Utilities of Springfield, Missouri, and begins coverage of The Empire District Electric Company.

## 2. Key Topics

- **Transmission Service Increments and Windows**: Fixed Hourly, Fixed Daily, Extended Weekly, Extended Monthly, Extended Yearly
- **NAESB Standards Compliance**: Reference to WEQ-001 Business Practice Standards
- **Rate Structures for Point-to-Point Service**: Both Firm and Non-Firm transmission service rates
- **Multiple Transmission Owner Rate Zones**: AEP-West, City Utilities of Springfield, Empire District Electric
- **Formula Rate Mechanisms**: Multiple formula rates referenced in Attachment H
- **Revenue Crediting and Reallocation**: Schedule 7 and 8 revenue adjustments, Attachment AU provisions
- **ERCOT Interface Provisions**: Special discount provisions for ERCOT Regional Transmission Service
- **Balanced Portfolio Reallocation**: Adjustments to Zonal Annual Transmission Revenue Requirements

## 3. Decisions or Actions

- **Service Offering Limitations**: Transmission Provider offers only specified service increment and window combinations (Fixed Hourly through Extended Yearly)
- **Time Zone Standardization**: All transmission service products offered and processed in Central Prevailing Time using 24-hour clock convention
- **Rate Filing Method**: Effective rates posted in Revenue Requirements and Rates File (RRR File) on SPP website
- **ERCOT Discount Application**: 45.27% reduction in zonal rates under Schedules 7 and 8 for qualifying Load Serving Entities importing planned/unplanned resources into ERCOT
- **Peak/Off-Peak Definitions**: 
  - On-Peak hours: HE 0700-2200 (excluding Sundays and holidays)
  - Off-Peak holidays: New Year's Day, Memorial Day, Independence Day, Labor Day, Thanksgiving Day, Christmas Day

## 4. Important Dates

- **Document Date**: August 14, 2025 (RR696 SPP Comments)
- **Service Start/Stop Times**: Various service windows defined (00:00 start times for daily, weekly, monthly, yearly services)
- **Billing Periods**: Monthly compensation for Reserved Capacity
- **Rate Divisors for Calculation**:
  - Yearly/12 months for monthly rates
  - Yearly/52 weeks for weekly rates
  - Yearly/260 days for on-peak daily rates
  - Yearly/365 days for off-peak daily rates
  - Yearly/4,160 hours for on-peak hourly rates
  - Yearly/8,760 hours for off-peak hourly rates

## 5. Organizations and People Mentioned

### Organizations:

**Transmission Owners in AEP-West Zone:**
- American Electric Power (AEP)
- East Texas Electric Cooperative, Inc.
- Deep East Electric Cooperative, Inc. (collectively "Texas Electric Cooperatives")
- Oklahoma Municipal Power Authority (OMPA)
- AEP West Transmission Companies (AEP-West Transco)
- Coffeyville Municipal Light and Power (CMLP)
- Arkansas Electric Cooperative Corporation (AECC)
- Transource Oklahoma (TROK)
- AEP Texas Central Company (TCC)
- AEP Texas North Company (TNC)

**Other Entities:**
- City Utilities of Springfield, Missouri
- The Empire District Electric Company
- Southwest Power Pool (SPP - Transmission Provider)
- North American Energy Standards Board (NAESB)
- North American Electric Reliability Corporation (NERC)
- Electric Reliability Council of Texas (ERCOT)
- Federal Energy Regulatory Commission (Commission)

**People Mentioned:**
- None specifically identified

## 6. Links or References

### Tariff Attachments Referenced:
- **Attachment R-1**: NAESB WEQ-001 Business Practice Standards incorporation
- **Attachment X**: Central Prevailing Time definition
- **Attachment T**: Rate Sheets for Point-To-Point Transmission Service
- **Attachment J, Section IV.A**: Balanced Portfolio Reallocation provisions
- **Attachment AU**: Revenue distribution and allocation
- **Attachment H**: Formula rates and protocols
  - Addendum 4: AEP Formula Rate
  - Addendum 12: AEP-West Transco Formula Rate
  - Addendum 17: City Utilities of Springfield Formula Rate
  - Addendum 38: AECC Formula Rate
  - Addendum 48: TROK Formula Rate

### Other References:
- **Section 34.1(2)**: Schedule 7 and 8 revenue crediting provisions
- **Tariff Part II**: SPP Tariff transmission service provisions
- **Tariff Part IV**: AEP Operating Companies' Tariff (ERCOT Regional Transmission Service)
- **Schedules 7 and 8**: Revenue schedules subject to adjustments
- **Revenue Requirements and Rates File (RRR File)**: Posted on SPP website
- **NAESB WEQ-001**: Wholesale Electric Quadrant Business Practice Standards

## 7. Suggested Tags

- Transmission Service Rates
- Point-to-Point Transmission
- SPP Tariff
- Formula Rates
- AEP-West Zone
- ERCOT Interface
- Revenue Requirements
- NAESB Standards
- Firm Transmission Service
- Non-Firm Transmission Service
- Rate Zones
- Balanced Portfolio
- Revenue Crediting
- Transmission Pricing
- Regional Transmission
- Service Increments
- RR696

## 8. Items That May Need Follow-Up

1. **Rate File Updates**: Verify current rates in the RRR File posted on SPP website match tariff provisions for all transmission owners listed

2. **Formula Rate Protocol Changes**: Monitor Attachment H addendums (4, 12, 17, 38, 48) for any updates to formula rate calculations affecting the transmission owners

3. **ERCOT Discount Verification**: Confirm 45.27% discount calculation methodology and applicability criteria for Load Serving Entities importing resources into ERCOT

4. **NAESB Standards Version**: Track updates to WEQ-001 Business Practice Standards referenced in Attachment R-1 to ensure compliance with latest version

5. **Incomplete Section**: Document appears to cut off mid-sentence regarding The Empire District Electric Company rate sheet - need complete section

6. **Balanced Portfolio Reallocation**: Monitor Section IV.A of Attachment J for any changes to reallocation methodology affecting point-to-point rates

7. **Peak Period Definitions**: Verify NERC holiday definitions remain consistent with those specified in the tariff

8. **Revenue Crediting Methodology**: Track implementation of Schedule 7 and 8 revenue adjustments and Attachment AU allocations per Section 34.1(2)

9. **Service Window Limitations**: Confirm operational systems can accommodate only the specified service increment combinations (no other combinations offered)

10. **Multi-Owner Rate Coordination**: Verify coordination among seven transmission owners in AEP-West zone for consistent rate application

11. **Static Rate Values**: Confirm whether specific rates mentioned (e.g., $2,053.993/MW for Texas Electric Cooperatives, $91.51/MW for OMPA, $47.32/MW for CMLP) are current or require updating

12. **Time Zone Conversion**: Ensure proper handling of Central Prevailing Time conversion, particularly for entities operating across multiple time zones

---

# Chunk 10 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document contains detailed tariff language and rate sheet specifications for Point-To-Point (PTP) transmission services within the SPP (Southwest Power Pool) system. The content focuses on rate calculation methodologies, revenue adjustments, and service terms for multiple transmission zones including Empire District Electric Company, Evergy Kansas Central, Inc., and Evergy Metro, Inc. The document establishes standardized procedures for firm and non-firm transmission service pricing, including balanced portfolio reallocation adjustments and revenue crediting mechanisms. All rates are calculated using zone-specific formula rates referenced in various Attachment H Addendums and published in the Revenue Requirements and Rates File (RRR File) on the SPP website.

## 2. Key Topics

- **Point-To-Point Transmission Service Rate Structures** for multiple utility zones
- **Balanced Portfolio Reallocation Adjustments** in accordance with Attachment J, Section IV.A
- **Revenue Crediting Mechanisms** for Schedule 7 and 8 revenues and Attachment AU allocations
- **Firm vs. Non-Firm Transmission Service** pricing distinctions
- **Reserved Capacity Compensation** methodologies (yearly, monthly, weekly, daily, hourly)
- **Formula Rate References** across multiple Attachment H Addendums (3, 10, 15, 16, 18, 43, 44)
- **On-Peak vs. Off-Peak Rate Differentials**
- **Demand Charge Caps** for various delivery periods
- **Zonal Annual Transmission Revenue Requirements (Zonal ATRR)**

## 3. Decisions or Actions

No specific decisions or actions are documented in this content. This appears to be established tariff language defining rate calculation procedures and service terms.

**Key Rate Calculation Procedures Established:**
- Rates calculated using zone-specific formula rates in Attachment H
- Results published in RRR File on SPP website
- Adjustments applied for balanced portfolio reallocation
- Revenue credits from Schedule 7 and 8 applied per Section 34.1(2)

## 4. Important Dates

### Annual Rate Posting Deadlines:
- **October 15** - Evergy Kansas Central, Inc. Formula Rate (Addendum 3) - posted annually, effective January 1 following year
- **September 1** - Prairie Wind Formula Rate (Addendum 15) - posted annually, effective January 1 following year
- **October 1** - South Central MCN Formula Rate (Addendum 43) - posted annually, effective January 1 following year
- **October 1** - Kansas Power Pool Formula Rate (Addendum 16) - posted annually, effective January 1 following year
- **October 1** - NEET Southwest Formula Rate (Addendum 44) - posted annually, effective January 1 following year

### Effective Dates:
- **January 1** - Annual effective date for all formula rate updates

## 5. Organizations and People Mentioned

### Organizations:

**Transmission Owners/Utilities:**
- The Empire District Electric Company
- Evergy Kansas Central, Inc.
- Evergy Kansas South, Inc.
- Evergy Metro, Inc. (EMe)
- City of Independence, Missouri (INDP)
- Prairie Wind Transmission LLC
- South Central MCN LLC
- Kansas Power Pool
- NextEra Energy Transmission Southwest, LLC (NEET Southwest)

**Regulatory/Market Entities:**
- Southwest Power Pool (SPP)
- Transmission Provider (generic reference)
- Transmission Customer (generic reference)
- Commission (referenced for rate approvals)

### People Mentioned:
None specifically identified

## 6. Links or References

### Internal Tariff References:
- **Attachment H** - Formula Rates
  - Addendum 3 (Evergy Kansas Central, Inc.)
  - Addendum 10, Parts 1 and 2 (Evergy Metro, Inc.)
  - Addendum 15 (Prairie Wind Transmission LLC)
  - Addendum 16 (Kansas Power Pool)
  - Addendum 18 (Empire District Electric Company)
  - Addendum 43 (South Central MCN LLC)
  - Addendum 44 (NextEra Energy Transmission Southwest, LLC)
- **Attachment J, Section IV.A** - Balanced Portfolio Reallocation
- **Attachment T** - Point-To-Point Transmission Service rates
- **Attachment AU** - Revenue distribution and allocation
- **Section 34.1(2)** - Revenue adjustment implementation
- **Schedule 7 and 8** - Revenue sources for crediting

### External References:
- **SPP Website** - location of RRR File posting
- **Revenue Requirements and Rates File (RRR File)** - specific tabs:
  - "Empire PTP Rate Att T" tab
  - "Evergy Kansas Central, Inc. PTP Rate Att T" tab
  - "EMe PTP Rate Att T" tab

### File Reference:
- Source: RR696 SPP Comments 20250814.docx.txt (chunk 10 of 27)

## 7. Suggested Tags

- Point-to-Point Transmission
- Transmission Rates
- SPP Tariff
- Formula Rates
- Revenue Requirements
- Evergy
- Empire District Electric
- Balanced Portfolio
- Reserved Capacity
- Firm Transmission Service
- Non-Firm Transmission Service
- On-Peak/Off-Peak Rates
- Zonal ATRR
- Rate Adjustment
- Revenue Crediting
- Transmission Service Agreement
- OATT (Open Access Transmission Tariff)
- FERC Tariff

## 8. Items That May Need Follow-Up

### Rate Compliance Monitoring:
1. **Annual Rate Posting Verification** - Confirm all formula rates are posted by required deadlines (September 1, October 1, October 15)
2. **Effective Date Tracking** - Ensure January 1 implementation of updated rates
3. **RRR File Updates** - Monitor SPP website for timely publication of all rate tabs

### Administrative Matters:
4. **Cross-Reference Verification** - Validate that all referenced Attachment H Addendums contain current, approved formula rates
5. **Revenue Crediting Reconciliation** - Verify Schedule 7 and 8 revenue adjustments are properly calculated and applied
6. **Balanced Portfolio Adjustments** - Confirm reallocation calculations per Attachment J, Section IV.A are accurate

### Entity-Specific Issues:
7. **Evergy Kansas Entity Consolidation** - Document references both "Evergy Kansas South, Inc." and "Evergy Kansas Central, Inc." - verify correct legal entity names
8. **Multi-Formula Zone Coordination** - For Evergy Kansas Central zone (5 separate formula rates), ensure proper aggregation methodology

### Procedural Clarifications Needed:
9. **Demand Charge Cap Application** - Clarify enforcement mechanism for weekly and daily demand charge caps
10. **Peak/Off-Peak Definitions** - Confirm whether peak hour definitions (16 hours vs. 24 hours) are standardized across all zones
11. **Reserved Capacity Units** - Document shows both MW and kW references; verify unit consistency requirements

### Potential Documentation Gaps:
12. **INDP Fixed Rate Justification** - Evergy Metro section includes fixed $2,442.048 rate for City of Independence; verify source and adjustment mechanism
13. **Formula Rate Protocol Updates** - Monitor for any changes to associated protocols for each addendum referenced

---

# Chunk 11 Analysis

# REGULATORY ANALYSIS REPORT
## Source: RR696 SPP Comments 20250814.docx.txt - chunk 11 of 27

---

## 1. Executive Summary

This document segment contains detailed tariff rate schedules for Point-To-Point (PTP) Transmission Service across multiple transmission zones within the Southwest Power Pool (SPP) territory. The content outlines compensation structures for both Firm and Non-Firm transmission services across various delivery timeframes (yearly, monthly, weekly, daily, hourly) for several transmission providers including Evergy Missouri West, Inc., Grand River Dam Authority, and Kansas City Board of Public Utilities. All rates reference formula rates contained in Attachment H addendums and are published in the Revenue Requirements and Rates File (RRR File) on the SPP website.

---

## 2. Key Topics

- **Point-To-Point Transmission Service Rate Structures**
  - Firm PTP Transmission Service rates and calculations
  - Non-Firm PTP Transmission Service rates and calculations
  - Reserved Capacity pricing methodologies

- **Delivery Period Classifications**
  - Yearly, monthly, weekly, daily (on-peak/off-peak), and hourly delivery options
  - Different calculation divisors for each period (e.g., 260 for daily on-peak, 365 for daily off-peak)

- **Rate Adjustments and Credits**
  - Balanced Portfolio Reallocation Adjustment provisions
  - Schedule 7 and 8 revenue crediting mechanisms
  - Attachment AU revenue distribution and allocation

- **Demand Charge Caps**
  - Weekly caps for daily reservations
  - Daily caps for hourly reservations
  - Multi-tiered capping structures

- **Zone-Specific Rate Schedules**
  - Evergy Missouri West, Inc. Zone
  - Grand River Dam Authority Zone
  - Kansas City Board of Public Utilities Zone

---

## 3. Decisions or Actions

- **Rate Publication**: All rates are to be set forth in the RRR File posted on the SPP website
- **Rate Adjustments**: Rates must reflect reallocation adjustments per Section IV.A of Attachment J
- **Revenue Crediting Implementation**: Adjustments for Schedule 7 and 8 revenues to be implemented per Section 34.1(2) of the Tariff
- **Formula Rate Application**: Specific formula rates designated for each transmission owner/zone

---

## 4. Important Dates

No specific dates are mentioned in this content segment. However, the document references:
- Monthly compensation schedules
- Weekly delivery periods
- Daily delivery calculations (260 days for on-peak, 365 days for off-peak)
- Hourly calculations (4,160 hours on-peak, 8,760 hours off-peak annually)

---

## 5. Organizations and People Mentioned

**Organizations:**
- **Evergy Missouri West, Inc.** - Transmission Owner
- **Transource Missouri, LLC** - Transmission Owner in Evergy Missouri West zone
- **Grand River Dam Authority (GRDA)** - Transmission Provider
- **Kansas City Board of Public Utilities (BPU)** - Transmission Provider
- **Southwest Power Pool (SPP)** - Regional Transmission Organization
- **Commission** - Referenced regarding approved rates (likely FERC)

**People:**
None mentioned

---

## 6. Links or References

**Tariff Attachments and Addendums:**
- Attachment T - Point-To-Point rate schedules
- Attachment H, Addendum 10, Parts 1 and 2 - EMe formula rate
- Attachment H, Addendum 11, Parts 1 and 2 - Evergy Missouri West formula rate
- Attachment H, Addendum 21 - Transource Missouri, LLC rate formula and protocols
- Attachment H, Addendum 13 - Grand River Dam Authority formula rate
- Attachment H, Addendum 46 - Kansas City Board of Public Utilities formula rate
- Attachment J, Section IV.A - Balanced Portfolio Reallocation provisions
- Attachment AU - Revenue distribution and allocation
- Section 34.1(2) of Tariff - Revenue crediting implementation

**Files:**
- Revenue Requirements and Rates File (RRR File) - Posted on SPP website
- Specific tabs: "EMW PTP Rate Att T", "GRDA PTP Rate Att T", "BPU PTP Rate Att T"

**Schedules:**
- Schedule 7 and 8 - Revenue schedules

---

## 7. Suggested Tags

- Point-To-Point Transmission
- Transmission Rates
- SPP Tariff
- Firm Transmission Service
- Non-Firm Transmission Service
- Formula Rates
- Reserved Capacity
- Evergy Missouri West
- Grand River Dam Authority
- Kansas City Board of Public Utilities
- Revenue Requirements
- Rate Schedules
- Transmission Pricing
- OATT (Open Access Transmission Tariff)
- Demand Charges

---

## 8. Items That May Need Follow-Up

1. **Rate Calculation Verification**: Confirm all formula rates in referenced Attachment H addendums are current and properly implemented

2. **RRR File Accessibility**: Verify that all referenced tabs in the RRR File are properly posted and accessible on the SPP website

3. **Commission Approval Status**: Confirm current status of Commission-approved rates for Transource Missouri, LLC

4. **Inconsistency in Unit Measurement**: Grand River Dam Authority uses kW/kWh while others use MW - verify if this is intentional or requires harmonization

5. **Revenue Crediting Implementation**: Verify proper implementation of Schedule 7 and 8 revenue adjustments per Section 34.1(2)

6. **Balanced Portfolio Reallocation**: Confirm current reallocation amounts are properly reflected in published rates

7. **Formula Rate Updates**: Track annual or periodic updates to formula rates in all referenced addendums

8. **Transmission Owner Changes**: Monitor for any additions or changes to transmission owners in each zone

9. **Document Continuity**: This is chunk 11 of 27 - review preceding and following chunks for complete context and any cross-references

10. **EMe and INDP Definitions**: Clarify what "EMe" and "INDP" abbreviations represent (referenced but not defined in this segment)

---

# Chunk 12 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document (chunk 12 of 27) is a detailed tariff filing outlining Point-To-Point (PTP) Transmission Service rates and structures for multiple utility organizations within the SPP (Southwest Power Pool) system. It establishes standardized rate methodologies for both Firm and Non-Firm transmission services across different delivery periods (yearly, monthly, weekly, daily, and hourly), with specific provisions for on-peak and off-peak pricing. The document references formula rates contained in Attachment H with various addenda, and directs users to the Revenue Requirements and Rates File (RRR File) posted on the SPP website for current effective rates.

## 2. Key Topics

- **Point-To-Point Transmission Service Rate Structures** for multiple utility zones
- **Firm vs. Non-Firm Transmission Service** pricing methodologies
- **On-Peak and Off-Peak Definitions**: HE 0700-2200 Central Time (excluding Sundays and NERC holidays)
- **Balanced Portfolio Reallocation Adjustments** in accordance with Section IV.A of Attachment J
- **Revenue Crediting Mechanisms** for Schedule 7 and 8 revenues and Attachment AU distributions
- **Demand Charge Caps** for hourly, daily, and weekly reservations
- **Reserved Capacity** measurement and compensation structures
- **Formula Rate References** to various Attachment H Addenda

## 3. Decisions or Actions

- Transmission Customers must compensate Transmission Providers monthly for reserved capacity
- Rates shall be adjusted to reflect reallocations from Zonal Annual Transmission Revenue Requirements
- Rates must reflect adjustments for Schedule 7 and 8 revenues per Section 34.1(2) of the Tariff
- All current rates and adjustments to be posted in the RRR File on the SPP website
- Total demand charges are capped at weekly rates for daily/hourly reservations
- NPPD formula results must be posted by December 15 for January 1 effectiveness
- Tri-State formula results must be posted by June 15 for July 1 effectiveness

## 4. Important Dates

- **December 15** (annually): NPPD formula calculation posting deadline
- **January 1** (following year): NPPD rate effectiveness date
- **June 15** (annually): Tri-State formula calculation posting deadline
- **July 1** (same year): Tri-State rate effectiveness date
- **On-Peak Hours**: HE 0700-2200 (excluding Sundays and holidays)
- **NERC Holidays**: New Year's Day, Memorial Day, Independence Day, Labor Day, Thanksgiving Day, Christmas Day

## 5. Organizations and People Mentioned

### Organizations:
- **Kansas City, Kansas Board of Public Utilities** (Attachment H, Addendum 46)
- **Lincoln Electric System (LES)** (Attachment H, Addendum 6)
- **Midwest Energy, Inc.** (Attachment H, Addendum 14)
- **Nebraska Public Power District (NPPD)** (Attachment H, Addendum 7)
- **Tri-State** (Attachment H, Addendum 36)
- **Central Nebraska Public Power and Irrigation District (CNPPID)**
- **SPP (Southwest Power Pool)** - Transmission Provider
- **NERC (North American Electric Reliability Corporation)**

### People:
None specifically mentioned

## 6. Links or References

### Internal References:
- **Attachment H** (multiple addenda: 6, 7, 14, 36, 46)
- **Attachment J, Section IV.A** (Balanced Portfolio Reallocation)
- **Attachment T** (Point-To-Point Transmission Service rates)
- **Attachment AU** (Revenue distribution and allocation)
- **Section 34.1(2)** of the Tariff (Revenue crediting implementation)

### External Resources:
- **RRR File (Revenue Requirements and Rates File)** - posted on SPP website
- **Specific Rate Tabs**: "LES PTP Rate Att T", "Midwest PTP Rate Att T", "NPPD PTP Rate Att T"
- NPPD website (for formula rate results)
- Tri-State website (for formula rate results)

## 7. Suggested Tags

- Point-To-Point Transmission Service
- Transmission Rates
- SPP Tariff
- Firm Transmission
- Non-Firm Transmission
- Formula Rates
- Revenue Requirements
- Reserved Capacity
- On-Peak/Off-Peak Pricing
- Zonal Rates
- FERC Regulatory
- Transmission Revenue Crediting
- Balanced Portfolio
- Utility Rate Structures

## 8. Items That May Need Follow-Up

1. **Rate Reconciliation**: Verify that all formula rates referenced in Attachment H addenda are current and properly posted on the SPP website
2. **Annual Rate Updates**: Monitor December 15 and June 15 deadlines for NPPD and Tri-State formula postings
3. **CNPPID Rate Verification**: Confirm the specific rates for CNPPID ($128.961/MW annual, $10.747/MW monthly, $2.480/MW weekly) are still current
4. **Demand Charge Caps**: Ensure proper implementation of weekly/daily caps on hourly reservations to prevent customer overcharging
5. **Revenue Crediting Compliance**: Track implementation of Schedule 7 and 8 revenue adjustments per Section 34.1(2)
6. **Balanced Portfolio Adjustments**: Monitor any reallocations from Zonal Annual Transmission Revenue Requirements
7. **RRR File Accessibility**: Verify all rate tabs are properly accessible and updated on SPP website
8. **Off-Peak Hourly Rate Discrepancy**: Note potential typo in Lincoln Electric System Non-Firm section (item 4 shows "per week" instead of "per hour")
9. **Unit Consistency**: Verify consistency between MW and kW usage across different utility zones
10. **Holiday Definition Updates**: Confirm NERC holiday definitions remain current

---

# Chunk 13 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document (chunk 13 of 27) contains detailed tariff rate schedules for Point-to-Point Transmission Service across multiple utility zones within the SPP (Southwest Power Pool) system. It specifies pricing structures for both Firm and Non-Firm transmission services across different delivery timeframes (yearly, monthly, weekly, daily, and hourly) for several utilities including NPPD, CNPPID, Tri-State, Oklahoma Gas and Electric Company (OG&E), Oklahoma Municipal Power Authority, and Omaha Public Power District (OPPD). The content establishes calculation methodologies, rate components, and references to formula rate templates in Attachment H.

## 2. Key Topics

- **Point-to-Point Transmission Service Rates**: Comprehensive rate structures for both Firm and Non-Firm services
- **Formula Rate Templates**: References to specific addenda in Attachment H for various utilities
- **On-Peak vs. Off-Peak Pricing**: Differential rates based on time of use (HE 0700-2200 Central Time, weekdays)
- **Rate Calculation Methodology**: Division factors for different time periods (260 days, 365 days, 4160 hours, 8760 hours)
- **Zonal Annual Transmission Revenue Requirement (ATRR)**: Basis for rate calculations
- **Balanced Portfolio Reallocation Adjustment**: Mechanism for adjusting Point-to-Point rates
- **Revenue Crediting**: Adjustments for Schedule 7 and 8 revenues and Attachment AU allocations
- **Reserved Capacity Charges**: Demand-based pricing structure

## 3. Decisions or Actions

- **Rate Formula Implementation**: OG&E Formula Rate and associated protocols (Attachment H, Addendum 2-A and 2-B) established
- **Multiple Entity Integration**: AECC, PEC, and NEET Southwest formula rates incorporated into OG&E rate zone
- **Specific Rate Amounts Established**:
  - CNPPID monthly: $10.747 per MW
  - CNPPID weekly: $2.480 per MW
  - CNPPID daily on-peak: $0.496 per MW
  - CNPPID daily off-peak: $0.353 per MW
  - CNPPID hourly on-peak: $0.031 per MW
  - CNPPID hourly off-peak: $0.015 per MW
  - Oklahoma Municipal Power Authority rates ranging from $0.0002/kW to $0.0086/MWh

## 4. Important Dates

- **September 1 (annual)**: Existing Zonal ATRR for OG&E to be posted on SPP website
- **January 1 (following year)**: OG&E Zonal ATRR becomes effective
- **July 20 (annual)**: OPPD formula calculation results to be posted on SPP website
- **August 1 (annual)**: OPPD rates become effective
- **Holiday Schedule (NERC-defined)**: New Year's Day, Memorial Day, Independence Day, Labor Day, Thanksgiving Day, Christmas Day

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)** - Regional transmission organization
- **NPPD (Nebraska Public Power District)** - Transmission provider
- **CNPPID (Central Nebraska Public Power and Irrigation District)** - Transmission provider
- **Tri-State** - Transmission provider
- **Oklahoma Gas and Electric Company (OG&E)** - Transmission provider
- **AECC (Arkansas Electric Cooperative Corporation)** - Rate formula participant
- **PEC (People's Electric Cooperative)** - Rate formula participant
- **NEET Southwest (NextEra Energy Transmission Southwest, LLC)** - Rate formula participant
- **Oklahoma Municipal Power Authority** - Service participant
- **OPPD (Omaha Public Power District)** - Transmission provider
- **NERC (North American Electric Reliability Corporation)** - Holiday definition authority

### People:
No specific individuals mentioned in this content.

## 6. Links or References

### Internal Document References:
- **Attachment H**: Contains formula rate templates
  - Addendum 2-A: OG&E Formula Rate
  - Addendum 2-B: OG&E Formula Rate Implementation Protocols
  - Addendum 7: NPPD Formula Rate Template
  - Addendum 8: OPPD Formula-based Rate Template
  - Addendum 38: AECC Formula Rate and protocols
  - Addendum 44: NEET Southwest Formula Rate and protocols
  - Addendum 51: PEC Formula Rate and protocols
- **Attachment J, Section IV.A**: Balanced Portfolio Reallocation provisions
- **Attachment T**: Point-to-Point Transmission Service rates (this attachment)
- **Attachment AU**: Revenue distribution and allocation
- **Section 34.1(2)**: Schedule 7 and 8 revenue adjustments
- **Revenue Requirements and Rates File (RRR File)**: Posted on SPP website
  - "OGE PTP Rate Att T" tab
  - "OPPD PTP Rate Att T" tab

### External References:
- **SPP Website**: Location for RRR File postings and rate information
- **NERC Holiday Definitions**: Standard for holiday scheduling

## 7. Suggested Tags

- Transmission Tariff
- Point-to-Point Service
- Rate Schedule
- Formula Rates
- SPP
- Firm Transmission
- Non-Firm Transmission
- NPPD
- OG&E
- OPPD
- CNPPID
- Reserved Capacity
- On-Peak Rates
- Off-Peak Rates
- Zonal ATRR
- Revenue Requirements
- Attachment H
- Attachment T
- Balanced Portfolio

## 8. Items That May Need Follow-Up

1. **Annual Rate Updates**: Monitor September 1 deadline for OG&E ATRR posting and January 1 effective date
2. **OPPD Rate Updates**: Track July 20 posting deadline and August 1 effective date
3. **RRR File Verification**: Confirm that rates posted in RRR File tabs match tariff specifications
4. **Formula Rate Calculations**: Verify proper implementation of divisors (12-CP, 260 days, 365 days, 4160 hours, 8760 hours)
5. **Multi-Entity Rate Coordination**: Ensure proper integration of AECC, PEC, and NEET Southwest rates into OG&E zone calculations
6. **Revenue Crediting Implementation**: Confirm Schedule 7 and 8 revenue adjustments are properly applied per Section 34.1(2)
7. **Balanced Portfolio Adjustments**: Verify reallocation adjustments are correctly reflected in rates
8. **Peak Definition Consistency**: Ensure HE 0700-2200 Central Time Zone definition is uniformly applied across all rates
9. **Holiday Schedule Updates**: Monitor NERC for any changes to holiday definitions
10. **Rate Cap Verification**: Confirm weekly and daily caps are properly enforced in billing systems
11. **Oklahoma Municipal Power Authority Rates**: Verify separate charge calculations are correctly applied

---

# Chunk 14 Analysis

# STRUCTURED ANALYSIS REPORT
## RR696 SPP Comments - Chunk 14 of 27

---

## 1. Executive Summary

This document section contains detailed tariff rate schedules for Point-To-Point Transmission Service across multiple transmission zones and providers within the SPP (Southwest Power Pool) system. It specifies rate calculation methodologies, delivery charge structures (monthly, weekly, daily, hourly), and revenue crediting mechanisms for both Firm and Non-Firm Point-To-Point Transmission Services. The content covers three primary rate zones: OPPD (Omaha Public Power District), Southwestern Power Administration Zone, and Southwestern Public Service Company (SPS) Zone, each with distinct rate formulas and calculation methods.

---

## 2. Key Topics

- **Point-To-Point Transmission Service Rate Structures**
  - Firm Point-To-Point Transmission Service rates
  - Non-Firm Point-To-Point Transmission Service rates
  - Delivery charge variations (monthly, weekly, daily, hourly)

- **Rate Calculation Methodologies**
  - Formula-based rate templates
  - Revenue Requirements and Rates (RRR) File references
  - Multiple addenda to Attachment H

- **Revenue Crediting and Adjustments**
  - Schedule 7 and 8 revenue adjustments
  - Attachment AU revenue distribution and allocation
  - Balanced Portfolio Reallocation Adjustments

- **Peak/Off-Peak Definitions**
  - On-Peak: Monday-Friday, excluding NERC holidays
  - Off-Peak: All other days
  - Hourly On-Peak: HE 0700-2200 (excluding weekends and holidays)

- **Zone-Specific Rate Structures**
  - OPPD zone rates
  - Southwestern Power Administration zone (including South Central MCN, MEUC, PEC)
  - Southwestern Public Service Company zone (including LCEC)

---

## 3. Decisions or Actions

- **Rate Publication Requirements**: Results of formula calculations must be posted on SPP website and SPS OASIS website by **October 1** of each calendar year

- **Rate Effectiveness**: Posted rates become effective on **January 1** of the following calendar year

- **Compensation Structure**: Transmission Customers must compensate Transmission Providers according to specified rate schedules in the RRR File

- **Demand Charge Caps**:
  - Weekly demand charges cannot exceed weekly rate × highest kW of Reserved Capacity
  - Daily demand charges for hourly delivery cannot exceed daily rate × highest kW in any hour
  - Weekly demand charges for daily/hourly delivery cannot exceed weekly rate × highest kW in any hour

---

## 4. Important Dates

- **October 1** (annually): Deadline for posting formula calculation results on SPP and SPS OASIS websites
- **January 1** (annually): Effective date for new rates (following year after October 1 posting)

**NERC Defined Holidays** (referenced for peak/off-peak definitions):
- New Year's Day
- Memorial Day
- Independence Day
- Labor Day
- Thanksgiving Day
- Christmas Day

---

## 5. Organizations and People Mentioned

### Organizations:

**Transmission Providers/Zones:**
- **OPPD** (Omaha Public Power District)
- **Southwestern Power Administration** ("Southwestern")
- **SPS** (Southwestern Public Service Company)
- **Xcel Energy Operating Companies**

**Additional Service Providers:**
- **South Central MCN LLC** ("South Central MCN")
- **Missouri Joint Municipal Electric Utility Commission** ("MEUC")
- **People's Electric Cooperative** ("PEC")
- **Lea County Electric Cooperative, Inc.** ("LCEC")

**Regulatory/Administrative:**
- **SPP** (Southwest Power Pool)
- **NERC** (North American Electric Reliability Corporation)

### People Mentioned:
None specifically identified in this section.

---

## 6. Links or References

### Attachment References:
- **Attachment T**: Point-To-Point Transmission Service rates
- **Attachment H**: Formula rate addenda
  - Addendum 8: OPPD Formula Rate
  - Addendum 43: South Central MCN Formula Rate
  - Addendum 50: MEUC Formula Rate
  - Addendum 51: PEC Formula Rate
  - Addendum 52: LCEC Formula Rate
- **Attachment J, Section IV.A**: Balanced Portfolio Reallocation provisions
- **Attachment AU**: Revenue distribution and allocation
- **Attachment O - SPS**: Xcel Energy OATT rate formula

### Other References:
- **Section 34.1(2)**: Tariff section governing Schedule 7 and 8 revenue implementation
- **RRR File** (Revenue Requirements and Rates File): Posted on SPP website with specific tabs:
  - "SPA PTP Rate Att T" tab
  - "SPS PTP Rate Att T" tab
- **Xcel Energy OATT** (Open Access Transmission Tariff)

### Website References:
- SPP website (for RRR File posting)
- SPS OASIS website (for rate posting)

---

## 7. Suggested Tags

- Point-To-Point Transmission Service
- Transmission Rates
- Firm Transmission Service
- Non-Firm Transmission Service
- OPPD
- Southwestern Power Administration
- SPS
- Formula Rates
- Revenue Requirements
- Tariff Schedules
- Peak Demand Charges
- RRR File
- Attachment H
- Schedule 7 and 8 Revenues
- Balanced Portfolio Reallocation
- NERC Holidays
- Reserved Capacity
- Transmission Zone Rates

---

## 8. Items That May Need Follow-Up

### Compliance and Filing Requirements:
1. **Annual Rate Posting Verification**: Confirm October 1 deadline compliance for formula calculation results posting to SPP website and SPS OASIS website
2. **Rate Effectiveness Tracking**: Verify January 1 effective dates are properly implemented following October postings

### Rate Calculation Issues:
3. **Formula Rate Updates**: Monitor changes to referenced formula rates in various Addenda (8, 43, 50, 51, 52) to Attachment H
4. **RRR File Accuracy**: Verify accuracy of rate calculations in RRR File tabs for different zones

### Revenue Crediting:
5. **Schedule 7 and 8 Revenue Adjustments**: Track implementation and proper crediting under Section 34.1(2)
6. **Attachment AU Allocations**: Monitor revenue distribution and allocation adjustments
7. **Balanced Portfolio Reallocation**: Verify proper adjustment implementation per Attachment J, Section IV.A

### Multi-Party Rate Structures:
8. **Southwestern Zone Complexity**: Coordinate rate calculations involving multiple parties (Southwestern, South Central MCN, MEUC, PEC)
9. **SPS Zone Coordination**: Track coordination between Xcel Energy OATT and LCEC formula rates

### Operational Clarifications:
10. **Peak Definition Application**: Ensure consistent application of On-Peak/Off-Peak definitions across all zones
11. **Demand Charge Cap Enforcement**: Verify proper implementation of weekly and daily demand charge caps
12. **Reserved Capacity Billing**: Review billing methodology for transmission customers directly connected to Southwestern's system

### Documentation Gaps:
13. **Document Completeness**: This appears to be chunk 14 of 27 - content cuts off mid-sentence regarding "revenues and revenu..." - requires review of complete document
14. **Cross-Reference Validation**: Verify all referenced attachments and sections are current and properly linked

---

# Chunk 15 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary
This document chunk (15 of 27) from RR696 SPP Comments details Point-to-Point (PTP) transmission service rate structures for multiple rate zones within the Southwest Power Pool (SPP) system. The content primarily covers rate calculations for Firm and Non-Firm Point-to-Point Transmission Service across three major zones: Southwestern Public Service Company (SPS), Sunflower Electric Power Corporation, and Upper Missouri Zone (UMZ). All rates reference formula rates contained in the Revenue Requirements and Rates (RRR) File posted on the SPP website and include provisions for portfolio reallocation adjustments and revenue crediting.

## 2. Key Topics
- **Point-to-Point Transmission Service Rate Structures** (Firm and Non-Firm)
- **Rate calculation methodologies** including yearly, monthly, weekly, daily, and hourly delivery rates
- **On-Peak/Off-Peak hour definitions** (HE 0700-2200 Central Time, excluding Sundays and NERC holidays)
- **Zone-specific rate sheets** for SPS, Sunflower Electric, and Upper Missouri Zone
- **Balanced Portfolio Reallocation Adjustments** in accordance with Attachment J
- **Revenue crediting mechanisms** for Schedule 7 and 8 revenues and Attachment AU allocations
- **Formula rate references** contained in various Attachment H addendums
- **Lamar Tie Line discounted rate** (50% discount for service between PSCo and SPS Zone)
- **Capacity reservation billing** based on Reserved Capacity in kilowatts/megawatts

## 3. Decisions or Actions
- **Rate determination**: All rates to be calculated using specific formula rates from Attachment H addendums
- **Revenue crediting implementation**: Adjustments for Schedule 7 and 8 revenues to be applied per Section 34.1(2) of the Tariff
- **Portfolio reallocation**: Rates adjusted according to Section IV.A of Attachment J
- **Lamar Tie Line special pricing**: 50% discount applied for cross-tie service
- **Weekly cap**: Total demand charges limited to weekly rate × highest daily Reserved Capacity
- **Daily cap (Non-Firm)**: Total demand charges limited to daily rate × highest hourly Reserved Capacity

## 4. Important Dates
- **NERC Holidays specified**: New Year's Day, Memorial Day, Independence Day, Labor Day, Thanksgiving Day, Christmas Day
- **On-Peak hours**: HE 0700 to HE 2200 (Central Time Zone)
- **Off-Peak hours**: All hours not designated as On-Peak
- **Filing date reference**: Document dated 20250814 (August 14, 2025)

## 5. Organizations and People Mentioned

### Organizations - Transmission Providers:
- **Southwest Power Pool (SPP)**
- **Southwestern Public Service Company (SPS)**
- **Xcel Energy** (references to Xcel Energy OATT)
- **LCEC** (formula rate provider)
- **Sunflower Electric Power Corporation (SECC)**
- **ITC Great Plains, LLC**
- **Prairie Wind Transmission, LLC**
- **Public Service Company of Colorado (PSCo)**

### Upper Missouri Zone Transmission Owners:
- Basin Electric Power Cooperative
- Heartland Consumers Power District
- Missouri River Energy Services (MRES)
- East River Electric Power Cooperative, Inc.
- Corn Belt Power Cooperative
- NorthWestern Energy Public Service Corporation (NWPS)
- Northwest Iowa Power Cooperative (NIPCO)
- Harlan Municipal Utilities (HMU)
- Western Area Power Administration, Upper Great Plains Region (Western-UGP)
- Central Electric Power Cooperative, Inc.
- Mountrail-Williams Electric Cooperative
- Mor-Gran-Sou Electric Cooperative, Inc.
- Roughrider Electric Cooperative, Inc.
- L and O Power Cooperative (LOPC)

### MRES Members listed:
- Moorhead Public Service
- Orange City Municipal Utilities
- City of Pierre, South Dakota
- City of Sioux Center, Iowa
- Watertown Municipal Utility Department
- Denison Municipal Utilities
- Vermillion Light & Power

### Regulatory Bodies:
- **NERC** (North American Electric Reliability Corporation)
- **Federal Energy Regulatory Commission (FERC)** (implied through "Commission approved rates")

## 6. Links or References

### Internal Tariff References:
- **Attachment H** - Formula rates with multiple addendums (5, 9, 15, 20, 22-35, 37, 40-42, 45, 47, 49)
- **Attachment J, Section IV.A** - Balanced Portfolio Reallocation
- **Attachment O - SPS** (Xcel Energy OATT)
- **Attachment T** - Rate sheets for Point-to-Point Transmission Service
- **Attachment AU** - Revenue distribution and allocation
- **Section 34.1(2)** - Revenue crediting implementation
- **Schedule 7 and 8** - Revenue adjustments

### External References:
- **Revenue Requirements and Rates File (RRR File)** - Posted on SPP website
  - "SPS PTP Rate Att T" tab
  - "SECC PTP Rate Att T" tab
  - "UMZ PTP Rate Att T" tab
- **Xcel Energy OATT** (Open Access Transmission Tariff)

### Geographic References:
- **Lamar Tie Line** (between SPS Zone and PSCo)
- **SPS Zone**
- **Upper Missouri Zone (UMZ)**
- **Central Time Zone**

## 7. Suggested Tags
- Point-to-Point Transmission Service
- Transmission Rates
- SPP Tariff
- Formula Rates
- Revenue Requirements
- Firm Transmission Service
- Non-Firm Transmission Service
- Rate Zones
- SPS Zone
- Upper Missouri Zone
- Sunflower Electric
- On-Peak/Off-Peak Pricing
- Reserved Capacity
- Balanced Portfolio
- Revenue Crediting
- OATT
- RR696

## 8. Items That May Need Follow-Up

### Rate Calculation Verification:
1. **Confirm consistency** of LCEC formula rate calculation methodology across different delivery timeframes
2. **Verify accuracy** of division factors (12 months, 52 weeks, 6 days on-peak, 7 days off-peak, 16 hours on-peak, 24 hours off-peak)
3. **Reconcile** all formula rate addendums referenced in Attachment H are complete and current

### Documentation Completeness:
4. **Confirm RRR File posting** on SPP website is current and accessible
5. **Verify all Attachment H addendums** (particularly numbers 22-35, 37, 40-42, 45, 47, 49) are properly cross-referenced
6. **Check for missing addendum numbers** (e.g., 36, 38, 39, 43, 44, 46, 48) - determine if intentional or error

### Rate Policy Clarifications:
7. **Clarify "opposite direction" service** treatment - confirm if separate charge applies to all rate zones or only specific ones
8. **Validate Lamar Tie Line 50% discount** - ensure proper implementation and qualification criteria
9. **Confirm facility credits** inclusion in UMZ ATRR calculations

### Regulatory Compliance:
10. **Verify NERC holiday list** is current (document states "currently" these holidays)
11. **Confirm Commission approval status** for all UMZ Transmission Owner rates
12. **Review Section 34.1(2)** implementation of revenue crediting adjustments

### Stakeholder Coordination:
13. **Coordinate with all UMZ transmission owners** (14 entities listed) on rate implementation
14. **Verify MRES member utilities** list is complete and current
15. **Confirm portfolio reallocation methodology** with affected parties per Attachment J

---

# Chunk 16 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document chunk (16 of 27) from SPP Comments (dated August 14, 2025) contains detailed transmission service rate calculations and integrated marketplace operational protocols. The content primarily covers Point-to-Point Transmission Service rate structures for the UMZ (Upper Missouri Zone) and WFEC (Western Farmers Electric Cooperative) rate zones, including both firm and non-firm service calculations. Additionally, it includes substantial updates to Attachment AE regarding the Integrated Marketplace, particularly focusing on must-offer requirements, market participant compliance, and Day-Ahead Market execution procedures.

## 2. Key Topics

- **UMZ Point-to-Point Transmission Service Rates**: Formulas for calculating yearly, monthly, weekly, daily, and hourly delivery rates
- **WFEC Rate Zone**: Point-to-Point transmission service rate structures and applicable adjustments
- **Balanced Portfolio Reallocation**: Adjustments to transmission rates based on Zonal Annual Transmission Revenue Requirements
- **Revenue Crediting**: Schedule 7 and 8 revenue adjustments under Attachment AU
- **Must-Offer Requirements**: Market participant compliance obligations for Day-Ahead Market
- **Day-Ahead Market Execution**: SCUC (Security Constrained Unit Commitment) algorithm methodology
- **Meter Agent Functions**: Data submission requirements for load and generation
- **Local Reliability Issues**: Commitments for voltage and reliability conditions

## 3. Decisions or Actions

### Rate Calculations
- UMZ transmission rates to be calculated based on sum of multiple entities' Annual Transmission Revenue Requirements (ATRRs)
- WFEC rates to reflect Balanced Portfolio Reallocation adjustments
- Point-to-Point rates to incorporate Schedule 7 and 8 revenue adjustments

### Market Participant Requirements
- Market Participants must designate Meter Agents and execute Meter Agent Agreement (Attachment AM)
- Compliance with must-offer obligation determined by:
  - 90% threshold of net resource capacity to load ratio
  - Asset Owner-specific hourly assessments
- Non-compliance results in penalties per Section 3.9 of Attachment AF

### Day-Ahead Market Operations
- SCUC algorithm to employ simultaneous co-optimization for resource commitment
- Priority order established for capacity shortage/surplus conditions
- Curtailment procedures defined for non-firm transactions

## 4. Important Dates

- **Operating Day**: Referenced throughout for data submission and market execution timelines
- **August 14, 2025**: Source document date (RR696 SPP Comments)

*Note: Specific implementation dates not provided in this chunk*

## 5. Organizations and People Mentioned

### Transmission Organizations/Entities (UMZ Rate Zone):
- Basin Electric
- Heartland
- MRES (Missouri River Energy Services)
- MRES Members
- East River
- Corn Belt
- NWPS
- NIPCO
- HMU
- Western-UGP
- Central Power
- Mountrail-Williams
- Mor-Gran-Sou
- Roughrider
- LOPC

### WFEC Rate Zone:
- Western Farmers Electric Cooperative (WFEC)
- People's Electric Cooperative (PEC)

### General Entities:
- Transmission Provider (SPP)
- Transmission Customer
- Market Participant
- Asset Owner
- Market Monitor
- Meter Agent

## 6. Links or References

### Internal Document References:
- **Attachment T**: Point-to-Point Transmission Service rates
- **Attachment J, Section IV.A**: Balanced Portfolio Reallocation
- **Attachment AU**: Revenue distribution and allocation
- **Attachment H, Addendum 39**: WFEC Formula Rate and protocols
- **Attachment H, Addendum 51**: PEC Formula Rate and protocols
- **Attachment AE**: Integrated Marketplace provisions
- **Attachment AF, Section 3.9**: Penalty provisions
- **Attachment AM**: Meter Agent Agreement
- **Section 34.1(2)**: Revenue crediting implementation
- **Section 2.2(2)**: Market registration procedures
- **Section 4.1(10)(a), (b), (c)**: Resource commitment status definitions

### External Files:
- **RRR File (Revenue Requirements and Rates File)**: Posted on SPP website
- **Market Protocols**: Timeline specifications for data submission

## 7. Suggested Tags

- Transmission Rates
- Point-to-Point Service
- Day-Ahead Market
- Must-Offer Requirement
- SCUC Algorithm
- Market Compliance
- Revenue Requirements
- UMZ Rate Zone
- WFEC Rate Zone
- Meter Agent
- Resource Commitment
- Operating Reserves
- Market Participant Obligations
- Balanced Portfolio
- Formula Rates
- Integrated Marketplace

## 8. Items That May Need Follow-Up

### Clarification Needed:
1. **Timeline specifications** in Market Protocols for data submission (referenced but not detailed)
2. **Specific penalty amounts** under Section 3.9 of Attachment AF for must-offer non-compliance
3. **Definition of "qualified entity"** for Meter Agent designation
4. **Emergency capacity limits** - specific thresholds and triggering conditions
5. **90% compliance threshold** - rationale and supporting analysis for this specific percentage

### Coordination Requirements:
6. **Multi-entity rate coordination** - Process for aggregating 15+ entities' ATRRs in UMZ
7. **Meter Agent Agreement execution** - Timeline and process for entities not yet compliant
8. **Market Monitor responsibilities** - Detailed monitoring procedures and reporting requirements

### Implementation Questions:
9. **RRR File posting frequency** - Update schedule and notification procedures
10. **Self-Charging MSR de-commitment** - Operational procedures and notice requirements
11. **Non-firm transaction curtailment** - Customer notification and compensation procedures
12. **Resource designation changes** - Process for switching between economic and reliability-only use

### Regulatory/Compliance:
13. **Commission approval status** - Verification that all referenced formula rates have current FERC approval
14. **Tariff consistency** - Cross-reference with other SPP tariff sections for conflicts
15. **Market Protocol updates** - Alignment with these tariff provisions

---

# Chunk 17 Analysis

# Regulatory Analysis Report
**Source: RR696 SPP Comments 20250814.docx.txt - Chunk 17 of 27**

---

## 1. Executive Summary

This document section contains detailed regulatory language governing the Day-Ahead Market operations and Day-Ahead Reliability Unit Commitment (RUC) processes within SPP's market structure. The content primarily addresses procedures for manual resource commitments and decommitments by the Transmission Provider when algorithmic solutions cannot address transmission system security constraints or local reliability issues. Key themes include non-discriminatory resource selection, Market Monitor verification requirements, cost minimization principles, and differentiated cost recovery mechanisms (regional vs. local) based on the nature of the reliability issue being addressed.

---

## 2. Key Topics

- **Day-Ahead Market SCUC and SCED Operations**
  - Security-Constrained Unit Commitment (SCUC) algorithm functionality
  - Security-Constrained Economic Dispatch (SCED) algorithm implementation
  - Emergency capacity limit incorporation
  - Co-optimization logic for Operating Reserve

- **Manual Commitment Authority**
  - Transmission Provider's authority as Reliability Coordinator
  - Manual resource commitment/decommitment procedures
  - Non-discriminatory selection requirements
  - Market Monitor verification process (Section 6.1.2.1)

- **Local Reliability Issues and Emergency Conditions**
  - Distinction between transmission system-wide and local reliability issues
  - Local transmission operator coordination and request processes
  - Local Emergency Condition handling
  - Operating guides development for known/recurring issues

- **Cost Recovery Mechanisms**
  - Regional cost allocation for transmission system security constraints
  - Local cost allocation for Local Reliability Issues
  - Compensation eligibility for manually committed resources
  - References to Sections 8.5.9, 8.5.10, 8.6.5, 8.6.7(A), and 8.6.44

- **Day-Ahead Reliability Unit Commitment (RUC)**
  - Capacity adequacy analysis procedures
  - Priority order for addressing capacity shortages and surpluses
  - Curtailment procedures for Export/Import Interchange Transactions
  - Resource eligibility criteria (reliability-only vs. economic use)

- **Virtual Resource Limits (VRLs)**
  - Application in SCED when Shadow Price exceeds VRL thresholds
  - Constraint enforcement feasibility considerations

- **Multi-Configuration Resources (MCRs)**
  - Transition State Time restrictions (>30 minutes)
  - Operating Reserve eligibility limitations during configuration transitions
  - Regulation Service eligibility during transitions

---

## 3. Decisions or Actions

**Established Procedures:**

1. **Manual Commitment Protocol**: Transmission Provider may manually commit/decommit resources when SCUC algorithm cannot directly address security constraints

2. **Market Monitor Verification**: All manual commitments must be verified by Market Monitor through Section 6.1.2.1 process to ensure non-discriminatory treatment

3. **SCUC Re-run Requirement**: Transmission Provider will re-run Day-Ahead SCUC algorithm after manual commitments (time permitting) if not included in initial run

4. **Operating Guides Development**: Transmission Provider, local transmission operators, and Resource owners will develop operating guides for manual commitments addressing known/recurring Local Reliability Issues

5. **Priority Order for Capacity Shortages** (in sequence):
   - Curtail non-firm fixed Export Interchange Transaction Bids
   - Incorporate emergency capacity limits
   - Commit reliability-only resources
   - De-commit Day-Ahead Market charging resources
   - De-commit self-committed charging resources

6. **Priority Order for Capacity Surplus** (in sequence):
   - Curtail non-firm fixed Import Interchange Transaction Offers
   - Incorporate minimum emergency capacity limits
   - Commit available reliability resources capable of charging
   - De-commit Transmission Provider-committed non-self-committed resources
   - De-commit self-committed resources

---

## 4. Important Dates

- **Operating Day**: Referenced throughout as the target day for Day-Ahead Market and Day-Ahead RUC processes
- **30-minute threshold**: MCRs with Transition State Time >30 minutes are ineligible to clear Operating Reserve during transition hours

*No specific calendar dates mentioned in this section*

---

## 5. Organizations and People Mentioned

**Organizations:**

- **Transmission Provider** (primary decision-making entity; also serves as Reliability Coordinator)
- **Market Monitor** (verification and oversight role)
- **Local Transmission Operators** (coordinate with Transmission Provider on Local Reliability Issues)
- **Resource Owners** (develop operating guides with Transmission Provider)
- **Market Participants** (notified of manual commitments)

**Roles Referenced:**
- Reliability Coordinator (authority role of Transmission Provider)

*No individual persons named in this section*

---

## 6. Links or References

**Internal Document References:**

- Section 3.3.1 of Attachment AE (SCED algorithm description)
- Section 4.1(10)(b) of Attachment AE (market commitment status)
- Section 4.1(10)(c) of Attachment AE (reliability-only use designation)
- Section 6.1.2.1 of Attachment AE (Market Monitor verification process)
- Section 8.3.2 of Attachment AE (VRL application in SCED)
- Section 8.5.9 of Attachment AE (compensation for Day-Ahead Market commitments)
- Section 8.5.10 of Attachment AE (regional cost recovery for Day-Ahead Market)
- Section 8.6.5 of Attachment AE (compensation for Day-Ahead RUC commitments)
- Section 8.6.7(A) of Attachment AE (regional cost recovery for Day-Ahead RUC)
- Section 8.6.44 of Attachment AE (local cost recovery mechanism)

**External References:**
- None identified in this section

---

## 7. Suggested Tags

`Day-Ahead Market` `SCUC` `SCED` `Reliability Unit Commitment` `Manual Commitment` `Local Reliability Issues` `Transmission Provider` `Market Monitor` `Cost Recovery` `Operating Reserve` `Resource Commitment` `Emergency Capacity` `Reliability Coordinator` `Non-Discriminatory` `Market Operations` `SPP` `Attachment AE` `Virtual Resource Limits` `MCR` `Interchange Transactions` `Capacity Adequacy` `Operating Guides` `Regional Allocation` `Local Allocation`

---

## 8. Items That May Need Follow-Up

### **Clarification Needed:**

1. **Market Monitor Verification Process**: Section 6.1.2.1 is repeatedly referenced but not detailed in this chunk—requires review to understand verification criteria and timeline

2. **Cost Recovery Differentiation**: The distinction between regional (Sections 8.5.10, 8.6.7(A)) and local (Section 8.6.44) cost allocation methods needs clarification regarding:
   - Specific cost allocation formulas
   - Stakeholder burden distribution
   - Dispute resolution mechanisms

3. **"Time Permitting" Specification**: The SCUC re-run provision includes "time permitting" qualifier—need operational definition of time constraints and prioritization criteria

4. **Operating Guides Development**: Process, timeline, and approval authority for developing operating guides between Transmission Provider, local operators, and Resource owners requires elaboration

### **Potential Policy Issues:**

5. **Self-Committed Resource Decommitment Authority**: The authority to decommit self-committed resources (both in shortage and surplus scenarios) may raise market participant concerns about reliability and contractual obligations

6. **Non-Discriminatory Selection Criteria**: While non-discriminatory selection is mandated, the specific criteria and methodology for manual commitment selection should be explicitly defined to ensure transparency

7. **Local vs. System-Wide Reliability**: The distinction between issues requiring local vs. regional cost recovery may be subject to interpretation disputes—need clear jurisdictional criteria

### **Coordination Requirements:**

8. **Notification Requirements**: Section (e) mentions notifying Market Participants of manual commitments but lacks detail on:
   - Notification timing requirements
   - Information to be disclosed
   - Communication channels

9. **Local Transmission Operator Interface**: The process for local transmission operators to request manual commitments needs operational procedure documentation

10. **MCR Transition State Management**: Coordination between MCR configuration transitions and market clearing processes requires operational protocols to prevent eligibility conflicts

### **Documentation Gaps:**

11. **

---

# Chunk 18 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document is a chunk from SPP (Southwest Power Pool) regulatory filing RR696, containing detailed technical specifications for Intra-Day Reliability Unit Commitment (RUC) processes and the Delivery Point Assessment Process. The content describes operational procedures for resource commitment, managing local reliability issues, and protocols for requesting changes to delivery point facilities. The material appears to be amendments to Attachment AE and Attachment AQ of SPP's regulatory framework.

## 2. Key Topics

- **Intra-Day Reliability Unit Commitment (RUC) Execution**: Procedures for capacity adequacy analysis using SCUC algorithm
- **Resource Commitment Optimization**: Minimization of commitment costs while maintaining system security
- **Local Reliability Issues**: Protocols for manual commitment/decommitment during local reliability events
- **Emergency Procedures**: Prioritized actions during capacity shortages and surpluses
- **Delivery Point Assessment Process (Attachment AQ)**: Procedures for modifying, upgrading, or establishing delivery points
- **Load Connection Studies**: Requirements and processes for delivery point changes
- **Cost Recovery Mechanisms**: Regional vs. local collection methodologies (Sections 8.6.7(A) and 8.6.44)

## 3. Decisions or Actions

**Capacity Shortage Response (Priority Order)**:
1. Curtail non-firm fixed Export Interchange Transaction Bids
2. Incorporate capacity up to Maximum Emergency Limits and/or commit reliability-only Resources
3. De-commit market-committed charging Resources from Day-Ahead Market
4. De-commit self-committed charging Resources

**Capacity Surplus Response (Priority Order)**:
1. Curtail non-firm fixed Import Interchange Transaction Offers
2. Incorporate capacity down to Minimum Emergency Limits
3. De-commit Resources committed by Transmission Provider (non-self-committed)
4. De-commit self-committed Resources

**Manual Commitments**: 
- Must be non-discriminatory (verified by Market Monitor per Section 6.1.2.1)
- Local transmission operators may issue instructions during Local Emergency Conditions when time doesn't permit Transmission Provider action

## 4. Important Dates

- **10 Business Days**: Host Transmission Owner response time for delivery point change requests
- **Operating Day**: Timeframe for Intra-Day RUC processes
- No specific calendar dates mentioned in this chunk

## 5. Organizations and People Mentioned

**Organizations:**
- **Transmission Provider** (SPP)
- **Host Transmission Owner**
- **Market Monitor**
- **Transmission Customer**
- **Local transmission operator**
- **Resource owners**

**Roles Referenced:**
- Market participants (undefined affiliations)
- Resource owners potentially affiliated with local transmission operators

## 6. Links or References

**Internal Cross-References:**
- Section 8.6.44 (local cost recovery)
- Section 8.6.7(A) (regional cost recovery)
- Section 8.6.5 (compensation mechanisms)
- Section 6.1.1 (SCUC inputs)
- Section 6.1.2.1 (Market Monitor verification process)
- Section 4.1(10)(b) (commitment status definitions)
- Section 4.1(10)(c) (reliability-only Resources)
- Section 20 of Network Operating Agreement
- Section 8 of Point to Point Transmission Service Agreement

**Referenced Attachments:**
- Attachment AE (RUC procedures)
- Attachment AQ (Delivery Point Assessment)
- Addendum 1 (Sample Request for Change in Local Delivery Facilities)

## 7. Suggested Tags

- Reliability Unit Commitment
- SCUC Algorithm
- Resource Commitment
- Local Reliability Issues
- Emergency Procedures
- Delivery Point Assessment
- Load Connection Study
- Cost Recovery
- Market Monitor
- Transmission System
- SPP RR696
- Operating Reserves
- Manual Commitment
- Capacity Adequacy

## 8. Items That May Need Follow-Up

1. **Market Monitor Verification Process**: Section 6.1.2.1 referenced multiple times but not detailed in this chunk—need full process documentation

2. **Affiliate Rules**: Potential compensation denial for Resources affiliated with local transmission operators when selected in discriminatory manner—requires clarification on affiliation definitions

3. **Operating Guides Development**: Section 6.1.2(4)(e) requires development of operating guides for recurring Local Reliability Issues—status and timeline unclear

4. **Load Connection Study Costs**: Actual cost commitment with potential $25,000 advance deposit—need verification of cost recovery procedures

5. **Exempted Delivery Point Changes**: Three criteria listed that don't require Attachment AQ process—may need clarification on interpretation and verification procedures

6. **Study Coordination**: Distinction between when Transmission Provider vs. Host Transmission Owner coordinates studies (based on DPNS requirement in Section 3.2)—Section 3.2 not included in this chunk

7. **Local vs. Regional Cost Recovery**: Multiple references to different recovery mechanisms (8.6.7(A) vs 8.6.44)—need complete cost allocation methodology

8. **MCR Regulation Restrictions**: Multi-Configuration Resources (MCRs) ineligible for Regulation services during configuration transitions—operational impacts need assessment

---

# Chunk 19 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary

This document chunk contains portions of a Southwest Power Pool (SPP) regulatory tariff covering two key processes: the Delivery Point Assessment Process (Attachment AQ) and the Provisional Load Process (Attachment AX). The content establishes detailed procedures for transmission customers requesting changes to local delivery facilities, including timelines for studies, deposit requirements, cost reimbursement procedures, and responsibilities of various parties. The procedures outline systematic approaches for assessing impacts on the transmission system when customers need to modify delivery points or add load without adequate designated resources.

## 2. Key Topics

- **Load Connection Study (LCS) Process**: Requirements for executing LCS agreements, deposits, and timelines for completion
- **Transmission System Study**: Preliminary assessment procedures for delivery point configuration changes
- **Delivery Point Network Study (DPNS)**: Detailed process for assessing significant transmission system impacts
- **Study Timelines and Deadlines**: 30-day execution periods, 60-day study completion requirements
- **Financial Requirements**: Deposit structures ($10,000 or estimated cost), reimbursement procedures, and interest calculations
- **Integrated Transmission Planning Assessment**: Evaluation process for network upgrades
- **Engineering and Construction Responsibilities**: Party responsibilities for new facilities
- **Provisional Load Process**: Procedures for increased load without adequate designated resources
- **Study Request Modifications**: Procedures for changing plans during studies

## 3. Decisions or Actions

- **LCS Agreement**: Transmission Customer must execute within 30 calendar days or request is deemed withdrawn
- **Deposit Requirements**: Transmission Customer must provide required deposit with executed agreement
- **Preliminary Assessment**: Transmission Provider must complete within 10 business days (extendable to 20 business days)
- **Monthly Posting**: SPP posts all requests receiving preliminary assessment by the 20th day of each month
- **DPNS Delivery**: Must be delivered within 5 business days of preliminary assessment results
- **Study Completion**: Host Transmission Owner/Transmission Provider must complete studies within 60 calendar days
- **Reimbursement**: Transmission Customer must reimburse unpaid study costs if costs exceed deposit
- **DPNS Report Posting**: Posted on SPP website after notification from Transmission Customer
- **Network Upgrades**: Subject to evaluation in soonest available Integrated Transmission Planning Assessment

## 4. Important Dates

- **30 Calendar Days**: Deadline for executing LCS and DPNS agreements after receipt
- **60 Calendar Days**: Study completion deadline after receipt of executed agreement and deposit
- **10 Business Days**: Preliminary assessment notification deadline
- **20 Business Days**: Extended deadline if request contains elements beyond Attachment AQ scope
- **5 Business Days**: Deadline to deliver DPNS Agreement after preliminary assessment
- **20th Day of Each Month**: Monthly posting deadline for requests receiving preliminary assessment

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)**: Transmission Provider
- **Host Transmission Owner**: Owner of transmission system portion for connection/modification
- **Transmission Customer**: Entity requesting delivery point changes

### Roles Referenced:
- Transmission Provider
- Host Transmission Owner
- Transmission Customer
- Representative of Transmission Customer (signature authority)

## 6. Links or References

### Legal/Regulatory References:
- **18 C.F.R. § 35.19a(a)(2)**: Interest calculation methodology
- **Attachment AQ**: Delivery Point Assessment Process
- **Attachment AX**: Provisional Load Process
- **Section 20 of the Network Operating Agreement**
- **Section 8 of the Point-to-Point Transmission Service Agreement**
- **SPP Business Practices**: Standardized project timelines

### Process References:
- Addendum 1 to Attachment AQ: Sample Request for Change in Local Delivery Facilities
- Addendum 1 to Attachment AX: Sample Request for Provisional Load Process
- OASIS (Open Access Same-Time Information System)
- SPP website for posting reports

## 7. Suggested Tags

- Transmission Planning
- Delivery Point Assessment
- Load Connection Study
- Network Study
- SPP Tariff
- Transmission Service Agreement
- Study Procedures
- Deposit Requirements
- Network Upgrades
- Integrated Transmission Planning
- Provisional Load Process
- Local Delivery Facilities
- DPNS (Delivery Point Network Study)
- LCS (Load Connection Study)
- Regulatory Compliance

## 8. Items That May Need Follow-Up

1. **Study Timeline Extensions**: Procedures allow mutual agreement for extensions beyond standard deadlines - tracking mechanism needed
2. **Interest-Bearing Account Verification**: Confirmation that Host Transmission Owner maintains proper interest-bearing accounts for deposits per 18 C.F.R. § 35.19a(a)(2)
3. **Monthly Posting Compliance**: Verification that SPP consistently posts preliminary assessments by the 20th of each month
4. **Scope Determination**: Clarity needed on what constitutes "elements beyond the scope of Attachment AQ process" for 10-day extension eligibility
5. **Network Upgrade Timing**: Coordination between DPNS-identified network upgrades and Integrated Transmission Planning Assessment scheduling
6. **Incomplete Study Reporting**: Procedures for delays and revised completion dates require documentation
7. **Cost Estimation Accuracy**: Monitoring of estimated vs. actual study costs to ensure $10,000 deposit threshold appropriateness
8. **Withdrawal Procedures**: Tracking of withdrawn requests and any pattern analysis
9. **PLPS Agreement Template**: Verification that current OASIS version matches tariff requirements
10. **Restudy Cost Recovery**: Tracking mechanism for restudies conducted per Section 3.3 modifications
11. **Technical Specification Completeness**: Ensuring transmission customers provide all required information in Addendum 1 format
12. **GPS Coordinate Accuracy**: Verification procedures for location data provided in delivery point requests

---

**Note**: This analysis covers chunk 19 of 27 from document RR696 SPP Comments 20250814.docx.txt. Content appears to be mid-section, with Attachment AX beginning but incomplete at the end of this chunk.

---

# Chunk 20 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary

This document chunk contains portions of SPP's (Southwest Power Pool) tariff and market protocols, specifically covering:
- **Provisional Load Process (Attachment AX)**: Detailed procedures for transmission customers requesting delivery point modifications, including study requirements, timelines, and cost responsibilities
- **Market Protocols**: Requirements for non-conforming load forecasting and must-offer obligations for market participants

The content establishes technical and procedural requirements for transmission system modifications and market participation, with specific focus on study processes, responsibilities, and reporting timelines.

## 2. Key Topics

1. **Load Connection Studies (LCS)**
   - Study agreements and deposit requirements ($25,000 or estimated cost, whichever is less)
   - 90-day completion timeline for Load Connection Reports
   - Feasibility assessments using power flow and short circuit analyses

2. **Transmission System Studies (PLPS - Provisional Load Process Study)**
   - Initial impact assessments on transmission system
   - 90-day study report delivery timeline
   - One-year validity period for study results

3. **Study Modifications and Postings**
   - Process for modifying study requests during studies
   - Posting requirements for PLPS reports identifying Network Upgrades

4. **Non-Conforming Load Requirements**
   - Hourly load forecast submission requirements
   - Day-Ahead RUC process timelines
   - 15-minute rolling forecast submissions

5. **Must-Offer Requirements**
   - Market participant obligations for Day-Ahead Market, RUC, and RTBM

## 3. Decisions or Actions

**Required Actions by Transmission Customers:**
- Return executed LCS agreement within 30 calendar days with required deposit
- Reimburse study costs upon completion
- Submit 10-year load forecasts and one-line diagrams with requests

**Required Actions by Host Transmission Owner:**
- Respond to requests within 10 business days
- Complete LCS within 90 calendar days
- Refund excess deposits with interest per 18 C.F.R. § 35.19a(a)(2)

**Required Actions by Transmission Provider:**
- Complete PLPS and issue reports within 90 calendar days
- Post PLPS reports on SPP website when Network Upgrades identified
- Notify customers if additional study time needed

**Required Actions by Market Participants:**
- Submit hourly Non-Conforming Load forecasts before Day-Ahead RUC
- Submit 15-minute rolling forecasts
- Comply with must-offer requirements

## 4. Important Dates

**Recurring Timeframes:**
- **10 Business Days**: Host Transmission Owner response time to study requests
- **30 Calendar Days**: Deadline for Transmission Customer to return executed LCS agreement
- **90 Calendar Days**: Standard completion time for both LCS and PLPS studies
- **1 Year**: Validity period for PLPS results after issuance
- **30 Minutes**: Deadline before Operating Hour for Non-Conforming Load forecast updates
- **15 Minutes**: Rolling forecast submission requirement for Non-Conforming Load

**Process Milestones:**
- Scoping call agreement on study assumptions
- Day-Ahead RUC process initiation
- Operating Day and 6 days following submission window

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)**: Transmission Provider and market operator
- **Host Transmission Owner**: Entity owning transmission facilities at delivery points
- **Transmission Customer**: Entity requesting delivery point changes
- **Market Participants**: Entities participating in SPP markets
- **Asset Owners**: Associated with registered loads

**Roles Identified:**
- Transmission Provider
- Host Transmission Owner
- Transmission Customer
- Market Participant
- Requestor Contact (specified in sample form)

## 6. Links or References

**Regulatory References:**
- **18 C.F.R. § 35.19a(a)(2)**: Interest calculation methodology for deposit refunds
- **Attachment AX**: Provisional Load Process procedures
- **Addendum 1 to Attachment AX**: Sample Request for Provisional Load Process
- **Addendum 2 and Addendum 3 of Attachment AX**: Provisional Load Process Agreements
- **Section 2**: Studies procedures
- **Section 6.2.2**: Non-Conforming Load description
- **Section 4.2.1**: Must-Offer Requirement
- **Section 4.2.1.1**: Day-Ahead Market requirements
- **Section 6.3, 8.2, 8.3**: Referenced but not detailed in chunk

**Technical References:**
- Power flow analyses
- Short circuit analyses
- Dynamics analyses
- Idev modeling files
- DYR modeling files

## 7. Suggested Tags

- Provisional Load Process
- Transmission Studies
- Load Connection Study
- PLPS
- Network Upgrades
- Delivery Point Modification
- Study Agreements
- Market Protocols
- Non-Conforming Load
- Must-Offer Requirement
- Day-Ahead Market
- RUC (Reliability Unit Commitment)
- RTBM (Real-Time Balancing Market)
- SPP Tariff
- Cost Allocation
- Study Timelines
- Forecasting Requirements

## 8. Items That May Need Follow-Up

**Process Clarifications:**
1. What constitutes "significant impact on the Transmission System" triggering full PLPS vs. initial assessment only?
2. Criteria for when study modifications are "not unreasonably withheld"
3. Definition and thresholds for "available Resources" under must-offer requirements
4. Incomplete section 4.2.1.1 - appears cut off mid-sentence ("based on the fol...")

**Procedural Questions:**
5. Process if Transmission Customer doesn't reimburse study costs after completion
6. Dispute resolution mechanism for study cost disagreements
7. Penalties for failure to meet Non-Conforming Load forecast submission requirements
8. What happens if 90-day study deadline cannot be met - are there automatic extensions?

**Technical Clarifications:**
9. Specific criteria differentiating "Conforming" vs. "Non-Conforming" Load
10. ESR (Energy Storage Resource) registration requirements and MSR definition
11. Interpolation methodology when 15-minute forecasts unavailable
12. Network Resource vs. Energy Resource Interconnection Service distinctions

**Documentation Issues:**
13. Multiple instances of "must" appearing without context (possible formatting errors)
14. Reference to "Reserved" section - clarification needed
15. "wi" notations appearing to be formatting artifacts

---

# Chunk 21 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document chunk contains detailed technical specifications from SPP's (Southwest Power Pool) market rules and procedures, specifically focusing on must-offer obligations for market participants, Day-Ahead (DA) Market execution processes, and resource commitment protocols. The content outlines calculation methodologies for reported load, operating reserve obligations, net resource capacity, compliance requirements, and the Security Constrained Unit Commitment (SCUC) and Security Constrained Economic Dispatch (SCED) algorithms used in market clearing. Key emphasis is placed on handling bilateral contracts, firm power transactions, resource commitments, and procedures for addressing reliability issues and capacity shortages/surpluses.

## 2. Key Topics

- **Must-Offer Obligations**: Requirements for Market Participants to offer available resources based on Asset Owner load and operating reserve obligations
- **Load Calculations**: Maximum hourly Reported Load methodology, including adjustments for bilateral contracts and Multi-Configuration Resources (MSR) Self-Charging
- **Operating Reserve Requirements**: Sum of Regulation-Up/Down Service, Contingency Reserve, Ramp Capability Up/Down, and Uncertainty Reserve
- **Net Resource Capacity**: Calculation including offered capacity, firm power purchases/sales, and Jointly Owned Unit (JOU) shares
- **Compliance Thresholds**: 90% net resource capacity requirement for must-offer compliance
- **Day-Ahead Market Execution**: SCUC and SCED simultaneous co-optimization methodology
- **Resource Commitment Statuses**: Market, Self, Reliability, and Not Participating designations
- **Emergency Procedures**: Capacity shortage and surplus management protocols
- **Local Reliability Issues**: Out-of-merit commitment/decommitment procedures
- **GFA Carve Out Requirements**: Resource offering obligations for Generation Forced Availability

## 3. Decisions or Actions

- **Market Monitor Verification**: Must verify firm power purchases and sales upon request with supporting documentation
- **Market Participant Reporting**: Option to input firm power transaction information into Market Monitor website
- **Counterparty Confirmation**: Market Monitor may confirm transactions with counterparties; disputed transactions excluded from calculations
- **Compliance Assessment**: Market Monitor monitors load, operating reserve, offered resources, and net resource capacity hourly
- **Penalty Assessment**: Non-compliant Market Participants assessed penalties per Section 4.2.1.1.1
- **Manual Commitments**: SPP may manually commit/decommit resources for transmission system security constraints
- **Non-Discriminatory Selection**: SPP must select manual commitments in non-discriminatory manner, verified by Market Monitor (Section 6.1.2.1)
- **Priority Order Actions**: 
  - Capacity shortage: (1) Curtail non-firm exports, (2) Use emergency limits/commit reliability resources
  - Capacity surplus: (1) Curtail non-firm imports, (2) Use emergency limits/commit MSR charging

## 4. Important Dates

- **Operating Day**: Referenced throughout as the timeframe for compliance measurement and market execution
- **Upcoming Operating Day**: Day-Ahead Market clears for each hour of the upcoming Operating Day
- No specific calendar dates mentioned in this chunk

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)**: Market operator and Reliability Coordinator
- **Market Monitor**: Oversight and compliance verification entity
- **Market Participants**: Load-serving entities and resource owners
- **Asset Owners**: Entities owning load and generation assets
- **Local Transmission Operators**: Request reliability-related resource commitments

### People:
- No specific individuals mentioned

## 6. Links or References

### Internal Cross-References:
- Section 6.2.8 (bilateral contract load registration)
- Section 4.1.3(4) (Operating Reserve obligation calculations)
- Section 4.2.1.1 (must-offer obligation)
- Section 4.2.1.1.1 (penalty assessment)
- Section 4.2.2.5.4 (JOU Individual Resource Option)
- Section 6.1.14 (Combined Interest Resource modeling)
- Section 6.1.7.1 (MCR registration options)
- Section 4.5.9.12 (resource commitment compensation)
- Section 4.5.9.13 (regional cost recovery)
- Section 4.5.8.12 (local reliability compensation)
- Section 4.5.9.10(1) (local cost recovery)
- Section 6.1.2.1 of Attachment AE to the Tariff (Market Monitor verification process)

### External References:
- **Firm Point-To-Point Transmission Service**: Referenced as comparable service standard
- **Firm Network Integration Transmission Service**: Referenced as comparable service standard

## 7. Suggested Tags

- Day-Ahead Market
- Must-Offer Obligation
- Resource Commitment
- Market Compliance
- Operating Reserves
- SCUC Algorithm
- SCED Algorithm
- Capacity Shortage
- Reliability Commitment
- Market Monitor
- Firm Power Transactions
- Bilateral Contracts
- GFA Carve Out
- Local Reliability Issues
- Emergency Capacity
- Net Resource Capacity
- Multi-Configuration Resources
- SPP Market Rules

## 8. Items That May Need Follow-Up

1. **Penalty Structure**: Section 4.2.1.1.1 referenced for penalty assessments but details not included in this chunk
2. **Market Monitor Website**: Functionality and access requirements for Market Participants to input firm power transaction data
3. **Dispute Resolution**: Process for resolving counterparty disputes on firm power transactions
4. **90% Compliance Threshold**: Rationale and historical basis for the 90% net resource capacity threshold
5. **Manual Commitment Selection**: Detailed methodology for SPP's "non-discriminatory manner" selection process
6. **Cost Minimization**: Specific algorithms or criteria used to minimize commitment costs during manual interventions
7. **Local vs. Regional Cost Recovery**: Distinction criteria and allocation methodologies (Sections 4.5.9.13 and 4.5.9.10(1))
8. **Operating Parameter Development**: Incomplete sentence at end regarding SPP, local transmission operator, and Resource owner collaboration
9. **Emergency Limits Usage**: Frequency and conditions triggering Maximum/Minimum Emergency Capacity Operating Limits
10. **GFA Carve Out Verification**: Monitoring and enforcement of sufficient capacity coverage requirements
11. **MCR Transition Restrictions**: Impact of configuration transitions on regulation service eligibility
12. **Multi-Day Reliability Assessment**: Integration with Day-Ahead Market commitment decisions

---

# Chunk 22 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document section (chunk 22 of 27) from RR696 SPP Comments describes detailed operational procedures for SPP's Day-Ahead Market, Day-Ahead Reliability Unit Commitment (RUC), and Intra-Day RUC processes. The content outlines the Security Constrained Unit Commitment (SCUC) and Security Constrained Economic Dispatch (SCED) algorithms used for resource commitment and dispatch, including protocols for manual interventions, local reliability issues, and compensation mechanisms. Key focus areas include resource optimization, transmission constraint management, operating reserve requirements, and Multi-Configuration Resources (MCRs) with transition times exceeding 30 minutes.

## 2. Key Topics

- **Day-Ahead Market SCUC/SCED Algorithm Execution**
  - Resource commitment and clearing processes
  - Marginal loss sensitivity factors in SCED
  - Co-optimization of Energy and Operating Reserve
  - Violation Relaxation Limits (VRLs) application

- **Manual Commitment Procedures**
  - Local Reliability Issues addressing
  - Non-discriminatory selection process
  - Operating guides development
  - Cost recovery mechanisms (local vs. regional)

- **Resource Eligibility and Limitations**
  - MCRs with transition times >30 minutes excluded from Contingency Reserve and regulation during configuration transitions
  - Commit Status categories: Market, Self, Reliability

- **RUC Capacity Adequacy Analysis**
  - Day-Ahead and Intra-Day RUC execution
  - Priority order for addressing capacity shortages/surpluses
  - Emergency capacity limits utilization

- **Compensation and Cost Recovery**
  - Section 4.5.9.8, 4.5.9.10, 4.5.9.12 referenced for payment mechanisms
  - Local vs. regional cost allocation

## 3. Decisions or Actions

- **Manual Commitment Protocol**: SPP may manually commit/de-commit Resources for transmission reliability issues not addressed by SCUC algorithm
- **Local Transmission Operator Requests**: SPP will issue commitment instructions at local operator request for Local Reliability Issues
- **Re-run Requirements**: SPP will re-run Day-Ahead SCUC after manual commitments (time permitting)
- **Market Participant Notification**: Required when units are manually committed
- **Operating Guides Development**: SPP, local transmission operators, and Resource owners shall develop operating guides for manual commitments addressing recurring Local Reliability Issues
- **RUC Operator Discretion**: Day-Ahead and Intra-Day RUC Operators determine which advisory options to act upon and timing

## 4. Important Dates

No specific dates mentioned in this content section.

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)** - Market operator and Reliability Coordinator
- **Market Participants** - General reference to market entities
- **Market Monitor** - Oversight role referenced in Section 6.1.2.1
- **Local transmission operators** - Regional transmission entities

**People:**
- SPP Operators
- Day-Ahead RUC Operators
- Intra-Day RUC Operators
- Resource owners

## 6. Links or References

**Internal Document References:**
- Section 3.1.1 - Resource operating constraints and transmission constraints
- Section 4.1.3.3 - VRLs in SCED
- Section 4.5.9.8 - Compensation for RUC commitments
- Section 4.5.9.10 - Cost recovery mechanisms
- Section 4.5.9.10(1) - Local cost collection
- Section 4.5.9.12 - Day-Ahead Market commitment compensation
- Section 6.1.2.1 of Attachment AE - Market Monitor process
- Section 6.1.7.1 - MCR registration option

**Referenced Concepts:**
- SCUC (Security Constrained Unit Commitment) algorithm
- SCED (Security Constrained Economic Dispatch) algorithm
- RTBM Offers (Real-Time Balancing Market Offers)
- SPP Mid-Term Load Forecast
- Shadow Price calculation

## 7. Suggested Tags

- Day-Ahead Market
- Reliability Unit Commitment
- SCUC Algorithm
- SCED Algorithm
- Manual Commitment
- Local Reliability Issues
- Multi-Configuration Resources
- Operating Reserves
- Capacity Adequacy
- Transmission Constraints
- Resource Compensation
- Cost Recovery
- Market Clearing
- Emergency Operations
- Violation Relaxation Limits
- RR696

## 8. Items That May Need Follow-Up

1. **MCR Transition Time Limitations**: Clarification needed on operational impacts of excluding MCRs with >30 minute transition times from Contingency Reserve and regulation services during configuration changes

2. **Operating Guides Development Timeline**: No timeline specified for development of operating guides between SPP, local transmission operators, and Resource owners for recurring Local Reliability Issues

3. **Non-Discriminatory Manual Commitment Process**: Details of Market Monitor review process (Section 6.1.2.1) should be cross-referenced to ensure compliance verification

4. **Local vs. Regional Cost Recovery**: Mechanisms under Section 4.5.9.10 need clarification to understand allocation methodology differences between local and regional recovery

5. **SCUC Re-run Protocol**: "Time permitting" language regarding SCUC re-runs after manual commitments lacks specific timing requirements or decision criteria

6. **Capacity Surplus/Shortage Priority Orders**: Verification needed that priority order cascades align across Day-Ahead Market, Day-Ahead RUC, and Intra-Day RUC processes

7. **Advisory vs. Binding Actions**: Clarification on criteria RUC Operators use to determine which advisory information from algorithms to act upon

8. **Compensation Parity**: Confirmation that Resources committed for Local Reliability Issues receive "same manner" compensation as other Resources needs validation against actual compensation calculations

---

# Chunk 23 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document chunk contains technical regulatory content from SPP (Southwest Power Pool) governing documents, including market operations tariffs, operating criteria, and planning criteria. The content primarily addresses resource commitment procedures during reliability events, non-conforming load requirements, emergency operating procedures, ICCP connectivity requirements, and transmission system planning standards. The material establishes protocols for manual and automatic resource commitments, operator responsibilities during local reliability issues, and technical definitions for transmission system modifications.

## 2. Key Topics

- **Resource Commitment Procedures**: SCUC algorithm processes for managing excess capacity, including de-commitment priorities and reliability-based commitments
- **Local Reliability Issues**: Protocols for out-of-merit commitments and dispatch instructions by SPP and local transmission operators
- **Manual Commitment Oversight**: Market Monitor verification processes for non-discriminatory resource selection
- **Non-Conforming Load Registration**: Requirements for Market Participants to identify and report Non-Conforming Load assets ≥50 MW
- **Emergency Operating Plans (EOPs)**: Guidelines for operator-controlled load shedding and protection of critical natural gas loads
- **ICCP Node Connectivity**: Technical requirements for GOP and TOP entities regarding Inter-Control Center Communications Protocol
- **Transmission Planning Standards**: Definitions and criteria for Transmission Material Modifications and Qualified Changes
- **Compensation Recovery**: Regional vs. local cost allocation for committed resources under various scenarios

## 3. Decisions or Actions

- **SCUC Algorithm Actions**: Automatic procedures to eliminate capacity surplus through operating limit reductions, reliability resource commitments, and market/self-committed resource de-commitments
- **Manual Commitment Authority**: SPP may manually commit/de-commit resources for transmission system reliability issues not directly addressable within SCUC
- **Local Transmission Operator Authority**: May issue emergency instructions during Local Emergency Conditions when time doesn't permit SPP coordination
- **Coordination Requirements**: Transmission Operators must notify SPP of instructions given and coordinate subsequent instructions through SPP
- **Operating Guide Development**: SPP, local transmission operators, and resource owners must develop operating guides for manual commitments addressing recurring Local Reliability Issues
- **Market Monitor Verification**: Required for all manual commitments to ensure non-discriminatory resource selection per Section 6.1.2.1 of Attachment AE

## 4. Important Dates

No specific dates are mentioned in this content chunk. The document references ongoing operational procedures and planning timelines rather than specific calendar dates.

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)**: Primary regional transmission organization
- **Market Monitor**: Oversight entity for non-discriminatory practices
- **NERC (North American Electric Reliability Corporation)**: Standards authority
- **Transmission Operators (TOPs)**: Local transmission system operators
- **Generator Operators (GOPs)**: Generation facility operators
- **Market Participants**: General category of market entities
- **Asset Owners**: Entities owning generation or load assets
- **Resource Owners**: Entities owning generation resources
- **Local Transmission Operators**: Regional/local system operators

### People:
No individual names are mentioned in this content.

## 6. Links or References

### Internal SPP Document References:
- **Section 4.5.9.8**: Compensation provisions for committed resources
- **Section 4.5.9.10**: Cost recovery allocation (regional vs. local)
- **Section 6.1.2.1 of Attachment AE**: Market Monitor verification process for resource selection
- **Attachment O (OATT)**: Transmission Planning Process
- **Attachment V (OATT)**: Generator interconnection procedures and Material Modification definitions
- **Attachment AB (OATT)**: Facility retirement procedures
- **Attachment AQ (OATT)**: Delivery point establishment/modification procedures

### External References:
- **NERC Reliability Standards**: General reference to mandatory reliability standards
- **NERC Standard FAC-002-041**: Facilities Connection Requirements (or successor version)
- **NERC Glossary of Terms**: Referenced for standard definitions

### Document Sections:
- **Section 3.6**: SPP Reliability Coordinator EOP Reviews
- **Section 5.2**: Node Connectivity Requirement
- **Section 5 (SPP Criteria)**: Planning criteria definitions and concepts

## 7. Suggested Tags

- Resource Commitment
- Market Operations
- Reliability Coordination
- Emergency Procedures
- SCUC Algorithm
- Local Reliability Issues
- Market Monitor
- Cost Recovery
- Non-Conforming Load
- ICCP Connectivity
- Transmission Planning
- Material Modification
- Operating Criteria
- SPP Tariff
- Load Shedding
- Generator Operations
- Transmission Operations
- Out-of-Merit Dispatch
- Day-Ahead Market
- Real-Time Market

## 8. Items That May Need Follow-Up

### Compliance and Implementation:
1. **Non-Conforming Load Registration**: Verify all Market Participants have identified Non-Conforming Load assets ≥50 MW with appropriate PNode/APNode assignments
2. **ICCP Connectivity Compliance**: Confirm all TOPs and qualifying GOPs (>1500 MW or 15+ capacity resources) meet dual-node and 240-second reconnection requirements
3. **Operating Guide Development**: Track status of operating guides for known and recurring Local Reliability Issues being developed jointly by SPP, transmission operators, and resource owners

### Monitoring and Verification:
4. **Market Monitor Review Process**: Ensure Section 6.1.2.1 verification procedures are consistently applied to all manual commitments
5. **Affiliated Resource Discrimination**: Monitor instances where local transmission operators issue emergency instructions to affiliated resources to ensure non-discriminatory treatment
6. **Cost Recovery Allocation**: Verify proper regional vs. local cost allocation for various commitment scenarios per Section 4.5.9.10

### Policy and Procedure Clarifications:
7. **"Time Permitting" Definition**: Establish clearer criteria for when local transmission operators may bypass SPP coordination during Local Emergency Conditions
8. **Transmission Material Modification Threshold**: Confirm understanding of the 20% rating reduction threshold and its application across the SPP footprint
9. **Critical Natural Gas Load Prioritization**: Verify implementation of EOP provisions protecting critical gas loads from load shedding

### Technical and Operational:
10. **Third-Party ICCP Contracts**: Confirm third-party providers can meet 240-second reconnection requirements
11. **Reserve Zone Constraint Conflicts**: Review instances where transmission constraints occur simultaneously with excess capacity events
12. **Seasonal Model Updates**: Ensure all applicable seasonal planning models reflect current system conditions and anticipated changes

---

# Chunk 24 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document chunk (24 of 27) from SPP Comments dated August 14, 2025, contains detailed technical procedures and business practices related to:
- Non-jurisdictional facility interconnection processes
- HILLGA (Higher-level Integrated Long-term Generation Assessment) network study procedures
- Business Practice 7850 regarding Delivery Point evaluations
- Requirements for system studies, short-circuit analyses, and network upgrades
- Coordination between transmission owners, SPP, and interconnection customers

The content primarily consists of procedural text defining how SPP evaluates system impacts from generator interconnections and delivery point changes, including study methodologies, responsibility assignments, and coordination requirements.

## 2. Key Topics

- **Non-Jurisdictional Generator Interconnection**: Process for facilities outside SPP's direct jurisdiction requiring affected system studies
- **HILLGA Network Studies**: Queue position determination, serial vs. parallel processing based on electrical equivalence
- **Short-Circuit Fault Current Calculations**: Analysis procedures consistent with SPP ITP Manual standards
- **Delivery Point Management (BP 7850)**: Processes for additions, modifications, and retirements of delivery points
- **Network Upgrades**: Requirements and completion timelines before generating facility operation
- **Study Agreements**: Responsibilities for entering into and financing various study types
- **Model Development**: Base and Change Model sets for analyses, including affected system generation
- **Local Delivery Facilities**: Definition and evaluation procedures for NITS-related facilities

## 3. Decisions or Actions

**Transmission Owner Responsibilities:**
- Conduct required studies when notified of generator interconnection requests
- Notify SPP of transmission system impacts
- Provide system impact studies detailing impacts
- Complete generator interconnection agreements per TO procedures
- Complete Network Upgrades on Distribution System and TO transmission system

**SPP Responsibilities:**
- Perform studies for non-jurisdictional facilities when warranted
- Determine additional required studies as impacted system
- Study impacts in Definitive Interconnection System Impact Studies if needed
- Approve mitigations if Network Upgrades cannot be completed before facility operation

**Transmission Customer Responsibilities:**
- Submit requests through Attachment AQ, AX, or other processes
- Notify SPP to update NITS Agreement for Delivery Point changes
- Enter into applicable study and facilities agreements
- Ensure all required studies completed as condition of interconnection

**Optional Actions:**
- TO/distribution provider may enter into Affected System study agreements or require interconnection customer to do so
- TO/distribution provider may enter into facilities agreement with SPP or require customer to do so

## 4. Important Dates

- **Network Upgrades Completion**: Must be completed **prior to operation** of the Generating Facility (unless mitigations approved by SPP)
- **Study Timeline Basis**: Determined by standardized project timelines per BP 7060
- **ITP Model Updates**: Reference to "prior to commencement of study and subsequent to publishing of ITP models"

*Note: No specific calendar dates are mentioned in this chunk*

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP** (Southwest Power Pool) - Primary regulatory body
- **Transmission Owner** - Multiple references
- **Distribution Provider** - Coordination role
- **Interconnection Customer** - Applicant entity
- **Transmission Customer** - Service recipient

**Referenced Organizations (in Reference Documents section):**
- Associated Electric Cooperatives, Inc.
- California Independent System Operator Corporation
- Electric Reliability Council of Texas (ERCOT)
- Midcontinent Independent System Operator, Inc. (MISO)
- Peak
- Public Service Company of Colorado
- Saskatchewan Power Corporation
- Southwestern Power Administration
- Tennessee Valley Authority

*No individual names mentioned*

## 6. Links or References

**Referenced Documents:**
- Business Practice 7250
- Business Practice 7850
- Business Practice 7060
- Attachment BB (multiple section references: 4.1.1, 8.4.1)
- Attachment AQ
- Attachment AX
- Attachment V (Generator Interconnection Procedures)
- SPP Open Access Transmission Tariff (OATT)
- SPP ITP Manual (Short-Circuit Analysis section)
- SPP Model Development Procedure Manual
- SPP Disturbance Performance Requirements
- SPP Quarterly Project Tracking Report
- Request Management System
- Seams Agreements (multiple listed)
- NITS Agreement (Network Integration Transmission Service)

**Referenced Processes:**
- GIP (Generator Interconnection Procedures)
- ITP (Integrated Transmission Planning)
- HILL (Higher-level Integrated Long-term) request process
- Definitive Interconnection System Impact Study
- Interconnection Facility Study/Analysis
- Provisional Load Process

## 7. Suggested Tags

- Generator_Interconnection
- Non-Jurisdictional_Facilities
- HILLGA_Studies
- Network_Upgrades
- Delivery_Point_Management
- Business_Practice_7850
- Transmission_Planning
- System_Impact_Studies
- Short-Circuit_Analysis
- Affected_System
- SPP_OATT
- Attachment_AQ
- Attachment_AX
- NITS_Agreement
- Facilities_Agreement
- Queue_Position
- Model_Development
- Study_Agreements
- Transmission_System
- BES_Facilities

## 8. Items That May Need Follow-Up

1. **Incomplete Sections**: Multiple "(Placeholder)" references indicate incomplete documentation requiring content addition

2. **Threshold Clarification**: "+/- 30% from original positive sequence impedance value" trigger needs verification of measurement methodology

3. **Cost Responsibility**: Financial responsibility allocation between TO, distribution provider, and interconnection customer for various study types may need contractual clarification

4. **Study Timeline Coordination**: Interaction between HILLGA, HILL, ITP, and Definitive Studies timelines should be mapped for potential conflicts

5. **Affected System Generation Dispatch Levels**: "Expected dispatch levels" criteria within bus-level boundaries needs operational definition

6. **Aggregation Criteria**: "Relative proximity" for aggregating multiple delivery point requests lacks specific geographic or electrical distance parameters

7. **NITS Agreement Update Process**: Specific procedural steps and timing for updating agreements after AQ/AX review need documentation

8. **Mitigation Approval Process**: SPP approval process for operating before Network Upgrades completion requires detailed procedure

9. **Model Currency Issues**: Reconciliation process for generation with GIAs occurring between ITP model publication and study commencement needs tracking mechanism

10. **Reference Document Links**: Actual hyperlinks/URLs for reference materials mentioned as "available at sites below" are missing

11. **LIST OF ACRONYMS**: Section header present but content missing - full acronym list needed

12. **Seams Agreement Coverage**: Verification needed that all relevant affected systems have current seams agreements in place

---

# Chunk 25 Analysis

# Regulatory Content Analysis Report
**Source:** RR696 SPP Comments 20250814.docx.txt - chunk 25 of 27

---

## 1. Executive Summary

This document segment contains SPP (Southwest Power Pool) regulatory procedures covering three main areas: (1) Delivery Point modification processes under Attachments AQ and AX, (2) Resource Adequacy requirements for Demand Response Programs and Behind-The-Meter Generation under Business Practice 8100, and (3) portions of the Integrated Transmission Planning (ITP) Manual regarding load forecasts and operational needs assessments. Additionally, it includes revenue requirement tables for Through And Out Transactions across multiple transmission owners in the SPP footprint.

---

## 2. Key Topics

- **Attachment AQ Process**: Evaluation criteria for Delivery Point additions, modifications, and retirements when Transmission Customers have sufficient existing Designated Resources
- **Attachment AX Process**: Evaluation criteria for similar changes when Transmission Customers lack sufficient Designated Resources
- **Network Upgrades**: Aggregated study approach for comprehensive system analysis
- **Demand Response Programs**: Requirements for controllable/dispatchable vs. non-controllable/non-dispatchable programs
- **Behind-The-Meter Generation**: Treatment of resources less than 10 MW (e.g., rooftop solar)
- **Resource Adequacy Requirements**: Meeting Winter Season Obligation and Attachment AA requirements
- **Load Forecasting**: Non-coincident peak conditions for ITP assessments
- **Persistent Operational Needs**: Economic and reliability-related criteria for transmission system operations
- **Revenue Requirements**: Allocation methodology for Through And Out Transactions across transmission owners

---

## 3. Decisions or Actions

- **Aggregated Study Approach**: Transmission Provider must propose aggregated study approach to all Parties and evaluate feedback before deciding to aggregate requests
- **Load Modifier vs. Resource Capacity**: Non-dispatchable/non-controllable demand response programs may only be considered in LRE's forecasted Peak Demand (not as resource capacity)
- **Reporting Requirement**: Each LRE must report projected MW level of Peak Demand reduction as an informational line item in the Workbook
- **50-50 Forecast Standard**: Peak Demand incorporating non-controllable programs must maintain 50% probability threshold
- **ESWG and TWG Review**: Additional operational needs not meeting criteria thresholds must be presented to these working groups for review and endorsement

---

## 4. Important Dates

- **Date Reference**: Document dated 20250814 (August 14, 2025) - appears to be a future date, possibly indicating a planned implementation or comment deadline
- No other specific dates mentioned in this content segment

---

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)** - Transmission Provider
- **ESWG (Economic Studies Working Group)**
- **TWG (Transmission Working Group)**

### Transmission Owners Listed:
- AEP Oklahoma Transmission Company, Inc.
- AEP Southwestern Transmission Company, Inc.
- Public Service Company of Oklahoma
- Southwestern Electric Power Company
- Arkansas Electric Cooperative Corporation (zones 1 and 7)
- City Utilities of Springfield
- Corn Belt Power Cooperative
- Empire District Electric Company
- Evergy Kansas Central, Inc. / Evergy Kansas South, Inc.
- Evergy Metro, Inc.
- Evergy Missouri West, Inc.
- Grand River Dam Authority
- Kansas City Board of Public Utilities
- Lincoln Electric System
- Midwest Energy, Inc.
- Missouri Joint Municipal Electric Utility Commission
- Nebraska Public Power District
- Oklahoma Gas and Electric
- Omaha Public Power District
- Southwestern Power Administration
- Southwestern Public Service Company
- Sunflower Electric Power Corporation
- Tri-State G&T Association
- Western Farmers Electric Cooperative
- Western-UGP

### Entity Types:
- Load Responsible Entity (LRE)
- Market Participant
- Network Customer
- Transmission Customer

---

## 6. Links or References

### Internal SPP Documents Referenced:
- **Attachment AQ** - Process for delivery point evaluations with sufficient resources
- **Attachment AX** - Process for delivery point evaluations with insufficient resources
- **Attachment AA** - Resource Adequacy Requirement and Winter Season Obligation
- **Business Practice 8100** - Resource Adequacy requirements for Demand Response Programs and Behind-The-Meter Generation
- **ITP (Integrated Transmission Planning) Manual** - Sections 2.1.3 and 4.4
- **Model Development Procedure Manual** - Process for submitting load forecasts
- **RRR File** - Revenue requirement reference file (multiple references in tables)
- **Workbook** - Document for reporting Peak Demand reduction projections

### Specific Sections Referenced:
- Section II.3 (American Electric Power reference)
- Table 1: Revenue Requirements for Allocation of Through And Out Transactions
- Table 2: Schedule 1 Point-to-Point ("PTP") Revenue Credit

---

## 7. Suggested Tags

- SPP
- Transmission Planning
- Delivery Point Management
- Resource Adequacy
- Demand Response
- Behind-The-Meter Generation
- Load Forecasting
- Network Upgrades
- Attachment AQ
- Attachment AX
- Business Practice 8100
- ITP Manual
- Revenue Requirements
- Through And Out Transactions
- Point-to-Point Service
- Transmission Owners
- Operational Needs Assessment
- ESWG
- TWG

---

## 8. Items That May Need Follow-Up

1. **Document Date Clarification**: The file name indicates a date of August 14, 2025, which appears to be in the future. Verify if this is a comment deadline, implementation date, or data entry error.

2. **RRR File References**: All revenue requirement amounts in Tables 1 and 2 reference "See RRR File" - need to obtain and review this supporting document for actual dollar amounts.

3. **Aggregated Study Approach**: The process requires Transmission Provider to "evaluate any feedback" from Parties - clarify the timeline and formal process for this feedback mechanism.

4. **Behind-The-Meter Generation Threshold**: The 10 MW threshold for behind-the-meter generation treatment needs clarification - what happens to resources above 10 MW?

5. **Non-Dispatchable Resources**: Verify how rooftop solar and similar resources are being tracked and reported in LRE forecasts, particularly regarding the 50-50 forecast standard.

6. **Historical Data Requirements**: Section 3.0 mentions "historical hourly demand data sufficient to establish reduction" - clarify the minimum time period required.

7. **Additional Operational Needs Criteria**: SPP may propose additional needs beyond established criteria thresholds - establish governance process and documentation requirements for these exceptions.

8. **Interface Transmission Service**: Multiple references to delivery points "not physically interconnected with the SPP Transmission System" - clarify coordination procedures with adjacent systems.

9. **Service Agreement Transfers**: Understand the distinction and rationale for different treatment of transfers between Network Customers vs. Transmission Customers.

10. **Revenue Credit Applicability**: Table 2 shows many transmission owners with "N/A" for Schedule 1 PTP Revenue Credit while others show "$0" - clarify the difference in treatment and eligibility.

---

# Chunk 26 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary
This document (chunk 26 of 27) from RR696 SPP Comments dated August 14, 2025, contains detailed financial allocation tables for Annual Transmission Revenue Requirements (ATRR) across multiple transmission zones within the Southwest Power Pool (SPP) region. The content consists primarily of three interconnected tables (Tables 3, 4, and 5) that outline zonal and region-wide ATRR allocations, with most specific dollar amounts referenced in an attached file (Attachment H tab, posted RRR File). Only a few specific dollar amounts are listed directly in the tables.

## 2. Key Topics
- **Annual Transmission Revenue Requirements (ATRR)** allocation methodology
- **Zonal ATRR** distribution across 20 designated transmission zones
- **Base Plan ATRR** allocations (pre and post June 19, 2010)
- **Balanced Portfolio Region-wide ATRR** reallocations
- **Upgrade Sponsor** payment structures
- **Interregional Planning** cost allocations
- **Network Integration Transmission Service (NITS)** ATRR
- **JTIQ (Joint Transmission Injection Queue) ATRR** balances

## 3. Decisions or Actions
- Specific ATRR amounts have been allocated to various entities:
  - East Texas Electric Cooperative, Inc.: $14,567,983
  - Deep East Texas Electric Cooperative, Inc.: $2,576,698
  - Oklahoma Municipal Power Authority (Zone 1e): $768,624
  - Coffeyville Municipal Light and Power: $391,790
  - City of Independence, Missouri: $7,043,930
  - Oklahoma Municipal Power Authority (Zone 7b): $368,501
  - Southwestern Power Administration (Non-Federal): $15,533,800
  - Central Nebraska Public Power and Irrigation District: $327,891
- Zone 15 designated as "Reserved for Future Use"
- Multiple sub-zones created for complex organizational structures (e.g., zones 1, 6, 7, 9, 10, 11, 12, 13, 14, 17, 19)

## 4. Important Dates
- **June 19, 2010**: Critical date distinguishing between different Base Plan ATRR calculations and allocations (referenced as threshold for NTC - Network Transmission Cost - calculations)
- **August 14, 2025**: Document date (RR696 SPP Comments 20250814)

## 5. Organizations and People Mentioned

**Transmission Zone Organizations (Zones 1-20):**
- American Electric Power entities (AEP West, PSO, SWEPCO, AEP Oklahoma/Southwestern Transmission)
- Evergy entities (Metro, Missouri West, Kansas Central/South)
- Oklahoma Gas and Electric
- Kansas City Board of Public Utilities
- City Utilities of Springfield, Missouri
- Empire District Electric Company
- Grand River Dam Authority
- Southwestern Power Administration
- Southwestern Public Service Company
- Sunflower Electric Power Corporation
- Western Farmers Electric Cooperative
- Lincoln Electric System
- Nebraska Public Power District
- Omaha Public Power District
- Upper Missouri Zone members (Basin Electric, Heartland, etc.)

**Cooperatives and Municipal Utilities:**
- East Texas Electric Cooperative
- Deep East Texas Electric Cooperative
- Oklahoma Municipal Power Authority
- Arkansas Electric Cooperative Corporation
- People's Electric Cooperative
- Multiple rural electric cooperatives in Upper Missouri Zone

**Transmission Companies:**
- Transource Oklahoma/Missouri, LLC
- NextEra Energy Transmission Southwest, LLC
- ITC Great Plains, LLC
- Prairie Wind Transmission, LLC
- South Central MCN LLC

**Municipal Power Entities:**
- Missouri Joint Municipal Electric Utility Commission
- Kansas Power Pool
- Missouri River Energy Services (and member cities)

## 6. Links or References
- **Attachment H tab, posted RRR File**: Primary reference document containing detailed ATRR amounts (referenced throughout all three tables)
- **Section II.2**: Referenced for American Electric Power zone details
- **RRR (Rate Ready Reckoner) File**: Repository for detailed financial information

## 7. Suggested Tags
- ATRR
- Transmission Cost Allocation
- SPP (Southwest Power Pool)
- RR696
- Zonal Allocation
- Base Plan
- Balanced Portfolio
- Upgrade Sponsors
- Interregional Planning
- Network Transmission Costs
- Rate Design
- Transmission Revenue Requirements
- FERC Regulatory
- Cost Recovery

## 8. Items That May Need Follow-Up

1. **Missing Data Reference**: Verify all references to "See Att. H tab, posted RRR File" are accessible and accurate
2. **Zone 15 Status**: Determine future allocation plans for Zone 15 (currently reserved)
3. **Zone 1c Status**: Clarify purpose of Zone 1c reservation
4. **June 19, 2010 Transition**: Verify proper application of pre/post-2010 cost allocation methodologies
5. **JTIQ ATRR Balance**: Confirm calculation methodology for Joint Transmission Injection Queue balances (Table 5, Line 9)
6. **Reallocation Amounts**: Validate reallocation amounts from zonal to region-wide ATRR (Column 6 references)
7. **Upgrade Sponsor Payments**: Confirm payment structures and amounts for upgrade sponsors across all zones
8. **Interregional Planning Costs**: Verify proper allocation of SPP and Other Interregional Planning Region ATRR
9. **Sub-zone Allocations**: Confirm proper distribution within multi-entity zones (particularly zones 1, 19)
10. **Document Completeness**: Review chunks 1-25 and 27 for additional context on methodology and definitions

---

# Chunk 27 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary
This document represents the final chunk (27 of 27) of SPP (Southwest Power Pool) regulatory comments dated August 14, 2025 (RR696). The content consists primarily of reference tables including: a comprehensive listing of transmission zones and owners with associated credits (Table 6), transmission service request timelines and requirements (Tables 7-10), and an acronym glossary (Table 29). The document appears to be technical tariff or procedural documentation related to transmission service administration within the SPP regional transmission organization.

## 2. Key Topics
- **Transmission Zone Organization**: Detailed breakdown of 19+ zones with sub-zones covering utilities across multiple states (Oklahoma, Kansas, Missouri, Nebraska, Texas, Arkansas, Iowa, South Dakota, North Dakota)
- **Zonal ATRR and Schedule 11 Credits**: Most entries marked as "N/A" or "$0"
- **Transmission Service Request Procedures**: Comprehensive timelines for different service types:
  - Long-term firm service (1 year or more)
  - Short-term firm service (daily to monthly)
  - Non-firm service (hourly to monthly)
  - Next-hour market service
- **Response and Study Timelines**: Specific deadlines for customer requests, transmission provider responses, system impact studies, and energy scheduling
- **Generator Interconnection Processes**: Referenced through acronyms (GI, GIA, GIP, GIR)

## 3. Decisions or Actions
No explicit decisions or actions are documented in this chunk, as it consists of reference tables and procedural timelines. However, the tables establish:
- **Standardized request windows**: Ranging from 90 days prior (long-term) to 30 minutes prior (hourly non-firm)
- **Response timeframes**: 24 hours to 10 days depending on service type
- **Customer commitment deadlines**: 2 hours to 4 days depending on queue timing
- **Energy scheduling change deadlines**: Generally 20 minutes prior to schedule start

## 4. Important Dates
**Procedural Deadlines (by Service Type):**
- **Long-term Firm (≥1 year)**: 90 days prior request deadline; 10-day response time
- **Short-term Firm (monthly)**: 31 days prior (earliest 120 days); 24-hour response
- **Short-term Firm (weekly)**: 8 days prior (earliest 60 days); 24-hour response
- **Short-term Firm (daily)**: 2 days prior or 10:00 day prior; 24-hour response
- **Non-firm (daily)**: 10:00 day prior (earliest 2 days)
- **Non-firm (hourly)**: 30 minutes prior (earliest 10:00 day prior)
- **Next-hour Market**: 20 minutes prior (earliest 1 hour prior)
- **Universal scheduling change deadline**: 20 minutes prior to start of schedule

## 5. Organizations and People Mentioned

**Major Utilities/Transmission Owners (Zone-based):**
- American Electric Power (AEP) entities - West, Oklahoma, Southwestern
- Evergy entities (Metro, Kansas Central/South, Missouri West)
- Oklahoma Gas and Electric
- Empire District Electric Company
- Southwestern Public Service Company
- Southwestern Power Administration
- Western Farmers Electric Cooperative
- Sunflower Electric Power Corporation

**Cooperatives:**
- East Texas Electric Cooperative
- Deep East Texas Electric Cooperative
- Arkansas Electric Cooperative Corporation (AECC)
- People's Electric Cooperative
- Basin Electric Power Cooperative
- Multiple regional cooperatives in Upper Missouri Zone

**Public Power Entities:**
- Kansas City Board of Public Utilities
- City Utilities of Springfield, Missouri
- Grand River Dam Authority
- Omaha Public Power District
- Lincoln Electric System
- Nebraska Public Power District

**Transmission Companies:**
- Transource Oklahoma, LLC
- Transource Missouri, LLC
- ITC Great Plains, LLC
- Prairie Wind Transmission, LLC
- NextEra Energy Transmission Southwest, LLC

**Regional Organizations:**
- Southwest Power Pool (SPP)
- Federal Energy Regulatory Commission (FERC)
- North American Electric Reliability Corporation (NERC)

**No individual people mentioned**

## 6. Links or References
- **Section II of Attachment Z1**: Referenced for open season procedures and aggregate transmission service studies
- **Sections 19.4 and 32.4**: Customer response schedules
- **Section 30.2.2**: Expedited designation process requirements
- **NERC TPL Standards**: Transmission System Planning Performance Requirements
- **Open Access Transmission Tariff (OATT)**: Governing document framework
- **Power System Simulator for Engineering (PSS/E)**: Technical analysis tool
- **Request Management System (RMS)**: Administrative platform

## 7. Suggested Tags
- Southwest Power Pool (SPP)
- Transmission Service
- OATT (Open Access Transmission Tariff)
- Generator Interconnection
- Zonal Transmission
- ATRR Credits
- Long-term Firm Service
- Short-term Firm Service
- Non-firm Transmission
- Energy Scheduling
- Transmission Owners
- Regional Transmission Organization (RTO)
- FERC Compliance
- Aggregate Transmission Service Study
- Next-hour Market
- Interconnection Procedures

## 8. Items That May Need Follow-Up

1. **Missing Content**: Tables 11-28 and 30-45 are listed but contain no visible data - verify if this is intentional or indicates missing content

2. **Zone 1a Cross-Reference**: States "See Section II.3" but content not included in this chunk - requires verification of what special provisions apply

3. **Reserved Zones**: Multiple "Reserved for Future Use" designations (Zones 1c, 11b, 15) - may need monitoring for future allocation

4. **Credit Verification**: Extensive use of "N/A" and "$0" values in ATRR and Schedule 11 Credit columns - confirm whether this indicates no credits apply or data gaps

5. **Open Season Timing**: References to "open season specified in Section II of Attachment Z1" without specific dates - current/upcoming open season schedules should be tracked

6. **Expedited Process Requirements**: Section 30.2.2 expedited designation process referenced but criteria not detailed in this chunk

7. **Best Effort Services**: Multiple "best effort" designations for certain queued requests - may create uncertainty for customers and should be monitored for disputes

8. **Next-Hour Market Implementation**: Shows "N/A" for customer response times - verify operational procedures and market participant understanding

9. **Document Context**: This is chunk 27 of 27 - full document review recommended to understand complete regulatory context and whether these are proposed or approved procedures

10. **Effective Date**: Document dated 20250814 (August 14, 2025) - confirm whether this is proposed future implementation or dating error