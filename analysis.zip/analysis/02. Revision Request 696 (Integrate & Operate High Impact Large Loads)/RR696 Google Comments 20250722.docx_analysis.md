# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document contains Google LLC's formal comments on SPP's Revision Request (RR) 696, which proposes to implement a framework for integrating and operating High Impact Large Loads (HILL) and Conditional High Impact Large Load Service (CHILLS). While Google generally supports the objectives of RR696 and acknowledges SPP Staff's exceptional work, the company raises eight significant concerns regarding implementation details, cost allocation, fairness, and operational requirements. Google emphasizes the need for more extensive stakeholder discussion before implementation, particularly regarding interconnection queue priorities, cost-shifting prevention, and integration with existing demand response frameworks.

## 2. Key Topics

- **High Impact Large Load (HILL) Integration Framework**: New assessment and interconnection process for large industrial loads
- **CHILLS Service**: Conditional service offering for large loads with flexibility requirements
- **HILLGA (High Impact Large Load Generation Agreement)**: Process for loads co-located with generation resources
- **Interconnection Queue Management**: Queue priority and cost allocation between different load types
- **Transmission Cost Assignment**: Fee structures and cost-sharing methodology
- **Non-Conforming Loads Definition**: Classification and forecasting of large industrial loads
- **Demand Response Integration**: Overlap between CHILLS and existing DR framework
- **Operational Requirements**: Voltage and frequency ride-through capabilities
- **Equal Access and Non-Discrimination**: Concerns about preferential treatment for Transmission Owner loads

## 3. Decisions or Actions

**No final decisions documented** - this is a comment submission document.

**Requested Actions/Recommendations from Google:**

1. **HILLGA Queue Priority**: Implement strict queue-based treatment based on load interconnection request order
2. **Revise Non-Conforming Load Definition**: Remove assertion that large loads cannot be forecasted through mathematical patterns
3. **Integrate with DR Framework**: Consolidate CHILLS with ongoing Demand Response framework to avoid duplication
4. **Add CHILLS Guardrails**: Establish clear operational limitations and deployment frequency caps
5. **Remove Ride-Through Language**: Delete undefined voltage/frequency ride-through requirements pending stakeholder discussion
6. **Add Delay Protections**: Include language protecting against disconnection due to delays beyond parties' control
7. **Revise Fee Structure**: Adopt single $/MW fee structure with caps instead of proposed tiered structure
8. **Ensure Equal Access**: Review process to prevent discrimination against Transmission User loads

## 4. Important Dates

- **July 22, 2025**: Date of Google's comment submission
- **Five-year service limit**: CHILLS service definitively limited to 5 years (concern raised about this limitation)

## 5. Organizations and People Mentioned

**Organizations:**
- Google, LLC (submitter)
- SPP (Southwest Power Pool) - grid operator
- Antora (supporting organization on cost concerns)
- Kansas Grain and Feed Association (KGFA) (supporting organization)
- NERC (North American Electric Reliability Corporation) - standards reference
- Transmission Owners (TOs)
- Load Responsible Entities (LREs)
- Transmission Users (TUs)

**People:**
- **Chris Matos** - Google representative submitting comments
  - Email: chrismatos@google.com
  - Phone: 650-930-6764

## 6. Links or References

**Referenced Documents/Frameworks:**
- RR696 Revision Request Form
- SPP Open Access Transmission Tariff
- Market Protocols
- SPP Operating Criteria
- SPP Planning Criteria
- SPP Business Practices
- Integrated Transmission Planning (ITP) Manual
- Attachment AQ (Load interconnection process)
- NERC standards (mentioned but not specifically cited)
- SPP Demand Response (DR) framework (ongoing stakeholder process)

**No URLs or hyperlinks provided in document**

## 7. Suggested Tags

- RR696
- High Impact Large Loads
- HILL
- CHILLS
- HILLGA
- SPP
- Load Interconnection
- Transmission Cost Allocation
- Grid Integration
- Data Center Loads
- Industrial Loads
- Demand Response
- Queue Priority
- Attachment AQ
- Cost Shifting
- Equal Access
- NERC Compliance
- Resource Adequacy
- Transmission Planning
- Google Energy Policy

## 8. Items That May Need Follow-Up

### Critical Issues Requiring Resolution:

1. **HILLGA and Attachment AQ Queue Coordination** (Concern #1)
   - Need clear policy on queue priority between HILLGA and AQ service requests
   - Resolve cost allocation when loads in similar locations use different processes
   - Action: Develop queue management protocols preventing cost-shifting

2. **Non-Conforming Load Definition** (Concern #2)
   - Revise definition to reflect predictability of large industrial loads
   - Action: Technical discussion on load forecasting methodologies for large loads

3. **CHILLS-DR Framework Integration** (Concern #3)
   - Resolve overlaps in metering requirements and market participation restrictions
   - Action: Coordinate CHILLS development with ongoing DR stakeholder process

4. **CHILLS Operational Parameters** (Concern #4)
   - Establish deployment frequency limits and curtailment guardrails
   - Action: Develop financial planning predictability mechanisms

5. **Voltage/Frequency Ride-Through Requirements** (Concern #5)
   - Remove or clarify undefined technical requirements
   - Action: Initiate stakeholder process for developing clear standards

6. **Service Term Flexibility** (Concern #6)
   - Add force majeure or delay protection language
   - Action: Draft protective provisions for circumstances beyond parties' control

7. **Transmission Fee Structure** (Concern #7)
   - Review and potentially revise study fee structure
   - Need detailed transmission cost assignment options analysis
   - Action: Develop equitable $/MW fee structure with caps

8. **Equal Access Verification** (Concern #8)
   - Review for potential discrimination between TO and TU loads
   - Action: Conduct equity analysis of interconnection process

### Administrative Follow-Up:

- **Stakeholder Process Timeline**: Establish timeline for addressing the eight concerns raised
- **Cost-Benefit Analysis**: Request detailed economic analysis of transmission cost options
- **Regulatory Compliance Review**: Ensure alignment with open access requirements
- **Document Revisions**: Track changes to tariff language based on stakeholder feedback
- **Coordination with Other RRs**: Identify any related revision requests affecting HILL/CHILLS implementation