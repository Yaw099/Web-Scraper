# Final Combined Report

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT
## RR696: Integrate & Operate High Impact Large Loads

---

## 1. EXECUTIVE SUMMARY

**Revision Request (RR) #696** is a comprehensive proposal submitted to Southwest Power Pool (SPP) on June 30, 2025, to establish a formal framework for integrating and operating **High Impact Large Loads (HILLs)**—large-scale industrial, data center, computational, and electrolyzer facilities. The request seeks **expedited resolution** to address the urgent influx of multi-megawatt projects across the SPP footprint.

**Core Proposal:** Create a new **"Conditional High Impact Large Load (CHILL) Service"** that would allow large loads to interconnect with the transmission grid through standardized, transparent processes while managing system reliability and cost impacts.

**Scope of Changes:** The RR proposes modifications to multiple SPP governing documents including:
- Open Access Transmission Tariff (OATT) – Parts I and VII, multiple Schedules and Attachments
- Market Protocols Version 112
- Operating Criteria
- Planning Criteria  
- Business Practices (BP7250, BP7850, BP8100)

**Key Drivers:**
- Growing wave of large load projects creating uncertainty and investment delays
- Current lack of formal procedures for HILL assessment and interconnection
- Reliability risks from inadequate study processes
- Need for transparent cost allocation mechanisms
- Pressure from federal and state incentive programs

---

## 2. KEY TOPICS

### A. High Impact Large Load (HILL) Integration
- Standardized assessment framework for large loads
- System impact evaluation procedures
- Interconnection process requirements
- Load predictability and forecasting improvements

### B. Conditional HILL (CHILL) Service
- New transmission service class allowing conditional interconnection
- Conditional transmission service provisions
- Curtailment protocols and priority structures
- Service eligibility and qualification criteria

### C. Cost Allocation & Rate Structures
- Transparent upgrade cost allocation mechanisms
- Point-to-Point transmission service rates (Firm and Non-Firm)
- Network Integration Transmission Service charges
- Formula rate calculations across multiple zones
- Revenue crediting and balanced portfolio reallocation
- Annual Transmission Revenue Requirements (ATRR) by zone

### D. Study & Planning Processes
- Study triggers for large load interconnection
- Integration with SPP Transmission Expansion Plan (STEP)
- Coordinated planning across Balancing Authorities
- Delivery Point evaluation processes (BP 7850)
- Generator interconnection coordination
- Material Modification assessment procedures

### E. Operational Procedures
- Day-Ahead Market execution (SCUC/SCED algorithms)
- Reliability Unit Commitment (RUC) processes
- Must-offer requirements for Market Participants
- Resource commitment hierarchies
- Local Reliability Issue management
- Emergency capacity protocols

### F. Compliance & Standards
- NAESB Standards impacts (WEQ-001, WEQ-002, WEQ-003, WEQ-021, WEQ-023)
- NERC Standards compliance
- FERC regulatory requirements
- Market Monitor oversight provisions

### G. Multi-Jurisdictional Coordination
- Balancing Authority coordination
- Interregional planning region coordination
- Adjacent transmission system impacts
- Seams agreements with other ISOs (MISO, ERCOT, etc.)

---

## 3. DECISIONS OR ACTIONS

### Requested Actions (RR696):
1. **Implement HILL Integration Framework** – Establish formal assessment procedures
2. **Create CHILL Service** – New tariff provisions for conditional large load service
3. **Revise Multiple Tariff Documents:**
   - OATT Parts I and VII
   - Schedules 1, 1A, 2, 11, 12, and new Schedule 15
   - Attachments H, L, M, O, P, T, AE, BA, BB
4. **Update Market Protocols** – Multiple sections of Version 112
5. **Modify Planning & Operating Criteria**
6. **Update Business Practices** – BP7250, BP7850, BP8100

### Established Procedural Actions (Current Tariff):

**Rate Administration:**
- Annual formula rate posting by specified deadlines (varies by zone: September 1, October 1, October 15, July 20, December 15)
- Rate effectiveness dates (typically January 1 or August 1)
- Monthly billing cycles for transmission services
- FERC Assessment Charge Rate posting by March 1 annually

**Resource Commitment:**
- SCUC algorithm prioritization for capacity shortfalls/surplus
- Manual commitment authority for reliability issues
- Market Monitor verification of non-discriminatory selections
- Operating guide development for recurring reliability issues

**Transmission Service:**
- Service request timelines (120 days to 20 minutes prior depending on service type)
- Study completion deadlines (24 hours to 60 days)
- Customer response requirements (30 minutes to 4 days)
- Energy scheduling deadlines (12:00 noon or 15:00 day prior)

**Load Forecasting:**
- Non-Conforming Load registration for loads ≥50 MW
- Hourly forecast submissions before Day-Ahead RUC
- 15-minute rolling forecasts required
- Demand Response reporting requirements

---

## 4. IMPORTANT DATES

### RR696 Submission:
- **June 30, 2025** – RR696 submitted to SPP

### Annual Recurring Deadlines:

**Rate Postings:**
- **March 1** – FERC Assessment Charge Rate effective
- **September 1** – Various formula rate postings (OPPD zone, AEP zones)
- **October 1** – Multiple formula rate postings (SPS, SECC, various zones)
- **October 15** – Evergy Kansas Central formula rate posting
- **July 20** – OPPD formula calculation results posting
- **December 15** – NPPD formula calculation results posting
- **June 15** – Tri-State formula calculation results posting

**Rate Effective Dates:**
- **January 1** – Primary effective date for most posted rates
- **August 1** – OPPD rates effective
- **July 1** – Tri-State rates effective

### Historical Reference Dates:
- **June 19, 2010** – Threshold for Base Plan Upgrade treatment (NTC issued before/after)
- **October 1, 2015** – Threshold for Network Upgrades treatment; Zone 19 grandfather provisions
- **January 1, 2008** – Cutoff for 2005 SPP Transmission Expansion Plan Zonal Reliability Upgrades

### Operational Timeframes:
- **On-Peak Hours:** HE 0700-2200 Central Prevailing Time
- **NERC Holidays:** New Year's Day, Memorial Day, Independence Day, Labor Day, Thanksgiving Day, Christmas Day
- **MCR Transition Threshold:** 30 minutes (affects Operating Reserve eligibility)
- **ICCP Failover:** 240 seconds maximum reconnection time
- **Transmission Service Request Windows:** Range from 120 days to 20 minutes prior to service

---

## 5. ORGANIZATIONS AND PEOPLE MENTIONED

### Primary Organizations:

**Southwest Power Pool (SPP)** – Regional Transmission Organization and Transmission Provider
- Markets and Operations Policy Committee
- SPP Board of Directors
- Regional State Committee
- Market Monitor
- Various working groups (ESWG, TWG, PCWG)

**Federal Regulatory/Standards Bodies:**
- **FERC (Federal Energy Regulatory Commission)** – Regulatory authority
- **NERC (North American Electric Reliability Corporation)** – Reliability standards
- **NAESB (North American Energy Standards Board)** – Business practice standards

**Adjacent ISOs/RTOs:**
- **MISO (Midcontinent Independent System Operator)**
- **ERCOT (Electric Reliability Council of Texas)**
- California Independent System Operator Corporation
- Tennessee Valley Authority

### Transmission Owners (50+ entities across 26+ zones):

**Major Utility Companies:**
- **American Electric Power (AEP)** – Multiple zones and subsidiaries
  - Public Service Company of Oklahoma
  - Southwestern Electric Power Company
  - AEP Oklahoma Transmission Company
  - AEP Southwestern Transmission Company
- **Evergy Companies:**
  - Evergy Metro, Inc.
  - Evergy Missouri West, Inc

---

# Partial Chunk Reports

# Chunk 1 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary
This document is a Revision Request (RR) #696 titled "Integrate & Operate High Impact Large Loads" submitted to Southwest Power Pool (SPP) on June 30, 2025. The request involves both system and process changes and requires an Impact Analysis. It is linked to System Impact Request (SIR) #764 and requires prioritization. This appears to be the initial submission form for addressing the integration and operational challenges associated with high-impact large electrical loads on the SPP system.

## 2. Key Topics
- Integration of high impact large loads into the electrical grid
- Operation and management of large loads
- System modifications required for large load integration
- Process changes for handling high-impact loads
- Impact analysis requirements
- SPP regulatory compliance and operational procedures

## 3. Decisions or Actions
- **System Changes Required:** Yes
- **Process Changes Required:** Yes
- **Impact Analysis Required:** Yes
- **Prioritization Needed:** Yes
- Submission accepted for processing (implied by form completion)

## 4. Important Dates
- **Submission Date:** June 30, 2025

## 5. Organizations and People Mentioned
**Organizations:**
- Southwest Power Pool (SPP)

**People:**
- Natasha Henderson (Co-submitter)
- Yasser Bahbaz (Co-submitter)

## 6. Links or References
- **RR Number:** 696
- **SIR (System Impact Request) Number:** 764
- Reference to "Comprehensive Roadmap" (no specific details provided in this chunk)
- Potential FERC Order considerations (mentioned as possible exemption criterion)

## 7. Suggested Tags
- Revision Request
- Large Loads
- System Integration
- Grid Operations
- Impact Analysis
- SPP
- System Changes
- Process Changes
- High Impact Loads
- SIR-764
- RR-696

## 8. Items That May Need Follow-Up
1. **Impact Analysis Completion:** Ensure the required Impact Analysis is conducted and documented
2. **Prioritization Process:** Track the prioritization decision and timeline
3. **System Changes:** Define specific system modifications needed
4. **Process Changes:** Document detailed process change requirements
5. **SIR #764 Coordination:** Ensure alignment between this RR and the related System Impact Request
6. **Comprehensive Roadmap:** Review connection to broader strategic planning
7. **Stakeholder Engagement:** Identify and engage affected parties for large load integration
8. **Implementation Timeline:** Establish once prioritization is complete
9. **Cost Estimates:** Develop budget requirements for system and process changes
10. **Regulatory Approvals:** Determine if FERC or other regulatory approval is needed

---
**Note:** This analysis is based on chunk 1 of 26. Subsequent chunks may contain additional details, technical specifications, stakeholder comments, and implementation plans that would provide more comprehensive information.

---

# Chunk 2 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This is a Revision Request (RR696) submitted to Southwest Power Pool (SPP) seeking to establish a formal framework for integrating and operating High Impact Large Loads (HILLs). The request proposes creating a new "Conditional High Impact Large Load (CHILL) Service" to enable large-scale industrial, computational, and electrolyzer loads to interconnect with the transmission grid through standardized, transparent processes. The submitters are requesting **expedited resolution** due to the growing wave of multi-megawatt projects across the SPP footprint and the current lack of formal procedures causing uncertainty, delayed investments, and reliability risks. The RR would impact multiple SPP governing documents including the Tariff, Market Protocols, Operating Criteria, Planning Criteria, and various Business Practices.

## 2. Key Topics

- **High Impact Large Load (HILL) Integration Framework**: Establishing formal procedures for assessing and interconnecting large loads
- **New CHILL Service**: Creating a Conditional High Impact Large Load service allowing interconnection with conditional transmission service
- **Standardization**: Implementing consistent study triggers, interconnection processes, and system impact evaluations
- **Cost Allocation**: Establishing transparent upgrade cost allocation mechanisms
- **Multi-jurisdictional Coordination**: Coordinating across Balancing Authorities within SPP footprint
- **NAESB Standards Compliance**: Impacts to WEQ-001, WEQ-002, WEQ-003, WEQ-023, and WEQ-021 standards
- **Load Predictability**: Improving planning reserve margin requirements through better load forecasting
- **Grid Reliability**: Ensuring proper study and modeling before interconnection

## 3. Decisions or Actions

**Requested Actions:**
- Implement HILL integration assessment framework
- Create new CHILL Service provisions
- Revise multiple SPP governing documents (Tariff Parts I and VII, Schedules 1, 1A, 2, 11, 12, new Schedule 15, multiple Attachments)
- Update Market Protocols Version 112 (multiple sections)
- Modify Operating Criteria, Planning Criteria, and Business Practices
- Establish standardized processes for load interconnection studies

**Type of Revision:**
- Enhancement (expanding existing intent/functionality)
- New Protocol provisions (new CHILL Service)
- NAESB Standard impacts identified

## 4. Important Dates

**No specific dates are explicitly mentioned in this chunk**, but the request indicates:
- **Urgency driver**: "Growing wave" of developments already underway
- **Timeline pressure**: Multiple multi-megawatt projects in progress with more expected under federal and state incentives
- Request type: **Expedited resolution** (not Normal or Urgent Action)

## 5. Organizations and People Mentioned

**Contacts:**
- **Nate Henderson** (nhenderson@spp.org)
- **Yasser Bahbaz** (ybahbaz@spp.org)

**Organizations:**
- **SPP (Southwest Power Pool)**: Transmission Provider/RTO
- **NERC**: Standards authority referenced
- **FERC**: Regulatory authority referenced
- **NAESB**: Standards organization (multiple WEQ standards referenced)
- **Transmission Owners**: Including American Electric Power (Zone 1), Southwestern Public Service (Zone 11)

**Zones Mentioned:**
- Zone 1 (American Electric Power territory)
- Zone 11 (Southwestern Public Service territory)

## 6. Links or References

**Standards Referenced:**
- NAESB WEQ-001: OASIS TSR process
- NAESB WEQ-002: Scheduling and confirmation standards
- NAESB WEQ-003: Standardized data for OASIS entries
- NAESB WEQ-023: Load and model submission standards
- NAESB WEQ-021: Demand-side participation standards
- NERC Standards (general reference, specific standards not listed in this chunk)

**Documents Requiring Revision:**
- SPP Open Access Transmission Tariff (Parts I, VII; Schedules 1, 1A, 2, 11, 12, 15; Attachments H, L, M, O, P, T, AE, BA, BB)
- Market Protocols Version 112 (Sections: Glossary, 4.2.1.1, 4.3.1.2, 4.3.2.2, 4.4.1.3, 6.1.1.7, 6.2.2, 6.2.9, 6.2.9.1)
- Operating Criteria (Sections 3.6, 5.2)
- Planning Criteria (Sections 5.1, 5.2, 5.6)
- Business Practices: BP7250, BP7850, BP8100
- ITP Manual (Sections 2.1.3, 4.4)

## 7. Suggested Tags

- High Impact Large Loads (HILL)
- Conditional High Impact Large Load (CHILL)
- Load Interconnection
- Transmission Service
- Data Centers
- Industrial Loads
- Electrolyzer Plants
- Grid Reliability
- NAESB Standards
- Cost Allocation
- Planning Reserve Margin
- Expedited Process
- Load Growth
- System Impact Studies
- Balancing Authority Coordination
- Market Efficiency
- RR696

## 8. Items That May Need Follow-Up

1. **Expedited Resolution Justification**: Verify stakeholder support for expedited vs. normal timeline given the scope of document changes

2. **NAESB Standards Coordination**: Confirm alignment with five cited NAESB WEQ standards and whether NAESB coordination is required

3. **Cost-Benefit Analysis**: Quantify the stated benefits:
   - "Reduction in planning reserve margin requirements"
   - "Avoidance of transmission upgrades or congestion costs"
   - "Quantified curtailment reduction"
   - "Cost savings from fewer emergency procedures"
   - "Increase in study efficiency"

4. **Stakeholder Engagement**: Identify affected parties across all SPP zones (only Zones 1 and 11 specifically mentioned)

5. **FERC Filing Strategy**: Determine if FERC pre-approval or coordination needed given extensive Tariff changes

6. **Implementation Timeline**: Develop detailed implementation schedule for multiple document revisions across different systems

7. **NERC Compliance Review**: Complete analysis of NERC Standard impacts (flagged but not detailed in this chunk)

8. **Existing Projects**: Determine treatment of HILL projects already in queue or under development

9. **Conditional Service Terms**: Define specific conditions under which CHILL service would be granted/curtailed

10. **Inter-BA Coordination Protocols**: Develop detailed procedures for multi-BA coordination mentioned as objective

11. **Risk Assessment**: Complete risk analysis for identified drivers:
    - Compliance risks
    - Reliability/Operations risks (insufficient standards, limited transparency)
    - Financial risks (loss of business, load growth uncertainty)

12. **Qualified Entity Status**: Confirm submitter's Qualified Entity status (field left blank in form)

---

# Chunk 3 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary

This document contains detailed tariff schedules from SPP's (Southwest Power Pool) transmission service tariff, specifically covering Schedule 1-A (Transmission Administration Service), Schedule 1 (Scheduling, System Control and Dispatch Service), and Schedule 2 (Reactive Supply and Voltage Control from Generation or Other Sources Service). The content establishes billing methodologies, rate calculations, cost recovery mechanisms, and service definitions for transmission customers. Key elements include billing determinants based on load characteristics, zonal rate structures, and specific formulas for calculating charges to transmission customers taking either Point-to-Point or Network Integration Transmission Service.

## 2. Key Topics

- **Schedule 1-A1 Transmission Administration Service**: Covers reliability coordination, transmission scheduling, system control, and transmission planning services with a rate cap of $0.515
- **Billing Determinants**: Different methodologies for Network Integration vs. Point-to-Point transmission services
- **Zonal Rate Structure**: Separate calculations for different zones within the SPP Region
- **Through and Out vs. Sinking Transactions**: Different charging mechanisms based on transaction type
- **Schedule 1 Revenue Requirements**: Adjustments for Point-to-Point revenues received by Transmission Owners
- **Reactive Power Compensation**: $2.26 per MVArh rate for Qualified Generators (QGs)
- **Dead Band Calculations**: Power factor of 0.95 used to determine compensable reactive power
- **On-Peak vs. Off-Peak Periods**: HE 0700-2200 Central Prevailing Time on weekdays (excluding NERC holidays)

## 3. Decisions or Actions

- **Rate Cap Established**: Schedule 1-A1 Recoverable Costs shall not exceed $0.515
- **Reactive Compensation Rate Set**: Fixed at $2.26 per MVArh
- **Annual Rate Determination**: Transmission Provider will determine Schedule 1-A1 Service rate annually
- **Periodic Review Authority**: Transmission Provider may periodically review the Reactive Compensation Rate (RCR)
- **Revenue Requirement Adjustments**: Specific procedures established for adjusting Schedule 1 RR based on Point-to-Point revenues
- **Billing Cycle Process**: SPP shall bill customers in the next billing cycle after calculating monthly RPOD (Reactive Power Outside Dead Band)

## 4. Important Dates

- **Annual Update Cycle**: Calendar year basis for rate calculations
- **Prior Calendar Year**: Used for calculating 12-month average coincident peak demands
- **Monthly Calculations**: All Schedule 2 amounts calculated monthly with no true-ups
- **On-Peak Hours**: HE 0700 through HE 2200 Central Prevailing Time
- **Off-Peak Days**: Saturdays, Sundays, and all NERC holidays
- **Rate Division Periods**: 
  - Yearly rate divided by 12 (monthly)
  - Divided by 52 (weekly)
  - Divided by 260 (daily on-peak)
  - Divided by 365 (daily off-peak)

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)**: Transmission Provider and Balancing Authority
- **NERC (North American Electric Reliability Corporation)**: Referenced for holiday schedules
- **Transmission Owners**: Multiple entities within SPP Region
- **Transmission Customers**: Network Customers and Point-to-Point customers
- **Qualified Generators (QGs)**: Generation facilities providing reactive power

**Note**: No specific individual names are mentioned in this content.

## 6. Links or References

- **Addendum 1 of Schedule 1-A**: Contains formula rate template
- **Revenue Requirements and Rates File (RRR File)**: Posted on SPP website, Schedule 1 tab
- **Zonal Sch 1 tab**: Within RRR file for multi-owner zones
- **Table 1**: Schedule 1 RR (Revenue Requirements)
- **Table 2 of Schedule 1**: Lists Point-to-Point revenues already credited
- **Section 31.4**: Regarding Network Load designation for loads not physically interconnected
- **SPP website**: Where RRR File is posted

## 7. Suggested Tags

- Transmission Tariff
- Rate Design
- Schedule 1-A
- Schedule 1
- Schedule 2
- Billing Determinants
- Reactive Power
- Network Integration Transmission Service
- Point-to-Point Transmission Service
- Zonal Rates
- Cost Recovery
- Revenue Requirements
- SPP
- Ancillary Services
- Voltage Control
- System Control
- Dispatch Service
- Transmission Administration

## 8. Items That May Need Follow-Up

1. **Rate Cap Compliance**: Monitoring whether Schedule 1-A1 Recoverable Costs remain below $0.515 threshold
2. **RCR Review Timeline**: No specific timeline provided for periodic review of $2.26/MVArh reactive compensation rate - need clarification on review schedule
3. **Grandfathered Agreements**: Incomplete information on treatment of load served under Grandfathered Agreements
4. **Formula Rate Updates**: Verification needed on which Transmission Owners have formula rates with annual updates vs. stated rates
5. **Monthly RPOD Data Availability**: Timing of data availability for billing purposes not fully specified
6. **Schedule 2 Revenue Distribution**: Document appears cut off at "In the event that the monthly revenue collected for a Zone do" - completion needed
7. **Multi-owner Zone Coordination**: Process for coordinating rate calculations among multiple Transmission Owners in same zone
8. **True-up Mechanisms**: Schedule 2 explicitly states "no true-ups" but over/under recovery adjustment mentioned for Schedule 1-A - reconciliation needed
9. **Posting Requirements**: Specific timeline for SPP to post Schedule 2 charges after data becomes available

---

# Chunk 4 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary
This document (chunk 4 of 26) from RR696 contains detailed tariff schedules governing transmission service charges and compensation mechanisms within the SPP (Southwest Power Pool) transmission system. The content primarily covers three schedules: compensation for Qualifying Generators (QGs), Base Plan Zonal and Region-wide Charges (Schedule 11), and FERC Assessment Charges (Schedule 12). Key provisions address revenue distribution methodologies, load calculation requirements, zone-specific charge applications, and exemptions for Western-UGP operations. The document establishes Commission-approved mechanisms for cost recovery and revenue allocation across multiple transmission zones.

## 2. Key Topics

- **Joint Ownership and Multiple Generator Compensation**: Compensation protocols for jointly owned qualifying generators and multiple generators behind common meters
- **Base Plan Zonal Charges**: Calculation methodologies for annual transmission revenue requirements across multiple zones
- **Region-wide Charges**: Assessment framework for Network Customers and Transmission Owners based on Resident Load
- **Western-UGP Exemptions**: Special exemptions from Region-wide Charges for Western-UGP Federal Service
- **Revenue Requirement Calculations**: Complex formulas incorporating point-to-point revenue, Energy and Operating Reserve Market dispatches, and SATOA revenue
- **Load Ratio Share Determinations**: Zone-specific and region-wide load calculation methodologies
- **FERC Assessment Recovery**: Annual charge mechanism for recovering FERC assessments based on interstate energy transmission
- **Zone-Specific Provisions**: Special provisions for Zones 10 and 19, including Federal Power considerations

## 3. Decisions or Actions

- Transmission Provider must individually certify all generators behind a single meter as QGs
- Transmission Provider compensates only the designated entity for jointly owned QGs (not responsible for disbursing to other owners)
- Revenue adjustments must be set forth in the RRR File for previous calendar year point-to-point revenue
- Transmission Provider shall calculate and post the FERC Assessment Charge Rate (FACR) on the SPP website prior to March 1 of each year
- Network Customers/Transmission Owners must pay monthly Base Plan Zonal Charges based on their Load Ratio Share
- Charges under Schedule 11 cannot be changed absent a filing with the Commission
- For formula rate Transmission Owners, annual credits are updated in the formula rate to avoid double-counting

## 4. Important Dates

- **Prior to March 1 annually**: Transmission Provider must calculate and post FERC Assessment Charge Rate
- **Monthly**: Base Plan Zonal Charges and Region-wide Charges assessed (calculated as 1/12 of annual requirement)
- **Annual basis**: Revenue adjustments for point-to-point revenue, Attachment AU distributions, and SATOA dispatch revenue
- **Previous calendar year**: Reference period for revenue adjustments in annual transmission revenue requirement calculations

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)** - Transmission Provider
- **FERC/Commission** - Federal Energy Regulatory Commission (regulatory authority)
- **Western-UGP** - Western Upper Great Plains (entity with special exemptions)
- **Network Customers** - Service recipients under network transmission service
- **Transmission Owners** - Entities owning transmission facilities
- **Transmission Customers** - Point-to-Point service recipients
- **SATOA** - (Specific entity type with ATRR recovered through Schedule 11)

### People:
- None specifically mentioned

## 6. Links or References

### Internal Document References:
- **Part V of this Tariff** - Governing provisions for Base Plan charges
- **Attachment J** - Cost allocation methodology
- **Attachment AU** (Sections IV and V) - Revenue distribution and allocation
- **Attachment H** (Table 3, Section 1; Section I, Tables 2-A and 2-B) - Annual transmission revenue requirements
- **Schedule 2** - Related revenue collection provisions
- **Schedule 11** (Section III) - Point-to-Point charges
- **Section 31.3** - Network Load designation provisions
- **Section 34.5** - Transmission System load determination
- **Section 34.9** - Federal-Power Southwestern identification
- **Section 39.2** - Bundled Retail and Grandfathered Loads provisions
- **Section 39.3(e)** - Western-UGP exemption provisions

### External References:
- **FERC Form 582** - Annual reporting form for megawatt-hours transmitted
- **Part 382 of Commission regulations** - FERC Assessment regulations

## 7. Suggested Tags

- Transmission_Tariff
- Revenue_Requirements
- Zonal_Charges
- FERC_Assessment
- Load_Ratio_Share
- Point-to-Point_Service
- Network_Integration_Service
- Western-UGP_Exemption
- Qualifying_Generators
- SPP_Tariff
- Schedule_11
- Schedule_12
- Cost_Recovery
- Transmission_Revenue
- Interstate_Commerce
- Federal_Power
- Joint_Ownership
- Formula_Rate

## 8. Items That May Need Follow-Up

1. **RRR File Contents**: Clarification needed on what specific information must be included in the RRR (Revenue Requirements) File and who has access
2. **SATOA Definition**: The acronym "SATOA" is used but not defined in this chunk; definition and qualification criteria needed
3. **Western-UGP Federal Service Exemption Scope**: Detailed boundaries of what qualifies for exemption from Region-wide Charges require verification
4. **Zone Boundary Definitions**: Specific geographic/operational definitions for Zones 1-19, particularly special zones 10 and 19
5. **Double Credit Prevention**: Verification mechanism needed to ensure stated rate Transmission Owners properly account for Schedule 11 revenue credits
6. **FACR Formula Completion**: The formula in Schedule 12 Section 3 appears truncated ("Where: y Year in wh...") and needs completion
7. **Multiple Generator Certification Process**: Specific procedures and timeline for individually certifying generators behind common meters
8. **Monthly Peak Determination**: Methodology for determining "monthly peak" for coincident load calculations across zones
9. **Western vs. Eastern Interconnection**: Clear delineation criteria for service "taken in whole or in part within the Eastern Interconnection"
10. **Federal Power-Western-UGP Load Exclusion**: Verification process for properly excluding statutory load obligations from Zone 19 calculations

---

# Chunk 5 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document (chunk 5 of 26) from RR696 contains detailed tariff provisions related to transmission service billing and revenue requirements within the Southwest Power Pool (SPP) region. The content primarily focuses on FERC Assessment Charge Rate calculations (Schedule 12), Annual Transmission Revenue Requirements (ATRR) for Network Integration Transmission Service (Attachment H), and specific provisions for individual Transmission Owners. Key elements include billing procedures, zonal and region-wide revenue requirement allocations, and transmission owner-specific formula rate requirements.

## 2. Key Topics

- **FERC Assessment Charge Rate (FACR) billing methodology** - Schedule 12 procedures
- **Annual Transmission Revenue Requirements (ATRR)** - Multiple categories including:
  - Zonal ATRR
  - Base Plan Zonal ATRR
  - Region-wide ATRR
  - Balanced Portfolio Region-wide ATRR
  - Interregional Planning Region ATRR
- **Network Integration Transmission Service charges** (Schedule 9)
- **Base Plan Upgrades** with different treatment for NTC issued before/after June 19, 2010
- **Revenue requirement allocation methodologies** via Attachment J
- **Formula rate processes** for Commission-approved transmission owners
- **Point-to-Point Transmission Service** revenue crediting (Schedule 11)
- **Transmission owner-specific requirements** (SPS and American Electric Power)

## 3. Decisions or Actions

- **FERC Assessment Charge Rate effective date**: March 1 of each year
- **Formula rate posting requirement**: Transmission Owners must post populated formula rates on SPP website by **October 1** of each calendar year
- **Formula rate effective date**: January 1 of the following year
- Revenue requirements posted on SPP website via Revenue Requirements and Rates File (RRR File)
- Transmission Provider authorized to update revenue requirements upon successful completion of approved annual formula rate update procedures
- Commission filing required for revenue requirement changes unless utilizing Commission-approved formula rate processes

## 4. Important Dates

- **March 1** - Annual effective date for FERC Assessment Charge Rate
- **June 19, 2010** - Threshold date differentiating Base Plan Upgrade treatment (NTC issued before vs. after)
- **October 1, 2015** - Threshold date for Network Upgrades treatment (different Region-wide ATRR calculations apply)
- **October 1** (annual) - Deadline for posting formula calculation results on SPP and SPS OASIS websites
- **January 1** (annual) - Effective date for new Existing Zonal ATRR for Zone 11

## 5. Organizations and People Mentioned

### Organizations:
- **FERC (Federal Energy Regulatory Commission)** - Regulatory authority
- **Southwest Power Pool (SPP)** - Transmission Provider
- **Southwestern Public Service Company (SPS)** - Transmission Owner for Zone 11
- **Xcel Energy Operating Companies** - Parent/affiliate of SPS
- **American Electric Power (AEP)** - Transmission Owner
- **Associated Electric Cooperative, Inc.** - Party to cost sharing agreements
- **Transmission Owners** (various, referenced collectively)
- **Transmission Customers** - Service recipients
- **Upgrade Sponsors** - Entities paid under Attachment Z2

### Specific Projects Mentioned:
- Morgan Transformer Project
- Blackberry Substation Upgrade

### People:
- None specifically mentioned

## 6. Links or References

### Tariff Sections/Schedules Referenced:
- **Section 7** - Billing procedures
- **Section 39.2** - Coverage for Transmission Owners
- **Schedule 7 and 8** - Revenue provisions
- **Schedule 9** - Network Integration Transmission Service charges
- **Schedule 11** - Base Plan Upgrades charges and Point-to-Point Service
- **Schedule 12** - FERC Assessment Charges

### Attachments Referenced:
- **Attachment H** - Annual Transmission Revenue Requirements (current document)
- **Attachment J** - Revenue requirement allocation procedures
- **Attachment L** - Point-to-Point transmission revenue allocation
- **Attachment O** - General reference; includes Addendum 1 coordination agreements
- **Attachment O - SPS** (Xcel Energy OATT) - SPS formula rate specifications
- **Attachment Z2** - Upgrade Sponsor payment provisions
- **Attachment AU (Sections IV and V)** - Revenue distribution and allocation
- **Addendum 1 to Attachment H** - AEP formula rate (referenced but not shown)

### External Documents:
- **Xcel Energy Operating Companies Joint Open Access Transmission Tariff** (Xcel Energy OATT)
- **Revenue Requirements and Rates File (RRR File)** - Posted on SPP website
- **Cost Sharing and Usage Agreement Between Southwest Power Pool, Inc. and Associated Electric Cooperative, Inc.**
- **OASIS website** (SPS) - Formula rate posting location

### Specific Terms Defined:
- JTIQ ATRR Balance - defined in Part I, Section 1 of the Tariff
- JTIQ Upgrades
- SATOA (appears to be a market participant type)

## 7. Suggested Tags

- FERC_Assessment_Charges
- Annual_Transmission_Revenue_Requirements
- ATRR
- Network_Integration_Service
- Schedule_9
- Schedule_11
- Schedule_12
- Transmission_Rates
- Formula_Rates
- SPP_Tariff
- Base_Plan_Upgrades
- Region_Wide_Charges
- Zonal_Charges
- Southwestern_Public_Service
- American_Electric_Power
- Revenue_Requirements
- Point_to_Point_Service
- Attachment_H
- Billing_Procedures
- FERC_Regulatory

## 8. Items That May Need Follow-Up

1. **Incomplete document section** - The American Electric Power section (Section II.2) appears cut off mid-sentence; full formula rate provisions need review

2. **Tables not included** - Multiple tables referenced but marked as "See Note" with content on SPP website:
   - Table 1 (Zonal ATRR values)
   - Table 2-A (Region-wide ATRR pre-October 1, 2015)
   - Table 2-B (Region-wide ATRR post-October 1, 2015)
   - Table 3 (Revenue credits)
   - Actual numerical values need verification from RRR File

3. **Formula rate protocols** - Section 5 references "applicable protocols and/or procedures" but specifics not detailed in this chunk

4. **Section 34.1 reference** - SPS exemption from "adjustment pursuant to section 34.1" mentioned but section not included here

5. **JTIQ definition** - JTIQ ATRR Balance and JTIQ Upgrades referenced but definition location noted as "Part I, Section 1" (not in this chunk)

6. **SATOA definition** - Term used but not defined in this section

7. **Addendum 1 to Attachment O** - Referenced for coordination agreements but list not provided here

8. **Addendum 1 to Attachment H** - AEP formula rate referenced but not included in this chunk

9. **Zone 19 distinction** - Note indicates different treatment for Zone 19 vs. Zones 1-18; context for this differentiation unclear

10. **Annual update deadlines** - Verify compliance timing for October 1 posting requirement and coordination with January 1 effective date

11. **Morgan Transformer Project and Blackberry Substation Upgrade** - Cost sharing agreements mentioned; may need review of underlying agreements for completeness

12. **Interregional Project coordination** - Multiple references to interregional planning but coordination mechanisms not detailed in this chunk

---

# Chunk 6 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document is a section of regulatory tariff language (Attachment H and J) governing the recovery of costs for canceled network upgrade projects and new transmission facilities within the SPP (Southwest Power Pool) system. It details specific cost recovery mechanisms for American Electric Power (AEP) and Sunflower Electric Power Corporation for canceled transmission projects, establishes procedures for Southwestern Power Administration's rate calculations, and outlines policies for Sponsored Upgrades and Service Upgrades. The document specifies precise dollar amounts, recovery periods, filing requirements, and allocation methodologies in accordance with FERC regulations.

## 2. Key Topics

- **Cost Recovery for Canceled Network Upgrade Projects**
  - AEP: Two sets of canceled projects totaling $3,264,402.55 and $414,465
  - Sunflower Electric Power Corporation: $718,359 for canceled project
  - 12-month recovery periods with monthly installments

- **Annual Transmission Revenue Requirement (ATRR) Procedures**
  - Recovery through Schedule 11
  - Allocation pursuant to Attachment J
  - Interest calculations per 18 C.F.R. § 35.19a(a)(2)(iii)

- **RRR File Maintenance and Commission Notifications**
  - Joint informational filings required upon full recovery
  - Property disposition credit mechanisms

- **Southwestern Power Administration Rate Calculations**
  - NITS ATRR component methodology
  - 872,000 kilowatt total capacity baseline
  - Formula Rate Posting Information Notification List procedures

- **Sponsored Upgrades and Service Upgrades**
  - Direct cost assignment mechanisms
  - Payment options (lump sum or periodic charges)
  - ILTCR (Incremental Long-Term Congestion Rights) eligibility
  - 20-year plant life depreciation standard

## 3. Decisions or Actions

**Established Cost Recovery Programs:**
- AEP authorized to recover $3,264,402.55 commencing April 1, 2018
- AEP authorized to recover $414,465 commencing March 1, 2019
- Sunflower Electric Power Corporation authorized to recover $718,359 commencing January 1, 2024

**Required Actions:**
- SPP and respective utilities must make joint informational filings to FERC upon:
  - Full recovery of canceled project costs
  - Sale or disposition of property during recovery period
- Transmission Provider must file Sponsored Upgrade Agreements with good faith cost estimates
- True-up of costs to actual construction costs upon project completion
- Project Sponsors must execute Attachment AH if receiving ILTCRs and not already a Market Participant

**Procedural Requirements:**
- Southwestern Power Administration must provide supporting documentation for NITS ATRR calculations
- Electronic notice required through Formula Rate Posting Information Notification List
- Monthly posting requirements on SPP website

## 4. Important Dates

- **October 31** (annually): PP website posting deadline
- **January 1** (following year): Changes become effective
- **April 1, 2018**: AEP cost recovery commencement for $3,264,402.55
- **March 1, 2019**: AEP cost recovery commencement for $414,465
- **January 1, 2024**: Sunflower Electric Power Corporation cost recovery commencement for $718,359
- **April 2017**: Reference date for Exploder List access information
- **12-month periods**: Standard recovery timeframe for all canceled project costs
- **20 years**: Standard plant life for depreciation and periodic payment terms
- **10-20 years**: ILTCR term range

## 5. Organizations and People Mentioned

**Organizations:**
- **American Electric Power (AEP)** - Transmission Owner recovering costs for multiple canceled projects
- **Sunflower Electric Power Corporation** - Transmission Owner recovering costs for canceled project
- **Southwestern Power Administration (Western-UGP)** - Federal power marketing administration with special rate calculation procedures
- **Southwest Power Pool (SPP)** - Transmission Provider and regional transmission organization
- **Federal Energy Regulatory Commission (FERC/Commission)** - Regulatory authority requiring filings and approvals
- **Transmission Owners** - Generic reference to entities owning transmission facilities
- **Project Sponsors** - Entities voluntarily funding Sponsored Upgrades
- **Transmission Customers** - Service recipients potentially receiving credits or ILTCRs

**No individual persons named in this section**

## 6. Links or References

**External References:**
- http://www.spp.org/stakeholder-center/exploder-lists/ (Exploder List access as of April 2017)

**Internal Document References:**
- Attachment H (containing Table 1, Column 3, various rows)
- Attachment J (Sections V, VII, VIII)
- Attachment Z1 (cost allocation for Service Upgrades)
- Attachment Z2 (transmission revenue credits and ILTCRs, Sections I, II, IV)
- Attachment AH (Market Participant requirements)
- Schedule 1 (Sponsored Upgrade Agreement description)
- Schedule 11 (cost recovery mechanism)
- Section 2.3.3 of Rate Schedule NFTS-13A (Southwestern Power Administration capacity)
- Addendum 20 of Attachment H (Sunflower rate establishment)

**Regulatory Citations:**
- Federal Power Act
- 18 C.F.R. § 35.19a(a)(2)(iii) (interest rate regulations)

**Supporting Documents:**
- RRR File (recurring reference for cost tracking)
- Power Repayment Study (Southwestern Power Administration)
- Agreement for Sponsored Upgrade

## 7. Suggested Tags

- Cost Recovery
- Canceled Projects
- Network Upgrades
- ATRR (Annual Transmission Revenue Requirement)
- FERC Filings
- Transmission Tariff
- American Electric Power
- Sunflower Electric Power
- Southwestern Power Administration
- SPP Tariff
- Attachment H
- Attachment J
- Sponsored Upgrades
- Service Upgrades
- ILTCR (Incremental Long-Term Congestion Rights)
- Revenue Credits
- Rate Schedule
- RRR File
- Joint Informational Filing
- Property Disposition
- 345 kV Projects
- 138 kV Projects
- 115 kV Projects
- 12-Month Recovery Period

## 8. Items That May Need Follow-Up

**Monitoring Requirements:**
1. **Recovery Period Tracking**: Monitor completion of 12-month recovery periods for:
   - AEP's $3,264,402.55 (began April 1, 2018 - should be completed)
   - AEP's $414,465 (began March 1, 2019 - should be completed)
   - Sunflower's $718,359 (began January 1, 2024 - currently in progress)

2. **Joint Informational Filings Due**: Verify that SPP and utilities filed required notifications upon full cost recovery

3. **Property Disposition Tracking**: Monitor whether any property from canceled projects has been sold or disposed of, triggering credit obligations

**Verification Needs:**
4. **Interest Calculation Verification**: Confirm interest calculations comply with 18 C.F.R. § 35.19a(a)(2)(iii) for AEP's first recovery amount

5. **RRR File Updates**: Verify RRR File reflects current status of all canceled project cost recoveries and $0 replacement upon completion

6. **Website Posting Compliance**: Confirm annual October 31 postings to PP website and January 1 effective dates are being maintained

**Policy Questions:**
7. **Southwestern Power Administration Ratio Calculations**: Verify current capacity utilization ratios and whether Power Repayment Study has been updated

8. **Formula Rate Notification List**: Confirm exploder list link is current (reference from April 2017 may be outdated)

9. **ILTCR Election Status**: Track which Project Sponsors/Transmission Customers elected ILTCRs vs. revenue credits for ongoing projects

**Potential Issues:**
10. **Canceled Project Identification**: Investigate reasons for project cancellations to identify systemic issues:
    - Multi-Shipe Road - East Rogers - Kings River 345 kV (Network Upgrades 10656, 10659, 10660)
    - Line - Georgia

---

# Chunk 7 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary
This document excerpt (chunk 7 of 26) from RR696 details tariff provisions for cost allocation and revenue distribution related to transmission service within the SPP (Southwest Power Pool) system. The content focuses on three main areas: (1) allocation of costs for Interconnection-related Network Upgrades with ILTCR (Incremental Long Term Congestion Rights) compensation mechanisms, (2) treatment of Zonal Reliability Upgrades and JTIQ (Joint Transmission Interconnection Queue) Upgrades, and (3) detailed revenue distribution methodologies for both Network Integration Transmission Service and Point-To-Point Transmission Service across single-owner and multi-owner zones. The document establishes specific procedures for handling Grandfathered Agreements and outlines complex formulas for distributing revenues among multiple Transmission Owners within zones.

## 2. Key Topics
- **ILTCR (Incremental Long Term Congestion Rights) Allocation**: Compensation mechanism for customers funding transmission upgrades
- **Generation Interconnection Related Network Upgrades**: Cost allocation and JTIQ Generator Charges
- **Zonal Reliability Upgrades**: Cost allocation methods depending on timing and SPP Transmission Expansion Plan inclusion
- **JTIQ Upgrades**: Integration into Region-wide Charge calculation
- **Grandfathered Agreements**: Treatment and revenue allocation procedures
- **Revenue Distribution Methodologies**: For Network Integration Transmission Service (Schedule 9)
- **Single-Owner vs. Multi-Owner Zones**: Different revenue distribution approaches
- **OZRR (Owner-Specific Zonal Annual Revenue Requirement)**: Calculation and adjustment procedures
- **Creditable Upgrades**: Revenue attribution under Tariff Attachment Z2
- **Point-To-Point Transmission Service**: Revenue distribution (Schedules 7 and 8)
- **Zone 1 Special Provisions**: Unique treatment for American Electric Power zone
- **Zone 19 Special Provisions**: Grandfather provisions for Network Load designated before October 1, 2015

## 3. Decisions or Actions
- ILTCR terms must be specified in agreements with minimum 10-year and maximum 20-year duration
- Candidate ILTCR MW and source-to-sink paths must be included in Transmission Service Agreements or generator interconnection agreements
- Interconnection Customers assigned Directly Assigned Upgrade Costs are eligible for ILTCR compensation
- Zonal Reliability Upgrades from 2005 SPP Transmission Expansion Plan placed in service before January 1, 2008 follow Section III allocation
- All other Zonal Reliability Upgrades are included in Zonal Annual Transmission Revenue Requirement
- JTIQ ATRR Balance included in Region-wide Charge per Attachments L and AV
- Transmission Provider has no claim to revenues under Grandfathered Agreements (except by mutual agreement)
- Revenue distribution follows specific formulas based on zone ownership structure
- Dispute resolution procedures or FERC determination available for Grandfathered Agreement disputes
- Zone 1 Transmission Owners (other than AEP) receive revenue based on formula: (1 - Load Ratio Share) × OZRR

## 4. Important Dates
- **January 1, 2008**: Cutoff date for Zonal Reliability Upgrades from 2005 SPP Transmission Expansion Plan requiring specific cost allocation treatment
- **October 1, 2015**: Grandfather date for Zone 19 Network Load designated outside Transmission Provider's System (receives special revenue distribution treatment)
- **Minimum 10 years, Maximum 20 years**: Term range for ILTCR agreements

## 5. Organizations and People Mentioned
**Organizations:**
- SPP (Southwest Power Pool) - Transmission Provider
- FERC (Federal Energy Regulatory Commission) - Dispute resolution authority
- American Electric Power - Specifically named as primary Transmission Owner in Zone 1
- Transmission Owners (various, unnamed specific entities)
- Interconnection Customers
- JTIQ Generation Interconnection Customers
- Network Customers
- Native Load Customers

**Zones Referenced:**
- Zone 1 (American Electric Power zone with special provisions)
- Zone 19 (with October 2015 grandfather provision)
- Multi-owner zones (unspecified)

**No individual people are mentioned by name in this excerpt.**

## 6. Links or References
**Internal Tariff References:**
- Attachment Z2 (Section IV) - ILTCR provisions and Creditable Upgrades
- Attachment V - Generation interconnection Network Upgrade cost allocation
- Section III of this Attachment - Zonal Reliability Upgrade cost allocation
- Attachments L and AV - JTIQ ATRR Balance calculation
- Attachment L (this document) - Revenue treatment provisions
- Attachment H - Zonal Annual Transmission Revenue Requirements
- Section 31.4 of the Tariff - Network Load designation outside Transmission System
- Section 34.4 of the Tariff - Load Ratio Share calculation
- Section 39 - Transmission service provisions
- Section IV of Attachment L - Additional Point-To-Point revenue provisions
- Schedule 7 - Point-To-Point rates (short-term)
- Schedule 8 - Point-To-Point rates (long-term)
- Schedule 9 - Network Integration Transmission Service rates

**External References:**
- 2005 SPP Transmission Expansion Plan

## 7. Suggested Tags
- Transmission Cost Allocation
- Revenue Distribution
- ILTCR
- Network Upgrades
- Generation Interconnection
- JTIQ
- Grandfathered Agreements
- Zonal Reliability Upgrades
- Point-to-Point Transmission
- Network Integration Transmission Service
- SPP Tariff
- OZRR
- Multi-Owner Zones
- Creditable Upgrades
- Load Ratio Share
- FERC Regulation
- Transmission Rights
- Rate Recovery

## 8. Items That May Need Follow-Up

**Policy/Implementation Questions:**
1. What is the current status of Grandfathered Agreements within multi-owner zones and how are disputes being resolved?
2. How are the hypothetical NITS payments calculated for Transmission Owners not taking Network Integration Transmission Service for Native Load?
3. What procedures exist for verifying that Grandfathered Agreement charges/credits are properly reflected in OZRR adjustments?
4. How is the distinction between "Directly Assigned Upgrade Costs" and other generator interconnection costs being applied in practice?

**Compliance/Monitoring Needs:**
5. Are all ILTCR agreements properly specifying 10-20 year terms as required?
6. Are Zone 19 Network Customers with pre-October 1, 2015 designations properly identified and receiving correct revenue treatment?
7. Is the revenue distribution formula for Zone 1 being correctly applied for non-AEP Transmission Owners?
8. How is compliance with the Creditable Upgrades revenue attribution provisions (Attachment Z2) being tracked?

**Clarification Needed:**
9. What constitutes "mutual agreement" sufficient to allow Transmission Provider claim to Grandfathered Agreement revenues?
10. Under what circumstances would Network Load "not physically connected with the Transmission System" be excluded from Load Ratio Share calculations?
11. What are the specific dispute resolution procedures referenced for Grandfathered Agreement treatment disagreements?
12. How is the distinction made between upgrades eligible for ILTCR compensation versus those not eligible?

**Process/Procedural:**
13. What documentation is required to establish candidate ILTCR MW and source-to-sink paths in agreements?
14. What is the annual true-up process for OZRR adjustments related to Grandfathered Agreements?
15. How frequently are Load Ratio Shares recalculated and what triggers updates?

---

# Chunk 8 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document is chunk 8 of 26 from a regulatory tariff document (RR696) concerning the integration and operation of high-impact large loads within the SPP (Southwest Power Pool) transmission system. The content primarily covers revenue distribution methodologies for various types of transmission services and upgrades, loss compensation procedures, and the transmission planning process framework. It details how revenues from different transmission services are allocated among Transmission Owners, the procedures for calculating transmission losses, and the comprehensive planning process that results in the SPP Transmission Expansion Plan (STEP).

## 2. Key Topics

- **Revenue Distribution Mechanisms:**
  - Distribution from Base Plan Zonal Charges
  - Region-wide Charges allocation
  - Interregional Projects revenue sharing
  - Point-to-Point revenue distribution
  - Creditable Upgrades revenue allocation
  - JTIQ (Joint Transmission Interconnection Queue) Upgrades revenue handling

- **Loss Compensation Procedures:**
  - Real power loss calculations for transmission services
  - Network Integration Transmission Service loss responsibilities
  - Point-to-Point Transmission Service loss factors
  - Injection Loss Factor (ILF) and Delivery Loss Factor (DLF)

- **Transmission Planning Process:**
  - Multiple sources for new transmission facilities
  - SPP Transmission Expansion Plan (STEP)
  - Integration of various planning processes

## 3. Decisions or Actions

- **Revenue distribution formulas** established with 50/50 splits between:
  - OZRR (Operating Zone Revenue Requirement) proportional distribution
  - MW-mile impact proportional distribution

- **Loss responsibility assignments:**
  - Network Customers responsible for losses in zones where Network Load is located
  - Transmission Customers responsible for losses under Schedules 7 and 8

- **JTIQ ATRR Balance methodology:**
  - Monthly charges/credits calculated as one-twelfth of annual balance
  - Positive balances charged to Resident Load and credited to Transmission Owner
  - Negative balances credited to Resident Load and charged to Transmission Owner

## 4. Important Dates

- **Monthly calculations** for JTIQ ATRR Balance distributions
- **Annual** transmission revenue requirements assessments
- No specific calendar dates are mentioned in this chunk

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)** - Primary transmission provider
- **Transmission Owners** - Multiple entities owning transmission facilities
- **Transmission Provider** - Entity managing the transmission system
- **Network Customers** - Service recipients under Network Integration
- **Transmission Customers** - Service recipients under Point-to-Point service
- **Upgrade Sponsors** - Entities sponsoring creditable upgrades
- **Interregional Planning Region** - Adjacent planning regions
- **Western-UGP** - Federal Power entity serving Statutory Load Obligations

**People:**
- No individual names mentioned

## 6. Links or References

**Internal Tariff References:**
- Section 34.1(2)
- Attachment H
- Attachment S
- Attachment Z2 (Sections II.D and III.C.2)
- Attachment J (Section IV.A)
- Attachment AU
- Attachment L (Sections II.A, II.C)
- Schedule 7, 8, 9, and 11
- Attachment AE (Energy and Operating Reserve Markets settlement procedures)
- Attachment AQ
- Attachment AX
- Attachment V (Generator Interconnection)
- Attachment Z1 (Transmission service requests)
- Attachment O (Transmission Planning Process)
- Attachment AV (JTIQ Formula Rate template, Appendix 2)
- Attachment M (Appendix 1 - loss factors)

**External References:**
- RRR File (posted on SPP website)
- Addendum(s) to Attachment O (interregional coordination agreements)
- Addendum 1 to Attachment O (coordination agreements)

## 7. Suggested Tags

- Revenue Distribution
- Transmission Tariff
- Loss Compensation
- JTIQ Upgrades
- Network Integration Service
- Point-to-Point Service
- Transmission Planning
- SPP Transmission Expansion Plan (STEP)
- Base Plan Upgrades
- Interregional Projects
- MW-mile Methodology
- Annual Transmission Revenue Requirements (ATRR)
- Creditable Upgrades
- Load Ratio Share
- Generator Interconnection
- Balanced Portfolios
- High Priority Upgrades
- Federal Power-Western-UGP

## 8. Items That May Need Follow-Up

1. **JTIQ ATRR Balance Calculation Verification:**
   - Ensure proper implementation of monthly one-twelfth distribution methodology
   - Verify accurate posting of JTIQ Upgrade-specific components in RRR File

2. **Loss Factor Updates:**
   - Confirm current ILF and DLF values in Appendix 1 to Attachment M
   - Review Zone 19 DLF for Federal Power-Western-UGP calculations

3. **Revenue Distribution Methodology Compliance:**
   - Audit 50/50 split implementation between OZRR and MW-mile impacts
   - Verify proper crediting of Upgrade Sponsors for Creditable Upgrades

4. **Interregional Coordination:**
   - Review status of interregional cost allocation agreements
   - Confirm proper revenue distribution to Interregional Planning Regions

5. **Integration with Integrated Marketplace:**
   - Ensure proper coordination between loss calculations and Attachment AE settlement procedures
   - Verify hourly energy settlement accounting for loss energy

6. **SPP Transmission Expansion Plan (STEP) Reporting:**
   - Confirm annual reporting includes all 10 sources of potential upgrades
   - Verify comprehensive listing accuracy across all transmission projects

7. **Attachment References:**
   - Cross-reference all cited tariff attachments for consistency
   - Ensure all referenced sections are current and properly updated

8. **Website Posting Requirements:**
   - Verify timely posting of RRR File on SPP website
   - Confirm accessibility of all required public information

---

# Chunk 9 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary
This document chunk contains sections from SPP's (Southwest Power Pool) Transmission Expansion Plan procedures, specifically covering the approval process for transmission upgrades (Section V) and transmission service timing requirements (Attachment P). The content establishes formal processes for developing, reviewing, approving, and maintaining the SPP Transmission Expansion Plan, including requirements for stakeholder engagement, board approval, and public disclosure. It outlines the governance structure requiring Markets and Operations Policy Committee recommendations and SPP Board of Directors approval for various types of transmission upgrades.

## 2. Key Topics
- **Transmission Expansion Plan Development**: Process for creating recommended sets of upgrades from planning studies
- **Stakeholder Engagement**: Requirements for stakeholder review, comment periods, and participation in planning summits
- **Approval Hierarchy**: Multi-tiered approval process involving Markets and Operations Policy Committee and SPP Board of Directors
- **Types of Upgrades**: ITP Upgrades, Balanced Portfolios, high priority upgrades, 20-Year Assessment upgrades, Sponsored Upgrades, Generator Retirement Upgrades, and JTIQ Upgrades
- **Information Disclosure**: Requirements for posting planning information on SPP website with CEII (Critical Energy Infrastructure Information) protections
- **Plan Modifications**: Quarterly updates and out-of-cycle adjustments to maintain system reliability
- **Interregional Coordination**: Assessment of impacts on adjacent transmission systems
- **Transmission Service Timing**: Deadlines and requirements for transmission service requests

## 3. Decisions or Actions
- Markets and Operations Policy Committee must make recommendations on all major upgrade categories before Board consideration
- SPP Board of Directors has final approval authority for:
  - ITP Upgrades
  - Balanced Portfolios
  - High priority upgrades
  - 20-Year Assessment upgrades
  - Generator Retirement Upgrades
  - JTIQ Upgrades
  - Endorsement of Sponsored Upgrades
- Transmission Provider must post draft project lists for stakeholder review
- Transmission Provider shall track upgrade status and report quarterly
- If Board approves upgrades different from Committee recommendations, explanations must be included in the Transmission Expansion Plan
- Upgrades may be removed from approved plans with appropriate reimbursement for incurred costs
- Adjacent system impacts from Competitive Upgrades must be identified but SPP is not obligated to pay for mitigation costs

## 4. Important Dates
- **10 days prior notice**: Required before SPP Board of Directors meetings where action on project lists is expected
- **Quarterly**: 
  - Status updates posted on SPP website
  - Modifications to Transmission Expansion Plan posted
  - Reports to Markets and Operations Policy Committee, Regional State Committee, and SPP Board
- **Annual**: SPP Transmission Expansion Plan presented to SPP Board at least once per year
- **Transmission Service Timing** (Attachment P references):
  - 15:00 day prior: Deadline for non-firm schedules
  - 23:00 previous day: Deadline for first hour of day
  - 09:55:00 - 10:05:00 a.m. CPT: Window for DC tie transmission requests

## 5. Organizations and People Mentioned
**Organizations:**
- SPP (Southwest Power Pool) - Transmission Provider
- Markets and Operations Policy Committee
- SPP Board of Directors
- Regional State Committee
- Stakeholder working groups
- Transmission Owners
- Adjacent transmission planning regions
- NERC (North American Electric Reliability Corporation)
- FERC/Commission (Federal Energy Regulatory Commission)

**Roles Referenced:**
- Transmission Provider
- Transmission Customers
- Transmission Owners
- Stakeholders

## 6. Links or References
- **Tariff Attachments Referenced:**
  - Attachment O (current document - Sections II, III, IV, V, VII)
  - Attachment Y (Competitive Upgrades definition)
  - Attachment J, Section VIII (reimbursement for removed upgrades)
  - Attachment Z1 (transmission service upgrades approval)
  - Attachment V (Generator Interconnection Service)
  - Attachment AB (Generator Retirement Process)
  - Attachment P (Transmission Service Timing Requirements)
- **Website**: SPP website (for posting plans, studies, and stakeholder information)
- **Agreements**: SPP Membership Agreement (confidentiality provisions)
- Section 15.3 of the Tariff (service agreement filing)

## 7. Suggested Tags
- Transmission Planning
- Regulatory Compliance
- Stakeholder Process
- Board Approval
- ITP Upgrades
- Balanced Portfolio
- Generator Interconnection
- CEII
- Regional Planning
- Transmission Expansion Plan
- SPP Governance
- Infrastructure Investment
- Reliability Standards
- Interregional Coordination

## 8. Items That May Need Follow-Up
1. **Quarterly Reporting Compliance**: Verify that quarterly status reports to Markets and Operations Policy Committee, Regional State Committee, and Board are being completed on schedule
2. **Website Posting Requirements**: Ensure all required materials are being posted to SPP website within specified timeframes, including both public and password-protected CEII materials
3. **10-Day Notice Compliance**: Confirm that stakeholders receive proper notice before Board meetings where project approvals are scheduled
4. **Deviation Documentation**: When Board approves upgrades different from Committee recommendations, verify explanations are included in Transmission Expansion Plan
5. **Adjacent System Impact Analysis**: Track whether Competitive Upgrades are being properly evaluated for impacts on neighboring transmission systems
6. **Reimbursement Process**: Monitor any removed upgrades to ensure Transmission Owners receive proper reimbursement for incurred costs
7. **Balanced Portfolio**: Clarify whether a Balanced Portfolio is required for current planning cycle (noted that one is not required each year)
8. **Out-of-Cycle Modifications**: Track modifications made between annual approvals to ensure proper stakeholder review and Board approval
9. **CEII Access Controls**: Verify password protection mechanisms are functioning properly for confidential planning information
10. **DC Tie Request Limitations**: The document cuts off mid-sentence regarding abuse prevention for DC tie requests - need complete provision

---

# Chunk 10 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document contains detailed tariff provisions for Point-To-Point Transmission Service within the Southwest Power Pool (SPP) system, specifically focusing on the American Electric Power - West (AEPW) rate zone and City Utilities. The content outlines transmission service request procedures, priority rules, service increments, rate structures, and special discount provisions. Key elements include NERC priority assignments for non-firm services, standardized service windows aligned with NAESB standards, and detailed rate calculations for multiple transmission owners within the AEPW zone.

## 2. Key Topics

- **Transmission Service Request Procedures**: Lottery system for simultaneous requests, five-minute window rules, OASIS posting requirements
- **NERC Priority Classifications**: Priority levels for Daily Non-Firm services (3-ND) versus Hourly Non-Firm (2-NH)
- **Service Increments**: Fixed Hourly, Fixed Daily, Extended Weekly, Extended Monthly, and Extended Yearly options
- **Rate Structures**: Firm and Non-Firm Point-To-Point rates for multiple entities
- **ERCOT-Related Discount Provisions**: 45.27% discount for specific through-and-out service transactions
- **Balanced Portfolio Reallocation Adjustments**: Revenue requirement reallocations per Attachment J
- **Revenue Crediting**: Schedule 7 and 8 revenue adjustments

## 3. Decisions or Actions

- **Lottery System Implementation**: Transmission Provider uses lottery to assign priorities for simultaneous reservation requests
- **Five-Minute Rule**: All requests within first five minutes after deadline deemed simultaneous; no public OASIS posting until period closes
- **Pro Rata Curtailment**: Daily Non-Firm services curtailed on pro rata basis with other 3-ND priority transactions
- **Time Convention**: All services offered and processed in Central Prevailing Time only
- **24-Hour Clock Convention**: Mandated for all time-keeping purposes
- **NAESB Standards Integration**: Service increments must align with WEQ-001 Business Practice Standards

## 4. Important Dates

- **Service Start/Stop Times**: 
  - Fixed Daily: 00:00 to 24:00 same calendar day
  - Extended Weekly: 00:00 start, more than one week but less than four weeks
  - Extended Monthly: 00:00 start, more than one month but less than twelve months
  - Extended Yearly: 00:00 start, more than one year duration
- **On-Peak Hours**: HE 0700 to HE 2200 (Central Time Zone)
- **NERC Holidays**: New Year's Day, Memorial Day, Independence Day, Labor Day, Thanksgiving Day, Christmas Day
- **Off-Peak Days**: Saturdays, Sundays, and NERC Holidays

## 5. Organizations and People Mentioned

### Organizations:
- **Southwest Power Pool (SPP)**
- **American Electric Power (AEP)**
- **AEP-West Transmission Companies (AEP-West Transco)**
- **Texas Electric Cooperatives** (East Texas Electric Cooperative, Inc. and Deep East Electric Cooperative, Inc.)
- **Oklahoma Municipal Power Authority (OMPA)**
- **Coffeyville Municipal Light and Power (CMLP)**
- **Arkansas Electric Cooperative Corporation (AECC)**
- **Transource Oklahoma (TROK)**
- **AEP Texas Central Company (TCC)**
- **AEP Texas North Company (TNC)**
- **City Utilities of [location not specified]**
- **NERC (North American Electric Reliability Corporation)**
- **NAESB (North American Energy Standards Board)**
- **ERCOT (Electric Reliability Council of Texas)**
- **Federal Energy Regulatory Commission (FERC/Commission)**

### People:
None specifically mentioned

## 6. Links or References

- **SPP OATT Sections 13.2 and 14.2** (superseded/displaced principles)
- **Attachment T** (Rate Sheets for Point-To-Point Transmission Service)
- **Attachment R-1** (NAESB WEQ-001 Business Practice Standards)
- **Attachment X** (Central Prevailing Time definition)
- **Attachment J, Section IV.A** (Balanced Portfolio Reallocation)
- **Attachment AU** (Revenue distribution and allocation)
- **Attachment H, Addendums 4, 12, 38, and 48** (Formula rates for AEP, AEP-West Transco, AECC, and TROK)
- **Section 34.1(2) of SPP Tariff** (Revenue crediting implementation)
- **Schedule 7 and 8** (Revenue provisions)
- **RRR File (Revenue Requirements and Rates File)** posted on SPP website
- **Part II and Part IV of AEP Operating Companies' Tariff**

## 7. Suggested Tags

- Transmission Service
- Point-To-Point Rates
- NERC Priority
- SPP Tariff
- AEPW Rate Zone
- Non-Firm Service
- Firm Service
- OASIS
- Formula Rates
- Revenue Requirements
- ERCOT
- NAESB Standards
- Transmission Reservation
- Curtailment Procedures
- Discount Provisions

## 8. Items That May Need Follow-Up

1. **Incomplete Entity Name**: "City Utilities of" appears without location specification - requires completion
2. **RRR File Updates**: Monitor Revenue Requirements and Rates File on SPP website for rate changes
3. **Formula Rate Tracking**: Verify current rates under AEP, AEP-West Transco, AECC, and TROK formula rates in Attachment H
4. **NAESB Standards Version**: Confirm current version of WEQ-001 Business Practice Standards incorporated in Attachment R-1
5. **Commission Approval Status**: Verify FERC approval status for all transmission owner rates listed
6. **45.27% Discount Justification**: Review basis and ongoing applicability of ERCOT-related discount provision
7. **Lottery System Documentation**: Ensure procedures for conducting lottery for simultaneous requests are documented
8. **Planned vs. Unplanned Resource Designations**: Clarify process for Load Serving Entities to designate resources
9. **Missing Text**: "Public Service Company of [blank]" and "Electric Reliability Council of [blank]" - complete entity names needed
10. **Off-Peak Definition Consistency**: Verify alignment of Off-Peak definitions across different rate calculations (260 days vs. Saturdays/Sundays/Holidays)

---

# Chunk 11 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document section (chunk 11 of 26) contains detailed tariff rate schedules and transmission service pricing structures for multiple utility companies operating within the SPP (Southwest Power Pool) system. The content specifies Point-to-Point (PTP) transmission service rates, both firm and non-firm, for City Utilities of Springfield MO, The Empire District Electric Company, Evergy Kansas Central Inc., and Evergy Metro Inc. All rates are calculated using formula rates referenced in various Attachment H Addendums and published in the Revenue Requirements and Rates (RRR) File on the SPP website.

## 2. Key Topics

- **Point-to-Point Transmission Service Rates** (Firm and Non-Firm)
- **Reserved Capacity Compensation** structures (Annual, Monthly, Weekly, Daily, Hourly)
- **Balanced Portfolio Reallocation Adjustments**
- **Revenue Crediting** for Schedule 7 and 8 revenues
- **Formula Rate Calculations** per Attachment H (multiple addendums)
- **Zonal Annual Transmission Revenue Requirements (ATRR)**
- **Rate posting requirements** on SPP website
- **Demand charge caps** for various delivery periods
- **On-Peak and Off-Peak rate differentials**

## 3. Decisions or Actions

- Rates must be adjusted to reflect reallocations from Zonal ATRR per Section IV.A of Attachment J
- Revenue crediting adjustments must be implemented per Section 34.1(2) of the Tariff
- All rates and adjustments must be set forth in the RRR File posted on SPP website
- Transmission Customers must compensate Transmission Providers monthly for Reserved Capacity
- Demand charge caps apply to prevent weekly charges from exceeding specified maximums

## 4. Important Dates

### Annual Posting Deadlines (for rates effective January 1):
- **September 1**: Prairie Wind Formula Rate (Evergy Kansas Central zone)
- **October 1**: South Central MCN Formula Rate and Kansas Power Pool Formula Rate (Evergy Kansas Central zone)
- **October 1**: NextEra Energy Transmission Southwest (NEET Southwest) Formula Rate
- **October 15**: Evergy Kansas Central Inc. Formula Rate

### Effective Date:
- **January 1**: All posted rates become effective the following year

## 5. Organizations and People Mentioned

### Organizations:
- **City Utilities of Springfield, MO**
- **The Empire District Electric Company**
- **Evergy Kansas Central, Inc.** (formerly Evergy Kansas South, Inc. and Evergy Kansas Central, Inc.)
- **Evergy Metro, Inc.**
- **Prairie Wind Transmission LLC**
- **South Central MCN LLC**
- **Kansas Power Pool**
- **NextEra Energy Transmission Southwest, LLC (NEET Southwest)**
- **Southwest Power Pool (SPP)** - website host for RRR Files

### Roles Referenced:
- Transmission Customer
- Transmission Provider

## 6. Links or References

### Tariff Attachments:
- **Attachment AU**: Revenue distribution and allocation
- **Attachment H**: Formula rates (multiple addendums)
  - Addendum 3: Evergy Kansas Central, Inc. Formula Rate
  - Addendum 15: Prairie Wind Formula Rate
  - Addendum 16: Kansas Power Pool Formula Rate
  - Addendum 17: City Utilities of Springfield, MO formula rate
  - Addendum 18: The Empire District Electric Company formula rate
  - Addendum 43: South Central MCN Formula Rate
  - Addendum 44: NEET Southwest Formula Rate
- **Attachment J, Section IV.A**: Balanced Portfolio Reallocation
- **Attachment T**: Point-To-Point Transmission Service rates

### Other References:
- **Section 34.1(2)** of the Tariff: Revenue crediting implementation
- **Schedule 7 and 8**: Revenue schedules
- **Revenue Requirements and Rates File (RRR File)**: Posted on SPP website
- **Attachment H, Section I, Table 1**: Existing Zonal ATRR specifications (Lines 14, 14a, 14b, 14c, 14d, 14e, Column 3)

## 7. Suggested Tags

- Transmission Rates
- Point-to-Point Service
- Tariff Schedules
- SPP (Southwest Power Pool)
- Revenue Requirements
- Formula Rates
- Reserved Capacity
- Firm Transmission Service
- Non-Firm Transmission Service
- FERC Regulation
- Evergy Kansas
- Empire District Electric
- Rate Schedules
- On-Peak/Off-Peak Pricing
- Demand Charges
- Annual Transmission Revenue Requirement (ATRR)

## 8. Items That May Need Follow-Up

1. **Verification of annual rate postings** by respective deadline dates (September 1, October 1, October 15)
2. **Confirmation that RRR Files are properly updated** on SPP website with all adjustments
3. **Reconciliation of Schedule 7 and 8 revenue credits** and their impact on final rates
4. **Monitoring of Balanced Portfolio Reallocation** adjustments and their calculation methodology
5. **Validation of formula rate calculations** across all referenced Attachment H Addendums (3, 15, 16, 17, 18, 43, 44)
6. **Review of demand charge cap calculations** to ensure proper implementation
7. **Clarification on the relationship** between Evergy Kansas South, Inc. and Evergy Kansas Central, Inc. (appears to be a merger/consolidation)
8. **Audit of Attachment AU revenue allocation** methodology and its impact on rates
9. **Verification of on-peak vs. off-peak hour definitions** (Daily charge divided by 16 hours suggests specific on-peak hours)
10. **Consistency check** between different utility rate structures within the same SPP system

---

# Chunk 12 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary
This document chunk contains detailed rate schedules and calculation methodologies for Point-To-Point (PTP) Transmission Service across multiple transmission zones within the SPP (Southwest Power Pool) system. It covers rate structures for three specific zones: Evergy Metro Inc., Evergy Missouri West Inc., and Grand River Dam Authority, along with a partial section on Kansas City Board of Public Utilities. The content specifies formulas for calculating transmission charges for both Firm and Non-Firm PTP Transmission Service across various delivery timeframes (yearly, monthly, weekly, daily, and hourly).

## 2. Key Topics
- **Point-To-Point Transmission Service Rate Structures**
  - Firm PTP Transmission Service rates and calculations
  - Non-Firm PTP Transmission Service rates and calculations
- **Balanced Portfolio Reallocation Adjustments**
- **Revenue Crediting Mechanisms** (Schedule 7 and 8 revenues, Attachment AU)
- **Reserved Capacity Compensation** across multiple time periods
- **Zonal Rate Differentiation** across transmission owner territories
- **Demand Charge Caps** for various delivery periods
- **Formula Rate Applications** referencing specific Attachment H Addendums

## 3. Decisions or Actions
- Rate calculations must reference the Revenue Requirements and Rates File (RRR File) posted on the SPP website
- Rates must be adjusted to reflect reallocations from Zonal Annual Transmission Revenue Requirements per Section IV.A of Attachment J
- Rates must incorporate Schedule 7 and 8 revenue adjustments per Section 34.1(2) of the Tariff
- Transmission Customers must compensate Transmission Providers according to specified formula rates for their respective zones
- Weekly demand charge caps apply to daily delivery reservations
- Daily and weekly demand charge caps apply to hourly delivery reservations

## 4. Important Dates
No specific dates are mentioned in this content chunk. The document references "currently effective rates" without specifying implementation dates.

## 5. Organizations and People Mentioned

### Organizations:
- **Evergy Metro, Inc. (EMe)**
- **City of Independence, Missouri (INDP)**
- **Evergy Missouri West, Inc.**
- **Transource Missouri, LLC**
- **Grand River Dam Authority (GRDA)**
- **Kansas City Board of Public Utilities (BPU)**
- **Southwest Power Pool (SPP)** (implied as Transmission Provider)
- **Commission** (Federal Energy Regulatory Commission implied)

### People:
None mentioned

## 6. Links or References

### Internal References:
- **Attachment T** - Point-To-Point Transmission Service specifications
- **Attachment J, Section IV.A** - Balanced Portfolio Reallocation provisions
- **Attachment AU** - Revenue distribution and allocation
- **Section 34.1(2)** - Revenue crediting implementation
- **Attachment H:**
  - Addendum 10, Parts 1 and 2 (EMe formula rate)
  - Addendum 11, Parts 1 and 2 (Evergy Missouri West formula rate)
  - Addendum 13 (Grand River Dam Authority formula rate)
  - Addendum 21 (Transource Missouri, LLC formula rate and protocols)

### External References:
- **RRR File (Revenue Requirements and Rates File)** - Posted on SPP website with specific tabs:
  - "EMe PTP Rate Att T" tab
  - "EMW PTP Rate Att T" tab
  - "GRDA PTP Rate Att T" tab
  - "BPU PTP Rate Att T" tab
- **SPP website** - Location for current rate postings

## 7. Suggested Tags
- Point-To-Point Transmission
- Transmission Rates
- SPP Tariff
- Evergy Metro
- Evergy Missouri West
- Grand River Dam Authority
- Reserved Capacity
- Firm Transmission Service
- Non-Firm Transmission Service
- Formula Rates
- Revenue Requirements
- Zonal Rates
- Demand Charges
- Transmission Service Pricing

## 8. Items That May Need Follow-Up

1. **Rate Reconciliation**: Verify that all referenced formula rates in Attachment H Addendums are current and properly implemented in the RRR File
2. **Website Accessibility**: Confirm that the RRR File is accessible and updated on the SPP website with all referenced tabs
3. **Commission Approval Status**: Verify current Commission approval status for all mentioned transmission owner rates
4. **INDP Fixed Rate**: The $2,442.048 fixed rate for City of Independence, Missouri may need periodic review or update confirmation
5. **Calculation Verification**: Validate the divisor values used in rate calculations (e.g., 260 for daily on-peak, 365 for daily off-peak, 4,160 for hourly on-peak, 8,760 for hourly off-peak)
6. **Kansas City BPU Section**: The document appears to be cut off - complete rate schedule information for Kansas City Board of Public Utilities needs to be reviewed
7. **Consistency Check**: Ensure consistency between different zone rate structures and identify any policy reasons for variations
8. **Attachment AU Implementation**: Monitor revenue distribution and allocation under Attachment AU for proper application to rates

---

# Chunk 13 Analysis

# Regulatory Content Analysis Report
## Source: RR696 Integrate _ Operate High Impact Large Loads.docx.txt - chunk 13 of 26

---

## 1. Executive Summary

This document segment contains detailed Point-To-Point (PTP) Transmission Service rate schedules and tariff provisions for multiple electric utilities within the SPP (Southwest Power Pool) system. The content outlines rate structures for both Firm and Non-Firm transmission services across different service zones including Kansas City Board of Public Utilities, Lincoln Electric System (LES), Midwest Energy Inc., and Nebraska Public Power District (NPPD). All rates are posted in the Revenue Requirements and Rates File (RRR File) on the SPP website and include various adjustments for revenue crediting and portfolio reallocation per Attachment J and Attachment AU provisions.

---

## 2. Key Topics

- **Point-To-Point Transmission Service Rate Structures**: Detailed pricing for yearly, monthly, weekly, daily, and hourly delivery options
- **Firm vs. Non-Firm Transmission Service**: Separate rate schedules and calculation methodologies
- **Balanced Portfolio Reallocation Adjustments**: Adjustments based on Section IV.A of Attachment J
- **Revenue Crediting**: Schedule 7 and 8 revenue adjustments per Section 34.1(2) and Attachment AU
- **Reserved Capacity Compensation**: Rate calculations based on MW or kW of reserved capacity
- **On-Peak vs. Off-Peak Pricing**: Time-based rate differentiation (HE 0700-2200 Central Time)
- **Formula Rate Calculations**: Specific addendums referenced for each utility zone
- **Demand Charge Caps**: Weekly and daily maximum charge provisions

---

## 3. Decisions or Actions

No specific decisions or action items are identified in this content. This appears to be established tariff language defining existing rate structures and methodologies.

---

## 4. Important Dates

- **December 15**: NPPD formula calculation results posting deadline (annually)
- **January 1**: NPPD rate effectiveness date (following year)
- **June 15**: Tri-State formula calculation results posting deadline (annually)
- **July 1**: Tri-State rate effectiveness date (same year)
- **NERC Holidays** (referenced for On-Peak/Off-Peak definitions):
  - New Year's Day
  - Memorial Day
  - Independence Day
  - Labor Day
  - Thanksgiving Day
  - Christmas Day

---

## 5. Organizations and People Mentioned

### Organizations:
- **Southwest Power Pool (SPP)** - Regional transmission organization
- **Kansas City Board of Public Utilities (Kansas City, Kansas)** - Transmission provider
- **Lincoln Electric System (LES)** - Electric utility
- **Midwest Energy, Inc.** - Electric utility
- **Nebraska Public Power District (NPPD)** - Electric utility
- **The Central Nebraska Public Power and Irrigation District (CNPPID)** - Electric utility
- **Tri-State** - Electric utility
- **NERC** (North American Electric Reliability Corporation) - Standards organization

### People:
None specifically mentioned.

---

## 6. Links or References

### Internal Document References:
- **Attachment T** - Point-To-Point Transmission Service rates
- **Attachment J, Section IV.A** - Balanced Portfolio Reallocation provisions
- **Attachment AU** - Revenue distribution and allocation
- **Attachment H** - Formula rates
  - Addendum 46: Kansas City Board of Public Utilities formula rate
  - Addendum 6: Lincoln Electric System formula rate
  - Addendum 14: Midwest Energy, Inc. formula rate
  - Addendum 7: NPPD formula rate
  - Addendum 36: Tri-State formula rate
- **Section 34.1(2)** - Revenue crediting implementation provisions
- **Schedule 7 and 8** - Revenue sources for adjustments

### External Resources:
- **SPP website** - RRR File posting location
- **Revenue Requirements and Rates File (RRR File)** tabs:
  - "LES PTP Rate Att T"
  - "Midwest PTP Rate Att T"
  - "NPPD PTP Rate Att T"
- **NPPD website** - Formula rate results posting location
- **Tri-State website** - Formula rate results posting location

---

## 7. Suggested Tags

- Point-To-Point Transmission
- Transmission Rates
- SPP Tariff
- Firm Transmission Service
- Non-Firm Transmission Service
- Reserved Capacity
- Formula Rates
- Revenue Requirements
- Rate Schedules
- Electric Transmission
- Balanced Portfolio
- Revenue Crediting
- NPPD
- Lincoln Electric System
- Midwest Energy
- Kansas City BPU
- On-Peak/Off-Peak Rates
- Demand Charges

---

## 8. Items That May Need Follow-Up

1. **Rate File Verification**: Confirm all referenced RRR File tabs are current and accessible on the SPP website
2. **Formula Rate Updates**: Monitor annual postings by December 15 (NPPD) and June 15 (Tri-State) for calculation results
3. **Attachment References**: Verify that all referenced attachments (J, AU, H with addendums) remain current and consistent with this tariff language
4. **NERC Holiday Definitions**: Confirm holiday list remains current with NERC standards
5. **Time Zone Consistency**: Verify Central Time Zone application across all service territories
6. **Schedule 7 and 8 Revenue Tracking**: Monitor adjustments for revenue crediting calculations
7. **Unit Consistency**: Note mixed units (MW vs. kW vs. MWh) across different utility zones - verify calculation consistency
8. **Website Accessibility**: Confirm all utility websites (NPPD, Tri-State) maintain accessible formula rate posting locations
9. **Cross-Reference Validation**: Ensure Section 34.1(2) implementation matches revenue crediting described here

---

**Note**: This document appears to be standard tariff language and may be part of FERC-approved rate schedules. Any modifications would likely require regulatory approval.

---

# Chunk 14 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary

This document contains detailed tariff rate schedules for Point-To-Point Transmission Service within the SPP (Southwest Power Pool) framework. It outlines specific pricing structures for both Firm and Non-Firm transmission services across multiple utility rate zones, including NPPD (Nebraska Public Power District), Tri-State, CNPPID (Central Nebraska Public Power and Irrigation District), and Oklahoma Gas and Electric Company (OG&E). The content specifies rate calculation methodologies, time-based delivery charges (annual, monthly, weekly, daily, and hourly), and various adjustments including revenue crediting and balanced portfolio reallocation.

## 2. Key Topics

- **Point-To-Point Transmission Service Rates** (Firm and Non-Firm)
- **Formula Rate Calculations** (multiple utility-specific formulas)
- **Time-Based Delivery Charges** (annual, monthly, weekly, daily, hourly)
- **On-Peak vs. Off-Peak Rate Differentials**
- **Revenue Requirements and Rate (RRR) File** specifications
- **Zonal Annual Transmission Revenue Requirement (Zonal ATRR)**
- **Balanced Portfolio Reallocation Adjustments**
- **Schedule 7 and 8 Revenue Crediting**
- **Attachment AU Revenue Distribution and Allocation**
- **Reserved Capacity calculations and limitations**

## 3. Decisions or Actions

- **Rate Posting Requirements**: Existing Zonal ATRR to be posted on SPP website by September 1 of each calendar year
- **Rate Effective Dates**: Posted rates become effective January 1 of the following year
- **Service Direction Classification**: Service in the opposite direction of original schedule requires payment of a separate charge as a new and separate service
- **Demand Charge Caps**: 
  - Weekly charge caps for daily delivery reservations
  - Daily charge caps for hourly delivery reservations
  - Specific limitations on total demand charges to prevent exceeding weekly rates

## 4. Important Dates

- **September 1** (Annual): Deadline for posting Existing Zonal ATRR on SPP website
- **January 1** (Annual): Effective date for new rates following year
- **On-Peak Hours**: HE 0700 to HE 2200, Central Time Zone
- **Recognized Holidays** (per NERC): New Year's Day, Memorial Day, Independence Day, Labor Day, Thanksgiving Day, Christmas Day

## 5. Organizations and People Mentioned

### Organizations:
- **NPPD** (Nebraska Public Power District)
- **Tri-State**
- **CNPPID** (Central Nebraska Public Power and Irrigation District)
- **OG&E** (Oklahoma Gas and Electric Company)
- **AECC** (Arkansas Electric Cooperative Corporation)
- **PEC** (People's Electric Cooperative)
- **NEET Southwest** (NextEra Energy Transmission Southwest, LLC)
- **Oklahoma Municipal Power Authority** (OMPA)
- **SPP** (Southwest Power Pool)
- **NERC** (North American Electric Reliability Corporation)

### People:
- None specifically mentioned

## 6. Links or References

### Tariff Attachments Referenced:
- **Attachment H** (Formula Rates)
  - Addendum 2-A and 2-B (OG&E Formula Rate and Implementation Protocols)
  - Addendum 7 (NPPD Formula Rate Template)
  - Addendum 36 (Tri-State Formula Rate)
  - Addendum 38 (AECC Formula Rate)
  - Addendum 44 (NEET Southwest Formula Rate)
  - Addendum 51 (PEC Formula Rate)
  - Section I, Table 1 (Zonal ATRR specifications)
- **Attachment T** (Point-To-Point Transmission Service)
- **Attachment J, Section IV.A** (Balanced Portfolio Reallocation)
- **Attachment AU** (Revenue Distribution and Allocation)
- **Section 34.1(2)** (Revenue Crediting)
- **RRR File** (Revenue Requirements and Rates File) - posted on SPP website
- **Schedule 7 and 8** (Revenue schedules)

## 7. Suggested Tags

- Transmission Tariff
- Point-to-Point Service
- Firm Transmission
- Non-Firm Transmission
- Rate Schedule
- Formula Rates
- SPP Tariff
- OG&E
- NPPD
- Revenue Requirements
- On-Peak/Off-Peak
- Reserved Capacity
- Zonal ATRR
- Transmission Pricing
- Electric Utilities

## 8. Items That May Need Follow-Up

1. **Annual Rate Updates**: Verify posting of updated Zonal ATRR on SPP website by September 1 deadline
2. **RRR File Accuracy**: Confirm all referenced rates are correctly calculated and posted in the "OGE PTP Rate Att T" tab and other relevant RRR File tabs
3. **Formula Rate Compliance**: Ensure all utility-specific formula rates (NPPD, Tri-State, OG&E, AECC, PEC, NEET Southwest) are being calculated according to specified protocols
4. **Revenue Crediting Reconciliation**: Verify proper implementation of Schedule 7 and 8 revenue adjustments and Attachment AU allocations
5. **CNPPID Fixed Rate Updates**: Confirm whether the specific dollar amounts for CNPPID ($128.961/MW annually through $0.015/MW hourly off-peak) require periodic review or adjustment
6. **On-Peak/Off-Peak Definitions**: Monitor NERC holiday definitions for any changes that would affect rate applications
7. **Capacity Loss Inclusivity**: Verify that capacity designations at Points of Receipt properly account for losses as specified
8. **Opposite Direction Service Billing**: Ensure proper billing processes for services in opposite direction as separate transactions
9. **Oklahoma Municipal Power Authority Adders**: Confirm accuracy and appropriateness of specific OMPA charges ($0.0752/kW yearly through $0.0002/kW weekend delivery)
10. **Document Completeness**: Text appears truncated at end (item 3 under Non-Firm service for OG&E) - verify complete tariff language is available

---

# Chunk 15 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary
This document is chunk 15 of 26 from a regulatory filing detailing Point-To-Point Transmission Service rates and rate structures for multiple transmission providers within the Southwest Power Pool (SPP) region. The content specifically covers rate schedules for Oklahoma Municipal Power Authority (referenced at beginning), Omaha Public Power District (OPPD), and Southwestern Power Administration (including South Central MCN, MEUC, and PEC). It establishes both Firm and Non-Firm transmission service rates with various delivery timeframes (yearly, monthly, weekly, daily, and hourly) and specifies calculation methodologies using formula-based rate templates.

## 2. Key Topics
- **Point-To-Point Transmission Service Rate Structures** - Detailed rate schedules for multiple delivery timeframes
- **Formula-Based Rate Templates** - OPPD uses formula rates posted to SPP website with specific calculation references
- **Balanced Portfolio Reallocation Adjustments** - Adjustments to reflect reallocated amounts from Zonal Annual Transmission Revenue Requirements
- **Revenue Crediting Mechanisms** - Adjustments for Schedule 7 and 8 revenues and Attachment AU distributions
- **On-Peak vs. Off-Peak Rate Differentiation** - Different rates based on time of day and day of week
- **Reserved Capacity Billing** - Various methods for calculating demand charges based on reserved capacity
- **Multi-Entity Rate Calculation** - Southwestern Zone rates combine multiple entities' formula rates

## 3. Decisions or Actions
- OPPD formula calculation results must be posted on SPP website by **July 20** of each calendar year
- Rates become effective **August 1** of each year
- All rates and adjustments must be published in the Revenue Requirements and Rates File (RRR File) on SPP website
- Rate caps established: daily charges cannot exceed weekly rates; weekly charges cannot exceed monthly rates (based on highest Reserved Capacity)
- Special billing provisions for transmission customers directly connected to Southwestern's system based on peak demand calculations

## 4. Important Dates
- **July 20** - Annual deadline for posting OPPD formula calculation results on SPP website
- **August 1** - Effective date for new rates each year
- **NERC Holidays** (for On-Peak/Off-Peak determination):
  - New Year's Day
  - Memorial Day
  - Independence Day
  - Labor Day
  - Thanksgiving Day
  - Christmas Day
- **On-Peak Hours**: HE 0700 through HE 2200 (excluding weekends and NERC holidays)

## 5. Organizations and People Mentioned

### Organizations:
- **Oklahoma Municipal Power Authority**
- **Omaha Public Power District (OPPD)**
- **Southwest Power Pool (SPP)**
- **Southwestern Power Administration**
- **South Central MCN LLC**
- **Missouri Joint Municipal Electric Utility Commission (MEUC)**
- **People's Electric Cooperative (PEC)**
- **NERC** (North American Electric Reliability Corporation)

### People:
None specifically mentioned

## 6. Links or References

### Tariff References:
- **Attachment H, Addendum 8** - OPPD Formula Rate Template
- **Attachment H, Addendum 43** - South Central MCN Formula Rate
- **Attachment H, Addendum 50** - MEUC Formula Rate
- **Attachment H, Addendum 51** - PEC Formula Rate
- **Attachment T** - Point-To-Point Transmission Service rates
- **Attachment J, Section IV.A** - Balanced Portfolio Reallocation provisions
- **Attachment AU** - Revenue distribution and allocation
- **Section 34.1(2)** - Revenue crediting implementation

### Document References:
- **Revenue Requirements and Rates File (RRR File)** - Posted on SPP website
- **"OPPD PTP Rate Att T" tab** - Specific worksheet in RRR File
- **"SPA PTP Rate Att T" tab** - Southwestern Power Administration rates worksheet
- **Attachment H, Section I, Table 1** - Various line items (10b, 10c, 10d) for Zonal Annual Transmission Revenue Requirements

## 7. Suggested Tags
- Point-To-Point Transmission Service
- Rate Schedules
- Formula-Based Rates
- OPPD
- Southwestern Power Administration
- SPP Tariff
- Reserved Capacity
- Firm Transmission Service
- Non-Firm Transmission Service
- Revenue Requirements
- On-Peak/Off-Peak Rates
- Transmission Pricing
- Electric Utilities
- FERC Tariff

## 8. Items That May Need Follow-Up

1. **Annual Rate Filing Compliance** - Verify OPPD meets July 20 posting deadline and August 1 effective date requirements annually

2. **RRR File Accessibility** - Confirm all referenced rate calculations and tabs are properly published and accessible on SPP website

3. **Formula Rate Updates** - Monitor updates to formula rates in Attachment H Addendums (8, 43, 50, 51) for consistency with rate calculations

4. **Revenue Crediting Reconciliation** - Track Schedule 7 and 8 revenue adjustments and Attachment AU distributions for proper rate implementation

5. **Peak Demand Billing Verification** - For Southwestern customers directly connected but outside control area, verify billing calculations using 11-month lookback methodology

6. **Rate Cap Calculations** - Ensure rate cap provisions (daily not exceeding weekly, weekly not exceeding monthly) are properly implemented in billing systems

7. **Balanced Portfolio Reallocation** - Monitor Section IV.A of Attachment J for any reallocations affecting Point-To-Point rates

8. **NERC Holiday Calendar** - Confirm holiday definitions remain consistent with NERC standards for On-Peak/Off-Peak determinations

9. **Multi-Entity Rate Coordination** - For Southwestern Zone, verify proper aggregation of rates from Southwestern, South Central MCN, MEUC, and PEC

10. **Cross-Reference Verification** - Validate that all attachment and section references remain current if tariff is restructured or amended

---

# Chunk 16 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary
This document chunk contains detailed rate schedules and tariff structures for Point-To-Point Transmission Service across multiple transmission zones and service providers. The content primarily focuses on two service providers (Southwestern Public Service Company and Sunflower Electric Power Corporation) and introduces the Upper Missouri Zone. It specifies rate calculation methodologies, service delivery options (firm and non-firm), pricing structures for various time periods (yearly, monthly, weekly, daily, hourly), and distinctions between on-peak and off-peak rates. The rates incorporate formula-based calculations posted on SPP and OASIS websites with annual updates.

## 2. Key Topics
- **Point-To-Point Transmission Service Rate Structures** for multiple zones
- **Firm vs. Non-Firm Transmission Service** pricing distinctions
- **Rate Calculation Methodologies** using formula rates from multiple attachments
- **Balanced Portfolio Reallocation Adjustments** to transmission rates
- **Revenue Crediting Mechanisms** (Schedule 7 and 8 revenues, Attachment AU distributions)
- **Time-Based Rate Variations** (yearly, monthly, weekly, daily, hourly)
- **On-Peak vs. Off-Peak Definitions** (HE 0700-2200 Central Time, excluding Sundays/holidays)
- **Reserved Capacity** billing structures and caps
- **Lamar Tie Line** special discounted rate provisions (50% discount)
- **Multi-Entity Rate Formulas** incorporating cooperative and LLC transmission entities

## 3. Decisions or Actions
- Rate formulas shall be posted on SPP website by **October 1** of each calendar year
- Rates become **effective January 1** of the following year
- Rates must be set forth in specific tabs of the Revenue Requirements and Rates File (RRR File):
  - "SPS PTP Rate Att T" tab for Southwestern Public Service
  - "SECC PTP Rate Att T" tab for Sunflower Electric
  - "UMZ PTP Rate Att T" tab for Upper Missouri Zone
- Service in opposite direction of original schedule constitutes a new/separate service requiring separate charge
- Weekly delivery demand charges capped at weekly rate × highest kilowatts of Reserved Capacity
- Daily delivery demand charges capped at daily rate × highest amount of Reserved Capacity

## 4. Important Dates
- **October 1** (annually) - Rate formula calculation results posting deadline
- **January 1** (annually) - New rates become effective
- **NERC Holidays** (for rate calculation purposes):
  - New Year's Day
  - Memorial Day
  - Independence Day
  - Labor Day
  - Thanksgiving Day
  - Christmas Day

## 5. Organizations and People Mentioned

### Organizations:
- **Southwestern Public Service Company (SPS)**
- **Xcel Energy Operating Companies**
- **Lea County Electric Cooperative, Inc. (LCEC)**
- **Southwest Power Pool (SPP)**
- **Public Service Company of Colorado (PSCo)**
- **Sunflower Electric Power Corporation (SECC)**
- **ITC Great Plains, LLC**
- **Prairie Wind Transmission, LLC**
- **Upper Missouri Zone (UMZ) Transmission Owners:**
  - Basin Electric Power Cooperative
  - Heartland Consumers Power District
  - Missouri River Energy Services (MRES)
  - East River Electric Power Cooperative, Inc.
  - Corn Belt Power Cooperative
  - NorthWestern Energy Public Service Corporation (NWPS)
  - Northwest Iowa Power Cooperative (NIPCO)
  - Harlan Municipal Utilities (HMU)
  - Western Area Power Administration, Upper Great Plains Region (Western-UGP)
  - Central Electric Power Cooperative, Inc.
  - Mountrail-Williams Electric Cooperative
  - Mor-Gran-Sou Electric Cooperative, Inc.
  - Roughrider Electric Cooperative, Inc.
  - L and O Power Cooperative (LOPC)
- **NERC (North American Electric Reliability Corporation)**

### People:
None specifically mentioned

## 6. Links or References

### Internal Tariff References:
- Attachment O - SPS of Xcel Energy OATT
- Attachment H, Addendum 5 (Southwestern Public Service Company formula rate)
- Addendum 52 to Attachment H (LCEC Formula Rate)
- Attachment H, Addendum 20 (Sunflower Electric Power Corporation formula rate)
- Attachment H, Addendum 9 (ITC Great Plains, LLC formula rate)
- Attachment H, Addendum 15 (Prairie Wind Transmission, LLC formula rate)
- Attachment J, Section IV.A (Balanced Portfolio Reallocation)
- Attachment AU (Revenue distribution and allocation)
- Section 34.1(2) of Tariff (Revenue crediting implementation)

### Website References:
- SPP website (for RRR File posting)
- SPS OASIS website (for rate formula posting)

### File References:
- Revenue Requirements and Rates File (RRR File)
- Multiple specific tabs: "SPS PTP Rate Att T", "SECC PTP Rate Att T", "UMZ PTP Rate Att T"

## 7. Suggested Tags
- Point-To-Point Transmission
- Rate Schedules
- Tariff Structure
- Firm Transmission Service
- Non-Firm Transmission Service
- Reserved Capacity
- On-Peak/Off-Peak Rates
- Formula Rates
- Revenue Requirements
- SPP OATT
- Transmission Pricing
- Capacity Reservations
- LCEC
- Southwestern Public Service
- Sunflower Electric
- Upper Missouri Zone
- Balanced Portfolio
- Schedule 7 and 8 Revenues

## 8. Items That May Need Follow-Up

### Operational Follow-Up:
1. **Annual Rate Posting Verification** - Confirm timely posting of rate calculations by October 1 deadline on SPP and OASIS websites
2. **RRR File Updates** - Verify all applicable tabs are properly updated with new rates
3. **Multi-Entity Coordination** - Ensure coordinated rate calculations across all entities (SPS, LCEC, ITC Great Plains, Prairie Wind Transmission)

### Compliance Monitoring:
4. **Revenue Crediting Accuracy** - Verify proper implementation of Schedule 7 and 8 revenue adjustments and Attachment AU distributions
5. **Balanced Portfolio Reallocation** - Confirm adjustments are properly calculated per Section IV.A of Attachment J
6. **Rate Cap Enforcement** - Monitor that weekly/daily demand charge caps are properly applied

### Customer Service Issues:
7. **Lamar Tie Line Discounted Rate Application** - Ensure 50% discount properly applied for PSCo-SPS Zone crossings
8. **Opposite Direction Service Billing** - Verify separate charges applied correctly for reverse direction services
9. **On-Peak/Off-Peak Definition Consistency** - Confirm consistent application of time definitions across all zones

### Documentation Needs:
10. **Formula Rate Transparency** - Verify all referenced attachments and addenda are accessible and current
11. **UMZ Multi-Owner Coordination** - Clarify rate application methodology with 14 different transmission owners in single zone
12. **NERC Holiday Updates** - Monitor any changes to NERC holiday definitions affecting rate calculations

### Strategic Questions:
13. **Capacity Designation Methodology** - Clarify how losses are "inclusive" at Points of Receipt
14. **Commission Approval Status** - Verify current FERC approval status for all UMZ transmission owners' rates

---

# Chunk 17 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document contains tariff language related to Point-to-Point (PTP) Transmission Service rates and Integrated Marketplace provisions within the SPP (Southwest Power Pool) system. The content focuses on rate structures for two main rate zones: the UMZ (Upper Missouri Zone) and Western Farmers Electric Cooperative (WFEC) zone. It also includes portions of Attachment AE governing the Integrated Marketplace, specifically addressing must-offer requirements, Day-Ahead Market execution, and resource commitment algorithms. The document appears to be tariff language filed with or approved by FERC.

## 2. Key Topics

- **Point-to-Point Transmission Service Rates**: Firm and Non-Firm transmission service rates for both UMZ and WFEC rate zones
- **Rate Calculation Methodologies**: Formula rates based on Annual Transmission Revenue Requirements (ATRR) for multiple transmission owners
- **Balanced Portfolio Reallocation Adjustment**: Adjustments to PTP rates based on Attachment J provisions
- **Revenue Crediting**: Schedule 7 and 8 revenue adjustments and Attachment AU allocations
- **Must-Offer Requirement**: Market participant obligations in the Day-Ahead Market
- **Day-Ahead Market Execution**: SCUC (Security-Constrained Unit Commitment) algorithm processes
- **Resource Commitment**: Procedures for committing resources to meet demand, export transactions, and operating reserve requirements

## 3. Decisions or Actions

- Transmission Customers must compensate Transmission Provider based on Reserved Capacity at rates calculated pursuant to specific formula rates
- Market Participants must comply with must-offer obligations or face penalties per Section 3.9 of Attachment AF
- Market Monitor will monitor Market Participant compliance with must-offer obligations for each hour
- Day-Ahead Market SCUC algorithm will prioritize:
  1. Curtail non-firm fixed Export Interchange Transaction Bids when capacity is insufficient
  2. Incorporate emergency capacity limits and commit reliability-only resources on an economic basis
- Rates must be posted in the Revenue Requirements and Rates (RRR) File on the SPP website

## 4. Important Dates

- No specific dates mentioned in this content chunk
- References to timeframes include:
  - Yearly, Monthly, Weekly, Daily, and Hourly delivery periods for rate calculations
  - Operating Day (for Day-Ahead Market operations)
  - 730 hours per month (for hourly rate calculations)

## 5. Organizations and People Mentioned

**Transmission Owners/Organizations:**
- Basin Electric
- Heartland
- MRES (Missouri River Energy Services)
- MRES Members (includes: Moorhead Public Service, Orange City Municipal Utilities, City of Pierre South Dakota, City of Sioux Center Iowa, Watertown Municipal Utility Department, Denison Municipal Utilities, Vermillion Light & Power)
- East River
- Corn Belt
- NWPS (Northwest Public Service)
- NIPCO
- HMU
- Western-UGP
- Central Power
- Mountrail-Williams
- Mor-Gran-Sou
- Roughrider
- LOPC
- Western Farmers Electric Cooperative (WFEC)
- People's Electric Cooperative (PEC)

**Entities Referenced:**
- SPP (Southwest Power Pool) - Transmission Provider
- Market Monitor
- Market Participant(s)
- Asset Owner(s)
- Transmission Customer(s)

## 6. Links or References

**Tariff Attachments:**
- Attachment T (Point-to-Point Transmission Service rates)
- Attachment J, Section IV.A (Balanced Portfolio Reallocation)
- Attachment AU (Revenue distribution and allocation)
- Attachment H, Addendums: 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 37, 39, 40, 41, 42, 45, 47, 49, 51
- Attachment AE (Integrated Marketplace)
- Attachment AF, Section 3.9 (Penalties)

**Specific Sections:**
- Section 34.1(2) of the Tariff (Revenue crediting implementation)
- Sections 4.1(10)(a), 4.1(10)(b), 4.1(10)(c) (Commitment status)
- Section 2.11.1(A)(1) and 2.11.1(B) (Must-offer requirements)
- Section 5.1.2 (Day-Ahead Market Execution)

**External References:**
- RRR File (Revenue Requirements and Rates File) posted on SPP website
- Schedule 7 and 8 revenues
- WFEC Formula Rate (Attachment H, Addendum 39)
- PEC Formula Rate (Attachment H, Addendum 51)

## 7. Suggested Tags

- Point-to-Point Transmission
- Transmission Rates
- Formula Rates
- SPP Tariff
- Day-Ahead Market
- Must-Offer Requirement
- SCUC Algorithm
- Revenue Requirements
- UMZ Rate Zone
- WFEC Rate Zone
- Market Compliance
- Operating Reserves
- Resource Commitment
- Integrated Marketplace
- FERC Tariff

## 8. Items That May Need Follow-Up

1. **RRR File Verification**: Confirm that the Revenue Requirements and Rates File on the SPP website contains current rates for all listed transmission owners in both UMZ and WFEC zones

2. **Formula Rate Updates**: Track updates to the 20+ Addendums to Attachment H referenced for various transmission owner formula rates

3. **Must-Offer Compliance Monitoring**: Verify Market Monitor reporting procedures for tracking Market Participant compliance with must-offer requirements

4. **Penalty Assessment**: Review Section 3.9 of Attachment AF to understand penalty calculations for must-offer requirement violations

5. **Load Estimate Methodology**: Clarify how "UMZ total load estimate" is calculated and updated for rate determination purposes

6. **Emergency Capacity Protocols**: Review procedures for incorporating emergency capacity limits and reliability-only resource commitments

7. **Revenue Crediting Reconciliation**: Track Schedule 7 and 8 revenue adjustments and Attachment AU allocations to ensure proper rate adjustments

8. **SCUC Algorithm Performance**: Monitor Day-Ahead Market SCUC algorithm effectiveness in meeting demand, export transactions, and operating reserve requirements

9. **Multi-Configuration Resources (MCR)**: Understand restrictions on MCR eligibility for Regulation Services during configuration transitions

10. **Incomplete Text**: The document appears to cut off mid-sentence at the end - obtain complete text for full analysis

---

# Chunk 18 Analysis

# Regulatory Content Analysis Report
## RR696 Integrate/Operate High Impact Large Loads - Chunk 18/26

---

## 1. Executive Summary

This document section details the operational procedures for Day-Ahead Market Security-Constrained Unit Commitment (SCUC) and Day-Ahead Reliability Unit Commitment processes within a wholesale electricity market. It establishes protocols for managing capacity surplus/shortage situations, manual resource commitments, local reliability issues, and compensation mechanisms. The content focuses on how the Transmission Provider manages system security constraints while minimizing costs and maintaining non-discriminatory practices subject to Market Monitor verification.

---

## 2. Key Topics

- **Day-Ahead Market SCUC Algorithm Operations**
  - Capacity surplus management procedures
  - Priority order for curtailments and resource deployment
  - Integration of emergency capacity limits

- **Manual Resource Commitments**
  - Authority and procedures for manual commitment/decommitment
  - Non-discriminatory selection requirements
  - Cost minimization protocols

- **Local Reliability Issues and Emergency Conditions**
  - Recognition and response procedures
  - Coordination between Transmission Provider and local transmission operators
  - Distinction between Local Reliability Issues and Local Emergency Conditions

- **Day-Ahead Reliability Unit Commitment (RUC)**
  - Capacity adequacy analysis methodology
  - Resource commitment optimization
  - SCUC algorithm operation for reliability purposes

- **Compensation and Cost Recovery**
  - Regional vs. local cost allocation
  - Recovery mechanisms under Sections 8.5.9, 8.6.5, 8.6.7(A), 8.6.44

- **Operating Reserve Requirements**
  - Regulation-Up and Regulation-Down services
  - MCR (Multi-Configuration Resource) eligibility restrictions
  - Co-optimization logic for marginal cost pricing

---

## 3. Decisions or Actions

**Automated Actions by SCUC Algorithm:**
1. Curtail non-firm fixed Import/Export Interchange Transaction Offers (priority order based on situation)
2. Incorporate emergency capacity limits when needed
3. Commit or decommit charging resources based on market conditions
4. Apply capacity up to Maximum Emergency/Minimum Emergency Operating Limits

**Manual Actions by Transmission Provider:**
1. Manually commit/decommit Resources to address security constraints not solvable by algorithm
2. Issue instructions for Local Reliability Issues (directly or at local operator request)
3. Re-run Day-Ahead SCUC algorithm after manual commitments (time permitting)
4. Notify Market Participants when units are manually committed

**Coordination Requirements:**
1. Transmission Provider, local transmission operators, and Resource owners must develop operating guides for manual commitments
2. Market Monitor must verify non-discriminatory selection of manual commitments (Section 6.1.2.1)

---

## 4. Important Dates

- **Upcoming Operating Day** - Referenced throughout as the planning horizon for Day-Ahead Market and Reliability Unit Commitment processes
- **30 minutes** - Threshold for MCR Transition State Time affecting Operating Reserve eligibility

*Note: No specific calendar dates are mentioned in this chunk.*

---

## 5. Organizations and People Mentioned

**Organizations:**
- **Transmission Provider** - Primary system operator and market administrator
- **Market Monitor** - Verification and oversight entity
- **Local transmission operators** - Regional/local system operators
- **Market Participants** - Generic reference to market entities
- **Resource owners** - Entities owning generation/storage resources
- **Reliability Coordinator** - Authority role for transmission system security

**People:**
- None specifically named

---

## 6. Links or References

**Internal Document References:**
- Section 3.3.1 of Attachment AE (SCED algorithm description)
- Section 4.1(10)(b) of Attachment AE (Market commitment status)
- Section 4.1(10)(c) of Attachment AE (Reliability only use designation)
- Section 6.1.2.1 of Attachment AE (Market Monitor verification process)
- Section 8.3.2 of Attachment AE (VRL application in SCED)
- Section 8.5.9 of Attachment AE (Compensation for committed Resources)
- Section 8.5.10 of Attachment AE (Regional cost recovery)
- Section 8.6.5 of Attachment AE (RUC compensation)
- Section 8.6.7(A) of Attachment AE (Regional cost collection)
- Section 8.6.44 of Attachment AE (Local cost collection)

**Technical Terms/Acronyms:**
- SCUC (Security-Constrained Unit Commitment)
- SCED (Security-Constrained Economic Dispatch)
- MCP (Marginal Clearing Price)
- MCR (Multi-Configuration Resource)
- VRL (Voltage Reduction Limit or similar)
- RTBM (Real-Time Balancing Market)

---

## 7. Suggested Tags

- Day-Ahead Market
- Unit Commitment
- Reliability Unit Commitment
- SCUC Algorithm
- Local Reliability Issues
- Manual Commitments
- Transmission System Security
- Market Monitor
- Operating Reserves
- Capacity Adequacy
- Cost Recovery
- Emergency Capacity Limits
- Resource Commitment
- Market Operations
- Non-Discriminatory Selection
- Interchange Transactions

---

## 8. Items That May Need Follow-Up

**Procedural Clarifications:**
1. **Operating Guide Development** - Status of operating guides being developed by Transmission Provider, local transmission operators, and Resource owners for manual commitments addressing recurring Local Reliability Issues

2. **Market Monitor Verification Process** - Details of the non-discriminatory selection verification process referenced in Section 6.1.2.1

3. **Cost Allocation Boundaries** - Clear delineation between situations requiring regional vs. local cost recovery (Sections 8.5.10 vs. 8.6.44)

**Technical Implementation:**
4. **VRL Application Criteria** - Specific situations and thresholds triggering Virtual Reduction Limits in SCED (referenced in Section 8.3.2)

5. **MCR Transition Rules** - Complete rules governing Multi-Configuration Resource eligibility during configuration transitions (30-minute threshold mentioned)

6. **Re-run Protocol** - Criteria for determining when time permits re-running Day-Ahead SCUC after manual commitments

**Coordination Concerns:**
7. **Local Operator Request Process** - Formal procedures and documentation requirements when local transmission operators request manual commitments

8. **Notification Timing** - Timing and method requirements for notifying Market Participants of manual commitments

**Compliance & Monitoring:**
9. **Market Monitor Reporting** - Frequency and format of Market Monitor verification reports on non-discriminatory selection

10. **Emergency Limit Usage Tracking** - Monitoring and reporting on frequency of emergency capacity limit utilization

---

**Document Context Note:** This is chunk 18 of 26, indicating this content is part of a larger regulatory document. Cross-references to other sections suggest comprehensive market operation procedures extending beyond this excerpt.

---

# Chunk 19 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary

This document section (chunk 19 of 26) from RR696 details the Intra-Day Reliability Unit Commitment (RUC) execution procedures and Market Protocols. It establishes procedures for how the Transmission Provider commits resources to meet load forecasts and operating reserve requirements while minimizing costs and maintaining system reliability. The content covers SCUC algorithm operations, handling of local reliability issues, non-conforming load forecasting requirements, and must-offer obligations for market participants. Key themes include coordination between Transmission Providers and local transmission operators, compensation mechanisms for committed resources, and Market Monitor verification processes.

## 2. Key Topics

- **Intra-Day Reliability Unit Commitment (RUC) Execution Process**
  - SCUC (Security-Constrained Unit Commitment) algorithm operation
  - Commitment cost minimization strategies
  - Resource capacity adequacy analysis

- **Resource Commitment Hierarchy**
  - Maximum/Minimum Economic Capacity Operating Limits
  - Emergency capacity utilization procedures
  - Reliability-only resource deployment

- **Local Reliability Issues Management**
  - Manual commitment/decommitment procedures
  - Local Emergency Condition protocols
  - Coordination between Transmission Provider and local transmission operators

- **Non-Conforming Load Requirements**
  - Hourly load forecast submission requirements
  - ESR (Energy Storage Resource) charging load modeling
  - 15-minute rolling forecast obligations

- **Must-Offer Requirements**
  - Day-Ahead Market obligations
  - Asset Owner-specific requirements
  - Bilateral contract load registration impacts

## 3. Decisions or Actions

**Transmission Provider Actions:**
- Perform capacity adequacy analysis using SCUC algorithm
- Manually commit/decommit Resources for reliability issues not addressable within SCUC
- Coordinate with local transmission operators on Local Reliability Issues
- Log manual commitments and decommitments
- Collect compensation payments regionally or locally as appropriate

**Local Transmission Operator Actions:**
- Request manual commitments from Transmission Provider for Local Reliability Issues
- Issue direct instructions to Resources during Local Emergency Conditions when time-critical
- Notify Transmission Provider of instructions given to Resources
- Develop operating guides with Transmission Provider and Resource owners

**Market Participant Actions:**
- Submit hourly load forecasts for Non-Conforming Load before Day-Ahead RUC begins
- Submit forecasts for Operating Day plus six days following
- Provide rolling 15-minute ahead forecasts
- Submit actual Non-Conforming Load data or estimates
- Satisfy must-offer obligations for registered loads

**Market Monitor Actions:**
- Verify non-discriminatory selection of manually committed Resources
- Determine whether Resources affiliated with local transmission operators were selected discriminatorily
- Apply standards and procedures from Section 6.1.2.1

## 4. Important Dates

**Recurring Timeframes:**
- **Before Day-Ahead RUC**: Initial Non-Conforming Load hourly forecasts due
- **Up to 30 minutes before Operating Hour**: Final Non-Conforming Load forecast updates allowed
- **Operating Day + 6 days**: Forecast horizon requirement
- **Every 15 minutes**: Rolling forecast update basis
- **2 hours ahead**: Encouraged forecast submission for each 15-minute interval

## 5. Organizations and People Mentioned

**Organizations:**
- **Transmission Provider** (SPP - Southwest Power Pool, referenced in Market Protocols section)
- **Local Transmission Operator(s)**
- **Market Monitor**
- **Resource Owners**
- **Market Participants**
- **Asset Owners**

**Roles Referenced:**
- No specific individuals named; all references are to organizational roles and functions

## 6. Links or References

**Internal Document References:**
- Section 8.6.44 of Attachment AE (local compensation collection)
- Section 6.1.1 of Attachment AE (SCUC inputs)
- Section 4.1(10)(c) of Attachment AE (reliability-only Resources)
- Section 4.1(10)(b) of Attachment AE (market commitment status)
- Section 6.1.2.1 of Attachment AE (Market Monitor verification process)
- Section 8.6.5 of Attachment AE (Resource compensation)
- Section 8.6.7(A) of Attachment AE (regional compensation collection)
- Section 6.2.2 (Non-Conforming Load description)
- Section 6.2.8 (bilateral contract load registration)

**Referenced Components:**
- RTBM Offers (Real-Time Balancing Market)
- Day-Ahead Market
- Start-Up Offer, No-Load Offer, Energy Offer Curve
- Operating Reserve Offers
- Export/Import Interchange Transactions

## 7. Suggested Tags

- Reliability Unit Commitment
- SCUC Algorithm
- Intra-Day RUC
- Local Reliability Issues
- Resource Commitment
- Non-Conforming Load
- Market Protocols
- Must-Offer Requirement
- Transmission Operations
- Energy Storage Resources
- Market Monitor
- Manual Commitment
- Local Emergency Condition
- Capacity Adequacy
- Operating Reserves
- Compensation Recovery

## 8. Items That May Need Follow-Up

**Process Clarifications Needed:**
1. **Market Monitor Verification Standards**: Section 6.1.2.1 referenced multiple times for non-discriminatory selection verification—ensure these standards are clearly defined and accessible
2. **Operating Guide Development**: Multiple references to developing operating guides between Transmission Provider, local operators, and Resource owners—track completion status
3. **Affiliation Determination**: Criteria for determining if a Resource is "affiliated with the local transmission operator" needs clear definition for compensation eligibility decisions

**Operational Concerns:**
4. **Time Permitting Determination**: No specific timeframe defined for when local transmission operators can act independently during Local Emergency Conditions vs. requesting Transmission Provider action
5. **Non-Conforming Load Metering**: Process for handling Non-Conforming Load "for which metering is not available"—quality assurance measures needed
6. **Self-Charging MW Calculation**: Impact on must-offer obligation calculations when MSR is Self-Charging requires validation methodology

**Coordination Issues:**
7. **Multi-party Operating Guide Development**: Coordination mechanism between Transmission Provider, local transmission operators, and Resource owners for developing operating guides for recurring Local Reliability Issues
8. **Bilateral Contract Load Registration**: Tracking and validation of load transfers between buyers and sellers under bilateral contracts

**Financial/Compensation:**
9. **Local vs. Regional Cost Recovery**: Clear criteria needed for determining when compensation is collected locally (Section 8.6.44) vs. regionally (Section 8.6.7(A))
10. **Discriminatory Selection Penalties**: Financial implications when affiliated Resources are denied compensation due to discriminatory selection

**Data Quality:**
11. **15-minute Forecast Interpolation**: Quality control for SPP interpolation when 15-minute forecasts are unavailable
12. **Forecast Deviation Thresholds**: Define when Market Participants "are encouraged" vs. "required" to submit updated forecasts

---

# Chunk 20 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document excerpt is from SPP's (Southwest Power Pool) market protocols governing resource commitment and Day-Ahead (DA) Market operations. The content details the must-offer obligation requirements for Market Participants, calculating net resource capacity, compliance thresholds, and the DA Market execution process. Key provisions include a 90% capacity threshold for compliance, treatment of firm power purchases/sales, and the Security Constrained Unit Commitment (SCUC) and Security Constrained Economic Dispatch (SCED) algorithms for market clearing. The document also addresses manual commitments for reliability issues and Local Emergency Conditions.

## 2. Key Topics

- **Must-Offer Obligation Requirements**: Market Participants must offer resources with sufficient capacity to meet load and Operating Reserve obligations
- **Net Resource Capacity Calculation**: Methodology for calculating capacity including firm power purchases/sales and Jointly Owned Units (JOUs)
- **Compliance Thresholds**: 90% net resource capacity threshold for deemed compliance
- **GFA Carve Out Requirements**: Source resources must be offered with sufficient capacity
- **DA Market Execution Process**: SCUC and SCED algorithm-based co-optimization methodology
- **Resource Commitment Hierarchy**: Market, Self, and Reliability commitment statuses
- **Emergency Capacity Utilization**: Protocols for incorporating emergency limits when standard capacity is insufficient
- **Manual Commitment Authority**: SPP's ability to manually commit/decommit resources for reliability
- **Local Reliability Issues**: Special handling and compensation for local transmission system constraints

## 3. Decisions or Actions

- Market Monitor will monitor participant compliance hourly for each Asset Owner
- Market Participants must provide supporting documentation for firm power purchases/sales upon Market Monitor request
- Market Participants have option to input firm power transaction information into Market Monitor website
- SPP will verify manual commitments in non-discriminatory manner through Market Monitor process
- SPP will re-run DA SCUC algorithm after manual commitments (time permitting)
- SPP will notify Market Participants when units are manually committed
- Operating guides will be developed by SPP, local transmission operators, and Resource owners for known/recurring Local Reliability Issues

## 4. Important Dates

- **Operating Day**: The upcoming day for which the DA Market clears (referenced throughout as the timeframe for compliance and execution)
- No specific calendar dates are mentioned in this excerpt

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)**: Regional Transmission Organization and market operator
- **Market Monitor**: Compliance monitoring entity
- **Asset Owner(s)**: Entities owning generation resources
- **Market Participant(s)**: Entities participating in SPP markets
- **Local Transmission Operator(s)**: Operators of local transmission systems
- **Resource Owners**: Owners of generation facilities
- **Reliability Coordinator**: SPP in its reliability oversight role

### People:
- No specific individuals mentioned

## 6. Links or References

### Internal Document References:
- Section 4.1.3(4) - Operating Reserve obligation calculations
- Section 4.2.1.1 - Must-offer obligation requirements
- Section 4.2.1.1.1 - Penalty assessment provisions
- Section 4.2.2.5.4 - JOU Individual Resource Option
- Section 6.1.14 - Combined Interest Resource modeling
- Section 6.1.7.1 - MCR registration options
- Section 6.1.2.1 of Attachment AE - Market Monitor verification process
- Section 4.5.9.12 - Resource compensation provisions
- Section 4.5.9.13 - Regional cost recovery
- Section 4.5.8.12 - Resource compensation (alternative reference)
- Section 4.5.9.10(1) - Local cost recovery

### Service Types Referenced:
- Firm Point-To-Point Transmission Service
- Firm Network Integration Transmission Service

## 7. Suggested Tags

- SPP Market Rules
- Must-Offer Obligation
- Day-Ahead Market
- Resource Commitment
- Market Compliance
- SCUC Algorithm
- SCED Algorithm
- Operating Reserves
- Capacity Requirements
- Local Reliability Issues
- Manual Commitment
- Market Monitor
- Firm Power Transactions
- Emergency Capacity
- GFA Carve Out
- Jointly Owned Units
- Multi-Configuration Resources

## 8. Items That May Need Follow-Up

1. **Penalty Structure**: Section 4.2.1.1.1 is referenced for non-compliance penalties but details are not provided in this excerpt
2. **Operating Guide Development**: Timeline and process for developing operating guides for manual commitments addressing Local Reliability Issues needs clarification
3. **Market Monitor Website**: Functionality and accessibility of the website for inputting firm power transaction information
4. **Dispute Resolution**: Process for resolving disputes between parties regarding firm power purchases/sales needs further documentation
5. **Manual Commitment Re-run Protocol**: Circumstances when "time permitting" would prevent re-running SCUC algorithm after manual commitments
6. **Emergency Limit Thresholds**: Specific criteria triggering incorporation of Maximum/Minimum Emergency Capacity Operating Limits
7. **MCR Transition Rules**: Details on Multi-Configuration Resource transitions and regulation ineligibility periods (Section 6.1.7.1)
8. **Cost Allocation Disputes**: Potential conflicts between regional vs. local cost recovery for reliability commitments
9. **Verification Timeline**: Market Monitor verification process timeline for manual commitments
10. **Non-Firm Transaction Curtailment**: Priority and methodology for curtailing non-firm Export/Import Interchange Transactions

---

# Chunk 21 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary

This document chunk (21 of 26) from "RR696 Integrate _ Operate High Impact Large Loads" contains detailed technical specifications for SPP's (Southwest Power Pool) energy market operations, specifically focusing on Security-Constrained Economic Dispatch (SCED), Security-Constrained Unit Commitment (SCUC), Day-Ahead Reliability Unit Commitment (RUC), and Intra-Day RUC execution processes. The content outlines algorithmic optimization procedures, resource commitment hierarchies, capacity adequacy protocols, and procedures for handling reliability issues including Local Reliability Issues. The document establishes rules for market clearing prices, violation relaxation limits, and compensation mechanisms for various resource commitments.

## 2. Key Topics

- **SCED Algorithm Operations**: Marginal loss sensitivity factors, energy dispatch optimization, and Violation Relaxation Limits (VRLs)
- **Co-optimization Logic**: Market clearing prices for operating reserves and lost opportunity cost calculations
- **Multi-Configuration Resources (MCRs)**: Transition time restrictions (>30 minutes) affecting contingency reserve and regulation service eligibility
- **Day-Ahead RUC Execution**: Capacity adequacy analysis using SCUC algorithm
- **Resource Commitment Priority Hierarchy**: Market, Self, and Reliability commit statuses with defined sequence for capacity shortfalls/surpluses
- **Capacity Limits Framework**: Maximum/Minimum Economic, Emergency, Discharge, and Charge limits
- **Local Reliability Issues**: Protocols for manual commitments by transmission operators
- **Intra-Day RUC Execution**: Real-time capacity adequacy analysis and adjustments
- **Non-firm Transaction Curtailment**: Priority order for import/export curtailments
- **Operating Reserve Requirements**: Integration with resource commitment decisions

## 3. Decisions or Actions

- **SCUC Priority Order for Capacity Shortfalls**:
  1. Curtail non-firm Export Interchange Transactions
  2. Incorporate emergency capacity limits
  3. Commit Reliability Status Resources
  4. De-commit Market-committed charging resources
  5. De-commit self-committed charging resources

- **SCUC Priority Order for Capacity Surplus**:
  1. Curtail non-firm fixed Import Interchange Transactions
  2. Incorporate minimum emergency capacity limits
  3. Commit Reliability Resources capable of charging
  4. De-commit Market-committed resources
  5. De-commit self-committed resources

- **Manual Commitment Authority**: SPP authorized to manually commit/de-commit resources for transmission system reliability issues not addressable within SCUC algorithm
- **Operating Guides Development**: SPP, local transmission operators, and resource owners must develop operating guides for manual commitments addressing known/recurring Local Reliability Issues
- **Market Monitor Oversight**: Non-discriminatory selection of manual commitments validated through Section 6.1.2.1 process

## 4. Important Dates

- **MCR Transition Restrictions**: Resources with transition times >30 minutes ineligible during transition hours
- **Operating Day**: Referenced throughout as the timeframe for RUC execution and capacity analysis
- **30-Minute Threshold**: Critical timing parameter for MCR eligibility determination

*Note: No specific calendar dates are mentioned in this chunk*

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)**: Primary market operator and reliability coordinator
- **SPP Operators**: Personnel executing RUC operations
- **SPP RUC Operators**: Specific operators for Day-Ahead and Intra-Day RUC
- **Market Monitor**: Oversight entity validating non-discriminatory commitment selections
- **Local Transmission Operators**: Regional transmission system operators requesting manual commitments
- **Market Participants**: General reference to entities participating in energy markets
- **Resource Owners**: Entities owning generation/storage resources

**People:** None specifically named

## 6. Links or References

**Internal Document References:**
- Section 3.1.1 (transmission constraints)
- Section 4.1.3.3 (Violation Relaxation Limits in SCED)
- Section 6.1.7.1 (MCR registration option)
- Section 6.1.2.1 of Attachment AE to the Tariff (Market Monitor process)
- Section 4.5.9.8 (compensation for committed resources)
- Section 4.5.9.10 (recovery of compensation - regional and local collection)

**Technical References:**
- SCED algorithm specifications
- SCUC algorithm specifications
- RTBM Offers (Real-Time Balancing Market)
- SPP Mid-Term Load Forecast
- Shadow Price calculation methodology

## 7. Suggested Tags

`SPP` `SCED` `SCUC` `Day-Ahead-RUC` `Intra-Day-RUC` `capacity-adequacy` `resource-commitment` `operating-reserves` `reliability-coordinator` `Local-Reliability-Issue` `manual-commitment` `transmission-constraints` `Multi-Configuration-Resources` `MCR` `Violation-Relaxation-Limits` `VRL` `market-clearing-price` `energy-dispatch` `export-interchange` `import-interchange` `emergency-capacity` `commitment-costs` `transmission-operator` `Market-Monitor` `non-discriminatory-selection` `operating-guides` `RR696`

## 8. Items That May Need Follow-Up

1. **MCR Transition Time Policy**: Clarification needed on rationale for 30-minute threshold and impact on market participants with longer transition times

2. **Local Reliability Issue Definition**: Need clear criteria distinguishing Local Reliability Issues from general transmission system reliability issues for proper cost allocation (local vs. regional)

3. **Manual Commitment Process Documentation**: Status of operating guides development between SPP, local transmission operators, and resource owners for known/recurring issues

4. **Market Monitor Validation Process**: Details on Section 6.1.2.1 process for verifying non-discriminatory manual commitment selection

5. **Cost Recovery Mechanism**: Implementation details for local vs. regional cost collection under Section 4.5.9.10 need verification

6. **Advisory vs. Binding Actions**: Clarification on when RUC algorithm outputs transition from advisory to binding operational instructions

7. **Coordination Protocol**: Formal procedures for local transmission operator requests to SPP for manual commitments

8. **Emergency Limit Usage**: Frequency and conditions under which emergency operating limits are actually utilized vs. remaining advisory

9. **De-commitment Authority**: Limits on SPP's authority to de-commit self-committed resources, particularly for Local Reliability Issues

10. **MCR Registration Documentation**: Complete requirements under Section 6.1.7.1 and impact on regulation service eligibility

11. **Shadow Price Calculation**: Detailed methodology ensuring market participant indifference between energy and operating reserve clearance

12. **Commitment Cost Minimization**: Verification that manual commitment selection actually achieves cost minimization objectives while maintaining non-discriminatory treatment

---

# Chunk 22 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary
This document chunk contains regulatory language from Southwest Power Pool (SPP) governing documents, including Market Protocols (Tariff Attachment AE), Operating Criteria, Planning Criteria, and Business Practices. The content primarily addresses procedures for resource commitment and dispatch during reliability issues, registration requirements for non-conforming loads, communication protocol requirements, transmission system planning standards, and interconnection study procedures for non-jurisdictional facilities. The text emphasizes coordination between SPP, local transmission operators, and resource owners while maintaining non-discriminatory practices subject to Market Monitor verification.

## 2. Key Topics
- **Manual Resource Commitment Procedures**: Out-of-merit commitment/dispatch instructions for local reliability issues
- **Market Monitor Oversight**: Verification of non-discriminatory resource selection per Section 6.1.2.1 of Attachment AE
- **Compensation and Cost Recovery**: Regional vs. local cost allocation for committed resources under Section 4.5.9.8 and 4.5.9.10
- **Local Emergency Conditions**: Protocols for transmission operator direct instructions when time-critical
- **Non-Conforming Load Registration**: Requirements for loads 50 MW or greater
- **ICCP Node Connectivity**: Redundancy and failover requirements for TOPs and GOPs
- **Emergency Operating Plans (EOPs)**: Load shedding rotation and critical natural gas load prioritization
- **Transmission Material Modification**: Definitions and thresholds for system changes requiring analysis
- **Non-Jurisdictional Generator Interconnection**: Study procedures for facilities outside SPP OATT jurisdiction

## 3. Decisions or Actions
- **Resource Commitment**: SPP selects resources to minimize commitment costs while maintaining security constraints
- **Local Transmission Operator Authority**: May issue direct instructions during Local Emergency Conditions if time does not permit SPP coordination
- **Required Notifications**: Transmission Operators must notify SPP of instructions given to resources
- **Coordination Requirement**: SPP and Transmission Operators must coordinate subsequent instructions
- **Operating Guides Development**: SPP, local transmission operators, and resource owners will develop guides for manual commitments addressing known/recurring local reliability issues
- **Non-Conforming Load Identification**: Market Participants must identify loads ≥50 MW and their PNode/APNode location
- **ICCP Node Configuration**: TOPs must connect to both SPP primary and backup sites concurrently; alternate nodes must reconnect within 240 seconds
- **System Change Analysis**: SPP shall analyze Transmission Material Modifications and Qualified Changes per OATT and NERC standards

## 4. Important Dates
- **240 seconds**: Maximum reconnection time for alternate ICCP nodes following failure
- **12 months**: Threshold duration for defining "permanent change" in Qualified Change and Transmission Material Modification definitions
- No specific calendar dates or deadlines mentioned in this chunk

## 5. Organizations and People Mentioned
**Organizations:**
- **SPP (Southwest Power Pool)**: Primary entity responsible for market operations, resource commitment, and planning coordination
- **Market Monitor**: Verification authority for non-discriminatory resource selection
- **Local Transmission Operators**: Issue reliability instructions and coordinate with SPP
- **NERC (North American Electric Reliability Corporation)**: Standards authority (referenced: FAC-002-041)
- **TOPs (Transmission Operators)**: Registered NERC entities within SPP RC Area
- **GOPs (Generator Operators)**: Registered NERC entities within SPP RC Area
- **Transmission Owners**: Host entities for delivery point changes
- **Market Participants**: Entities required to identify Non-Conforming Loads
- **Resource Owners**: Participants in operating guide development

**People:** None specifically named

## 6. Links or References
**Internal References:**
- Section 4.5.9.8 (Resource compensation)
- Section 4.5.9.10 (Cost recovery and allocation)
- Section 6.1.2.1 of Attachment AE (Market Monitor verification process)
- Attachment O (Transmission Planning Process)
- Attachment V (Generator interconnection and generation changes)
- Attachment AB (Retirement process)
- Attachment AQ (Delivery point changes)
- Section 1 of Attachment V (Material Modification definition)
- Section 5.2, 5.4, and 5.5 of SPP Planning Criteria
- Business Practice 7250, Section 6.3
- RDS (Telemetering and Control System Status) - Outage Scheduling Information

**External References:**
- NERC Reliability Standards (general)
- NERC Standard FAC-002-041 (Facility interconnection studies)
- NERC Glossary of Terms
- SPP Open Access Transmission Tariff (OATT)
- Inter-Control Center Communications Protocol (ICCP)

## 7. Suggested Tags
- Resource Commitment
- Market Operations
- Local Reliability Issues
- Emergency Operations
- Market Monitor
- Cost Allocation
- Non-Conforming Load
- ICCP Requirements
- Transmission Planning
- Material Modification
- Generator Interconnection
- Load Shedding
- System Security
- Real-Time Operations
- Reliability Coordination
- Transmission System
- NERC Compliance
- Operating Guides
- Emergency Operating Plans

## 8. Items That May Need Follow-Up

**Clarification Needed:**
1. **Affiliated Resource Definition**: The text mentions "affiliated Resource" in context of discriminatory selection but doesn't define the relationship threshold
2. **Operating Guide Status**: No indication of completion status or timeline for development of operating guides for manual commitments
3. **APNode Eligibility**: Criteria for "same location" when representing Non-Conforming Load via APNode needs clearer definition (e.g., what constitutes "single industrial process")

**Potential Compliance Gaps:**
1. **Third-Party ICCP Contracts**: Requirement states third parties "should" reconnect within 240 seconds—verify if this is enforceable obligation
2. **GOP Threshold Application**: 1500 MW threshold for dual ICCP node requirement—confirm whether this is net aggregate generation at any time or based on specific measurement period

**Coordination Issues:**
1. **Market Monitor Verification Timeline**: No specified timeframe for Market Monitor determination of discriminatory selection
2. **Local Emergency Condition Definition**: Not defined in this section—ensure consistency with NERC/regional definitions
3. **Operating Guide Development Process**: No specified stakeholders, approval process, or implementation timeline

**Cost Recovery Questions:**
1. **Regional vs. Local Cost Allocation**: Boundary conditions between regional collection (standard commitments) and local collection (local reliability issues) may need examples/clarification
2. **Denied Compensation Recovery**: Process when affiliated resources are denied compensation for discriminatory selection—who bears the costs?

**Implementation Monitoring:**
1. **240-Second Reconnection Compliance**: Verification and testing procedures for ICCP failover requirements
2. **Non-Conforming Load Registration**: Enforcement mechanism and update frequency for 50+ MW loads
3. **Critical Natural Gas Load Priority**: Implementation status of EOP recommendation for protecting gas loads during load shedding

---

# Chunk 23 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document section (chunk 23 of 26) from RR696 covers critical procedures for integrating and operating high-impact large loads within the SPP (Southwest Power Pool) system. The content primarily focuses on three key regulatory frameworks: generator interconnection procedures for distribution-connected facilities, Delivery Point evaluation processes (Business Practice 7850), and Resource Adequacy requirements for Demand Response Programs (Business Practice 8100). The material establishes formal processes for assessing system impacts, coordinating studies, and ensuring network upgrades are completed before facility operations commence.

## 2. Key Topics

- **Generator Interconnection Impact Assessment**: Procedures for Transmission Owners to evaluate and coordinate generator interconnection impacts on the Transmission System
- **SPP System Impact Studies**: Requirements for Definitive Interconnection System Impact Studies and coordination with affected systems
- **Network Upgrades**: Mandatory completion requirements and financial responsibility allocation between Transmission Owners and interconnection customers
- **Delivery Point Management (BP 7850)**: Processes for evaluating Delivery Point Additions, Modifications, and Retirements under Attachments AQ and AX
- **Resource Adequacy (BP 8100)**: Requirements for Demand Response Programs and Behind-The-Meter Generation under 10 MW
- **Study Process Coordination**: Integration between Attachment AQ, Attachment AX, and Integrated Transmission Planning Assessment processes

## 3. Decisions or Actions

- Transmission Owners must notify SPP when generator interconnections may impact the Transmission System and provide system impact studies
- SPP determines what additional studies are required for affected system coordination
- Transmission Owner/distribution provider must require completion of all SPP-required studies as a condition of interconnection
- All Network Upgrades must be completed prior to Generating Facility operation unless alternative mitigations are approved by SPP
- Transmission Customers are responsible for notifying SPP to update NITS Agreements for Delivery Point changes
- Transmission Provider must approve aggregation of multiple Delivery Point requests and evaluate feedback from all parties before proceeding
- Non-controllable and non-dispatchable Demand Response Programs may only be considered in LRE's forecasted Peak Demand

## 4. Important Dates

- No specific dates mentioned in this section
- Reference to "future" regarding delivery points ceasing to serve load
- Timeframe requirements reference BP 7060 for standardized project timelines based on Network Upgrade need dates

## 5. Organizations and People Mentioned

**Organizations:**
- SPP (Southwest Power Pool) - Transmission Provider
- Associated Electric Cooperatives, Inc.
- California Independent System Operator Corporation
- Electric Reliability Council of Texas (ERCOT)
- Midcontinent Independent System Operator, Inc. (MISO)
- Peak
- Public Service Company of Colorado
- Saskatchewan Power Corporation
- Southwestern Power Administration
- Tennessee Valley Authority

**Roles Referenced:**
- Transmission Owners
- Distribution Providers
- Transmission Customers
- Network Customers
- Interconnection Customers
- Load Responsible Entities (LRE)
- Market Participants

## 6. Links or References

**Referenced Documents:**
- SPP Open Access Transmission Tariff (OATT)
- Generator Interconnection Procedures (Attachment V)
- SPP Business Practices
- Attachment AQ (Delivery Point evaluation process)
- Attachment AX (Delivery Point Additions with planned generation)
- Attachment AA (Resource Adequacy Requirements)
- Business Practice 7850 (Delivery Point processes)
- Business Practice 7060 (standardized project timelines)
- Business Practice 8100 (Resource Adequacy for Demand Response)
- Seams Agreements (various ISOs/utilities)
- SPP Disturbance Performance Requirements
- SPP Quarterly Project Tracking Report
- Request Management System
- New Three Stage Interconnection Process
- ITP Manual
- SPP Model Development Procedure Manual

## 7. Suggested Tags

- Generator Interconnection
- System Impact Studies
- Network Upgrades
- Delivery Point Management
- Transmission Planning
- Resource Adequacy
- Demand Response
- Behind-The-Meter Generation
- OATT Compliance
- Attachment AQ
- Attachment AX
- Business Practice 7850
- Business Practice 8100
- Transmission Service
- NITS Agreement
- Load Forecasting
- Affected System Studies

## 8. Items That May Need Follow-Up

1. **Study Agreement Responsibility**: Clarification needed on circumstances when Transmission Owner versus interconnection customer enters into SPP study agreements and bears financial responsibility
2. **Mitigation Approval Process**: Details on the process and criteria for SPP approving alternative mitigations before Network Upgrades are completed
3. **Aggregation Criteria**: Specific definition of "relative proximity" for aggregating multiple Delivery Point requests and formal process for evaluating party feedback
4. **Interface Transmission Service**: Process for granting transmission service across interfaces for Delivery Points not physically interconnected with SPP Transmission System
5. **50-50 Forecast Methodology**: Technical details on maintaining 50-50 forecast probability when incorporating non-controllable/non-dispatchable demand response programs
6. **Behind-The-Meter Generation Threshold**: Rationale and implications of the 10 MW threshold for behind-the-meter generation resources
7. **NITS Agreement Update Process**: Detailed timeline and procedural steps for Transmission Customers to update agreements following Attachment AQ/AX reviews
8. **Facilities Agreement Terms**: Specific requirements and timelines for facilities agreements between SPP, Transmission Owners, and interconnection customers

---

# Chunk 24 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary
This document (chunk 24 of 26 from RR696) contains technical specifications from Southwest Power Pool (SPP) regarding load forecasting, demand response reporting, and transmission revenue requirements. The content primarily consists of detailed tariff tables listing transmission owners and their associated Annual Transmission Revenue Requirements (ATRR), along with procedural requirements for Load Responsible Entities (LREs) and Integrated Transmission Planning (ITP) processes.

## 2. Key Topics
- **Demand Response Programs**: Requirements for LREs to report projected MW levels of peak demand reduction using historical hourly demand data
- **Load Forecasting**: ITP assessment requirements for SPP Transmission Owners (TOs) and stakeholders for load forecasts representing non-coincident peak conditions
- **Persistent Operational Needs Assessment**: Criteria for identifying economic or reliability-related operational needs
- **Revenue Requirements Allocation**: Comprehensive listing of transmission owner revenue requirements for Through and Out transactions
- **Zonal ATRR Structure**: Detailed breakdown of Annual Transmission Revenue Requirements by zone and transmission owner

## 3. Decisions or Actions
- **LRE Reporting Requirement**: Each LRE must report projected MW level of Peak Demand reduction as an informational line item in the Workbook
- **Load Forecast Submission**: Load forecasts must be submitted to SPP using the process described in the Model Development Procedure Manual
- **Additional Needs Proposal**: SPP may propose additional operational needs not meeting standard criteria thresholds; these must be presented to ESWG and TWG for review and endorsement
- **Revenue Requirement References**: All specific dollar amounts and detailed requirements direct users to "See RRR File" or "See Att. H tab, posted RRR File"

## 4. Important Dates
- **June 19, 2010**: Referenced as a key date for Base Plan Zonal ATRR transitions (noted in Tables 3 and 4 with "prior to" and "on or after" distinctions)

## 5. Organizations and People Mentioned

### Organizations/Committees:
- **SPP (Southwest Power Pool)** - Regional Transmission Organization
- **ESWG (Economic Studies Working Group)** - Review body for operational needs
- **TWG (Transmission Working Group)** - Endorsement body for operational needs

### Transmission Owners (numerous entities including):
- AEP (American Electric Power) companies
- Evergy entities (Kansas Central, Metro, Missouri West)
- Oklahoma Gas and Electric
- Grand River Dam Authority
- Nebraska Public Power District
- Omaha Public Power District
- Southwestern Power Administration
- Multiple municipal utilities and electric cooperatives
- Independent transmission companies (ITC Great Plains, Transource entities, NextEra Energy Transmission Southwest)

## 6. Links or References
- **Model Development Procedure Manual** - Referenced for load forecast submission process
- **Integrated Transmission Planning (ITP) Manual Section 2.1.3** - Load Forecasts
- **Section 4.4** - Persistent Operational Needs Assessment
- **RRR File** - Revenue Requirements file (referenced extensively)
- **Attachment H tab** - Posted RRR File (referenced in tables)
- **Section II.2 and II.3** - Additional cross-references for AEP entities

## 7. Suggested Tags
- Transmission Planning
- Load Forecasting
- Revenue Requirements
- Demand Response
- ATRR (Annual Transmission Revenue Requirements)
- SPP Tariff
- Operational Needs Assessment
- Transmission Owners
- Point-to-Point Transmission
- Regional Transmission Organization
- Rate Design

## 8. Items That May Need Follow-Up

1. **Workbook Specifications**: The "Workbook" mentioned for LRE reporting is not defined in this chunk - clarification needed on format and submission deadlines

2. **Survey Methodology**: "Adequate system survey" mentioned for augmenting demand response data lacks detailed criteria

3. **RRR File Access**: All revenue requirement amounts reference external files - verify stakeholder access to current versions

4. **Criteria Thresholds**: Specific thresholds for identifying persistent operational needs are mentioned but not detailed in this section

5. **Reserved Zones**: Multiple zones marked "Reserved for Future Use" (1c, 11b, 15) - monitor for future assignments

6. **Revenue Credit Discrepancies**: Table 2 shows mix of "$0" and "N/A" values - clarification needed on distinction

7. **ESWG/TWG Review Process**: Timeline and formal procedures for endorsement of additional operational needs not specified

8. **Study Year Parameters**: Load forecast study years mentioned but specific timeframes not provided in this chunk

9. **Model Development Procedure Manual**: Ensure current version is referenced and accessible to all LREs

10. **People's Electric Cooperative**: Listed under multiple zones (7d, 10d, 13b) - verify zone assignment accuracy

---

# Chunk 25 Analysis

# Regulatory Analysis Report
**Source:** RR696 Integrate_Operate High Impact Large Loads.docx.txt - chunk 25 of 26

---

## 1. Executive Summary

This document section contains detailed regulatory tables related to transmission service administration within what appears to be the Southwest Power Pool (SPP) region. The content includes:

- **Annual Transmission Revenue Requirements (ATRR)** allocation tables showing region-wide and zonal cost distributions
- **Transmission zone listings** covering multiple states and transmission owners across the SPP footprint
- **Transmission service request timelines** detailing procedures for long-term firm, short-term firm, and non-firm transmission services with specific deadlines for applications, responses, studies, and scheduling

This appears to be part of a comprehensive tariff or operational procedure document governing transmission access and cost recovery.

---

## 2. Key Topics

### Transmission Revenue Requirements & Cost Allocation
- Region-wide ATRR calculations (Base Plan and Balanced Portfolio)
- Zonal ATRR credits by transmission owner
- Schedule 11 credits
- Interregional planning region ATRR
- JTIQ ATRR Balance

### Transmission Service Categories
- **Long-Term Firm Service** (1 year or more)
- **Short-Term Firm Service** (ranging from 1 day to multiple months)
- **Non-Firm Service** (hourly to monthly)
- **Next Hour Market** service

### Transmission Zones & Owners (26+ zones identified)
Key transmission owners include:
- American Electric Power (West zone with multiple sub-zones)
- Evergy entities (Metro, Missouri West, Kansas Central)
- Oklahoma Gas and Electric
- Southwestern Power Administration
- Nebraska utilities (Lincoln Electric System, NPPD, OPPD)
- Upper Missouri Zone utilities
- Southwestern Public Service Company
- Multiple cooperatives and municipal utilities

### Service Request Timelines
- Application windows (ranging from 30 minutes to 120 days prior)
- Provider response requirements (24 hours to end of open season)
- Study processes (best effort to 60 days)
- Customer response deadlines (30 minutes to 4 days)
- Energy scheduling change deadlines

---

## 3. Decisions or Actions

### Procedural Requirements Established

**Long-Term Firm Service (1 year+):**
- Open season process per Attachment Z1
- Aggregate Transmission Service Study required
- Expedited designation available if Section 30.2.2 requirements met
- 10-day provider response for requests 90+ days prior
- 3-day customer response period

**Short-Term Firm Service:**
- Monthly service: 24-hour provider response, 30-60 day study period, 4-day customer response
- Weekly service: 24-hour response, 30-60 day study, 48-hour customer response
- Daily service: 24-hour response, variable study period based on queue timing

**Non-Firm Service:**
- Monthly: 2-day customer response, 24-hour for changes
- Daily: 30-minute system impact determination, 2-hour customer response
- Hourly: Best effort or 30-minute response depending on timing
- Next-hour market: Best effort, 20-minute deadlines

**Energy Scheduling:**
- Standard deadline: 12:00 noon day prior (firm services)
- Non-firm: 15:00 day prior
- Changes allowed until 20 minutes prior to schedule start

---

## 4. Important Dates

### Critical Deadline Referenced
- **June 19, 2010** - Dividing line for Base Plan Region-wide ATRR calculations (NTC prior vs. on/after this date)

### Recurring Deadlines by Service Type
- **120 days prior** - Earliest application for monthly short-term firm (>1 month)
- **90 days prior** - Long-term firm expedited requests; earliest for monthly short-term
- **60 days prior** - Study completion deadlines; earliest for weekly and monthly non-firm
- **30 days prior** - Various study windows and earliest weekly firm requests
- **Day prior** - Standard energy scheduling deadlines (12:00 for firm, 15:00 for non-firm)
- **20 minutes prior** - Universal deadline for schedule changes and next-hour market requests

---

## 5. Organizations and People Mentioned

### Major Transmission Owners/Utilities

**American Electric Power (AEP) Zone:**
- Public Service Company of Oklahoma
- Southwestern Electric Power Company
- AEP Oklahoma Transmission Company, Inc.
- AEP Southwestern Transmission Company, Inc.

**Evergy Companies:**
- Evergy Metro, Inc.
- Evergy Missouri West, Inc.
- Evergy Kansas Central, Inc.
- Evergy Kansas South, Inc.

**Oklahoma Utilities:**
- Oklahoma Gas and Electric
- Oklahoma Municipal Power Authority
- Western Farmers Electric Cooperative

**Kansas Utilities:**
- Kansas City Board of Public Utilities
- City Utilities of Springfield, Missouri
- Empire District Electric Company
- Midwest Energy, Inc.
- Sunflower Electric Power Corporation
- Kansas Power Pool

**Nebraska Utilities:**
- Lincoln Electric System
- Nebraska Public Power District
- Omaha Public Power District
- Central Nebraska Public Power and Irrigation District

**Upper Missouri Zone Entities:**
- Western-UGP
- Basin Electric Power Cooperative
- Heartland Consumers Power District
- Missouri River Energy Services
- East River Electric Power Cooperative, Inc.
- Corn Belt Power Cooperative
- NorthWestern Energy Public Service Corporation
- Multiple municipal utilities and cooperatives

**Federal Entity:**
- Southwestern Power Administration

**Transmission Companies:**
- ITC Great Plains, LLC
- Prairie Wind Transmission, LLC
- Transource Oklahoma, LLC
- Transource Missouri, LLC
- NextEra Energy Transmission Southwest, LLC
- South Central MCN LLC

**Cooperatives:**
- East Texas Electric Cooperative, Inc.
- Deep East Texas Electric Cooperative, Inc.
- Arkansas Electric Cooperative Corporation
- People's Electric Cooperative
- Lea County Electric Cooperative, Inc.
- Tri-State G&T Association
- Multiple other cooperatives in Upper Missouri Zone

**Municipal Utilities:**
- City of Independence, Missouri
- Missouri Joint Municipal Electric Utility Commission
- Multiple Iowa and South Dakota municipal utilities

---

## 6. Links or References

### Document Cross-References
- **Attachment H tab** - Referenced for all ATRR values in Table 5
- **Posted RRR File** - Contains detailed ATRR data
- **Attachment Z1** - Governs open season process and aggregate study procedures
- **Section II of Attachment Z1** - Specifies open season timing
- **Sections 19.4 and 32.4** - Contain study schedules
- **Section 30.2.2** - Requirements for expedited designation process
- **Section II.3** - Referenced for AEP zone details

### External References
- Schedule 11 Credits (multiple zones)
- NITS ATRR (Network Integration Transmission Service)
- JTIQ (appears to be Joint Transmission Interconnection Queue)

---

## 7. Suggested Tags

- Transmission Service
- ATRR (Annual Transmission Revenue Requirements)
- SPP (Southwest Power Pool)
- Cost Allocation
- Tariff Administration
- Long-Term Firm Service
- Short-Term Firm Service
- Non-Firm Transmission
- Open Season
- Transmission Studies
- Energy Scheduling
- Zonal Rates
- Interregional Planning
- Network Integration
- OATT (Open Access Transmission Tariff)
- Request Timelines
- Transmission Owners
- Revenue Requirements
- Service Requests
- Market Operations

---

## 8. Items That May Need Follow-Up

### Documentation Completeness
1. **Missing table content** - Tables 11-28 appear empty or not included in this chunk; verify if content exists in other sections
2. **Attachment H verification** - All ATRR values reference "See Att. H tab" - need to verify this attachment is accessible and current
3. **RRR File posting** - Confirm the "posted RRR File" location and accessibility

### Policy/Procedural Clarifications Needed
4. **N/A designations** - Numerous zones show "N/A" for both Zonal ATRR Credit and Schedule 11 Credit; clarify if this means zero, not applicable, or to be

---

# Chunk 26 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary
This document chunk (26 of 26) from "RR696 Integrate & Operate High Impact Large Loads" contains primarily a comprehensive acronym glossary (Table 29) defining technical and regulatory terms used throughout the full document. The remaining tables (30-45) appear to be empty or contain no extractable content. This represents the final reference section of a larger regulatory or technical document related to power system interconnection and transmission planning.

## 2. Key Topics
- **Interconnection Procedures**: Multiple acronyms related to generator and energy resource interconnection (GI, GIA, GIP, GIR, ERIS, NRIS)
- **Transmission Planning**: Terms related to transmission system planning and analysis (ITP, PTDF, TPL, FCITC)
- **Energy Resources**: Various resource types including Energy Storage Resources (ESR) and Variable Energy Resources (VER, HVER, LVER)
- **Regulatory Framework**: References to FERC, NERC, and tariff structures (OATT)
- **Voltage Classifications**: High Voltage and Extra-High Voltage distinctions (HV, EHV)
- **Technical Systems**: Power system modeling and simulation tools (PSS/E)

## 3. Decisions or Actions
- No specific decisions or actions are documented in this chunk
- This section serves as a reference appendix only

## 4. Important Dates
- No dates mentioned in this content chunk

## 5. Organizations and People Mentioned
**Organizations:**
- **SPP (Southwest Power Pool)** - Primary organization
- **FERC (Federal Energy Regulatory Commission)** - Federal regulatory body
- **NERC (North American Electric Reliability Corporation)** - Reliability standards organization
- **PCWG (Project Cost Working Group)** - Internal working group
- **TO (Transmission Owner)** - Generic reference to transmission owners
- **IC (Interconnection Customer)** - Generic reference to customers

**People:** None mentioned

## 6. Links or References
- **NERC TPL Standards**: Transmission System Planning Performance Requirements
- **OATT (Open Access Transmission Tariff)**: Regulatory tariff framework
- **PSS/E**: Siemens power system simulation software
- **RMS (Request Management System)**: Internal system reference
- Document reference: RR696 (Revision Request 696)

## 7. Suggested Tags
- Interconnection
- Transmission Planning
- Generator Interconnection
- Energy Storage
- Variable Energy Resources
- Southwest Power Pool
- FERC Compliance
- NERC Standards
- Tariff Administration
- High Voltage Systems
- Acronym Glossary
- Technical Standards

## 8. Items That May Need Follow-Up
- **Document Completeness**: Tables 30-45 appear empty - verify if content is missing or if these are placeholder tables
- **Full Document Review**: This is chunk 26 of 26; substantive content requiring follow-up would be in earlier chunks
- **Cross-Reference Verification**: Ensure all acronyms defined in Table 29 are actually used in the preceding document sections
- **Version Control**: Confirm this is the final approved version of RR696
- **Implementation Status**: Determine if the procedures and requirements outlined in the full RR696 document have been implemented

---

**Note**: This analysis is limited by the content provided (final chunk only). A comprehensive understanding of decisions, actions, and regulatory implications would require review of the complete document (chunks 1-26).