# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document contains comments from the Kansas Grain and Feed Association (KGFA) and Renew Kansas Biofuels Association regarding SPP's Revision Request RR696, which establishes a framework for integrating High Impact Large Loads (HILL) and Conditional High Impact Large Loads (CHILL) into the SPP grid. While the associations support the initiative to facilitate large load interconnections, they express concerns about two key provisions that may create unreasonable costs and administrative burdens for flexible industrial loads. They request amendments to: (1) extend the conditional transmission allowance beyond the proposed 5-year limit for flexible loads, and (2) allow usage-based rather than capacity-based transmission payment structures for flexible loads.

## 2. Key Topics

- **High Impact Large Load (HILL) Integration Framework** - New assessment process for accelerating large load interconnections
- **Conditional HILL (CHILL) Service** - Conditional transmission service pathway for large loads
- **Non-Firm vs. Firm Transmission Service** - Transition requirements after 5-year conditional period
- **Flexible Load Operations** - Energy storage and off-peak usage by industrial facilities
- **Transmission Cost Allocation** - Payment structures for maximum capacity vs. actual usage
- **Grid Reliability Standards** - NERC compliance and system stability considerations
- **Economic Development Impact** - Effects on grain elevators and biofuel processing facilities in rural Kansas

## 3. Decisions or Actions

**Requested Actions by Commenters:**
1. Extend conditional transmission allowance beyond 5 years on a long-term basis for flexible large loads
2. Modify payment requirement to usage-based billing rather than capacity-based for flexible loads on conditional service
3. Include this comment letter in the official Committee meeting record
4. Adopt the proposed amendments before advancing RR696

**Proposed Framework Actions (from RR objectives):**
- Implement HILL integration assessment framework
- Incorporate HILL requirements and CHILL Service language into SPP governing documents
- Establish integrated design, study, registration, and operations process

## 4. Important Dates

- **July 11, 2025** - Date of comment submission
- **5-year limit** - Current proposed timeline after which large loads must transition from conditional to firm transmission service (subject of objection)

## 5. Organizations and People Mentioned

**Organizations:**
- Kansas Grain and Feed Association (KGFA) - 950+ Kansas business locations, 99% of commercially licensed grain storage
- Renew Kansas Biofuels Association (Renew Kansas)
- Southwest Power Pool (SPP)
- North American Electric Reliability Corporation (NERC)

**People:**
- **Ron Seeber** - Submitter representing KGFA
  - Email: Ron@Kansasag.org
  - Phone: 785-234-0461

## 6. Links or References

**Referenced Documents:**
- RR696 Revision Request Form
- SPP Open Access Transmission Tariff
- Market Protocols
- SPP Governing Documents
- NERC Standards

**No web links provided in document**

## 7. Suggested Tags

- RR696
- High-Impact-Large-Loads
- HILL
- CHILL
- Kansas-Grain-Feed-Association
- Transmission-Interconnection
- Non-Firm-Service
- Flexible-Loads
- Energy-Storage
- Biofuels
- Grid-Reliability
- Transmission-Cost-Allocation
- SPP-Tariff
- Load-Integration
- Economic-Development
- Rural-Energy

## 8. Items That May Need Follow-Up

1. **Committee Response Required** - Decision needed on whether to accept the two requested amendments regarding:
   - Extension of conditional transmission service timeline
   - Usage-based payment structure for flexible loads

2. **Cost-Benefit Analysis** - Need assessment of financial impact of requested changes on:
   - Grid operators and other transmission customers
   - Industrial flexible loads (grain elevators, biofuel plants)
   - Overall system costs and reliability

3. **Technical Feasibility Review** - Evaluation of whether long-term conditional service can maintain grid reliability standards and NERC compliance

4. **Definition Clarification** - Need clear definition and criteria for what qualifies as "flexible large loads" eligible for requested accommodations

5. **Stakeholder Coordination** - Determine if other industrial associations or large load customers have similar concerns or requests

6. **Tariff Language Development** - If amendments accepted, specific redlined language changes needed for SPP Open Access Transmission Tariff and Market Protocols

7. **Precedent Assessment** - Evaluate whether similar accommodations exist in other RTOs/ISOs and their outcomes

8. **Next Committee Meeting** - Ensure this letter is formally entered into the meeting record as requested

9. **Economic Impact Study** - Consider broader implications for rural Kansas economic development if requests are denied vs. approved

10. **Alternative Solutions** - Explore compromise options if full requests cannot be accommodated (e.g., extended but not permanent conditional service, hybrid payment structures)