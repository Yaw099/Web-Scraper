# Final Combined Report

# COMPREHENSIVE REGULATORY ANALYSIS REPORT
## Southwest Power Pool Market Monitoring Unit Board Memo on RR696
### High Impact Large Load Interconnection Procedures

---

## 1. EXECUTIVE SUMMARY

The Southwest Power Pool Market Monitoring Unit (SPP MMU) has issued a comprehensive memorandum addressing Revision Request 696 (RR696), submitted by SPP on June 30, 2025. This proposal establishes expedited 90-day interconnection procedures for High Impact Large Loads (HILLs) in response to significant development demand across the SPP footprint.

**Two Primary Pathways Proposed:**
- **CHILLS (Conditional High Impact Large Load Service)**: Temporary interconnection subject to curtailment
- **HILLGA (HILL Generation Assessment)**: Studies for HILLs paired with nearby generation in three configurations (behind-the-meter, local area deliverability, and wider deliverability area)

**MMU Position:** The MMU does not oppose the proposal but identifies significant concerns requiring resolution before implementation. The memo categorizes recommendations into pre-implementation requirements (primarily participation rules and market fairness safeguards) and post-implementation enhancements (operational efficiency improvements).

**Critical Concerns:**
- Potential compromise of open access transmission principles, particularly with HILLGA-DA option
- Need for formalized MMU oversight authority
- Market manipulation risks from paired generation resources
- Cost-causation alignment for forecast deviations
- Impact on existing interconnection queues (DISIS and ERAS)

The MMU acknowledges the rapid development pace necessitated by market conditions while emphasizing the need for careful implementation to protect market fidelity.

---

## 2. KEY TOPICS

### Primary Interconnection Framework
- **High Impact Large Load (HILL) interconnection procedures** - Expedited framework responding to development wave across SPP territory
- **CHILLS (Conditional High Impact Large Load Service)** - Temporary interconnection with curtailment rights for transmission constraints
- **HILLGA (HILL Generation Assessment)** - Three-tiered study process for loads paired with generation:
  - Behind-the-meter (BTM) configuration
  - Local area deliverability (HILLGA-Local)
  - Wider deliverability area (HILLGA-DA)

### Market Integrity & Regulatory Compliance
- **Open access transmission principles** - Concerns about priority treatment over existing queues
- **MMU oversight and monitoring role** - Formalization of authority to ensure compliance and prevent market manipulation
- **Market fairness and efficiency** - Supply/demand balance, pricing integrity, and congestion cost impacts
- **Cost-causation principles** - Financial consequences for forecast deviations and system use

### Operational & Technical Issues
- **Generation offer rules** - Requirements for paired generation resources, especially common bus arrangements
- **Curtailment procedures** - Shift factor-based deployment for CHILLs during transmission constraints
- **RUC (Reliability Unit Commitment) make-whole payments** - Distribution methodology incorporating non-conforming load forecasts
- **Non-conforming load forecasting** - Requirements for HILL load prediction accuracy

### Market Mechanisms & Interactions
- **Automatic mitigation requirements** - For CHILL-paired generation dispatched above load levels
- **Validation checks and compliance monitoring** - Automated systems for capacity exceedances and GIA limit violations
- **Demand response framework** - Enhancements for opportunity cost, performance measurement, and peak load assessment
- **LTCR (Long-Term Congestion Rights) netting** - Relationship to RR697 and congestion pattern impacts

### Broader Planning Considerations
- **Transmission limitations and congestion management** - System impacts from large load additions
- **Planning, markets, and operational process alignment** - Integration of environmental, regulatory, and operational constraints
- **Queue priority concerns** - Fair treatment relative to DISIS and ERAS processes

---

## 3. DECISIONS OR ACTIONS

### PRE-IMPLEMENTATION REQUIREMENTS (Critical for Market Protection)

#### 1. **MMU Oversight Authority**
- **Action:** Memorialize SPP MMU's oversight role in tariff language
- **Precedent:** Similar to RR655 language on information submission standards and due diligence
- **Purpose:** Ensure authority to monitor compliance and prevent market manipulation

#### 2. **HILLGA-DA Option Removal**
- **Action:** Eliminate the Deliverability Area generation option
- **Rationale:** Addresses open access concerns and priority issues over DISIS and ERAS queues
- **Impact:** Prevents preferential treatment that could compromise transmission fairness principles

#### 3. **Automatic Mitigation for CHILL Generation**
- **Action:** Require automatic mitigation when generation supporting CHILL is dispatched above CHILL load
- **Constraints:** 
  - Limit offers to short-run marginal costs
  - No make-whole payments during such dispatch
- **Exception:** SPP Reliability Coordinator may dispatch above load in emergencies

#### 4. **Common Bus Arrangement Offer Rules**
- **Action:** Establish clear rules preventing CHILL-paired generation from:
  - Being used as market resource when CHILL is curtailed
  - Being dispatched above CHILL load levels
  - Injecting onto grid in violation of GIA limits
  - Clearing operating reserves for MWs it cannot supply to grid

#### 5. **Validation Checks and Compliance Monitoring Systems**
- **Action:** Implement automated systems to:
  - Monitor CHILLs exceeding reserved capacity
  - Ensure load-limited generators don't exceed paired load limits
  - Identify and charge unreserved transmission system use
  - Prevent market impacts from GIA limit exceedances
- **Timing:** Must be operational before significant load additions

### POST-IMPLEMENTATION ENHANCEMENTS (Operational Efficiency)

#### 6. **Two-Step Curtailment Process**
- **Step 1:** Operator triggers curtailment of CHILLs for transmission constraints
- **Step 2:** Market clearing engine deploys curtailments based on shift factors
- **Benefit:** More efficient and orderly curtailment process

#### 7. **RUC Make-Whole Payment Modification**
- **Action:** Modify market protocols to include non-conforming load forecast deviations in RUC make-whole payment calculations
- **Purpose:** Align financial consequences with cost-causation

#### 8. **Demand Response Framework Enhancement**
- **Action:** Address SPP MMU requests including:
  - Enhanced opportunity cost definition for mitigated offers
  - Improved performance measurement
  - Peak load assessment implementation
  - Future implementation effective date with advance notice for existing HILLs (avoid grandfathering)

#### 9. **Planning Process Integration (2023 Recommendation 2023-2)**
- **Action:** Better align planning, markets, and operational processes
- **Focus:** Incorporate environmental, regulatory, and operational constraints into planning
- **Context:** Particularly relevant for HILL/CHILL paired generation

#### 10. **RR697 Reexamination**
- **Action:** Reexamine LTCR Netting of Flows in context of congestion patterns from CHILLs/HILLs
- **Purpose:** Ensure congestion rights framework adapts to new load patterns

### ONGOING PROCESS REQUIREMENTS

#### 11. **Continued Collaboration**
- **Action:** Maintain close working relationship between SPP staff and SPP MMU during modification and implementation
- **Note:** MMU reserves right to modify recommendations as new information emerges

---

## 4. IMPORTANT DATES

| Date | Event/Milestone |
|------|----------------|
| **June 30, 2025** | SPP submitted Revision Request 696 |
| **July 28, 2025** | Date of MMU memorandum |
| **August 4-5, 2025** | SPP Board of Directors Oversight Committee meeting - MMU presentation on RR696 |
| **90-day timeline** | Duration referenced for both CHILLS and HILLGA processes (specific start dates not provided) |
| **TBD - "Future implementation effective date"** | Recommended for avoiding grandfathering issues with existing HILLs (requires "significant advance notice") |

### Dates Requiring Clarification:
- Specific start date for 90-day pathways
- Definition of "significant advance notice" timeline
- Target implementation date for pre-implementation requirements
- Timeline for post-implementation enhancements

---

## 5. ORGANIZATIONS AND PEOPLE MENTIONED

### Organizations

**Primary Parties:**
- **Southwest Power Pool (SPP

---

# Partial Chunk Reports

# Chunk 1 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This memorandum from the Southwest Power Pool Market Monitoring Unit (SPP MMU) addresses Revision Request 696 (RR696), submitted by SPP on June 30, 2025, which proposes new procedures for interconnecting High Impact Large Loads (HILLs). The proposal establishes two expedited 90-day pathways: Conditional High Impact Large Load Service (CHILLS) for temporary load interconnection subject to curtailment, and HILL Generation Assessment (HILLGA) for studying HILLs paired with nearby generation. 

The SPP MMU, while not opposing the proposal outright, identifies several concerns related to market fairness, efficiency, and open access principles. The memo provides recommendations split into pre-implementation requirements (primarily participation rules) and post-implementation enhancements (operational risks). Key concerns include the need for MMU oversight authority, issues with the HILLGA-DA option that may compromise open access principles, and the need for automatic mitigation and clear offer rules for paired generation resources.

## 2. Key Topics

- **High Impact Large Load (HILL) interconnection procedures** - Framework for expedited interconnection of large loads responding to significant development wave across SPP footprint
- **Two interconnection pathways:**
  - CHILLS (Conditional High Impact Large Load Service) - temporary interconnection subject to curtailment
  - HILLGA (HILL Generation Assessment) - studies for HILLs with paired generation in three location types: behind-the-meter (BTM), local area deliverability (HILLGA-Local), and wider deliverability area (HILLGA-DA)
- **Market fairness and efficiency concerns** - Impact on supply/demand balance, pricing, and congestion costs
- **Open access transmission principles** - Concerns about priority given to HILLGA-DA generation over existing queues
- **MMU oversight and monitoring role** - Need for formalized authority to ensure compliance and prevent market manipulation
- **Generation offer rules** - Requirements for paired generation resources, particularly in common bus arrangements
- **Market impacts** - Effects on transmission limitations, congestion, and market imbalances

## 3. Decisions or Actions

**Pre-Implementation Recommendations (Required before implementation):**

1. **Memorialize SPP MMU's oversight role** - Include language clarifying MMU's authority to ensure fair and efficient markets, similar to RR655 language requiring information submission standards and due diligence
2. **Remove HILLGA-DA option** - Eliminate the Deliverability Area generation option due to open access concerns and priority issues over DISIS and ERAS queues
3. **Implement automatic mitigation for CHILL generation** - Require automatic mitigation when generation supporting CHILL is dispatched above CHILL load, limiting offers to short-run marginal costs without make-whole payments
4. **Create clear offer rules for common bus arrangements** - Establish rules preventing CHILL-paired generation from:
   - Being used as market resource when CHILL is curtailed
   - Being dispatched above CHILL load
   - Injecting onto grid in violation of GIA limits
   - Clearing operating reserves for MWs it cannot supply to grid
5. **Develop validation checks and compliance monitoring** - Implement automated systems to:
   - Monitor CHILLs exceeding reserved capacity
   - Ensure load-limited generators don't exceed paired load limits
   - Identify and charge unreserved transmission system use
   - Prevent market impacts from GIA limit exceedances

**Post-Implementation Recommendations:**

1. **Address 2023 State of the Market Recommendation 2023-2** - Better align planning, markets, and operational processes; incorporate environmental, regulatory, and operational constraints into planning
2. **Deploy more efficient CHILL curtailment scheme** - Base curtailment on shift factors for more efficient and orderly process

## 4. Important Dates

- **June 30, 2025** - SPP submitted Revision Request 696
- **July 28, 2025** - Date of this MMU memorandum
- **August 4-5, 2025** - SPP Board of Directors Oversight Committee meeting where MMU will present on this proposal
- **90-day pathways** - Timeline referenced for both CHILLS and HILLGA processes (specific start dates not provided)

## 5. Organizations and People Mentioned

**Organizations:**
- **Southwest Power Pool (SPP)** - Regional transmission organization submitting the proposal
- **Southwest Power Pool Market Monitoring Unit (SPP MMU)** - Author of memorandum, tasked with ensuring market efficiency and fairness
- **Board of Directors** - Recipient of memo
- **Regional State Committee** - Recipient of memo
- **Members Committee** - Recipient of memo
- **SPP Board of Directors Oversight Committee** - Requested this written discussion, meeting August 4-5, 2025
- **SPP Reliability Coordinator** - May dispatch paired generation above CHILL load in emergencies
- **FERC (Federal Energy Regulatory Commission)** - Referenced in regulatory citations

**People:**
- No individual names mentioned

**Referenced Studies/Queues:**
- DISIS (Definitive Interconnection System Impact Study)
- ERAS (Expedited Resource Adequacy Study)

## 6. Links or References

**Regulatory References:**
- **Revision Request 696 (RR696)** - Primary proposal being analyzed
- **Revision Request 655 (RR655)** - Referenced for precedent language on information submission standards
- **Order 719** - Wholesale Competition in regions with Organized Electric Markets, 125 FERC ¶ 61,071 (2008)
- **18 C.F.R. § 35.28(g)(3)(ii) (2024)** - Federal regulations on MMU role
- **SPP Open Access Transmission Tariff (OATT)**:
  - Attachment AG § 1.3 - MMU authority and role
  - Attachment AG § 8 - Information request standards
  - Attachment AE § 2.20 - Resource registration and offer requirements (proposed in RR655)

**Internal References:**
- **2023 Annual State of the Market Report** - Contains Recommendation 2023-2 on large load integration
- **Generator Interconnection Agreement (GIA)** - Contains limits for paired generation

## 7. Suggested Tags

- High Impact Large Loads (HILLs)
- CHILLS (Conditional High Impact Large Load Service)
- HILLGA (HILL Generation Assessment)
- Market Monitoring
- Interconnection Procedures
- Open Access Transmission
- Market Efficiency
- Generation Interconnection
- Load Integration
- Behind-the-Meter Generation
- Deliverability Area
- Transmission Planning
- Market Mitigation
- SPP Tariff
- Resource Adequacy
- Congestion Management
- Curtailment Procedures
- Compliance Monitoring
- RR696
- Southwest Power Pool

## 8. Items That May Need Follow-Up

**Critical Follow-Up Items:**

1. **HILLGA-DA Disposition** - Track whether SPP removes the Deliverability Area option as recommended or provides alternative safeguards for open access principles

2. **MMU Oversight Language** - Verify inclusion of appropriate language memorializing MMU's role in final tariff provisions

3. **Automatic Mitigation Rules** - Confirm implementation of automatic mitigation requirements for CHILL-paired generation when dispatched above load

4. **Common Bus Offer Rules** - Ensure clear tariff language is developed preventing:
   - Dispatch above paired load
   - Grid injection violations
   - Operating reserve clearing for unavailable capacity

5. **Validation Systems Development** - Monitor SPP's progress on automated compliance checks and validation tools before significant load additions

6. **Board Decision on August 4-5, 2025** - Follow up on Oversight Committee's response to MMU recommendations and any modifications to RR696

7. **2023 Recommendation 2023-2 Implementation** - Track progress on incorporating environmental, regulatory, and operational constraints into planning processes, especially relevant given HILL/CHILL paired generation

8. **Curtailment Scheme Revision** - Follow development of shift factor-based curtailment methodology for CHILLs

9. **Priority Queue Concerns** - Monitor how HILLGA interacts with existing DISIS and ERAS queues to ensure fair treatment

10. **Market Impact Assessment** - Track actual market impacts (pricing, congestion costs, transmission limitations) once HILLs begin interconnecting

11. **Stakeholder Process** - Monitor stakeholder feedback and any

---

# Chunk 2 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document represents the second chunk of a memo from the SPP Market Monitoring Unit (MMU) Board regarding RR696, concerning the integration of large loads (HILLs and CHILLs) into SPP's service territory. The MMU provides critical recommendations for curtailment procedures, RUC make-whole payment calculations, and additional market efficiency measures. The memo emphasizes concerns about market impacts, cost-causation principles, and the need for careful implementation to protect market fidelity while acknowledging the rapid pace of proposal development.

## 2. Key Topics

- **Curtailment procedures for CHILLs** during transmission constraints
- **Market clearing engine deployment** based on shift factors
- **Non-conforming load forecasting** requirements for HILLs
- **RUC (Reliability Unit Commitment) make-whole payment distribution**
- **Cost-causation principles** and financial consequences for forecast deviations
- **Demand response framework** enhancements
- **Opportunity cost definitions** for mitigated offers
- **Performance measurement** and peak load assessment
- **Grandfathering concerns** and discriminatory treatment risks
- **LTCR (Long-Term Congestion Rights) netting of flows** (RR697 relationship)

## 3. Decisions or Actions

### Recommended Actions:
1. **Implement two-step curtailment process**:
   - Operator triggers curtailment of CHILLs for transmission constraints
   - Market clearing engine deploys curtailments based on shift factors

2. **Modify market protocols** to include non-conforming load forecast deviations in RUC make-whole payment calculations

3. **Address SPP MMU requests** including:
   - Enhance opportunity cost definition for mitigated offers
   - Enhance performance measurement
   - Implement peak load assessment
   - Set future implementation effective date with advance notice for existing HILLs (avoid grandfathering)

4. **Reexamine RR697** (LTCR Netting of Flows) in context of congestion patterns from CHILLs/HILLs

5. **Continue close working relationship** between SPP staff and SPP MMU during modification and implementation

## 4. Important Dates

- **No specific dates mentioned** in this chunk
- Reference to "future implementation effective date with significant advance notice" (timing not specified)

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)**
- **SPP MMU (Market Monitoring Unit)**
- **SPP Board** (recipient of memo)

### Processes/Market Mechanisms:
- MDRA (Multi-Day Reliability Assessment)
- RUC (Reliability Unit Commitment)
- Day Ahead Market (DA)
- Intra-Day RUC

### Referenced Items:
- RR696 (main subject)
- RR697 (LTCR Netting of Flows)

## 6. Links or References

- **2023 Annual State of the Market**, recommendation 2023.2: "Ensure Planning, Markets, and Operational Processes appropriately consider integration of large loads"
- **Demand response framework** and upcoming revision request
- **RR697** - LTCR Netting of Flows

## 7. Suggested Tags

- Market Monitoring
- Large Load Integration
- HILLs (High Impact Large Loads)
- CHILLs (specific load category)
- Reliability Unit Commitment
- Transmission Constraints
- Curtailment Procedures
- Cost Causation
- Market Protocols
- Make-Whole Payments
- Shift Factors
- Non-Conforming Load
- Demand Response
- Congestion Management
- Market Efficiency
- RR696
- SPP Markets

## 8. Items That May Need Follow-Up

### Critical Follow-Up Items:

1. **Implementation Timeline**: Establish specific effective dates for new requirements, especially for existing HILLs

2. **Market Protocol Changes**: Track formal revisions to incorporate non-conforming load forecast deviations in RUC make-whole calculations

3. **RR697 Reexamination**: Monitor review of LTCR Netting of Flows in context of CHILL/HILL congestion patterns

4. **Demand Response Framework Updates**: Track resolution of SPP MMU requests including:
   - Opportunity cost definition enhancements
   - Performance measurement improvements
   - Peak load assessment implementation

5. **Grandfathering Policy**: Confirm approach to existing HILLs to avoid discriminatory treatment concerns

6. **Potential Recommendation Modifications**: Monitor for updates from SPP MMU given stated possibility of modifications based on new information

7. **Curtailment Procedure Implementation**: Track development and deployment of shift factor-based curtailment system

8. **Cost-Causation Alignment**: Verify that financial consequences are appropriately assigned for forecast inaccuracies

9. **Market Fidelity Protection**: Monitor ongoing SPP MMU oversight during implementation period

10. **Stakeholder Communication**: Ensure adequate notice and transparency for all affected parties

### Questions Requiring Clarification:
- What constitutes "significant advance notice" for implementation?
- How will shift factors be calculated and updated for individual CHILLs?
- What specific metrics will be used for performance measurement?
- What are the criteria for determining when curtailment is "necessary for transmission constraints"?