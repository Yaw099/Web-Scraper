# Regulatory Meeting/Page Content Analysis Report

**Source File:** RR696 CUS Comments 20250731.docx.txt

---

## 1. Executive Summary

City Utilities of Springfield (CU) has submitted detailed comments on Revision Request 696 (RR696), which proposes a framework for integrating High Impact Large Loads (HILL) and creating a new Conditional High Impact Large Load (CHILL) Service. While CU commends SPP's initiative to develop solutions for large load integration, they raise significant concerns regarding reliability assurance, the feasibility of the proposed 90-day study timeline, operational processes, and cost allocation methodologies. CU strongly advocates for a revised cost allocation approach that assigns upgrade costs primarily to the beneficiaries of the large loads and requests clearer operational procedures to maintain grid reliability.

---

## 2. Key Topics

- **High Impact Large Load (HILL) Integration Framework** - New assessment process for accelerated interconnections
- **Conditional High Impact Large Load (CHILL) Service** - New service allowing conditional transmission service interconnection
- **90-Day Study Turnaround Process** - Proposed expedited timeline for studies
- **Reliability Standards** - Ensuring HILL/CHILL resources meet existing generation standards
- **Cost Allocation Methodology** - Concerns about equitable distribution of network upgrade costs
- **HILLGA Pathways** - Three different paths for High Impact Large Load with Generation Additions (Paths 1, 2, and 3)
- **Operational Procedures** - Curtailment, load ramping, stability, and security protocols
- **Queue Priority and Deliverability** - Impact on existing DISIS (Definitive Interconnection System Impact Study) projects
- **Regional Competitiveness** - Supporting business growth through accelerated generation interconnection

---

## 3. Decisions or Actions

**No formal decisions recorded** - this is a comment submission on a proposed Revision Request.

**CU's Requested Actions:**
- Ensure all studies remain thorough despite 90-day timeline
- Define clear timeframes for TO/TP/TOP and GO/GOP contributions
- Establish internal milestones (within first 20-30 days) for data submissions
- Implement pre-notification process before the 90-day study clock starts
- Provide process for extending 90-day period when reliability issues arise
- Develop clear operating processes for observability, curtailment, ramping, stability, and security
- Optimize curtailment processes to prevent reserve shortages
- Limit HILLGA to Paths 1 and 2; eliminate or modify Path 3
- Implement revised three-tier cost allocation methodology
- Create flowchart for study process

---

## 4. Important Dates

- **July 31, 2025** - Comment submission date
- **90-day study turnaround** - Proposed timeline for HILL/CHILL studies (concern item)
- **20-30 days** - Suggested internal milestone for TO/TP data submissions

---

## 5. Organizations and People Mentioned

**Organizations:**
- **City Utilities of Springfield (CU)** - Submitting organization
- **Southwest Power Pool (SPP)** - Organization managing the revision request
- **NERC (North American Electric Reliability Corporation)** - Referenced for standards

**People:**
- **Olivia Hough** - Submitter, City Utilities of Springfield
  - Email: CULargeLoadsTaskForce@cityutil.onmicrosoft.com
  - Phone: 417-831-8324

**Roles/Entities Referenced:**
- TO/TP/TOP (Transmission Owner/Transmission Planner/Transmission Operator)
- GO/GOP (Generator Owner/Generator Operator)

---

## 6. Links or References

**Referenced Documents/Systems:**
- SPP Open Access Transmission Tariff
- Market Protocols
- SPP Operating Criteria
- SPP Planning Criteria
- SPP Business Practices
- Integrated Transmission Planning (ITP) Manual
- NERC standards
- DISIS (Definitive Interconnection System Impact Study) projects
- Highway/Byway cost allocation method

**No URLs or hyperlinks provided in the document**

---

## 7. Suggested Tags

- RR696
- High Impact Large Load (HILL)
- CHILL Service
- SPP (Southwest Power Pool)
- Grid Reliability
- Cost Allocation
- Transmission Planning
- Interconnection Studies
- HILLGA (High Impact Large Load with Generation Addition)
- City Utilities of Springfield
- Load Integration
- 90-Day Study Process
- Transmission Upgrades
- DISIS
- Queue Reform
- Voltage Stability
- Reactive Resources

---

## 8. Items That May Need Follow-Up

**Critical Follow-Up Items:**

1. **90-Day Study Process Clarification**
   - Documentation of how due diligence will be maintained within 90 days
   - If AI is being used, request performance metrics and documentation
   - Need for process flowchart
   - Extension procedures when reliability concerns arise

2. **Operational Process Development**
   - Clear procedures needed for: observability/coordination, curtailment, load ramping, stability/ride-through, cyber/physical security
   - Impact on planned outage approvals

3. **HILLGA Path 3 Concerns**
   - Address queue-jumping concerns
   - Impact on existing DISIS projects
   - Network upgrade responsibility allocation
   - Transmission capacity utilization equity

4. **Cost Allocation Methodology Revision**
   - Evaluation of CU's proposed three-tier cost allocation approach:
     - Tier 1: ITP reliability upgrade comparison
     - Tier 2: Production cost savings and market benefit analysis
     - Tier 3: Local area benefit socialization
   - "But for" justification analysis

5. **Reliability Standards Alignment**
   - Confirmation that HILL/CHILL will meet same accreditation standards as existing generation
   - Voltage instability and thermal overload prevention measures
   - Reactive resource adequacy assessment

6. **Pre-Notification Process**
   - Design and implementation of pre-study notification system
   - Workload assessment procedures
   - Resource availability confirmation protocols

7. **Internal Milestone Definition**
   - Specific deadlines for TO/TP data submissions (20-30 day proposal)
   - Coordination requirements with local TOP/TP entities

8. **Stakeholder Support Assessment**
   - Gauge broader stakeholder response to HILLGA Path 3
   - Consensus-building around cost allocation methodology