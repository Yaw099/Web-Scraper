# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

**Source File:** RR696 NPPD Comments 20250725.docx.txt

---

## 1. Executive Summary

This document contains comments from Nebraska Public Power District (NPPD) regarding Revision Request 696 (RR696), which proposes to implement a High Impact Large Load (HILL) integration assessment framework and create a new Conditional High Impact Large Load (CHILL) Service. The RR aims to accelerate large load interconnections while maintaining grid reliability. 

NPPD raises significant concerns about:
- Differing MW thresholds at different voltage levels (10 MW at ≤69 kV vs. 50 MW at >69 kV)
- Overlapping with recently implemented processes
- Cost structure and study requirements
- Compliance with FERC requirements regarding mixed transmission services at delivery points
- Long-term impacts on transmission investment and congestion costs

NPPD generally supports limiting non-firm transmission service to 5 years but questions the overall need given other recent process improvements.

---

## 2. Key Topics

### A. HILL Definition and Thresholds
- **10 MW threshold** applies to 69 kV and below
- **50 MW threshold** applies to greater than 69 kV
- NPPD questions rationale for dual thresholds, preferring single 50-100 MW threshold
- Concerns about resource impact of performing multiple 5-10 MW studies vs. single 1-50 MW study

### B. CHILL Service Structure
- Allows High Impact Large Loads to interconnect with conditional transmission service
- Non-firm Point-to-Point (PTP) transmission service required
- 5-year duration limit for non-firm service (NPPD supports this)
- Transition requirement to Firm service after 5 years

### C. Technical Requirements
- Phasor Measurement Units (PMUs) required for HILL loads
- Currently applies to 10 MW+ loads at 69 kV and below
- NPPD proposes raising threshold to 50 MW+

### D. Study Process and Fees
- **Application fee:** $10,000 non-refundable
- **HDPS advance deposit:** $125,000
- NPPD agrees with Google's concern about fee structure being onerous for smaller loads
- Suggests $/MW fee structure with minimum deposit (no cap)

### E. Process Overlap Concerns
- Multiple concurrent new processes: Provisional Load, ERAS, Surplus Plus, CRIS, AQ improvements
- Questions about incremental benefits of HILLS/CHILLS
- Resource concerns about SPP's reliance on external consultants

### F. FERC Compliance Questions
- Current requirement: 100% Network (NITS) OR 100% PTP service per delivery point
- CHILL creates scenario with mixed services at same delivery point
- Unclear how SPP will maintain compliance

### G. Modeling and Reliability
- CHILL loads must be included in future year ITP BR models
- NERC Standards compliance (TPL, MOD, FAC) requires accurate representation
- Detailed models needed for all interconnected load and generation

### H. Transmission Investment Concerns
- Risk to firm transmission infrastructure investment
- "Free rider problem" where some benefit without cost contribution
- Potential focus on short-term vs. long-term solutions
- Congestion revenue shortfalls and uplift to market participants

---

## 3. Decisions or Actions

### Proposed by RR696:
- Implement HILL integration assessment framework
- Create new CHILL Service
- Incorporate language into SPP governing documents for HILL requirements and CHILL Service
- Require PMU installation for qualifying loads
- Establish study fees and deposit structure
- Limit non-firm transmission service to 5 years

### NPPD Recommendations:
- Adopt single 50-100 MW threshold instead of dual thresholds
- Raise PMU requirement threshold to 50 MW+
- Implement $/MW fee structure with minimum deposit (no cap)
- Clarify transition process between Attachment AQ and BA studies
- Address FERC compliance for mixed transmission services
- Develop internal SPP resources rather than relying on consultants

---

## 4. Important Dates

- **7/25/2025** - Date of NPPD comment submission
- **90 days** - Standard study completion timeframe mentioned
- **5 years** - Duration limit for non-firm transmission service before transition to firm service required

---

## 5. Organizations and People Mentioned

### Organizations:
- **NPPD (Nebraska Public Power District)** - Submitter/Commenter
- **SPP (Southwest Power Pool)** - Grid operator/process administrator
- **Google** - Referenced as having submitted similar concerns about fee structure
- **FERC (Federal Energy Regulatory Commission)** - Regulatory authority
- **NERC** - Reliability standards organization

### People:
- **Robert Pick** - Submitter
  - Email: rjpick@nppd.com
  - Company: NPPD

### Referenced Internal Groups:
- NPPD Board (Approved Transmission extension policy)
- SPP RMS (ticket response system)
- SPP Staff

---

## 6. Links or References

### SPP Documents/Processes Referenced:
- **Attachment AQ** - Study process
- **Attachment BA** - Study process (Section 2.2.4 specifically mentioned)
- **RR Form** - Original Revision Request documentation
- **ITP BR models** - Integrated Transmission Planning Base Reliability models

### Standards Referenced:
- **NERC TPL Standards** - Transmission Planning
- **NERC MOD Standards** - Modeling requirements
- **NERC FAC Standards** - Facilities requirements

### Other Processes Referenced:
- Provisional Load process
- ERAS (Energy Reliability Assessment Study)
- Surplus Plus
- CRIS (Capacity Resource Interconnection Service)
- AQ improvements
- LRE (Load Responsible Entity) - mentioned regarding generation availability

### Policies Referenced:
- NPPD Board's Approved Transmission Extension Policy
- FERC requirements for transmission service at delivery points

---

## 7. Suggested Tags

**Primary Tags:**
- RR696
- High Impact Large Load (HILL)
- Conditional High Impact Large Load (CHILL)
- Transmission Service
- Load Interconnection

**Secondary Tags:**
- NPPD
- Non-firm transmission
- Point-to-Point service
- Network Integration Transmission Service (NITS)
- Study process
- Fee structure
- Voltage thresholds
- Phasor Measurement Units (PMU)

**Technical Tags:**
- 69 kV
- 115 kV
- 10 MW threshold
- 50 MW threshold
- NERC compliance
- Grid reliability

**Process Tags:**
- Attachment AQ
- Attachment BA
- HDPS (High Demand Planning Study)
- ITP (Integrated Transmission Planning)
- Comment period

---

## 8. Items That May Need Follow-Up

### Critical Issues Requiring Resolution:

1. **FERC Compliance Clarification**
   - How will SPP comply with FERC requirements when CHILL requires non-firm PTP service at delivery points that may also serve network customers?
   - Current prohibition on mixed service types at single delivery point needs reconciliation

2. **Threshold Justification**
   - SPP needs to provide basis/rationale for dual MW thresholds (10 MW vs. 50 MW at different voltage levels)
   - Technical justification for why 10 MW at ≤69 kV is "High Impact" and "Non-conforming"

3. **Study Process Clarification**
   - Define process for customers to determine whether to request Attachment AQ or BA study
   - Establish transition mechanism between AQ and BA study requests
   - Clarify impact on AQ study process timeline and workload

4. **Fee Structure Revision**
   - Review Google and NPPD comments on fee structure inequity
   - Consider $/MW approach with minimum deposit requirement
   - Ensure adequate financial protection for TPs/TOs

5. **PMU Requirements**
   - Reconsider cost-benefit of PMU requirements for 10 MW+ loads at lower voltages
   - Evaluate NPPD proposal to limit to 50 MW+ loads

6. **Process Overlap Assessment**
   - Document incremental benefits