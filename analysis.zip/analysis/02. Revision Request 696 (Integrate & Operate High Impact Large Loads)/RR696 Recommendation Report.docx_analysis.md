# Final Combined Report

# COMPREHENSIVE REGULATORY ANALYSIS REPORT
## RR696: Integrate & Operate High Impact Large Loads

---

## 1. EXECUTIVE SUMMARY

**Document Overview:**
RR696 establishes a comprehensive framework for accelerating the interconnection of High Impact Large Loads (HILL) while maintaining grid reliability within the Southwest Power Pool (SPP). Requested by the SPP Board of Directors for their August 2025 meeting, the proposal addresses exponential load demand growth—particularly from data centers and industrial facilities—by creating three service types: HILL, Conditional HILL (CHILL), and HILL Generation Assessment (HILLGA).

**Approval Timeline:**
- **July 16, 2025:** Initial MOPC rejection (53.73% opposed)
- **July-August 2025:** Stakeholder workshops and policy refinement
- **August 21, 2025:** Special MOPC approval (96%, with modification to Attachment AQ 3.2 timeline)
- **September 4, 2025:** Board of Directors final approval (1 opposed, 3 abstained)
- **October 27, 2025:** Impact Analysis approved (High severity/complexity)

**Implementation Requirements:**
- **Timeline:** 9 months
- **Staff Hours:** 1,620 hours
- **Complexity/Severity:** High
- **Tariff Modifications:** Multiple sections across Tariff Parts I-V, Market Protocols, Operating Criteria, Planning Criteria, Business Practices, and ITP Manual

**Critical Unresolved Issues:**
Despite approval, significant concerns remain regarding service territory protection, cost allocation equity, queue integrity, stakeholder process adequacy, and coordination with other pending policy initiatives (ERAS, CPP, LTCR netting).

---

## 2. KEY TOPICS

### A. Large Load Integration Framework

**Three Service Types:**
1. **HILL (High Impact Large Load):** Expedited interconnection for large loads with firm transmission service requirements
2. **CHILL (Conditional High Impact Large Load):** Non-firm service for flexible, curtailable loads (5-year conditional period)
3. **HILLGA (High Impact Large Load Generation Agreement):** Three pathways for loads bringing co-located generation
   - Path 1: Common Bus (behind-the-meter)
   - Path 2: Local Area (nearby generation)
   - Path 3: Delivery Area (generation within deliverability area) - *Most controversial*

**Load Thresholds:**
- 50 MW minimum for Non-Conforming Load registration requirements
- 10 MW threshold at 69 kV and below raised concerns from NPPD

### B. Interconnection Process

**Study Pathways:**
- **Attachment AQ:** Load Connection Study (LCS) + Delivery Point Network Study (DPNS)
  - Timeline: 60 days standard; **90 days for HILL** (modified per MOPC contingency)
- **Attachment AX:** Provisional Load Process Study (PLPS) when insufficient designated resources
- **Attachment BA/BB:** NEW - HILL-specific requirements

**Study Fees:**
- LCS deposit: Lesser of $25,000 or estimated cost
- DPNS deposit: Lesser of $10,000 or estimated cost
- Interest on deposits per 18 C.F.R. § 35.19a(a)(2)
- Concerns raised about discriminatory impact on smaller loads (flat fee vs. $/MW approach)

### C. Reliability and Operations

**Technical Requirements:**
- Voltage and frequency ride-through capabilities (specifics not fully defined)
- Phasor measurement units (PMU) for certain loads (contested by NPPD)
- Real-time telemetry and remote disconnect capability
- ICCP connectivity for GOPs >1,500 MW or 15+ resources (dual-node with 240-second reconnection)

**Curtailment Hierarchy:**
1. Non-firm Export Interchange Transactions
2. Emergency capacity limit incorporation
3. CHILL loads (before Demand Response programs per SAWG conditions)
4. Reliability-status resources
5. Charging energy storage resources

**SCUC/SCED Integration:**
- Day-Ahead Market commitment optimization
- Intra-Day RUC execution
- Real-Time Balancing Market (RTBM) dispatch
- Must-offer requirements (90% threshold)

**Emergency Procedures:**
- Local Emergency Condition protocols
- Manual commitment/decommitment authority
- Operating guide development requirements
- Market Monitor verification of non-discriminatory selection

### D. Market and Resource Adequacy

**Load Forecasting:**
- Non-Conforming Load designation for unpredictable load patterns
- Hourly forecasts required before Day-Ahead RUC (Operating Day + 6)
- Rolling 15-minute forecast submission
- Forecast error penalties

**Resource Adequacy Integration:**
- Incorporation into LOLE (Loss of Load Expectation) studies
- Impact on PRM (Planning Reserve Margin), PBA (Performance-Based Accreditation), ELCC (Effective Load Carrying Capability)
- Exclusion from regional CONE (Cost of New Entry) multiplier (per SAWG conditions)
- Generator availability reserve requirements with environmental limitations

**Must-Offer Requirements:**
- Day-Ahead Market participation obligations
- LDAMO (Long-term Day-Ahead Must Offer) implications
- Resources supporting CHILLs subject to automatic mitigation when dispatched above CHILL load

**Cost Allocation:**
- Usage-based vs. maximum capacity payment debate
- Regional vs. local cost recovery mechanisms
- Schedule 11 charges (Base Plan Zonal + Region-wide)
- GRID-Contribution (GRID-C) requirements under CPP

### E. Transmission Planning

**Network Upgrades:**
- Sponsored Upgrades (20-year cost recovery; lump sum or periodic charges)
- Service Upgrades (Creditable vs. non-Creditable)
- Generation Interconnection Related Network Upgrades
- Zonal Reliability Upgrades
- JTIQ (Joint Transmission Interconnection Queue) Upgrades

**ITP Integration:**
- Delivery Point changes evaluated in Integrated Transmission Planning Assessment
- Aggregation of proximate requests for comprehensive analysis
- Quarterly status reporting and plan modifications
- Stakeholder review through ESWG, TWG, Regional State Committee

**Transmission Material Modification:**
- Triggers: Rating reductions >20%, impedance changes >±30%, voltage changes, configuration changes
- Duration threshold: 12 months for "permanent" designation
- NERC FAC-002-041 compliance requirements

### F. Stakeholder Process Concerns

**Timeline Issues:**
- Initial materials posted only 1.5 business days before meetings
- Insufficient review time for complex policy (~1 month extension requested)
- Compressed stakeholder engagement vs. traditional processes

**Process Deviations:**
- Reduced utilization of established working groups (TWG, Tariff groups)
- Multiple simultaneous policy changes (HILL/CHILL, ERAS, CPP, LTCR netting, Surplus+)
- Implementation before FERC approval concerns

**Participation Concerns:**
- Lower stakeholder participation rates in expedited process
- Incomplete comments (Renewable Fuels Nebraska)
- All initial stakeholder comments "Reviewed, not accepted"

---

## 3. DECISIONS OR ACTIONS

### A. Final Approval Chain

**MWG (October 27, 2025):**
- Approved Impact Analysis: High severity, High complexity
- Vote: 100% approval (1 abstention: OPPD)

**SAWG (July 23, 2025):**
- Conditional support requiring 8 clarifications before Board approval
- Vote: 100% consensus with conditions

**MOPC (Special Session, August 21, 2025):**
- Approved RR696 with SPP Comments dated August 14, 2025
- **Critical Modification:** Attachment AQ 3.2 timeline remains 90 days for HILL (not reduced to 60 days)
- Vote: 96% approval, 2 opposed (ConocoPhillips, NPPD), 15 abstentions

**Board of Directors/Members Committee (September 4, 2025):**
- Final approval granted
- Vote: 1 opposed (OGE), 3 abstained (NRDC, Xcel/SPS, NPPD)
- Approval by secret ballot

### B

---

# Partial Chunk Reports

# Chunk 1 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

**Document:** RR696 Recommendation Report - Integrate & Operate High Impact Large Loads

This recommendation report proposes a comprehensive framework for accelerating the interconnection of High Impact Large Loads (HILL) while maintaining grid reliability and operational efficiency. The proposal addresses exponential load demand growth across the SPP (Southwest Power Pool) footprint by creating standardized processes for load assessment, study, registration, and operations. The Board requested this timely, scalable, and reliable approach for their August meeting. The framework includes modifications to multiple SPP governing documents and requires 1,620 estimated staff hours over 9 months for implementation.

**Key Challenge:** Balancing rapid load interconnection needs with traditional planning processes, reliability standards, and cost allocation equity, while protecting certificated service territories.

## 2. Key Topics

- **High Impact Large Load (HILL) Integration Framework**
  - Accelerated interconnection processes for large loads
  - Integration of design, study, registration, and operations
  - Three service types: HILL, Conditional HILL (CHILL), and HILL Generation Assessment (HILLGA)

- **Grid Reliability and Planning**
  - Alignment with NERC standards
  - System stability and accurate modeling
  - Early detection of system constraints
  - Reduction in planning reserve margin requirements

- **Market Efficiency**
  - Clear, consistent interconnection rules
  - Reduced uncertainty for developers
  - Enhanced price signals
  - Better cost certainty and speed to market

- **Service Territory Protection Concerns**
  - Potential encroachment on retail utilities' certificated service territories
  - Cherry-picking of lucrative customers
  - State regulatory authority implications

- **Cost Allocation and Benefits**
  - Transmission upgrade avoidance
  - Reduced congestion costs
  - Fewer emergency procedures
  - Improved study efficiency

## 3. Decisions or Actions

**Recommendation:** Approve RR696 (Integrate & Operate High Impact Large Loads) with SPP Comments dated 20250827

**Implementation Requirements:**
- Estimated implementation time: 9 months
- Estimated implementation staff hours: 1,620
- Complexity level: High
- Severity level: High
- Prioritization needed: Yes
- Impact Analysis needed: Yes

**Document Modifications Required:**
- **Tariff:** Multiple sections including Part I (1.1, 34.1, 34.3, Schedule 11, Attachments J, O, AE, AQ, AX) and NEW Attachments BA and BB
- **Market Protocols:** Version 112a (Glossary, multiple sections 4.x and 6.x)
- **Operating Criteria:** Sections 3.6, 5.2
- **Planning Criteria:** Sections 5.1, 5.2, and NEW Section 5.6
- **Business Practice:** BP7850
- **ITP Manual:** Sections 2.1.3, 4.4

**Stakeholder Review Status:**
- Tri-State comments: Reviewed, not accepted
- SPP internal amendments: Reviewed, not accepted
- Renewable Fuels Nebraska: Comments incomplete in provided text

## 4. Important Dates

- **Report Date:** July 18, 2025
- **Target Board Meeting:** August 2025 (Board approval requested)
- **SPP Comments Date:** August 27, 2025 (referenced as 20250827)
- **Implementation Timeline:** 9 months from approval

## 5. Organizations and People Mentioned

**Primary Authors:**
- **Natasha Henderson** - Southwest Power Pool (nhenderson@spp.org)
- **Yasser Bahbaz** - Southwest Power Pool (ybahbaz@spp.org)

**Organizations:**
- **Southwest Power Pool (SPP)** - Transmission Provider
- **Tri-State** - Stakeholder with concerns about service territory protections
- **Renewable Fuels Nebraska** - Stakeholder supporting the initiative (with concerns about costs)
- **NERC (North American Electric Reliability Corporation)** - Standards organization
- **FERC (Federal Energy Regulatory Commission)** - Referenced in regulatory context

**Entity Types Referenced:**
- Transmission Owners
- Transmission Customers
- Load-Serving Entities (LSEs)
- Power Marketers
- Eligible Customers
- Federal Power Marketing Agencies
- Balancing Authorities

## 6. Links or References

**Supporting Materials:**
- High Impact Large Load presentation (7 pages)
- Comprehensive Roadmap
- SIR# 764

**Referenced Documents:**
- SPP Tariff (multiple sections)
- Market Protocols Version 112a
- Operating Criteria
- Planning Criteria
- Business Practice BP7850
- Integrated Transmission Planning (ITP) Manual
- Federal Power Act Section 212(h)

**Related Pending Items:**
- Energy Storage Resource Load Assessment language (pending July 2025 MOPC approval)

## 7. Suggested Tags

- High Impact Large Loads (HILL)
- Load Interconnection
- Grid Reliability
- Transmission Planning
- SPP Tariff Revision
- Market Efficiency
- Service Territory Protection
- Cost Allocation
- NERC Compliance
- Board Approval
- RR696
- Conditional HILL (CHILL)
- HILL Generation Assessment (HILLGA)
- Transmission Customer
- Load-Serving Entity
- Planning Reserve Margin
- Stakeholder Process

## 8. Items That May Need Follow-Up

**Critical Issues Requiring Resolution:**

1. **Service Territory Protection (Tri-State Concerns)**
   - **Issue:** Lack of guardrails preventing encroachment on certificated retail service territories
   - **Risk:** Power marketers or HILLs becoming Transmission Customers to bypass retail utilities
   - **Proposed Solution:** Tri-State suggests additions to Part 1, Section 1.1 Definitions and Attachment BA Introduction
   - **Status:** Reviewed but not accepted - requires resolution before Board approval

2. **Interruptible Load Tariff Requirements (Tri-State Concern)**
   - **Issue:** CHILL service may create problems for retail utilities without interruptible load tariffs
   - **Proposed Solution:** Limit CHILL service to LSEs with effective interruptible load tariffs
   - **Status:** Reviewed but not accepted

3. **Renewable Fuels Nebraska Comments**
   - **Status:** Comments incomplete in provided text - full stakeholder position unclear
   - **Concern:** "Unreasonable and unjust costs and hurdles for some of the most flexible loads"
   - **Action Needed:** Review complete comments and address concerns about impacts on biofuels/ethanol industry

4. **Attachment BB Modifications**
   - Energy Storage Resource Load Assessment language pending MOPC approval (July 2025)
   - Maximum injection limit calculation methodology changed to use capacity accreditation MW value
   - **Action Needed:** Confirm MOPC approval status before Board meeting

5. **Implementation Resource Allocation**
   - 1,620 staff hours over 9 months required
   - High complexity implementation
   - **Action Needed:** Confirm resource availability and detailed implementation plan

6. **Cost-Benefit Quantification**
   - Multiple qualitative benefits listed but not quantified
   - **Action Needed:** Develop specific metrics for:
     - Transmission upgrade cost avoidance
     - Congestion cost reduction
     - Emergency procedure savings
     - Study efficiency improvements

7. **State Regulatory Coordination**
   - Potential conflicts with state commission authority over retail service
   - **Action Needed:** Clarify relationship between FERC jurisdiction and state retail regulation

8. **Vendor Cost Estimation**
   - Field left blank in impact analysis
   - **Action Needed:** Obtain vendor cost estimates for complete financial assessment

9. **Comprehensive Roadmap and SIR#764**
   - Referenced but not detailed in provided content
   - **Action Needed:** Ensure supporting documentation is available for Board review

10. **Primary Working Group Final Recommendation**
    - Multiple items marked "Reviewed, not accepted"
    - **Action Needed:** Clarify final working group position and rationale for non-acceptance of stakeholder comments

**Compliance and Regulatory Follow-Up:**
- Ensure NERC standards alignment is documented
- Confirm FERC filing requirements and timeline
- Verify state regulatory commission notification procedures

**Stakeholder Engagement:**
- Address unresolved concerns before Board meeting
- Potential need for additional stakeholder meetings

---

# Chunk 2 Analysis

# REGULATORY MEETING ANALYSIS REPORT

## 1. Executive Summary

This document contains stakeholder comments on SPP's Revision Request 696 (RR696) concerning the integration and operation of High Impact Large Loads (HILL). The proposal introduces CHILLS (Conditional High Impact Large Load Service) and HILLGA (High Impact Large Load Generation Aggregation) processes to expedite large load interconnections. Multiple stakeholder groups submitted comments, all of which were "Reviewed, not accepted" by the Primary Working Group. Key concerns include:

- Transmission cost allocation and conditional service duration limits
- Potential discrimination against existing ratepayers and clean energy resources
- Inadequate stakeholder engagement timeline
- Reliability and stability study concerns
- Risk of preferential treatment for certain resources over queued projects

## 2. Key Topics

- **Large Load Interconnection Process**: Fast-tracking procedures for data centers and other high-demand facilities
- **HILLGA Pathways**: Three-tiered approach (Path 1, 2, and 3) with varying requirements and concerns
- **Cost Recovery Models**: Debate over usage-based vs. maximum capacity-based charging
- **Conditional Service Duration**: Current 5-year limit vs. longer-term stability needs
- **Reliability Concerns**: Voltage stability, transient stability, power quality, and grid infrastructure strain
- **Stakeholder Process**: Compressed timeline and limited engagement opportunities
- **Resource Discrimination**: Concerns about preferential treatment and impacts on existing DISIS queue projects
- **FERC Approval**: Questions about implementing before federal regulatory approval

## 3. Decisions or Actions

**Primary Working Group Actions:**
- All submitted comments were **"Reviewed, not accepted"**
- Submitters included: Renewable Fuels Nebraska/Antora Energy, Public Interest Organizations (PIOs), NextEra Energy Resources, and KGFA

**Stakeholder Recommendations (Not Accepted):**

*From Renewable Fuels Nebraska/Antora Energy:*
1. Extend conditional service beyond 5-year limit
2. Implement usage-based cost recovery model aligned with actual use

*From NextEra Energy Resources:*
1. Eliminate HILLGA Path 3 entirely
2. Clarify generation caps refer to accredited capacity, not nameplate capacity
3. Require executed agreements and $100,000 fee for large loads prior to study
4. Address voltage and stability study requirements within 90-day timeframe

## 4. Important Dates

- **July 1**: Large Load Stakeholder Engagement Forum where RR 696 was presented
- **Q2 and Q3 2025**: NERC Large Load Task Force scheduled to produce white papers (referenced)
- **Q1 2026**: NERC Reliability Guideline for emerging large loads expected (referenced)
- **90 days**: Proposed study timeframe for CHILLS and HILLGA results
- **5 years**: Current conditional service duration limit (contested)

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)**: RTO proposing RR696
- **Renewable Fuels Nebraska**: Trade association submitting comments
- **Antora Energy**: Member company with projects dependent on policy certainty
- **Public Interest Organizations (PIOs)**: Coalition including:
  - Earthjustice
  - Natural Resources Defense Council (NRDC)
  - Renew Missouri
  - Sierra Club
  - Sustainable FERC Project
- **NextEra Energy Resources**: Major stakeholder opposing elements of proposal
- **KGFA**: Submitter (comments cut off in excerpt)
- **FERC (Federal Energy Regulatory Commission)**: Federal regulatory authority
- **NERC (North American Electric Reliability Corporation)**: Reliability standards organization
- **LREs (Load Responsible Entities)**: SPP members serving existing load
- **ERCOT**: Referenced as comparison for fee structure
- **Primary Working Group**: Review body that rejected all comments

**Working Groups Referenced:**
- ORWG (Operations and Reliability Working Group)
- DISIS (Definitive Interconnection System Impact Study process)

## 6. Links or References

- **RR 696**: Main revision request document
- **Antora Energy's comments**: Referenced as attached/on file
- **NERC incident review**: Issued earlier in 2025 regarding 1.5 GW load loss incident
- **NERC April presentation**: Plans to address reliability impacts from large load integration
- **NERC Large Load Task Force white papers**: Expected Q2-Q3 2025
- **NERC Reliability Guideline**: Expected Q1 2026
- **SPP ERAS proposal**: Referenced as having similar discriminatory concerns
- **Consolidated Planning Process (CPP)**: Forthcoming SPP process that should align with RR696
- **SPP existing tariff**: Referenced regarding implementation before FERC approval

## 7. Suggested Tags

- RR696
- Large Load Interconnection
- CHILLS
- HILLGA
- SPP
- Transmission Planning
- Cost Recovery
- Stakeholder Comments
- Grid Reliability
- Voltage Stability
- Data Centers
- Economic Development
- FERC Approval
- NERC Standards
- Resource Adequacy
- Queue Reform
- Agricultural Economy
- Clean Energy
- Ratepayer Protection

## 8. Items That May Need Follow-Up

**Critical Process Issues:**
1. **FERC approval timeline and implementation**: SPP reportedly moving forward with implementation before FERC approval, creating potential unwinding challenges
2. **Stakeholder engagement adequacy**: Multiple parties cite insufficient review time and compressed process
3. **All comments rejected**: Need to understand Primary Working Group rationale for rejecting all stakeholder input

**Technical/Reliability Concerns:**
4. **90-day study adequacy**: Whether expedited timeline can adequately assess voltage stability, transient stability, power quality, harmonics, torsional modes, and affected system impacts
5. **NERC alignment**: Coordination with NERC's Large Load Task Force work and 2026 Reliability Guideline development
6. **Stability requirements**: Need explicit voltage and frequency stability specifications for large load interconnection

**Policy/Fairness Issues:**
7. **HILLGA Path 3 discrimination concerns**: Potential for unfair queue-jumping and preference for LRE resources over DISIS projects
8. **Generation cap definition**: Clarification needed on accredited vs. nameplate capacity to avoid resource-type discrimination
9. **Speculative load prevention**: Current proposal lacks provisions to prevent duplicative/speculative requests
10. **Cost allocation fairness**: Resolution of usage-based vs. maximum-capacity cost recovery debate

**Financial Safeguards:**
11. **Study fee structure**: Whether $100,000 additional fee (similar to ERCOT) should be required
12. **Executed agreement requirement**: Whether demonstration of real load commitment should be mandatory before expedited study

**Long-term Planning:**
13. **Conditional service duration**: Resolution of 5-year limit vs. long-term investment needs
14. **CPP alignment**: Ensuring consistency between RR696 and forthcoming Consolidated Planning Process
15. **Demand-side resource accreditation**: Consistency across frameworks needed

**Monitoring:**
16. **Litigation risk**: Multiple parties suggest current proposal may face FERC challenges and delays
17. **Grid stability incidents**: Monitor for any issues similar to the 1.5 GW load loss incident referenced by NERC

---

# Chunk 3 Analysis

# REGULATORY MEETING ANALYSIS REPORT
## RR696 Recommendation Report - Chunk 3 of 20

---

## 1. Executive Summary

This document contains stakeholder comments on SPP's (Southwest Power Pool) Revision Request 696 (RR696), which proposes a new conditional transmission interconnection pathway for large loads. Three stakeholders submitted comments: Kansas Grain and Feed Association/Renew Kansas Biofuels Association (supporting with amendments), Enchanted Rock (providing technical perspective), and APA (opposing with significant concerns). The primary focus is on the CHILLS (Conditional High Impact Large Load Service) and HILLGA (High Impact Large Load Generation Addition) pathways. The Primary Working Group reviewed but did not accept these comments. Key concerns include cost allocation, flexibility for industrial loads, queue jumping, stakeholder process adequacy, and grid reliability impacts.

---

## 2. Key Topics

- **Conditional Transmission Service for Large Loads**: Proposed CHILLS pathway with 5-year limit on non-firm transmission
- **HILLGA Pathways (Paths 1, 2, and 3)**: New generation interconnection processes associated with large loads
- **Flexible Load Integration**: Industrial energy users seeking ability to use off-peak energy with storage capabilities
- **Cost Allocation Concerns**: Debate over transmission payment structures (pay-for-use vs. maximum capacity payment)
- **Queue Management**: Concerns about preferential treatment and "queue jumping" for certain projects
- **Grid Reliability and Stability**: Impact of multiple simultaneous policy changes on system reliability
- **Stakeholder Process**: Complaints about rushed timelines and inadequate time for review
- **Curtailment and On-site Generation**: Use of dispatchable generation to manage peak demand
- **Deliverability Areas**: Geographic zones affecting interconnection rights
- **Resource Neutrality**: Ensuring non-discriminatory treatment of all generation types

---

## 3. Decisions or Actions

**Primary Working Group Actions:**
- **Reviewed but NOT accepted** comments from Kansas Grain and Feed Association/Renew Kansas
- **Reviewed but NOT accepted** comments from Enchanted Rock
- **Reviewed but NOT accepted** comments from APA

**Requested Actions/Amendments:**

*Kansas Grain and Feed Association/Renew Kansas:*
1. Remove 5-year limitation on conditional transmission for flexible large loads (make long-term)
2. Allow flexible loads to pay only for transmission actually used rather than maximum potential usage

*APA Recommendations:*
1. Modify HILLGA Paths 2 and 3 to provide interim service only until Consolidated Planning Process (CPP) takes effect
2. Require HILLs to pay full GRID-Contribution (GRID-C) under CPP
3. Create permanent option for flexible resources to obtain long-term conditional service
4. Ensure tariff language reflects resource neutrality
5. Set HILLGA capacity limitations in terms of accredited capacity
6. Provide clarity on interaction with existing processes (AQ, AX studies)

---

## 4. Important Dates

- **5-year term**: Proposed limitation on CHILLS non-firm transmission service before transition to firm service required
- **No specific calendar dates mentioned** in this chunk

---

## 5. Organizations and People Mentioned

**Organizations:**

*Commenting Stakeholders:*
- **Kansas Grain and Feed Association (KGFA)** - 950+ Kansas business locations, 99% of commercially licensed grain storage
- **Renew Kansas Biofuels Association (Renew Kansas)** - Kansas biofuels processing industry
- **Enchanted Rock** - Houston-based microgrid owner/operator/developer with 1+ GW capacity across 329 sites
- **APA** (Organization name not spelled out in this chunk)

*Other Mentioned:*
- **SPP (Southwest Power Pool)** - Regional transmission organization
- **Microsoft** - Data center customer mentioned in Enchanted Rock comments
- **Duke University** - Published "Rethinking Load Growth" report
- **FERC (Federal Energy Regulatory Commission)** - Regulatory authority referenced in APA comments
- **Load Serving Entities (LSEs)** - Entities that could potentially block competitor generation

**People:**
- No individual names mentioned in this chunk

---

## 6. Links or References

**Referenced Documents/Policies:**
- RR696 (Revision Request 696) - main policy under discussion
- CHILLS (Conditional High Impact Large Load Service)
- HILLGA (High Impact Large Load Generation Addition) - Paths 1, 2, and 3
- DISIS (appears to be an existing queue/study process)
- ERAS proposal - previous SPP proposal with similar discriminatory concerns
- Surplus+ - capacity counting mechanism
- CPP (Consolidated Planning Process)
- GRID-Contribution (GRID-C) - cost allocation mechanism
- ITP process (Integrated Transmission Planning)
- AQ and AX studies - existing application processes
- PRM (Planning Reserve Margin)
- SPP Tariff
- SPP governing documents

**External References:**
- Duke University "Rethinking Load Growth" report - suggests 10 GW of new load could be integrated with 0.5% annual curtailment rate
- FERC Open Access principles

---

## 7. Suggested Tags

- RR696
- Conditional Transmission Service
- CHILLS
- HILLGA
- Large Load Interconnection
- Grid Reliability
- Queue Management
- SPP
- Kansas Energy
- Data Centers
- Biofuels Industry
- Grain Industry
- Microgrids
- Flexible Loads
- Curtailment
- Cost Allocation
- Stakeholder Process
- Generator Interconnection
- Transmission Planning
- Resource Neutrality
- Energy Storage

---

## 8. Items That May Need Follow-Up

**Critical Unresolved Questions (per APA comments):**
1. **End-of-term transition**: What happens after 5-year CHILLS term if customers don't attain firm transmission?
   - Can CHILLS customers reapply for CHILLS?
   - Can they remain curtailed indefinitely?
   - Do they transition to CPP?

2. **Study process coordination**: How do AQ, AX, and CHILLS studies interact when applications are submitted simultaneously?

3. **Policy integration issues**:
   - How do CHILLS and HILLGA impact Load Responsible Entity (LRE) Planning Reserve Margin (PRM) requirements?
   - How do these policies interact with ITP process?
   - What are grid stability impacts when policies converge?

4. **Capacity counting concerns**: Potential "double counting" of capacity in Surplus+, ERAS, and new proposals

5. **Discriminatory treatment concerns**:
   - Path 3 allowing Transmission Customers to block competitor generation
   - Similar issues to ERAS proposal currently being challenged at FERC
   - Resource neutrality not adequately addressed in tariff language

6. **Cost and payment structure**: 
   - Flexibility for pay-as-you-use vs. maximum capacity payment models
   - Long-term vs. 5-year limitation on conditional service

7. **Process concerns**:
   - Inadequate stakeholder review time
   - Circumvention of normal SPP governing processes
   - Piecemeal vs. holistic policy development

8. **Reliability analysis**: Grid stability studies being delayed while new policies advance

9. **Economic impacts**: Unclear future for developers utilizing these constructs

10. **Demand Response participation**: Language appears incomplete regarding Demand Response resources in HILLGA (text cuts off)

**Recommended Next Steps:**
- Clarify tariff language on all unresolved questions before implementation
- Provide comprehensive analysis of policy interactions (CHILLS, HILLGA, ERAS, Surplus+, CPP)
- Allow additional stakeholder review time
- Address FERC Open Access compliance concerns
- Complete grid stability analysis before advancing proposal

---

# Chunk 4 Analysis

# Regulatory Content Analysis Report
## RR696 Recommendation Report - Chunk 4 of 20

---

## 1. Executive Summary

This document segment contains stakeholder comments on SPP's Revision Request 696 concerning the integration and operation of High Impact Large Loads (HILLs). Three entities submitted comments: American Psychological Association (APA), Antora Energy, and SPP's Market Monitoring Unit (MMU). APA's comments were reviewed but not accepted. Antora Energy proposes modifications to make the Conditional HILL (CHILL) service more accommodating for low load-factor, flexible loads like thermal energy storage systems, but their recommendations were also not accepted. The MMU provides advisory comments focused on marketplace risks, separated into pre-implementation and post-implementation recommendations. SPP also submitted self-generated updates regarding Attachment BB Appendix 3 for Western Area Power Administration and alignment of Resource Day Ahead Must Offer requirements.

---

## 2. Key Topics

- **HILL Interconnection Process**: Creation of faster, transparent Large Load interconnection process through Tariff Attachments BA & BB
- **CHILL Service (Conditional High Impact Large Load Service)**: Optional service for flexible, low load-factor loads
- **Cost Structure**: Hourly non-firm point-to-point pricing based on scheduled usage
- **Resource Adequacy**: Treatment of CHILL loads regarding Load Serving Entity obligations
- **Market Monitoring**: MMU oversight of new requirements and market participant compliance
- **Tariff Language**: Need for strengthened oversight provisions
- **Energy Storage Integration**: Antora thermal energy storage systems as grid-enhancing flexible loads
- **Zoning**: 19-zone structure for rate calculation purposes
- **Western Area Power Administration**: New GIA appendix when WAPA Division is party to agreement

---

## 3. Decisions or Actions

**Stakeholder Comment Outcomes:**
- APA comments: Reviewed, not accepted
- Antora Energy comments: Reviewed, not accepted
- SPP self-submissions: Not yet reviewed
- MMU comments: Advisory only (no decisional role per FERC Order 719)

**Proposed Changes (Pending):**
- Addition of Attachment BB Appendix 3 for WAPA participation
- Alignment of Resource Day Ahead Must Offer with existing requirements
- Changes to HILL definition to exclude Energy Storage Resources (ESRs)
- Grammatical corrections and enhancements
- Implementation of validation checks for CHILL capacity monitoring

**MMU Recommendations:**
- Pre-implementation: Strengthen tariff language, implement automated compliance checks
- Post-implementation: Ongoing commitment to address identified risks

---

## 4. Important Dates

- **Mid-June**: MMU began engagement with RTO regarding the proposal
- **June**: MWG approved Revision Request 655 Outage Criteria
- **5-year milestone**: CHILL service eligibility limitation (as proposed by Antora)
- No specific implementation dates mentioned in this chunk

---

## 5. Organizations and People Mentioned

**Organizations:**
- American Psychological Association (APA)
- Antora Energy
- Southwest Power Pool (SPP)
- Market Monitoring Unit (MMU)
- Federal Energy Regulatory Commission (FERC)
- Western Area Power Administration (WAPA)
- Load Serving Entities
- Primary Working Group
- Markets and Operations Policy Committee (MWG)

**Zone Entities (19 zones listed):**
1. American Electric Power – West
2. Kansas City Board of Public Utilities
3. City Utilities of Springfield, Missouri
4. Empire District Electric Company
5. Grand River Dam Authority
6. Evergy Metro, Inc.
7. Oklahoma Gas & Electric Company
8. Midwest Energy, Inc.
9. Evergy Missouri West, Inc.
10. Southwestern Power Administration
11. Southwestern Public Service
12. Sunflower Electric Power Corporation
13. Western Farmers Electric Cooperative
14. Evergy Kansas Central, Inc.
15. Reserved for Future Use
16. Lincoln Electric System
17. Nebraska Public Power District
18. Omaha Public Power District
19. Upper Missouri Zone

---

## 6. Links or References

**Regulatory References:**
- FERC Order 719, 18 C.F.R. § 35.28(g)(3)(ii)
- FERC Order 2022
- SPP OATT Attachment AG, §1.3
- Revision Request 655 (Outage Criteria)
- Revision Request 696 (Integrate and Operate High Impact Large Loads)

**Tariff References:**
- Tariff Attachments BA & BB
- Schedule 11 (hourly non-firm point-to-point zonal rates)
- Schedule 15 (proposed CHILLS pricing)
- Schedule 10 (Wholesale Distribution Service)
- Attachment K (redispatch cost formulas)
- Attachment M (real power losses)
- Attachment AE (Resource Day Ahead Must Offer)
- Part VII
- Section 44.4 (penalties)
- Section 45.7 (real power losses)
- Appendix AG (MMU data requirements)

**System References:**
- SPP OASIS (Open Access Same-Time Information System)

---

## 7. Suggested Tags

- High Impact Large Load (HILL)
- Conditional High Impact Large Load (CHILL)
- Revision Request 696
- SPP Tariff
- Energy Storage
- Thermal Energy Storage
- Market Monitoring
- Interconnection Process
- Resource Adequacy
- Transmission Pricing
- Load Factor
- Demand Response
- Grid Flexibility
- Point-to-Point Transmission
- Zonal Rates
- Stakeholder Process
- FERC Compliance
- Antora Energy
- Market Participant Compliance

---

## 8. Items That May Need Follow-Up

**Immediate Follow-Up Required:**
1. **Stakeholder Comment Resolution**: Determine final disposition of rejected APA and Antora Energy comments and rationale
2. **SPP Self-Submission Review**: Primary Working Group review of SPP's proposed changes (currently "not yet reviewed")
3. **MMU Post-Implementation Recommendations**: Obtain commitment from RTO to address post-implementation items
4. **WAPA GIA Appendix**: Finalization of Attachment BB Appendix 3

**Technical Implementation:**
1. **Automated Compliance Monitoring**: Development and deployment of validation checks for CHILL reserved capacity compliance
2. **Load-Limited Resource Monitoring**: Implementation of automated checks for paired generators operating as load-limited resources
3. **Performance Metrics Definition**: Establish specific load factor thresholds (40%, 50%, 60%, or 80%) for CHILL eligibility

**Policy Clarifications Needed:**
1. **ESR Classification**: Clarify impact of excluding Energy Storage Resources from HILL definition
2. **Resource Adequacy Treatment**: Finalize treatment of CHILL loads regarding LSE obligations
3. **Curtailment/Dispatchability Obligations**: Develop detailed curtailment and dispatchability requirements for CHILL customers
4. **Discount Policy**: Operationalize discount announcement and negotiation procedures via OASIS

**Pilot Program Opportunities:**
1. **Antora Pilot Projects**: Evaluate proposal to use initial SPP territory projects to quantify system impacts and benefits
2. **Demand Response Participation**: Develop additional DR opportunities beyond emergency curtailment per FERC Order 2022
3. **Frequency Support Value**: Quantify value of rapidly dispatchable, low load-factor resources

**Timeline Concerns:**
1. **Accelerated Schedule Risk**: Address concerns about "short timeline" and "rapid pace" affecting stakeholder input quality
2. **Continuous Modifications**: Establish version control and stakeholder notification process for ongoing changes
3. **Future MMU Recommendations**: Monitor for additional risk assessments as MMU continues evaluation

**Revenue and Cost Issues:**
1. **Cost-Causation Methodology**: Validate appropriateness of hourly scheduling approach for flexible loads
2. **Revenue Impact Analysis**: Assess incremental revenue potential from low load-factor customers
3. **Penalty Structure**: Finalize penalties under Section 44.4 for capacity exceedances

---

# Chunk 5 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary
This document contains detailed comments from the SPP Market Monitoring Unit (MMU) and Google on Revision Request 696 regarding the integration and operation of High Impact Large Loads (HILLs). The MMU provides extensive recommendations for modifications to the proposal, focusing on open access principles, market mitigation, and operational requirements. Key concerns include the HILLGA-DA (Deliverability Area) option potentially violating open access principles, lack of mitigation for resources supporting Conditional HILLs (CHILLs), and inadequate incentives for accurate load forecasting. Google expresses general support for the initiative while acknowledging the need for policy adjustments to accommodate large load growth timelines.

## 2. Key Topics
- **High Impact Large Loads (HILLs)** and Conditional HILLs (CHILLs) integration
- **HILLGA (High Impact Large Load Generation Agreement)** study process and options
- **Open access transmission principles** and potential violations
- **Market mitigation** requirements for CHILL-supporting resources
- **DSIS (Definitive Interconnection System Impact Study)** and ERAS queue interactions
- **Common bus arrangements** for behind-the-meter generation
- **Non-conforming load forecasting** requirements and incentives
- **RUC (Reliability Unit Commitment)** make-whole payment distribution
- **Demand Response (DR)** framework enhancements
- **LTCR (Long-Term Congestion Rights)** and RR697 interactions
- **Resource adequacy** challenges and load growth

## 3. Decisions or Actions
**MMU Recommendations (Implementation Phase):**
1. Include Seasonal Limits in HILLGA-SS (standalone) option considerations
2. Remove HILLGA-DA option entirely due to open access concerns
3. Require automatic mitigation for resources supporting CHILLs when dispatched above CHILL load
4. Create clear offer rules for HILL/CHILL mixed behind common bus arrangements

**Post-Implementation Recommendations:**
1. Address MMU Annual State of the Market (ASOM) recommendation 2023-2
2. Develop two-step CHILL curtailment process (operator trigger + market clearing engine deployment)
3. Include non-conforming load deviation in RUC make-whole payment calculations
4. Address MMU items in Demand Response framework
5. Apply new HILL requirements to existing HILLs with future effective date instead of permanent grandfathering
6. Reconsider RR697 LTCR Netting of Flows policy in context of HILL/CHILL congestion impacts

**Status:**
- Result of Primary Working Group review: Not yet reviewed

## 4. Important Dates
- **Five-year holding requirement** proposed for LTCR awards under RR697
- **Future effective date** recommended for applying new HILL requirements to existing HILLs (specific date not provided)
- **2023 ASOM** reference for recommendation 2023-2

## 5. Organizations and People Mentioned
**Organizations:**
- SPP (Southwest Power Pool) - RTO operating the markets
- MMU (Market Monitoring Unit) - commenting party
- Google, LLC - commenting party (large load customer)

**Roles Referenced (no specific names):**
- SPP Staff
- Transmission customers
- Generators
- Operators

## 6. Links or References
- **RR696** - Integrate & Operate High Impact Large Loads (primary subject)
- **RR697** - LTCR Netting of Flows
- **RR698** - Referenced in context of LTCR policy
- **Attachment AF, Section 3.10** - Proposed new section for CHILL mitigation measures
- **2023 MMU Annual State of the Market (ASOM)** - Recommendation 2023-2
- **Market Protocols** - Requirements for non-conforming load forecasts
- **Generation Interconnection Agreement** - Limits on grid injection
- **SPP Tariff** - Various provisions referenced

## 7. Suggested Tags
- RR696
- High Impact Large Loads (HILL)
- Conditional HILL (CHILL)
- HILLGA
- Open Access
- Market Mitigation
- Interconnection
- Resource Adequacy
- Load Forecasting
- RUC Make-Whole Payments
- Demand Response
- LTCR
- Market Monitoring Unit
- Data Center Load
- Behind-the-Meter Generation
- Transmission Planning

## 8. Items That May Need Follow-Up

**Critical Issues Requiring Resolution:**
1. **HILLGA-DA Open Access Concern** - MMU recommends complete removal; requires stakeholder decision on whether expedited treatment creates undue discrimination
2. **Mitigation Language** - Proposed new Section 3.10 of Attachment AF needs drafting and approval
3. **Common Bus Offer Rules** - Clear tariff language needed to prevent market gaming and grid injection violations
4. **Primary Working Group Review** - Comments marked as "not yet reviewed" - pending initial stakeholder review

**Post-Implementation Commitments Needed:**
1. **Run-limited resources planning** - Address environmental/operational restrictions on HILLGA generators
2. **CHILL curtailment process** - Develop two-step framework with market clearing engine and potential demand curve
3. **Non-conforming load forecast incentives** - Create financial consequences for inaccurate forecasts
4. **DR framework enhancements** - Address opportunity cost definition, performance measurements, and peak load assessment
5. **Grandfathering timeline** - Establish future effective date for applying new requirements to existing HILLs

**Cross-RR Coordination:**
- **RR697 interaction** - Need to assess LTCR five-year holding requirement in context of HILL/CHILL congestion impacts and increased credit requirements

**Data/Monitoring Requirements:**
- Real-time telemetry for HILLs
- Remote disconnect capability
- Mandatory non-conforming load forecast updates
- Operating reserve clearing limitations for common bus generation

---

# Chunk 6 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document contains stakeholder comments on Revision Request 696 (RR696) concerning High Impact Large Load (HILL) interconnection processes within the SPP (Southwest Power Pool) transmission system. The primary focus involves the proposed CHILLS (Critical High Impact Large Load Service) framework and Attachment AQ service modifications. Major stakeholders including Google, Antora, NPPD, and the MMU have submitted detailed comments raising concerns about cost allocation, operational requirements, definitional issues, and implementation complexity. Key concerns center on potential cost-shifting, unclear processes for distinguishing between HILLGA and AQ service pathways, and the need for more extensive stakeholder discussion before implementation. All submitted comments are marked as "Not yet reviewed" by the Primary Working Group.

## 2. Key Topics

- **HILL/CHILLS Framework**: New service offering for high-impact large loads with non-firm interconnection options
- **Attachment AQ Service**: Load interconnection processes and their relationship to HILLGA
- **Cost Allocation and Transmission Charges**: Concerns about equitable cost assignment and study fee structures
- **Non-Conforming Load Definition**: Disagreement over characterization of large load predictability
- **Queue Management**: Priority treatment based on interconnection request timing
- **Operational Requirements**: Voltage and frequency ride-through capabilities
- **Demand Response Integration**: Overlap between CHILLS and ongoing DR framework development
- **Equal Access**: Ensuring non-discriminatory treatment between Transmission Owner loads and Transmission User loads
- **Study Requirements**: Threshold definitions (10 MW vs. 50-100 MW) and associated administrative burden

## 3. Decisions or Actions

**Pending Decisions** (all comments marked "Not yet reviewed"):
- Review of Google's eight specific concern areas
- Evaluation of Antora's proposed revisions to sections 44.1, 45.3, and Schedule 15
- NPPD's objections to 10 MW threshold and phasor measurement unit requirements
- MMU's recommendations for strengthening oversight language

**SPP Proposed Adjustments**:
- Adjust Attachment AQ 3.2 timeline from 90 to 60 days (90 days for HILL cases)
- Adjust Attachment BB 3.1.1 (2) from 100% to 110%
- Relocate 20 MW ramp rate requirement to Integrated Marketplace Protocols
- Add detail to Attachment BB Section 3 on Affective system studies
- Correct calculation in Attachment BB 3.1.1

## 4. Important Dates

- **Five-year limit**: CHILL service definitively limited to five years (with concerns raised about delay provisions)
- **Study timeline**: 60 calendar days (90 days for HILL) for Attachment AQ 3.2 processing
- **No specific implementation dates provided** in this chunk

## 5. Organizations and People Mentioned

**Organizations**:
- **Google** (primary commenter with 8 detailed concerns)
- **Antora** (submitted revisions)
- **Kansas Grain and Feed Association (KGFA)** (allied with Google on transmission cost concerns)
- **NPPD** (Nebraska Public Power District - detailed implementation concerns)
- **MMU** (Market Monitoring Unit - oversight concerns)
- **SPP** (Southwest Power Pool - RTO/transmission provider)
- **FERC** (Federal Energy Regulatory Commission - compliance concerns mentioned)
- **NERC** (North American Electric Reliability Corporation - modeling standards)

**Entities Referenced**:
- Load Responsible Entities (LREs)
- Transmission Users (TUs)
- Transmission Owners (TOs)

**No individual names mentioned**

## 6. Links or References

**Tariff References**:
- Attachment AQ (Load interconnection service)
- Attachment BB (Sections 3, 3.1.1)
- Attachment AE Section 2.22
- Schedule 15
- Part II of the Tariff
- Integrated Marketplace Protocols

**Regulatory Frameworks**:
- HILLGA (High Impact Large Load Generation Agreement)
- CHILLS (Critical High Impact Large Load Service)
- SPP Demand Response (DR) Framework
- FERC compliance requirements
- NERC standards

**Document Reference**:
- RR696 Recommendation Report.docx.txt (chunk 6 of 20)

## 7. Suggested Tags

- RR696
- HILL (High Impact Large Load)
- CHILLS
- Attachment AQ
- HILLGA
- Load Interconnection
- Transmission Service
- Cost Allocation
- Queue Management
- Stakeholder Comments
- Non-Conforming Loads
- Demand Response
- Equal Access
- Study Requirements
- SPP Tariff
- Grid Integration
- Data Center Loads
- Industrial Loads

## 8. Items That May Need Follow-Up

**Critical Issues Requiring Resolution**:

1. **Queue Priority Mechanism**: Establish clear queue-based prioritization to prevent Load A being burdened by costs from later-requesting Load B under HILLGA vs. AQ service

2. **Non-Conforming Load Definition**: Resolve disagreement between SPP and Google regarding predictability characterization of large industrial loads

3. **CHILLS-DR Framework Integration**: Clarify overlap and potential duplication between CHILLS regulations and concurrent Demand Response framework to avoid administrative burden

4. **Voltage/Frequency Ride-Through Standards**: Develop specific, workable standards instead of undefined blanket requirements; consider market-based solutions

5. **Delay Protections**: Add tariff language providing safeguards for delays beyond reasonable party control within the five-year service limit

6. **Cost Assignment Framework**: 
   - Develop equitable transmission cost assignment (consider Antora's proposal)
   - Reform study fee structure from flat fees to $/MW with cap to avoid discriminating against smaller loads

7. **Equal Access Safeguards**: Review process to prevent preferential treatment of TO loads over TU loads with co-located generation

8. **Threshold Standardization**: Resolve NPPD concern about 10 MW threshold at 69 kV and below vs. unified 50-100 MW threshold

9. **Study Path Navigation**: Clarify how to choose between AQ and BA study paths

10. **FERC Compliance**: Address potential issues with mixed network and CHILL service at same delivery point

11. **MMU Oversight Language**: Strengthen tariff language for adequate RTO and MMU oversight of new requirements

12. **Long-term Investment Impact**: Assess NPPD concern that widespread non-firm service could undermine transmission investment and increase congestion costs

13. **Primary Working Group Review**: All submitted comments require formal PWG review and disposition

14. **Stakeholder Process**: Google's call for "more extensive and deliberate stakeholder discussion" suggests implementation timeline may need extension

---

# Chunk 7 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary
This document is chunk 7 of a Recommendation Report (RR696) containing tariff provisions related to transmission service charges in a multi-zone electricity transmission system. The content primarily covers monthly demand charges for network customers, calculation methodologies for Base Plan Zonal Charges and Region-wide Charges under Schedule 11, and specific provisions for different transmission zones. Key provisions include Load Ratio Share calculations, Annual Transmission Revenue Requirements (ATRR), and revenue adjustments for various schedules and transmission owners utilizing formula rates or stated rates.

## 2. Key Topics
- **Monthly Demand Charges (Section 34.1, 34.3)**: Calculation methodology for network customers based on Load Ratio Share and Zonal ATRR
- **Schedule 11 Charges**: Base Plan Zonal Charges and Region-wide Charges for transmission service
- **Revenue Adjustments**: Treatment of Schedule 7 and 8 revenues, and Attachment AU revenues
- **Zonal Provisions**: Special treatment for specific zones (Zone 10, Zone 11, Zone 19)
- **Formula Rate vs. Stated Rate Treatment**: Different revenue credit methodologies
- **Eastern Interconnection vs. Western-UGP**: Geographic distinctions in charge application
- **Resident Load Calculations**: Methodologies for determining monthly zonal loads
- **Point-to-Point Transmission Service**: Revenue treatment and charge calculations

## 3. Decisions or Actions
- Network Customers must pay monthly Demand Charges calculated using Load Ratio Share
- Transmission Provider will make adjustments set forth in the RRR File
- Western-UGP shall be exempt from Region-wide Charge under Schedule 11
- Federal Power-Western-UGP transmission to Statutory Load Obligations excluded from Zone 19 calculations
- Schedule 11 charges cannot be changed absent a Commission filing
- Revenue adjustments for previous calendar year revenues to be applied
- Different calculation methodologies apply for Transmission Owners using formula rates vs. stated rates

## 4. Important Dates
- **Previous calendar year**: Referenced for Schedule 7 and 8 revenue adjustments
- **Monthly**: Frequency of Demand Charges and load calculations
- **Annual basis**: Revenue credits and updates for formula rates
- No specific future dates mentioned in this chunk

## 5. Organizations and People Mentioned
- **Transmission Provider** (primary entity administering charges)
- **Network Customer(s)**
- **Transmission Owner(s)**
- **Transmission Customer(s)**
- **The Commission** (FERC - Federal Energy Regulatory Commission, implied)
- **Southwestern Public Service** (specific Transmission Owner in Zone 11)
- **Western-UGP** (entity exempt from certain charges)
- **SATOA** (specific transmission entity type)

## 6. Links or References
### Internal Document References:
- Sections 34.1, 34.2, 34.3, 34.5, 34.9
- Section 31.3
- Section 39.3(e)
- Part I, II, III, IV, V of the Tariff
- Attachment H (Table 1, Table 2-A, Table 2-B, Table 3, Section I; Addendum 5)
- Attachment J (Section IV.A)
- Attachment L
- Attachment AU (Section IV, Section V)
- Schedule 7 and 8
- Schedule 11 (Sections I, II, III)
- RRR File

## 7. Suggested Tags
- Transmission Service
- Tariff Provisions
- Monthly Demand Charge
- Schedule 11
- Base Plan Zonal Charge
- Region-wide Charge
- Load Ratio Share
- Annual Transmission Revenue Requirement (ATRR)
- Formula Rate
- Stated Rate
- Network Customer
- Transmission Owner
- Revenue Adjustments
- Zone-specific Provisions
- Western-UGP
- Eastern Interconnection
- Point-to-Point Service
- Resident Load

## 8. Items That May Need Follow-Up

### Clarification Needed:
1. **RRR File details**: What specific information is contained in the RRR File referenced for adjustments?
2. **Zone 11 special provisions**: Why does Southwestern Public Service have different calculation methodology (Addendum 5)?
3. **Western-UGP exemption rationale**: Basis for exempting Western-UGP from Region-wide Charges
4. **SATOA definition**: Full definition and qualification criteria for SATOAs referenced in revenue calculations

### Potential Issues:
1. **Revenue credit timing**: Reconciliation process for previous calendar year revenues may create cash flow implications
2. **Formula rate vs. stated rate complexity**: Different treatment may create inequities between Transmission Owners
3. **Zone 19 load calculation exclusions**: Complexity of excluding Federal Power-Western-UGP transmissions
4. **Federal-Power Southwestern deductions**: Section 34.9 reference for Zone 10 needs verification

### Compliance Monitoring:
1. **Commission filing requirements**: Changes to Schedule 11 charges require Commission approval
2. **Annual revenue credit updates**: Verify proper application for formula rate Transmission Owners
3. **Monthly load calculations**: Accuracy of integrated hourly load coincident with monthly peaks
4. **Attachment J reallocations**: Proper application of Section IV.A adjustments

### Cross-References to Verify:
1. Complete text of Section 34.9 (Federal-Power Southwestern)
2. Complete text of Section 39.3(e) (Western-UGP exemption)
3. Addendum 5 of Attachment H (Zone 11 calculations)
4. Full content of Attachment AU (revenue distribution and allocation)

---

# Chunk 8 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary
This document is a section from SPP's (Southwest Power Pool) Tariff covering cost allocation and recovery mechanisms for transmission upgrades and the transmission planning process. It details how regional load charges are calculated, particularly for Zone 10 and Western-UGP service exemptions. The content extensively covers different types of network upgrades (Sponsored, Service, Generation Interconnection, and Zonal Reliability Upgrades) and their associated cost allocation methodologies. It also outlines SPP's comprehensive transmission planning process and the development of the SPP Transmission Expansion Plan (STEP).

## 2. Key Topics
- **Regional Load Calculation Methodologies** for Zone 10 and Transmission Providers
- **Western-UGP Federal Service Exemptions** and special provisions for statutory load obligations
- **Cost Recovery for Network Upgrades** including:
  - Sponsored Upgrades
  - Service Upgrades
  - Generation Interconnection Related Network Upgrades
  - Zonal Reliability Upgrades
  - JTIQ (Joint Transmission Interconnection Queue) Upgrades
- **Payment Options**: Lump sum vs. periodic charges over 20-year periods
- **ILTCR (Incremental Long-Term Congestion Rights)** eligibility and allocation
- **SPP Transmission Expansion Plan (STEP)** development process
- **Multiple Planning Processes** integration into comprehensive regional plan
- **Stakeholder Review Process** for recommended upgrades

## 3. Decisions or Actions
- **Project Sponsors must elect** payment method for Sponsored Upgrades: (1) lump sum or (2) periodic charges
- **Lump sum is mandatory** for Sponsored Upgrades constructed by Western-UGP
- **Transmission Provider shall file** agreements using good faith construction cost estimates
- **True-up required** upon completion to actual construction costs
- **Transmission Provider shall prepare** draft project lists for stakeholder review
- **Transmission Provider shall post** draft project lists on SPP website
- **Transmission Provider shall invite** written stakeholder comments
- **Stakeholder working groups and Regional State Committee** review required
- **ILTCR terms must be specified** in agreements (minimum 10 years, maximum 20 years)

## 4. Important Dates
- **January 1, 2008**: Cutoff date for Zonal Reliability Upgrades from 2005 SPP Transmission Expansion Plan
- **20-year period**: Standard depreciation and payment period for Sponsored Upgrades
- **10-20 years**: Required term range for ILTCR agreements
- **Monthly basis**: Periodic charge payment frequency (unless otherwise established)
- **Annual**: SPP Transmission Expansion Plan reporting frequency

## 5. Organizations and People Mentioned
### Organizations:
- **SPP (Southwest Power Pool)** - Transmission Provider
- **Western-UGP** - Transmission Owner with Federal Service Exemption
- **Commission** (presumably FERC - Federal Energy Regulatory Commission)
- **Regional State Committee**
- **Stakeholder working groups**

### Roles Referenced:
- Network Customers
- Transmission Owners
- Project Sponsors
- Transmission Customers
- Interconnection Customers
- Market Participants
- JTIQ Generation Interconnection Customers

## 6. Links or References
### Internal Tariff References:
- **Schedule 11**: Region-wide Charges
- **Schedule 1**: Sponsored Upgrade Agreement (of Attachment J)
- **Attachment J**: Recovery of Costs Associated with New Facilities
- **Attachment V**: Generation interconnection cost allocation
- **Attachment Z1**: Service Upgrade cost allocation
- **Attachment Z2**: Transmission revenue credits and ILTCRs
- **Attachment AH**: Market Participant requirements
- **Attachment AQ**: Delivery point facilities changes
- **Attachment AX**: (Referenced but not detailed)
- **Attachment L**: JTIQ ATRR calculations
- **Attachment AV**: JTIQ ATRR calculations
- **Attachment O**: Transmission Planning Process
- **Attachment Y**: Competitive Upgrades definitions

### External References:
- **2005 SPP Transmission Expansion Plan**
- **Commission policy** (for periodic charge calculations)

## 7. Suggested Tags
- Transmission Planning
- Cost Allocation
- Network Upgrades
- ILTCR
- Sponsored Upgrades
- Zone 10
- Western-UGP
- Federal Service Exemption
- JTIQ
- Regional Load Calculation
- SPP Transmission Expansion Plan
- STEP
- Service Upgrades
- Generator Interconnection
- Stakeholder Process
- Revenue Requirements
- Directly Assigned Costs
- Zonal Reliability Upgrades

## 8. Items That May Need Follow-Up
1. **Cost True-up Mechanism**: Verification process for reconciling estimated vs. actual construction costs for Sponsored Upgrades
2. **ILTCR Allocation Criteria**: Specific MW amounts and source-to-sink paths that must be included in agreements
3. **Western-UGP Exemption Scope**: Clarification needed on when Federal Service Exemption applies vs. when Region-wide Charges are assessed
4. **Stakeholder Comment Period**: Specific timeline for written comments submission not specified
5. **Draft Project List Review**: Timeline and format requirements for stakeholder review process
6. **Competitive Upgrades Impact**: Process for identifying and addressing reliability violations on adjacent systems
7. **Market Participant Requirements**: Conditions under which Project Sponsors must execute Attachment AH
8. **Revenue Credit vs. ILTCR Election**: Criteria and implications for Transmission Customers choosing between compensation methods
9. **Creditable Upgrade Definition**: Specific criteria distinguishing Creditable vs. non-Creditable Service Upgrades
10. **Generator Retirement Process**: Referenced but not detailed in this section - may need cross-reference review

---

# Chunk 9 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary
This document contains sections from the SPP (Southwest Power Pool) Tariff addressing transmission expansion planning processes and integrated marketplace operations. The content primarily covers stakeholder engagement procedures, approval processes for transmission upgrades, plan modifications, and market participant requirements. Key governance structures include the Markets and Operations Policy Committee making recommendations and the SPP Board of Directors providing final approvals for various transmission expansion plan components.

## 2. Key Topics
- **Stakeholder Participation**: Equal access and notice requirements for planning summits, working group meetings, and sub-regional planning meetings
- **Information Transparency**: Website posting requirements for study results, data, and transmission expansion plans (including CEII-compliant versions)
- **Approval Processes**: Multiple types of upgrades requiring Board approval (ITP Upgrades, Balanced Portfolios, high priority upgrades, 20-Year Assessment upgrades, Sponsored Upgrades, Generator Retirement Upgrades, JTIQ Upgrades)
- **Plan Updates**: Quarterly modifications and out-of-cycle adjustments to maintain reliability
- **Market Participant Requirements**: Must-offer obligations, load and generation data submission, and meter agent functions
- **Day-Ahead Market Operations**: Reliability unit commitment and capacity adequacy analysis

## 3. Decisions or Actions
- Markets and Operations Policy Committee makes recommendations on all major upgrade categories
- SPP Board of Directors provides final approval/endorsement for transmission expansion plan elements
- Board required to explain deviations from Committee recommendations
- Quarterly status reporting to Markets and Operations Policy Committee, Regional State Committee, and SPP Board
- Quarterly posting of plan modifications on SPP website
- Transmission Provider may remove upgrades from approved plans (with stakeholder consultation)
- Reimbursement required for Transmission Owners who incurred costs on removed upgrades
- Market Monitor will monitor Market Participant compliance with must-offer requirements
- Non-compliant Market Participants assessed penalties per Section 3.9 of Attachment AF

## 4. Important Dates
- **At least 10 days prior notice** required before SPP Board of Directors meetings where action is expected
- **Quarterly basis**: Plan modifications posted, status reports provided
- **Annual**: SPP Transmission Expansion Plan presented to Board at least once yearly
- **Operating Day**: Timeline for load and generation data submission

## 5. Organizations and People Mentioned
### Organizations:
- SPP (Southwest Power Pool)
- SPP Board of Directors
- Markets and Operations Policy Committee
- Regional State Committee
- Stakeholder working groups
- Transmission Provider
- Transmission Owner(s)
- Market Participant(s)
- Meter Agent
- Market Monitor
- Asset Owner

### People:
- No specific individuals mentioned

## 6. Links or References
### Referenced Tariff Sections/Attachments:
- Section II of Attachment O (stakeholder process)
- Section IV.7 of Attachment O (Interregional Projects)
- Section V of Attachment O (stakeholder consultation)
- Section VII of Attachment O (Transmission Owner plans)
- Section VIII of Attachment J (reimbursement procedures)
- Attachment Z1 (transmission service upgrades)
- Attachment V (Generator Interconnection Service)
- Attachment AB (Generator Retirement Upgrades)
- Attachment AE (Integrated Marketplace)
- Attachment AF, Section 3.9 (penalties)
- Attachment AM (Meter Agent Agreement)
- Section 2.2(2) (market registration)
- Sections 4.1(10)(a), (b), (c) (commitment status)

### Other References:
- SPP website (multiple posting requirements)
- SPP Membership Agreement
- CEII (Critical Energy Infrastructure Information) requirements
- Market Protocols
- STEP (transmission expansion plan tracking)

## 7. Suggested Tags
- Transmission Planning
- SPP Tariff
- Stakeholder Engagement
- Approval Process
- Board Governance
- Transparency Requirements
- ITP Upgrades
- Balanced Portfolio
- Market Participation
- Must-Offer Requirement
- Day-Ahead Market
- Reliability Planning
- CEII Compliance
- Quarterly Reporting
- Generator Interconnection

## 8. Items That May Need Follow-Up

### Process Compliance:
- Verification that 10-day advance notice requirement is consistently met for Board meetings
- Confirmation that quarterly modifications and status reports are posted on schedule
- Review of stakeholder access and participation in planning meetings

### Transparency Issues:
- Ensure CEII-compliant redacted versions include proper instructions for obtaining complete versions
- Verify electronic comment link functionality on SPP website
- Confirm password-protected access procedures maintain confidentiality while allowing appropriate stakeholder access

### Approval Process:
- Track instances where Board deviates from Committee recommendations and ensure explanations are documented
- Monitor reimbursement claims for removed upgrades

### Market Participant Compliance:
- Monitor Market Participant compliance with must-offer requirements (90% threshold)
- Review penalty assessments for non-compliance
- Verify Meter Agent Agreement execution prior to function performance
- Confirm data submission timelines are being met

### Coordination:
- Impacts on adjacent transmission systems and cost responsibility determinations
- Interregional project coordination processes

### Documentation:
- Completeness of upgrade status tracking
- Availability of Transmission Owner-specific local plans via website links

---

# Chunk 10 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document is chunk 10 of RR696 Recommendation Report, containing detailed technical specifications for the Security Constrained Unit Commitment (SCUC) algorithm used in Day-Ahead and Intra-Day Reliability Unit Commitment (RUC) processes. The content outlines operational procedures for managing capacity shortages and surpluses, resource commitment/decommitment protocols, handling of Local Reliability Issues, and compensation recovery mechanisms. The document establishes priority hierarchies for curtailment actions and defines responsibilities between the Transmission Provider, local transmission operators, and the Market Monitor.

## 2. Key Topics

- **SCUC Algorithm Operations**: Resource commitment considering Maximum/Minimum Economic Capacity Operating Limits, Discharge/Charge Limits, and Regulation Capacity Operating Limits
- **Capacity Shortage Management**: Priority order for curtailing Export Interchange Transactions, incorporating emergency capacity limits, and de-committing charging resources
- **Capacity Surplus Management**: Procedures for curtailing Import Interchange Transactions and de-committing resources
- **Manual Resource Commitment**: Protocols for addressing transmission system security constraints not handled by SCUC algorithm
- **Local Reliability Issues**: Procedures for manual commitment/decommitment by Transmission Provider or local transmission operators
- **Operating Guides**: Development by Transmission Provider, local transmission operators, and Resource owners for recurring reliability issues
- **Multi-Configuration Resources (MCRs)**: Restrictions on Regulation Service eligibility during configuration transitions
- **Compensation Recovery**: Regional vs. local cost allocation mechanisms

## 3. Decisions or Actions

- SCUC algorithm shall curtail non-firm fixed Export Interchange Transaction Bids as first priority during capacity shortages
- Transmission Provider may manually commit/decommit Resources for security constraints not addressable by SCUC
- Manual commitments must be selected in non-discriminatory manner, verified by Market Monitor
- Local transmission operators may request Transmission Provider to issue instructions for Local Reliability Issues
- Transmission Provider, local transmission operators, and Resource owners will develop operating guides for known recurring reliability issues
- Market Monitor will verify non-discriminatory selection through process described in Section 6.1.2.1
- Time-critical Local Reliability Issues may be addressed directly by local transmission operators

## 4. Important Dates

- **Operating Day**: Referenced as the time horizon for Intra-Day RUC execution (specific dates not provided in this chunk)

*Note: No specific calendar dates are mentioned in this technical specification document.*

## 5. Organizations and People Mentioned

### Organizations:
- **Transmission Provider**: Primary entity managing RUC processes, manual commitments, and compensation
- **Market Monitor**: Verification entity for non-discriminatory resource selection
- **Local Transmission Operators**: Request manual commitments for Local Reliability Issues
- **Resource Owners**: Participate in developing operating guides

### People:
*No specific individuals are named in this document chunk.*

## 6. Links or References

### Internal Cross-References:
- Section 4.1(10)(c) of Attachment AE (reliability only use designation)
- Section 4.1(10)(b) of Attachment AE (market commitment status)
- Section 6.1.1 (SCUC inputs)
- Section 6.1.2.1 of Attachment AE (Market Monitor verification process)
- Section 8.6.5 of Attachment AE (compensation for committed Resources)
- Section 8.6.7(A) of Attachment AE (regional cost recovery)
- Section 8.6.44 of Attachment AE (local cost recovery)

### External References:
*None identified in this chunk.*

## 7. Suggested Tags

- SCUC Algorithm
- Reliability Unit Commitment
- Day-Ahead Market
- Intra-Day RUC
- Capacity Management
- Resource Commitment
- Local Reliability Issues
- Transmission System Security
- Market Monitor
- Operating Reserves
- Interchange Transactions
- Manual Commitment
- Emergency Capacity Limits
- Multi-Configuration Resources
- Regulation Services
- Compensation Recovery
- Non-Discriminatory Selection
- Operating Guides
- RR696

## 8. Items That May Need Follow-Up

1. **Incomplete Text**: The document appears to cut off mid-sentence at "...if the Local Reliability Issue is a Local Emer" - requires completion

2. **Market Monitor Verification Process**: Section 6.1.2.1 referenced multiple times but not included in this chunk - need to review detailed verification procedures

3. **Compensation Mechanisms**: Sections 8.6.5, 8.6.7(A), and 8.6.44 referenced for compensation details but not included - requires review of actual compensation formulas and recovery mechanisms

4. **Operating Guide Development**: No timeline or format specified for developing operating guides between Transmission Provider, local operators, and Resource owners

5. **MCR Configuration Transitions**: Definition of "transitioning between configurations" and duration of ineligibility for Regulation Services needs clarification

6. **Non-Discriminatory Selection Criteria**: Specific criteria for ensuring non-discriminatory manual commitment selection not detailed in this chunk

7. **Local Reliability Issue Definition**: Distinction between general reliability issues and Local Reliability Issues requires clarification

8. **Time Sensitivity Threshold**: "Time permitting" language in Section (4) lacks specific timeframes for when local operators can act independently

9. **Consistency Check**: Minor grammatical inconsistencies suggest need for editorial review (e.g., missing "will" in several places in Intra-Day section)

10. **Cost Minimization Methodology**: Specific methodology for ensuring commitment costs are minimized during manual commitments not detailed

---

# Chunk 11 Analysis

# Regulatory Document Analysis Report

## 1. Executive Summary
This document section (chunk 11 of 20) from RR696 Recommendation Report covers two primary regulatory areas: (1) procedures for local transmission operator emergency actions and associated compensation mechanisms, and (2) the complete Attachment AQ governing the Delivery Point Assessment Process. The content establishes protocols for manual resource commitments during Local Emergency Conditions, including coordination between transmission operators, compensation eligibility, and cost recovery procedures. Attachment AQ details the comprehensive process for requesting, studying, and implementing changes to delivery point facilities, including study requirements, timelines, and cost responsibilities.

## 2. Key Topics

### Emergency Operations & Compensation
- Local Emergency Condition protocols and resource commitment procedures
- Coordination requirements between local transmission operators and Transmission Provider
- Compensation eligibility for resources committed during emergencies
- Anti-discrimination provisions for affiliated resources
- Local cost recovery mechanisms under Section 8.6.44

### Delivery Point Assessment Process (Attachment AQ)
- Study request procedures for delivery point changes
- Load Connection Study (LCS) requirements and timelines
- Delivery Point Network Study (DPNS) procedures
- Exemptions for certain capacity and facility changes
- Cost allocation and deposit requirements
- Modification procedures during study process

## 3. Decisions or Actions

### Required Actions by Transmission Operators
- Local transmission operators must notify Transmission Provider when issuing initial emergency instructions
- Coordination required for subsequent instructions through Transmission Provider
- Logging requirements for all manual commitment/decommitment instructions

### Required Actions by Market Monitor
- Determine if resource selection was discriminatory when affiliated with local transmission operator
- Apply standards and procedures from Section 6.1.2.1
- Deny compensation eligibility for discriminatory selections

### Required Actions by Transmission Customers
- Submit written requests for delivery point changes to Transmission Provider and Host Transmission Owner
- Execute study agreements within 30 Calendar Days of receipt
- Provide advance deposits ($25,000 or estimated cost for LCS; $10,000 or estimated cost for DPNS)
- Reimburse actual study costs exceeding deposits

### Required Actions by Host Transmission Owner
- Respond within 10 Business Days to study requests
- Provide LCS Agreement and information requirements
- Complete LCS within 60 Calendar Days
- Coordinate studies when no significant transmission system impact identified

### Required Actions by Transmission Provider
- Complete preliminary assessment within 10 Business Days
- Post monthly summary of requests receiving preliminary assessment by 20th of each month
- Issue DPNS Agreement within 5 Business Days if significant impact found
- Complete DPNS within 60 Calendar Days

## 4. Important Dates

### Recurring Deadlines
- **10 Business Days**: Host Transmission Owner response time; Transmission Provider preliminary assessment
- **20th of each month**: SPP website posting of prior month's preliminary assessments
- **30 Calendar Days**: Transmission Customer deadline to return executed study agreements
- **60 Calendar Days**: Completion timeframe for both LCS and DPNS studies

### Extension Provisions
- Up to additional 10 Business Days for preliminary assessment if elements beyond Attachment AQ scope
- Later dates by mutual agreement for study agreement execution and completion

## 5. Organizations and People Mentioned

### Organizations
- **Transmission Provider** (SPP - Southwest Power Pool implied)
- **Local Transmission Operator**
- **Host Transmission Owner**
- **Market Monitor**
- **Transmission Customer**
- **Resource Owners**

### Roles (no specific individuals named)
- All references are to organizational roles and functional positions

## 6. Links or References

### Internal Cross-References
- **Section 8.6.5** of Attachment AE (compensation provisions)
- **Section 6.1.2.1** of Attachment AE (Market Monitor standards and procedures)
- **Section 8.6.44** of Attachment AE (local cost recovery)
- **Section 20** of Network Operating Agreement
- **Section 8** of Point to Point Transmission Service Agreement
- **Section 3.2** of Attachment AQ (DPNS requirements)

### External References
- **18 C.F.R. § 35.19a(a)(2)** - Federal interest calculation regulation

### Attachments
- **Addendum 1**: Sample Request for Change in Local Delivery Facilities

## 7. Suggested Tags
- Emergency Operations
- Transmission Planning
- Delivery Point Assessment
- Cost Recovery
- Study Procedures
- Market Monitor
- Load Connection Study
- Network Study
- Compensation Mechanisms
- Local Reliability
- Transmission Customer Rights
- Resource Commitment
- Regulatory Compliance
- FERC Regulations
- SPP Tariff

## 8. Items That May Need Follow-Up

### Policy Clarifications Needed
1. **Definition clarity**: Specific criteria for determining "significant impact on the Transmission System" in preliminary assessments
2. **Discriminatory selection standards**: Detailed explanation of Market Monitor's evaluation methodology under Section 6.1.2.1
3. **Operating guide development**: Status and timeline for development of operating guides referenced in subsection (e)

### Process Implementation Questions
4. **Exemption criteria**: Practical application of the three exemption categories for delivery point changes
5. **Coordination protocols**: Detailed procedures for coordination between Host Transmission Owner and Transmission Provider
6. **Extension requests**: Process for obtaining mutual agreement on deadline extensions

### Financial/Cost Recovery Issues
7. **Local cost recovery mechanism**: Details of Section 8.6.44 implementation procedures
8. **Interest-bearing account requirements**: Specifics on account establishment and management
9. **Actual cost determination**: Methodology for calculating actual study costs vs. estimates

### Incomplete Section
10. **Section 3.4 cutoff**: "Integrated Transmission Planning Assessment Evaluation" section appears incomplete at document chunk boundary - requires review of next section

### Compliance Monitoring
11. **Monthly posting compliance**: Verification that SPP consistently posts requests by 20th of each month
12. **Timeline adherence**: Tracking of 10-day and 60-day deadlines across multiple study requests
13. **Affiliate relationship disclosure**: Process for identifying resources affiliated with local transmission operators

---

# Chunk 12 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary
This document section (chunk 12 of 20) from RR696 Recommendation Report details processes for managing changes to electrical transmission delivery points. It covers two main regulatory processes: the Delivery Point Network Study (DPNS) posting requirements and the comprehensive Provisional Load Process (Attachment AX). The content provides detailed procedural requirements for transmission customers requesting modifications to delivery points, including study requirements, timelines, cost responsibilities, and technical specifications. These processes apply when transmission customers need to add, modify, or upgrade delivery points due to load changes.

## 2. Key Topics
- **DPNS Report Posting Requirements**: Conditions under which DPNS reports are posted on SPP website
- **Provisional Load Process (PLP)**: Comprehensive process for managing delivery point changes when transmission customers lack sufficient designated resources
- **Study Requirements**: 
  - Load Connection Study (LCS) by Host Transmission Owner
  - Provisional Load Process Study (PLPS) by Transmission Provider
- **Cost Allocation**: Transmission Customer responsibility for study costs and deposits
- **Technical Requirements**: Detailed specifications for delivery point modifications including voltage, metering, protective devices
- **Facilities Construction**: Engineering, design, and construction responsibilities
- **Delivery Point Transfers**: Process for transferring load between delivery points

## 3. Decisions or Actions
- **DPNS Report Posting**: Reports posted when unable to be evaluated in Integrated Transmission Planning Assessment after Transmission Customer notifies SPP to update Network Integration Transmission Service Agreement
- **Study Initiation**: Host Transmission Owner must respond within 10 business days of receiving request
- **Study Execution**: Transmission Customer must return executed LCS agreement within 30 calendar days with required deposit or request is deemed withdrawn
- **Deposit Requirements**: Host Transmission Owner may require advance deposit equal to estimated study cost or $25,000, whichever is less
- **Study Withdrawal**: Transmission Customer may withdraw study request at any time by written notice
- **Study Modifications**: Parties may agree to restudy if desirable changes are identified during study process

## 4. Important Dates
- **10 Business Days**: Host Transmission Owner response time to study request
- **30 Calendar Days**: Deadline for Transmission Customer to return executed LCS agreement with deposit
- **90 Calendar Days**: Standard timeframe for:
  - Host Transmission Owner to complete LCS and issue Load Connection Report
  - Transmission Provider to send PLPS study report after scoping call
- **One Year**: PLPS results validity period after issuance of study report

## 5. Organizations and People Mentioned
**Organizations:**
- SPP (Southwest Power Pool) - Transmission Provider
- Host Transmission Owner
- Transmission Customer

**Roles Referenced:**
- Representative of Transmission Customer
- Requestor Contact (various titles)

## 6. Links or References
**Regulatory References:**
- 18 C.F.R. § 35.19a(a)(2) - Interest calculation methodology
- SPP Business Practices - Standardized project timelines
- Section 20 of the Network Operating Agreement
- Section 8 of the Point-to-Point Transmission Service Agreement
- SPP OASIS - For PLPS agreement availability

**Cross-References within Document:**
- Attachment AQ (DPNS Process)
- Attachment AX (Provisional Load Process)
- Addendum 1 to Attachment AQ - Sample Request Form
- Addendum 2 and Addendum 3 of Attachment AX - Provisional Load Process Agreements
- Section 3.4 of Attachment AQ

## 7. Suggested Tags
- Transmission Planning
- Delivery Point Modifications
- Network Upgrades
- Load Connection Study
- Provisional Load Process
- DPNS (Delivery Point Network Study)
- SPP Tariff
- Transmission Service Agreements
- Study Agreements
- Cost Allocation
- Host Transmission Owner
- Technical Requirements
- Regulatory Compliance
- Electric Transmission

## 8. Items That May Need Follow-Up

**Process Clarifications Needed:**
1. Criteria for determining when a Network Upgrade is "unable to be further evaluated" in the Integrated Transmission Planning Assessment
2. Definition and threshold for "significant impact on the Transmission System" requiring PLPS vs. coordination by Host Transmission Owner
3. Conditions under which parties may "mutually agree" to extend study timelines beyond standard 90-day periods

**Technical Requirements:**
4. Complete specifications for Idev modeling file requirements (referenced in Addendum 1 but not fully detailed)
5. Standards for determining appropriate protective device types and locations
6. Guidelines for power flow, short circuit, and dynamics analyses mentioned

**Financial/Administrative:**
7. Mechanism for calculating "actual cost" of studies and potential dispute resolution
8. Interest-bearing account requirements and procedures for Host Transmission Owner deposit management
9. Refund process timeline when deposit exceeds study cost

**Incomplete Information:**
10. Section 2.5 numbering gap (Section 2.4 appears to be missing)
11. Section 4.0 on Delivery Point Transfers appears cut off at end of chunk - needs continuation from next chunk
12. Complete details of Addendums 2 and 3 referenced but not included in this section

**Coordination Requirements:**
13. Notification procedures between Transmission Customer, Host Transmission Owner, and Transmission Provider
14. Website posting procedures and access controls for DPNS and PLPS reports
15. Process for updating Network Integration Transmission Service Agreements to reflect delivery point changes

---

# Chunk 13 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document is chunk 13 of a Recommendation Report (RR696) containing regulatory content related to SPP (Southwest Power Pool) transmission and market operations. The content primarily covers three areas: (1) a standardized form template for requesting provisional load process modifications to delivery points, (2) protocols for non-conforming load forecasting and submission requirements, and (3) must-offer requirements for market participants in the Day-Ahead Market. The document appears to be from tariff attachments and market protocols governing transmission service and market participation.

## 2. Key Topics

- **Provisional Load Process (Attachment AX)**: Procedures for requesting modifications to transmission delivery points
- **Non-Conforming Load Requirements**: Forecasting and submission protocols for loads that don't follow predictable patterns, including Energy Storage Resources (ESRs) not registered as Market Settlement Resources (MSRs)
- **Must-Offer Obligations**: Requirements for Market Participants to offer available resources to Day-Ahead Market, Reliability Unit Commitment (RUC), and Real-Time Balancing Market (RTBM)
- **Asset Owner Load Calculations**: Methodologies for determining reported load and net resource capacity
- **Day-Ahead Market Execution**: SCUC (Security-Constrained Unit Commitment) and SCED (Security-Constrained Economic Dispatch) algorithms
- **Generation Facility Agreement (GFA) Carve Out**: Requirements for resources used as GFA carve out sources

## 3. Decisions or Actions

- Market Participants with Non-Conforming Load **must submit** hourly load forecasts before SPP begins Day-Ahead RUC process for Operating Day plus six days
- Market Participants **are allowed** to submit hourly load forecasts up to thirty minutes before Operating Hour
- Market Participants **must submit** a forecast on rolling 15-minute ahead basis
- Market Participants **are required** to submit actual Non-Conforming Load data or estimates
- Resources submitted with Commitment Status of Market, Self, or Reliability **may be used** to satisfy must-offer requirements
- Supporting documentation **must be provided** to Market Monitor upon request for firm power purchases/sales verification
- Market Participants will be **assessed a penalty** if deemed noncompliant with must-offer requirements (90% threshold)
- Resources used as GFA Carve Out source **must be offered** with sufficient capacity to cover the GFA Carve Out Schedule

## 4. Important Dates

- **Before Day-Ahead RUC process**: Initial Non-Conforming Load forecast submission deadline for Operating Day + 6 days
- **Up to 30 minutes before Operating Hour**: Final deadline for Non-Conforming Load forecast updates
- **15-minute intervals**: Rolling forecast submission requirement
- **2 hours following current interval**: Encouraged forecast submission timeframe for each 15-minute interval
- No specific calendar dates are mentioned in this chunk

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)**: Market operator and transmission provider
- **Host Transmission Owner**: Entity owning transmission facilities at delivery points
- **Transmission Customer**: Entity requesting delivery point modifications
- **Transmission Provider**: Entity providing transmission service
- **Market Participants**: Entities participating in SPP markets
- **Asset Owner**: Entity owning generation or load assets
- **Market Monitor**: Oversight entity monitoring market compliance

### People:
- No specific individuals are named in this content

## 6. Links or References

### Internal Document References:
- **Attachment AX**: Provisional Load Process in the Tariff
- **Section 6.2.2**: Non-Conforming Load description
- **Section 6.2.8**: Bilateral contract load registration
- **Section 4.1.3(4)**: Operating Reserve obligation calculations
- **Section 4.2.2.5.4**: JOU Individual Resource Option
- **Section 6.1.14**: Combined Interest Resource modeling
- **Section 4.2.1.1.1**: Must-offer penalty assessment
- **Addendum 1 to Attachment AX**: Sample Request for Provisional Load Process form

### File References:
- **Idev modeling files**: Required for planned generation and anticipated load
- **DYR modeling file**: Required for planned generation

### External References:
- Market Monitor website (for firm power purchase/sale information input)

## 7. Suggested Tags

- Transmission Service
- Delivery Point Modification
- Provisional Load Process
- Non-Conforming Load
- Energy Storage Resources
- Must-Offer Requirement
- Day-Ahead Market
- Market Participants
- RUC (Reliability Unit Commitment)
- RTBM (Real-Time Balancing Market)
- Asset Owner
- Load Forecasting
- SCUC (Security-Constrained Unit Commitment)
- SCED (Security-Constrained Economic Dispatch)
- GFA Carve Out
- Market Monitor
- Compliance
- Operating Reserves
- Firm Power Purchase/Sale
- SPP Tariff

## 8. Items That May Need Follow-Up

1. **Compliance Threshold Clarification**: The 90% net resource capacity threshold for must-offer compliance may need further definition or examples
2. **Penalty Assessment Details**: Section 4.2.1.1.1 is referenced for penalty details but not included in this chunk
3. **Market Monitor Website Access**: Process and credentials for Market Participants to input firm power purchase/sale information
4. **ESR Registration**: Criteria and process for ESRs to be registered as MSRs versus being modeled as Non-Conforming Load
5. **Modeling File Standards**: Technical specifications and submission procedures for Idev and DYR modeling files
6. **15-Minute Forecast Interpolation**: Specific methodology when 15-minute forecasts are unavailable
7. **Dispute Resolution**: Process when counterparties dispute firm power purchases/sales with Market Monitor
8. **Self-Charging MW Calculation**: Methodology for determining Self-Charging MW that reduces available generation
9. **Jointly Owned Unit Treatment**: Complete procedures for JOU registration options
10. **DA Market SCUC Algorithm**: Full description of algorithm appears truncated at end of chunk
11. **Supporting Documentation Requirements**: Specific documents needed to verify firm power purchases/sales
12. **Maximum Economic Capacity vs. Maximum Regulation Capacity**: Decision criteria for which limit applies

---

# Chunk 14 Analysis

# Regulatory Content Analysis Report
## RR696 Recommendation Report - Chunk 14 of 20

---

## 1. Executive Summary

This section of the RR696 Recommendation Report details the technical procedures for SPP's Day-Ahead Market operations, specifically focusing on Security Constrained Unit Commitment (SCUC) and Security Constrained Economic Dispatch (SCED) algorithms. The content outlines capacity management protocols, emergency procedures, treatment of various resource types (particularly Multi-Configuration Resources - MCRs), and processes for addressing local reliability issues and transmission constraints. Key themes include hierarchical curtailment procedures, emergency limit utilization, manual commitment authority, and compensation mechanisms for resources committed for reliability purposes.

---

## 2. Key Topics

- **Day-Ahead Market SCUC/SCED Algorithm Operations**
  - Capacity adequacy analysis procedures
  - Commitment optimization logic
  - Co-optimization of energy and operating reserves

- **Resource Capacity Limits Management**
  - Economic vs. Emergency capacity operating limits
  - Maximum/Minimum discharge and charge limits
  - Regulation capacity operating limits

- **Multi-Configuration Resources (MCRs)**
  - Transition time restrictions (>30 minutes)
  - Ineligibility for regulation/contingency reserve during configuration transitions
  - Reference to Section 6.1.7.1 registration option

- **Capacity Shortage/Surplus Procedures**
  - Priority-ordered curtailment processes
  - Emergency capacity incorporation protocols
  - System-wide vs. local reliability considerations

- **Manual Commitment Authority**
  - SPP's Reliability Coordinator authority
  - Non-discriminatory selection requirements
  - Market Monitor verification processes

- **Local Reliability Issues and Emergency Conditions**
  - Out-of-merit commitment/decommitment procedures
  - Local transmission operator coordination
  - Operating guide development requirements

- **Compensation and Cost Recovery**
  - Regional vs. local cost allocation
  - References to Sections 4.5.9.12, 4.5.9.13, 4.5.8.12, and 4.5.9.10(1)

- **Day-Ahead RUC (Reliability Unit Commitment) Execution**
  - Capacity adequacy analysis using SCUC
  - SPP Mid-Term Load Forecast integration
  - Advisory information for SPP Operators

- **Violation Relaxation Limits (VRLs)**
  - Application in SCED for infeasible solutions
  - Reference to Section 4.1.3.3

---

## 3. Decisions or Actions

**Operational Procedures Established:**

1. **Capacity Shortage Response** (Priority Order):
   - Curtail non-firm fixed Export Interchange Transaction Bids
   - Incorporate emergency capacity limits
   - Commit Reliability-status Resources
   - De-commit Self-Charging MSRs (economically)

2. **Capacity Surplus Response** (Priority Order):
   - Curtail non-firm fixed Import Interchange Transaction Offers
   - Incorporate emergency minimum limits
   - Commit MSRs available for charging (Reliability status)

3. **RUC Capacity Shortage Response** (Priority Order):
   - Curtail non-firm Export Interchange Transactions
   - Incorporate emergency capacity limits
   - Commit Reliability-status Resources
   - De-commit DA Market charging Resources (Market status)
   - De-commit self-committed charging Resources

4. **Manual Commitment Requirements:**
   - Must be non-discriminatory
   - Must minimize commitment costs
   - Requires Market Monitor verification (Section 6.1.2.1, Attachment AE)
   - SPP will re-run DA SCUC after manual commitments (time permitting)

5. **Operating Guide Development:**
   - SPP, local transmission operators, and Resource owners to develop guides for manual commitments
   - Focus on known and recurring Local Reliability Issues

---

## 4. Important Dates

- **No specific dates mentioned** in this content chunk
- References to "upcoming Operating Day" (operational timeframe, not specific date)

---

## 5. Organizations and People Mentioned

**Organizations:**

- **SPP (Southwest Power Pool)**
  - Acting as Reliability Coordinator
  - Performing DA Market operations
  - Issuing manual commitment instructions

- **Market Monitor**
  - Verification role for manual commitments
  - Process oversight per Section 6.1.2.1 of Attachment AE

- **Local Transmission Operators**
  - Request SPP to issue instructions for Local Reliability Issues
  - Participate in operating guide development

- **Market Participants**
  - Receiving notifications of manual commitments
  - Subject to clearing decisions

- **Resource Owners**
  - Participate in operating guide development

**People:**
- No specific individuals mentioned

---

## 6. Links or References

**Internal Document References:**

- Section 6.1.7.1 (MCR registration option - referenced multiple times)
- Section 6.1.2.1 of Attachment AE (Market Monitor verification process)
- Section 4.5.9.12 (Resource compensation)
- Section 4.5.9.13 (Regional cost recovery)
- Section 4.5.8.12 (Alternative compensation reference)
- Section 4.5.9.10(1) (Local cost recovery)
- Section 3.1.1 (Resource operating constraints and transmission constraints)
- Section 4.1.3.3 (VRL application in SCED)
- Attachment AE to the Tariff

**Referenced Concepts/Documents:**
- SPP Tariff
- Operating Reserve requirements
- Transmission System security constraints
- SPP Mid-Term Load Forecast

---

## 7. Suggested Tags

- Day-Ahead Market
- SCUC (Security Constrained Unit Commitment)
- SCED (Security Constrained Economic Dispatch)
- RUC (Reliability Unit Commitment)
- Multi-Configuration Resources (MCR)
- Manual Commitment
- Local Reliability Issues
- Emergency Capacity Limits
- Regulation Services
- Contingency Reserve
- Market Monitor
- Reliability Coordinator
- Cost Recovery
- Violation Relaxation Limits
- Interchange Transactions
- Resource Commitment
- Operating Reserves
- Transmission Constraints
- SPP Operations
- Market Clearing Prices

---

## 8. Items That May Need Follow-Up

**Cross-Reference Verification Needed:**

1. **Section 6.1.7.1** - MCR registration option details
   - What are the specific registration requirements?
   - What are the full implications of this option?

2. **Section 6.1.2.1 of Attachment AE** - Market Monitor verification process
   - What are the detailed verification procedures?
   - What constitutes "non-discriminatory manner"?

3. **Compensation Sections (4.5.9.12, 4.5.9.13, 4.5.8.12, 4.5.9.10(1))**
   - Complete compensation methodology details
   - Regional vs. local cost allocation formulas

4. **Section 4.1.3.3** - VRL application details
   - Full VRL pricing methodology
   - Shadow Price calculation methodology

**Policy/Operational Clarifications:**

5. **MCR Transition Time Threshold**
   - Why is 30 minutes the threshold for contingency reserve eligibility?
   - Are there provisions for exceptions?

6. **Operating Guide Development**
   - Timeline for development of operating guides?
   - Approval process for these guides?
   - Update frequency?

7. **Manual Commitment Re-run Procedures**
   - What determines if "time permits" for SCUC re-run?
   - What happens if time doesn't permit?

8. **Lost Opportunity Cost Calculations**
   - Detailed methodology for calculating lost opportunity costs in co-optimization
   - How are Market Participants kept "indifferent"?

**Stakeholder Coordination:**

9. **Local Transmission Operator Coordination**
   - Formalized communication protocols?
   - Decision-making authority boundaries between SPP and local operators?

10. **Resource Owner Involvement**
    - Process for Resource owners to participate in operating guide development?
    - Frequency of updates to Resource operating parameters?

**Incomplete Content:**

11. **Document Truncation** - The text ends mid-sentence ("Additionally, such manual commitments will be s...")
    - Need to review complete sentence/paragraph in next chunk

---

# Chunk 15 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary
This document section (chunk 15 of 20) from RR696 Recommendation Report contains detailed operational procedures for SPP's (Southwest Power Pool) Reliability Unit Commitment (RUC) processes, including Day-Ahead and Intra-Day RUC execution. It outlines protocols for handling local reliability issues, resource commitment decisions, compensation mechanisms, and technical requirements for market participants. The content also includes provisions for emergency operating plans, non-conforming load registration, and Inter-Control Center Communications Protocol (ICCP) connectivity requirements.

## 2. Key Topics
- **Intra-Day RUC Execution**: Security Constrained Unit Commitment (SCUC) algorithm for capacity adequacy analysis
- **Local Reliability Issues**: Procedures for out-of-merit commitments, decommitments, and dispatch instructions
- **Resource Commitment Hierarchy**: Priority order for addressing capacity shortages and surpluses
- **Compensation and Cost Recovery**: Regional vs. local collection methods (Section 4.5.9.8 and 4.5.9.10)
- **Manual Commitments**: Operating guides and non-discriminatory selection processes
- **Market Monitor Oversight**: Verification procedures per Section 6.1.2.1 of Attachment AE
- **Non-Conforming Load Registration**: Requirements for loads of 50 MW or greater
- **Emergency Operating Plans (EOPs)**: Load shedding rotation and critical natural gas load protection
- **ICCP Node Connectivity**: Requirements for TOPs and GOPs within SPP RC Area

## 3. Decisions or Actions
- SPP will commit resources using SCUC algorithm to minimize commitment costs while maintaining transmission system security
- Local transmission operators may request SPP to issue commitment/decommitment instructions for Local Reliability Issues
- In emergency situations (Local Emergency Conditions), local transmission operators may issue direct instructions if time does not permit coordination
- Market Monitor will verify non-discriminatory resource selection through established processes
- SPP, local transmission operators, and resource owners must develop operating guides for manual commitments
- Market Participants must identify Non-Conforming Load assets of 50 MW or greater
- TOPs must configure ICCP nodes to connect to both SPP primary and backup sites concurrently
- TOPs and GOPs must configure alternate ICCP nodes with 240-second reconnection capability

## 4. Important Dates
No specific dates are mentioned in this content section. References are made to:
- Operating Day (ongoing operational timeframe)
- Day-Ahead RUC process
- Intra-Day RUC process

## 5. Organizations and People Mentioned
### Organizations:
- **SPP (Southwest Power Pool)** - Primary market operator and reliability coordinator
- **Local transmission operators** - Entities managing local transmission systems
- **Market Monitor** - Oversight entity for non-discriminatory practices
- **NERC** - North American Electric Reliability Corporation (standard-setting body)
- **Resource owners/Market Participants** - Generation and load resource entities
- **TOPs (Transmission Operators)** - NERC-registered transmission operators
- **GOPs (Generator Operators)** - NERC-registered generator operators
- **BA (Balancing Authority)** - Balancing authority entities

### People:
- SPP RUC Operators
- SPP Operators
- No specific individuals named

## 6. Links or References
### Internal Document References:
- Section 4.5.9.8 (compensation provisions)
- Section 4.5.9.10 (cost recovery collection methods)
- Section 6.1.2.1 of Attachment AE to the Tariff (Market Monitor verification process)
- Section 6.1.7.1 (MCR registration options)
- Section 4.4.1.2 (Intra-Day RUC Execution)
- Section 6.2.2 (Non-Conforming Load)
- Section 3.6 (SPP Reliability Coordinator EOP Reviews)
- Section 5.2 (Node Connectivity Requirement)

### External References:
- NERC standard requirements
- SPP Operating Criteria

## 7. Suggested Tags
- Reliability Unit Commitment (RUC)
- SCUC Algorithm
- Local Reliability Issues
- Resource Commitment
- Market Operations
- Compensation Mechanisms
- Emergency Operating Plans
- ICCP Connectivity
- Non-Conforming Load
- Market Monitor
- Transmission Security
- Operating Reserves
- Load Shedding
- SPP Tariff
- Day-Ahead Market
- Real-Time Balancing Market (RTBM)

## 8. Items That May Need Follow-Up

### Critical Follow-Up Items:
1. **Operating Guide Development**: Status of operating guides being developed by SPP, local transmission operators, and resource owners for manual commitments addressing known and recurring Local Reliability Issues

2. **Market Monitor Verification Process**: Confirmation that Section 6.1.2.1 procedures for non-discriminatory resource selection are operational and effective

3. **ICCP Connectivity Compliance**: Verification that all TOPs and GOPs have implemented:
   - Concurrent connections to primary and backup SPP sites
   - Alternate ICCP node configurations with 240-second reconnection capability
   - Block 1 and Block 2 data availability to both nodes

4. **Non-Conforming Load Registration**: Completion status of registration for all Non-Conforming Loads ≥50 MW with proper PNode/APNode identification

5. **Emergency Operating Plan Reviews**: Confirmation that TOP/BA EOPs include:
   - Rotating load shedding provisions
   - Critical natural gas load prioritization

6. **Affiliated Resource Compensation**: Clarification on discrimination determinations by Market Monitor for affiliated resources during Local Emergency Conditions

7. **Cost Recovery Implementation**: Verification that regional vs. local cost collection mechanisms under Section 4.5.9.10 are properly implemented

8. **MCR Configuration Transitions**: Confirmation that Multi-Configuration Resources (MCRs) registered under Section 6.1.7.1 are properly excluded from regulation selection during configuration transitions

### Administrative Follow-Up:
- Incomplete sentence at document end: "If the TOP or GOP has a third-party contract for t..." - requires completion or clarification in full document review

---

# Chunk 16 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary
This document section covers SPP (Southwest Power Pool) technical and operational requirements across three main areas: ICCP (Inter-Control Center Communications Protocol) connectivity standards for generation operators, SPP Planning Criteria for transmission system reliability, and Business Practices for non-jurisdictional facilities and delivery point modifications. The content establishes technical thresholds, definitions, and procedural requirements for maintaining grid reliability and coordinating interconnections across the SPP system.

## 2. Key Topics

- **ICCP Node Requirements**: GOPs with >1500 MW or 15+ capacity resources must configure dual ICCP nodes for redundancy with 240-second reconnection requirements
- **SPP Planning Criteria (Section 5)**: Transmission system performance standards, single element contingency requirements, and seasonal model planning
- **Transmission Material Modification**: Permanent changes requiring evaluation including rating reductions >20%, impedance changes >±30%, voltage changes, and configuration changes
- **Qualified Change Definitions**: Three categories - Transmission, Generation, and Electricity End-User
- **Business Practice 7250**: Non-jurisdictional generator interconnection study requirements
- **Business Practice 7850**: Delivery Point Additions, Modifications, and Retirements evaluation process
- **Attachment AQ and AX Processes**: Planning processes for delivery point assessments

## 3. Decisions or Actions

- GOPs must contact SPP and follow RDS Outage Scheduling Information for forced/unplanned ICCP outages
- SPP shall analyze Transmission Material Modifications or Qualified Changes per OATT processes and NERC standards
- Transmission Owners must conduct studies when notified of potential system impacts
- Transmission Owners must notify SPP of generator interconnection impacts and provide system impact studies
- All Network Upgrades must be completed prior to Generating Facility operation (unless alternative mitigations approved by SPP)
- Interconnection customers may be required to enter study agreements with SPP

## 4. Important Dates

- **240 seconds**: Maximum reconnection time for ICCP nodes
- **12 months**: Threshold duration for permanent changes (Qualified Change and Transmission Material Modification definitions)

## 5. Organizations and People Mentioned

**Organizations:**
- SPP (Southwest Power Pool) - Regional Transmission Organization
- NERC (North American Electric Reliability Corporation)
- Associated Electric Cooperatives, Inc.
- California Independent System Operator Corporation
- Electric Reliability Council of Texas (ERCOT)
- Midcontinent Independent System Operator, Inc (MISO)
- Peak
- Public Service Company of Colorado
- Saskatchewan Power Corporation
- Southwestern Power Administration
- Tennessee Valley Authority

**Roles Referenced:**
- GOPs (Generator Operators)
- TOPs (Transmission Operators)
- Transmission Owners
- Transmission Customers
- Planning Coordinator
- Transmission Provider
- Interconnection Customers
- Distribution Providers

## 6. Links or References

**SPP Documents:**
- SPP Open Access Transmission Tariff (OATT)
- Attachment O (Transmission Planning Process)
- Attachment V (Generator Interconnection Procedures)
- Attachment AB (Retirement)
- Attachment AQ (Delivery Points)
- Attachment AX (Delivery Point Additions)
- SPP Criteria Section 5
- Business Practice 7250
- Business Practice 7850
- RDS (Telemetering and Control System Status)
- ITP Manual
- SPP Model Development Procedure Manual
- SPP Disturbance Performance Requirements
- SPP Quarterly Project Tracking Report
- Request Management System

**NERC Standards:**
- FAC-002-041
- NERC Glossary of Terms
- NERC Reliability Standards (general)
- Seams Agreements

**Voltage Levels Referenced:**
- 500 kV, 345 kV, 230 kV, 161 kV, 138 kV, 115 kV, 69 kV

## 7. Suggested Tags

- ICCP_Connectivity
- Planning_Criteria
- Generator_Interconnection
- Transmission_Planning
- Material_Modification
- Delivery_Points
- Network_Upgrades
- System_Studies
- SPP_OATT
- NERC_Compliance
- Reliability_Standards
- Business_Practices
- Non-Jurisdictional_Facilities
- Attachment_AQ
- Attachment_V
- BES_Facilities
- Contingency_Planning

## 8. Items That May Need Follow-Up

1. **ICCP Configuration Verification**: Confirm all GOPs with >1500 MW or 15+ capacity resources have dual ICCP node configuration implemented
2. **Outage Procedure Compliance**: Verify GOPs/TOPs are following RDS Outage Scheduling Information for both planned and unplanned outages
3. **Material Modification Tracking**: Establish tracking system for changes meeting the 20% rating reduction or ±30% impedance change thresholds
4. **Study Agreement Status**: Monitor completion of study agreements between non-jurisdictional generator interconnection customers and SPP
5. **Network Upgrade Completion**: Track Network Upgrades required before Generating Facility operation
6. **Reference Document Updates**: Verify all referenced attachments (O, V, AB, AQ, AX) are current versions
7. **NERC FAC-002-041 Compliance**: Confirm adherence to qualified change requirements under this standard
8. **Delivery Point Process Clarification**: Ensure clarity between Attachment AQ and AX process interactions as mentioned in Business Practice 7850
9. **HILLGA Model Modifications**: Follow up on modifications from Base Model to Change Models for NRIS to DA analysis
10. **Seams Agreement Coordination**: Verify coordination with all listed external entities (ERCOT, MISO, CAISO, etc.)

---

# Chunk 17 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document section outlines procedures for managing Delivery Point changes within the SPP (Southwest Power Pool) transmission system. It details two primary evaluation processes (Attachment AQ and Attachment AX) for handling Delivery Point Additions, Modifications, and Retirements. The content also addresses aggregation of requests, treatment of non-dispatchable demand response programs, and integration with the Integrated Transmission Planning (ITP) process. The framework establishes when each process applies based on whether a Transmission Customer has sufficient Designated Resources to serve increased load plus losses.

## 2. Key Topics

- **Delivery Point Change Management**: Additions, Modifications, and Retirements through Attachment AQ and AX processes
- **Process Differentiation**: Selection criteria between Attachment AQ (sufficient resources) vs. Attachment AX (insufficient resources)
- **Request Aggregation**: Combining multiple proximate Delivery Point requests for comprehensive analysis
- **Network Upgrade Evaluation**: Integration with Integrated Transmission Planning Assessment and BP 7060 project timelines
- **Non-Dispatchable Demand Response**: Treatment of non-controllable demand response programs and behind-the-meter generation
- **Load Forecasting Requirements**: 50-50 forecast methodology for peak demand
- **Customer Responsibilities**: Notification requirements for Service Agreement updates

## 3. Decisions or Actions

- Transmission Customers must submit all Delivery Point change requests through Attachment AQ, AX, or other specified attachment processes
- Transmission Customers are responsible for notifying SPP to update NITS Agreements and Provisional Load Process Agreements
- Transmission Provider must approve aggregation of multiple requests and evaluate feedback from all Parties before proceeding
- Network Upgrades may be subject to Integrated Transmission Planning Assessment based on SPP-determined need dates
- Load-serving entities (LREs) must report projected MW level of Peak Demand reduction as an informational line item in the Workbook
- SPP may propose additional persistent operational needs to ESWG and TWG for review and endorsement

## 4. Important Dates

- **No specific dates mentioned** in this content section
- Reference to "study timeframe requirements pursuant to standardized project timelines" per BP 7060 (specific dates not provided)

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)** - Transmission Provider
- **Host Transmission Owner**
- **ESWG (Economic Studies Working Group)**
- **TWG (Transmission Working Group)**
- **LRE (Load-Serving Entity)**
- **Network Customers**
- **Transmission Customers**

### People:
- No specific individuals mentioned

## 6. Links or References

### Internal References:
- **Attachment AQ** - Process for Delivery Point changes with sufficient Designated Resources
- **Attachment AX** - Provisional Load Process for Delivery Point Additions without sufficient resources
- **BP 7060** - Business practice document containing standardized project timelines
- **Delivery Point Network Study (DPNS)**
- **Provisional Load Process Study (PLPS)**
- **Model Development Procedure Manual**
- **ITP (Integrated Transmission Planning) Manual, Section 2.1.3** - Load Forecasts
- **ITP Manual, Section 4.4** - Persistent Operational Needs Assessment
- **NITS Agreement** - Network Integration Transmission Service Agreement
- **Provisional Load Process Agreement**
- **Workbook** (for reporting Peak Demand reduction)

### External References:
- None explicitly mentioned

## 7. Suggested Tags

- Delivery Point Management
- Attachment AQ Process
- Attachment AX Process
- Transmission Planning
- Network Upgrades
- Load Forecasting
- Demand Response
- Behind-the-Meter Generation
- NITS Agreement
- Provisional Load Process
- Request Aggregation
- SPP Transmission System
- Local Delivery Facilities
- Peak Demand Reduction
- Non-Dispatchable Resources
- ITP Assessment
- Service Agreement Updates

## 8. Items That May Need Follow-Up

1. **Process Clarification**: Clarify the complete list of "other Attachment processes" referenced beyond AQ and AX
2. **Timeline Documentation**: Obtain specific details from BP 7060 regarding standardized project timelines and Network Upgrade need dates
3. **Aggregation Criteria**: Define specific parameters for "relative proximity" when determining eligibility for request aggregation
4. **Historical Data Requirements**: Determine the minimum amount of "historical hourly demand data sufficient to establish reduction in load" for demand response programs
5. **Survey Standards**: Establish standards for "adequate system survey" methodology for determining potential demand
6. **Transfer Procedures**: Document detailed procedures for Delivery Point transfers between customers (excluded from both AQ and AX processes)
7. **Interface Requirements**: Clarify procedures for Delivery Points not physically interconnected with SPP Transmission System
8. **Non-Controllable Resources**: Define criteria for determining whether demand response or behind-the-meter resources qualify as "non-controllable and non-dispatchable"
9. **ESWG/TWG Review Process**: Establish timelines and procedures for ESWG and TWG review of additional operational needs proposed by SPP
10. **50-50 Forecast Methodology**: Document specific methodology for establishing and validating 50-50 peak demand forecasts
11. **Workbook Format**: Obtain template and instructions for LRE reporting of Peak Demand reduction informational line items

---

# Chunk 18 Analysis

# Regulatory Meeting Content Analysis Report

## 1. Executive Summary

This document contains voting records and stakeholder discussions for RR696 (SIR764) - "Integrate & Operate High Impact Large Loads (HILL)," which establishes a framework for integrating large load customers into the SPP system. The proposal introduces two load categories: HILL (High Impact Large Loads) and CHILL (Controllable High Impact Large Loads). After initial rejection at MOPC in July 2025 (53.73% opposed), the recommendation underwent stakeholder workshops and refinement, ultimately passing at a Special MOPC meeting in August 2025 (96% approval) and receiving final Board of Directors approval in September 2025. The proposal faced significant concerns regarding transmission congestion, reliability impacts, resource adequacy requirements, and market cost shifting.

## 2. Key Topics

- **Large Load Integration Framework**: Two-tiered approach for HILL and CHILL loads
- **Expedited Interconnection Process**: Faster timelines for large load interconnection (three pathways: Common Bus, Local Area, and Delivery Area)
- **CHILL Load Management**: Curtailment protocols, operational procedures, and load forecasting integration
- **Transmission System Concerns**: Congestion impacts, system capacity constraints, and upgrade requirements
- **Resource Adequacy**: Integration with LOLE studies, PRM/PBA/ELCC calculations, and generation reserve requirements
- **Market Impacts**: Congestion costs, TCR market effects, day-ahead must-offer requirements (LDAMO)
- **Reliability Safeguards**: Curtailment priorities, primary frequency response, stability concerns
- **Queue Management**: Concerns about queue jumping, particularly through Path 3 (Delivery Area pathway)
- **Generation Pairing**: Requirements for synchronous/firm generation versus inverter-based resources (IBRs)

## 3. Decisions or Actions

**Approved Motions:**
- **MWG (10/27/2025)**: Approved RR696 Impact Analysis with High severity level (100% with 1 abstention - OPPD)
- **SAWG (7/23/2025)**: Supported further CHILL policy development with conditional recommendations (100% consensus)
- **Special MOPC (8/21/2025)**: Approved RR696 with modification to Tariff Attachment AQ 3.2 (96% approval, 15 abstentions, 2 opposed)
- **Board of Directors (9/4/2025)**: Final approval granted (Members Committee: 1 opposed, 3 abstentions; Board: approved by secret ballot)

**Rejected Motions:**
- **MOPC (7/16/2025)**: Initial rejection of RR696 (53.73% opposed, 43 entities against, 12 abstentions)

**Other Actions:**
- **MOPC (7/16/2025)**: Approved special MOPC workshop by end of September 2025 (69.85% approval)
- **MWG (7/21/2025)**: Non-binding straw poll (99% participation)
- **ORWG (7/24/2025)**: Non-binding straw poll (71% participation)
- **TWG/ESWG/MDAG (7/31/2025)**: No formal vote; general support expressed

**Tariff Modification:**
- Attachment AQ 3.2 modified to maintain 90-day timeline for HILL (instead of reducing to 60 days for all loads)

## 4. Important Dates

- **July 16, 2025**: Initial MOPC rejection and approval of special workshop
- **July 21, 2025**: MWG straw poll
- **July 23, 2025**: SAWG conditional support motion
- **July 24, 2025**: ORWG straw poll
- **July 31, 2025**: TWG/ESWG/MDAG discussion
- **August 14, 2025**: Revised SPP Comments dated
- **August 21, 2025**: Special MOPC meeting with approval
- **September 2025**: Target deadline for workshop (as of July motion)
- **September 4, 2025**: Board of Directors final approval
- **October 27, 2025**: MWG Impact Analysis approval

## 5. Organizations and People Mentioned

**Key Individuals:**
- Jim Flucke (Evergy) - MWG motion
- Brandon McCracken (WFEC) - MWG second
- Rick Yanovich (OPPD) - MWG abstention
- Richard Ross (AEP) - MOPC motions
- Olivia Hough (CUS) - MOPC second
- Steve Gaw (Advanced Power Alliance) - Workshop motion
- Matt Caves (Western Farmers Electric Cooperative) - Workshop second
- Jeff Wells (NextEra Energy Resources) - Special MOPC second
- Stuart Solomon - BOD motion
- Lanny Nickell - BOD second
- Myers, Clayton - ORWG stakeholders

**Organizations (Partial List):**

*Utilities/Cooperatives:*
- Western Farmers Electric Cooperative (WFEC)
- Evergy (Kansas Central, Kansas South, Metro, Missouri West)
- AEP (Public Service Co. of Oklahoma, Southwestern Electric Power Co.)
- Oklahoma Gas & Electric
- Omaha Public Power District (OPPD)
- Nebraska Public Power District
- Basin Electric Power Cooperative
- Golden Spread Electric Cooperative
- Xcel Energy/Southwestern Public Service

*IPPs/Renewable Developers:*
- NextEra Energy Resources
- Advanced Power Alliance
- American Clean Power Association
- EDP Renewables North America
- Enel Green Power North America
- Clearway Power Marketing
- Pine Gate Renewables
- Southern Power
- Leeward Renewables

*Transmission Companies:*
- GridLiance High Plains
- NextEra Energy Transmission
- Grain Belt Express Clean Line
- Transource Energy

*Other:*
- Google Energy
- Natural Resources Defense Council
- Advanced Energy United
- Continental Resources
- ConocoPhillips Company
- Oxy USA Inc.

## 6. Links or References

- **RR696**: Main recommendation report
- **SIR764**: System Impact Request associated with RR696
- **Tariff Attachment AQ 3.2**: Modified section regarding timeline (60 vs. 90 days)
- **Related Policies/Processes**:
  - GAP (Generation Availability Process)
  - LTCR netting (Long-Term Congestion Rights)
  - PRM/PBA/ELCC (Planning Reserve Margin/Performance-Based Accreditation/Effective Load Carrying Capability)
  - Outage policy
  - DAMKT/RTGEN (Day-Ahead Market/Real-Time Generation)
  - RUC charges (Reliability Unit Commitment)
  - LDAMO (Long-term Day-Ahead Must Offer)
  - LOLE study (Loss of Load Expectation)
  - EUE (Expected Unserved Energy)
  - CONE multiplier (Cost of New Entry)
  - TOP (Transmission Operations)
  - RAS (Remedial Action Scheme)
  - TCR market (Transmission Congestion Rights)
  - PTP (Point-to-Point transmission service)

**SPP Comments Documents:**
- SPP Comments 20250711
- SPP Comments dated August 14, 2025

## 7. Suggested Tags

- Large Load Integration
- HILL/CHILL
- Transmission Planning
- Resource Adequacy
- Market Design
- Data Centers
- Curtailable Load
- Interconnection Process
- RR696
- Congestion Management
- Reliability Standards
- Stakeholder Governance
- MOPC
- Board Approval
- Generation Capacity
- Load Forecasting
- Queue Reform
- Primary Frequency Response
- Transmission Congestion Rights

## 8. Items That May Need Follow-Up

**Policy Clarifications Required (per SAWG conditions):**
1. How CHILL load is incorporated into LRE load forecasts and LRE obligations to curtail for peak demand/RA management
2. Integration of CHILL loads into LOLE study and impacts on EUE, ELCC, and PRM obligations
3. Mechanism to reserve generator availability for RA events considering

---

# Chunk 19 Analysis

# Regulatory Meeting Content Analysis Report
## RR696 Recommendation Report - Chunk 19 of 20

---

## 1. Executive Summary

This section documents the extensive stakeholder voting process for RR696, which proposes a framework for integrating and operating High Impact Large Loads (HILL/CHILL). The proposal faced significant initial opposition through multiple working groups in July 2025, primarily due to concerns about inadequate stakeholder review time, reliability risks, market impacts, and transmission system constraints. Despite initial failure at MOPC on July 16, 2025, the recommendation ultimately passed at the Board of Directors/Members Committee on September 4, 2025, with minimal opposition (1 opposed, 3 abstained). The interim period included a special MOPC workshop and impact analysis approval in October 2025.

---

## 2. Key Topics

### Large Load Integration Framework (HILL/CHILL)
- **HILL (High Impact Large Loads)** and **CHILL (Curtailable High Impact Large Loads)** policy development
- Three integration pathways: Common Bus, Local Area, and Delivery Area (Path 3)
- Expedited interconnection process for large loads

### Stakeholder Process Concerns
- Insufficient review time (materials posted only 1.5 business days before meetings)
- Reduced stakeholder participation compared to traditional processes
- Calls for utilizing existing stakeholder groups (TWG, Tariff working groups)

### Reliability and Operations Issues
- Transmission system congestion and capacity constraints
- Stability impacts of instantaneous large load drops
- Curtailment priorities (CHILL loads vs. demand response)
- Primary frequency response requirements
- Conservative Operations and Emergency Alert frequency concerns

### Market and Resource Adequacy Impacts
- Integration with Generator Aggregate Program (GAP)
- Non-conforming load requirements and forecast error penalties
- Day-Ahead Must Offer (LDAMO) requirements
- Resource Adequacy obligations for Load Responsible Entities (LREs)
- LOLE study incorporation and impacts on ELCC, PRM, EUE
- Cost shifting concerns and congestion redispatch costs

### Queue Integrity
- Concerns about "queue jumping," particularly via Path 3 (Delivery Area pathway)
- General support for Path 1 (Common Bus) and Path 2 (Local Area)

---

## 3. Decisions or Actions

### Formal Votes

**July 16, 2025 - MOPC:**
- **FAILED**: Motion to approve RR696 (43 opposed, 12 abstained)
- **PASSED**: Motion to hold special MOPC workshop by end of September 2025 (15 opposed, 1 abstained)

**July 21, 2025 - Market Working Group:**
- **Straw Poll** on large load integration framework (non-binding)
- Result: Significant opposition (8 entities opposed: OGE, GSEC, OPPD, WAPA, Tenaska, KPP, WFEC; 1 abstained: AEP)

**July 24, 2025 - ORWG (Operations):**
- **Straw Poll** on framework (non-binding)
- Result: 4 opposed (WFEC, NextEra, EDE, WAPA), 1 abstained (OPPD)

**July 31, 2025 - SAWG:**
- **PASSED**: Motion supporting further CHILL development with conditions requiring clarifications before Board approval

**July 31, 2025 - TWG, ESWG, MDAG:**
- No formal vote taken; general support noted with concerns

**October 27, 2025 - Market Working Group:**
- **PASSED**: Motion to approve RR696 (SIR764) Impact Analysis with High severity level (0 opposed, 1 abstained - OPPD)

**September 4, 2025 - Board of Directors/Members Committee:**
- **PASSED**: Final approval of RR696 (1 opposed - OGE, 3 abstained - NRDC, Xcel/SPS, NPPD)

### Key Conditions from SAWG
SAWG recommended Board approval only after clarifying:
- CHILL curtailment occurs before demand response programs
- No impact on maintenance margin availability
- Exclusion from regional CONE multiplier calculation
- No requirement for resources in reliability status
- LRE obligations for load forecasting and curtailment
- LOLE study incorporation methodology
- Environmental limitations and generator availability reserves

---

## 4. Important Dates

- **July 16, 2025**: Initial MOPC vote (failed); Workshop motion approved
- **July 21, 2025**: Market Working Group straw poll
- **July 24, 2025**: ORWG straw poll
- **July 31, 2025**: SAWG motion; TWG/ESWG/MDAG straw poll
- **September 2025 (end of month)**: Special MOPC workshop deadline
- **September 4, 2025**: Board of Directors/Members Committee final approval
- **October 27, 2025**: Impact Analysis approval (Market Working Group)

### Timeline Concern
- Stakeholders requested **~1 month** additional review time in July 2025

---

## 5. Organizations and People Mentioned

### People
- **Jim Flucke** (Evergy) - Motioned for Impact Analysis approval
- **Brandon McCracken** (WFEC) - Seconded Impact Analysis motion
- **Richard Ross** (AEP) - Motioned for RR696 approval at MOPC (failed)
- **Olivia Hough** (CUS) - Seconded MOPC motion
- **Steve Gaw** (Advanced Power Alliance) - Motioned for special MOPC workshop
- **Matt Caves** (WFEC) - Seconded workshop motion
- **Stuart Solomon** - Motioned for final Board approval
- **Lanny Nickell** - Seconded Board motion
- **Myers, Clayton** - Mentioned as needing internal review time

### Organizations

#### Transmission Owners/Load Serving Entities
- AEP (multiple subsidiaries)
- Evergy (Kansas Central/Westar, Kansas South/KGE, Metro/KCP&L, Missouri West)
- OGE (Oklahoma Gas & Electric)
- Xcel Energy/Southwestern Public Service (SPS)
- WFEC (Western Farmers Electric Cooperative)
- OPPD (Omaha Public Power District)
- NPPD (Nebraska Public Power District)
- Basin Electric Power Cooperative
- Sunflower Electric Power Corp
- Golden Spread Electric Cooperative (GSEC)
- Tri-State Generation and Transmission

#### Generation/Power Cooperatives
- East River Electric Power Cooperative
- Central Power Electric Cooperative
- Corn Belt Power Cooperative
- Midwest Energy
- KEPCo (Kansas Electric Power Cooperative)
- Multiple rural electric cooperatives

#### Renewable Energy Companies
- NextEra Energy (Resources, Transmission, Southwest)
- EDP Renewables North America
- Enel Green Power North America
- Clearway Power Marketing
- Leeward Renewables Energy
- Pine Gate Renewables
- Savion LLC
- Southern Power
- Spearmint Renewable Development Company

#### Transmission Companies
- Grain Belt Express Clean Line
- GridLiance High Plains
- Transource Energy (Missouri, Oklahoma)
- Prairie Wind Transmission

#### Energy Marketers/Traders
- Google Energy
- Targa Northern LLC
- Boston Energy Trading & Marketing
- DC Energy Midwest LLC
- Tenaska
- KPP Energy

#### Advocacy/Policy Organizations
- Advanced Power Alliance
- American Clean Power Association
- Advanced Energy United
- Natural Resources Defense Council (NRDC)

#### Other
- WAPA (Western Area Power Administration)
- Municipal Energy Agency of Nebraska
- Lincoln Electric System
- Heartland Consumers Power District

---

## 6. Links or References

### Referenced Processes and Programs
- **GAP (Generator Aggregate Program)** - process for incorporating HILL/CHILL loads
- **SIR764** - System Impact Request associated with RR696
- **LTCR netting** - Long-Term Congestion Rights
- **PRM/PBA/ELCC** - Planning Reserve Margin/Performance-Based Allocation/Effective Load Carrying Capability
- **DAMKT/

---

# Chunk 20 Analysis

# REGULATORY MEETING ANALYSIS REPORT

## 1. Executive Summary

This document represents the final chunk (20 of 20) of RR696 Recommendation Report concerning the integration and operation of High Impact Large Loads (HILL) within the SPP system. The Markets and Operations Policy Committee (MOPC) held a special session on August 21, 2025, where they voted to approve RR696 with a modification to the timeline requirements in Tariff Attachment AQ 3.2. The motion passed despite 2 oppositions and 15 abstentions, primarily due to concerns about the treatment of High Impact Large Load Generation Agreements (HILLGAs) and timing mismatches between generation and load interconnection processes.

## 2. Key Topics

- **High Impact Large Loads (HILL)** - New framework for integrating large loads into the SPP system
- **Tariff Attachment AQ 3.2 Modification** - Timeline adjustment for HILL processing (60 vs 90 days)
- **HILLGA (High Impact Large Load Generation Agreement)** - Treatment of large loads that bring generation
- **Unreserved Use Charges** - Concerns about penalties during interim periods
- **Generation Interconnection Timing** - Mismatch between load and generation interconnection processes
- **Firm Transmission Service** - Requirements for generation components to obtain firm service through CPP or other processes

## 3. Decisions or Actions

**Motion Approved:**
- RR696 "Integrate and Operate with High Impact Large Loads SPP Comments" dated August 14, 2025
- **Contingency:** SPP must modify Tariff Attachment AQ 3.2 to adjust timeline language to "within sixty (60) Calendar Days, or ninety (90) Calendar Days in the case of a HILL, of the receipt" (striking the blanket change from 90 to 60 days)
- **Motion by:** Richard Ross (AEP Southwestern Electric Power Company)
- **Second by:** Jeff Wells (NextEra Energy Resources)
- **Result:** Passed

**Vote Breakdown:**
- Opposed: 2 entities
- Abstained: 15 entities

## 4. Important Dates

- **August 14, 2025** - Date of SPP Comments on RR696
- **August 21, 2025** - MOPC Special Session meeting date
- **5-year period** - Initial period granted by HILLGA before generation must obtain firm transmission service

## 5. Organizations and People Mentioned

**People:**
- Richard Ross (AEP Southwestern Electric Power Company) - Made the motion
- Jeff Wells (NextEra Energy Resources) - Seconded the motion

**Organizations - Abstained (15):**
- Continental Resources
- Kansas Municipal Energy Agency
- KPP Energy
- Lea County Electric Cooperative
- Missouri Joint Municipal EUC
- Municipal Energy Agency of Nebraska
- Oklahoma Gas & Electric (Electric Services and Transmission divisions)
- Oxy USA Inc.
- Sunflower Electric Power Corp
- Tenaska Power Services Co.
- Viridon Southwest LLC
- Western Farmers Electric Cooperative
- Xcel Energy Southwest Transmission Co
- Xcel Southwestern Public Service Company

**Organizations - Opposed (2):**
- ConocoPhillips Company
- Nebraska Public Power District

**Other Organizations:**
- Southwest Power Pool (SPP)
- Federal Energy Regulatory Commission (FERC)
- North American Electric Reliability Corporation (NERC)

## 6. Links or References

- **RR696 Recommendation Report** - SPP Comments dated August 14, 2025
- **Tariff Attachment AQ 3.2** - Specific tariff section requiring modification
- **Generator Interconnection Procedures (GIP)**
- **Open Access Transmission Tariff (OATT)**
- **CPP (Competitive Process for Purchase)** - Referenced as potential pathway for firm service

## 7. Suggested Tags

- RR696
- High Impact Large Loads (HILL)
- HILLGA
- MOPC
- SPP Tariff
- Generator Interconnection
- Unreserved Use Charges
- Firm Transmission Service
- Load Interconnection
- Tariff Attachment AQ
- Timeline Requirements
- August 2025

## 8. Items That May Need Follow-Up

1. **SPP Tariff Modification** - Confirm that SPP modifies Tariff Attachment AQ 3.2 per the approved motion's contingency requirement

2. **OG&E Concerns Resolution** - Address the fundamental concern about unreserved use charges for HILLGA loads during the interim period between HILLGA approval and generation firm service approval

3. **Generation/Load Interconnection Timing Mismatch** - Develop solution for the procedural gap where generation must go through longer interconnection processes while load cannot become firm

4. **Firm Service Pathway for HILLGA Generation** - Clarify the process and requirements for HILLGA generation components to obtain firm transmission service (CPP or alternative processes)

5. **Five-Year Transition Period** - Monitor implementation of the 5-year period mechanism and its adequacy for generation to complete firm service processes

6. **Curtailment and Penalty Framework** - Establish clear guidelines for load firmness status when co-located generation is present but not yet firm

7. **FERC Filing** - Likely required for tariff modifications; track filing and approval status

8. **Implementation Timeline** - Establish clear timeline for implementing approved changes to Attachment AQ 3.2