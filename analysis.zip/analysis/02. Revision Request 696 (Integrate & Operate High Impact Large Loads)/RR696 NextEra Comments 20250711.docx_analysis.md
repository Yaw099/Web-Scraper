# REGULATORY MEETING/CONTENT ANALYSIS REPORT

## 1. EXECUTIVE SUMMARY

This document contains NextEra Energy Resources' comments on SPP's Revision Request 696 (RR696), which proposes a framework for integrating High Impact Large Loads (HILL) and Curtailable High Impact Large Loads (CHILL) into the grid. While NextEra supports expediting large load integration and agrees with HILLGA Path 1, they raise significant concerns about:

- **Compressed stakeholder engagement timeline** preventing adequate review
- **SPP's plan to implement before FERC approval**, creating potential reversal complications
- **HILLGA Path 3's overly broad criteria** that may allow excessive queue-jumping
- **Inadequate provisions for reliability studies** within the proposed 90-day timeframe
- **Lack of protections against speculative load requests**

NextEra warns that rushing this proposal without proper vetting could lead to reliability issues, regulatory litigation, and reputational damage to SPP, echoing problems from SPP's previous ERAS proposal.

## 2. KEY TOPICS

### High Impact Large Load Integration Framework
- Three proposed pathways (HILLGA Path 1, 2, and 3) for expedited interconnection
- 90-day study timeline for CHILL and HILLGA assessments
- Integration of planning, market, and operational aspects

### Stakeholder Process Concerns
- Extremely shortened review period
- Limited stakeholder input despite complexity
- Previous stakeholder outreach by NextEra not incorporated

### Reliability and Study Adequacy
- Voltage and stability analysis within compressed timeline
- Power quality considerations (harmonics, voltage fluctuations)
- Transient stability and voltage recovery
- Small signal stability and forced oscillations
- Resonance stability impacts on nearby units
- Ramping rate and ride-through requirements
- Affected system impacts

### Discrimination and Queue Priority Issues
- HILLGA Path 3 allowing projects to bypass DISIS queued projects
- Similarities to problematic SPP ERAS proposal
- Generation capacity measurement (nameplate vs. accredited)

### Speculative Load Prevention
- Duplicative load study requests across utility queues
- Need for executed agreements before study
- Financial commitment mechanisms

## 3. DECISIONS OR ACTIONS

### Requested by NextEra:

1. **Eliminate HILLGA Path 3 entirely** - Due to overly broad deliverability area criteria that could allow excessive queue-jumping

2. **Clarify generation capacity measurement** - Specify that "supporting generation is capped at load max plus reserve margin x 1.25" refers to accredited capacity, not nameplate capacity

3. **Require executed agreements with loads** - Demonstrate utility has executed agreement before receiving expedited study

4. **Implement $100,000 additional fee** per request to discourage speculative loads

5. **Address reliability study methodology** - Explicitly specify how voltage and stability will be studied within 90-day timeframe, including:
   - Power quality analysis
   - Transient stability
   - Small signal stability
   - Resonance stability
   - Ramping and ride-through requirements
   - Affected system impacts

6. **Extend stakeholder review period** - Allow proper vetting by working groups (especially ORWG)

### SPP's Stated Intent:
- Move forward with implementation prior to FERC approval (NextEra objects to this)

## 4. IMPORTANT DATES

- **July 11, 2025** - Date of NextEra's comment submission
- **April 2025** - NERC presented plans to address large load integration reliability impacts
- **Q2 and Q3 2025** - NERC Large Load Task Force scheduled to produce white papers
- **Q1 2026** - NERC Reliability Guideline for emerging large loads expected
- **Earlier in 2025** - NERC issued incident review on 1.5 GW load loss event

## 5. ORGANIZATIONS AND PEOPLE MENTIONED

### Organizations:
- **NextEra Energy Resources (NextEra)** - Submitting entity
- **SPP (Southwest Power Pool)** - Grid operator proposing RR696
- **FERC (Federal Energy Regulatory Commission)** - Regulatory approval authority
- **NERC (North American Electric Reliability Corporation)** - Reliability standards authority
- **NERC Large Load Task Force** - Working on large load integration guidance
- **DISIS** - Reference to existing queue process
- **ERCOT** - Cited as comparison for fee structure

### People:
- **Jeff Wells** - NextEra representative submitting comments
  - Email: jeff.wells@nexteraenergy.com

### Working Groups Referenced:
- **ORWG (Operations Reliability Working Group)** - Should vet reliability concerns

## 6. LINKS OR REFERENCES

### Referenced Proposals/Programs:
- **RR696** - Main revision request being commented on
- **SPP ERAS proposal** - Previous proposal cited as having similar discriminatory concerns
- **HILLGA Path 1, 2, and 3** - Three pathways for expedited interconnection
- **CHILL Service** - Curtailable High Impact Large Load service
- **HILL requirements** - High Impact Large Load requirements
- **DISIS** - Existing queue process

### Governing Documents to be Modified:
- SPP Open Access Transmission Tariff
- Market Protocols
- SPP governing documents (general)

### External References:
- **NERC incident review** - Regarding 1.5 GW load loss incident (earlier in 2025)
- **NERC April 2025 presentation** - Plans to address reliability impacts from large load integration
- **NERC white papers** - Series planned for Q2 and Q3 2025
- **NERC Reliability Guideline** - For emerging large loads, expected Q1 2026
- **NERC standards** - Referenced for compliance alignment
- **ERCOT $100,000 fee structure** - Cited as precedent for speculative load deterrent

## 7. SUGGESTED TAGS

- RR696
- High Impact Large Loads (HILL)
- Curtailable High Impact Large Loads (CHILL)
- HILLGA
- Large Load Integration
- Interconnection Queue
- Generator Interconnection
- Stakeholder Process
- FERC Approval
- Reliability Studies
- Voltage Stability
- Transient Stability
- NextEra Energy
- SPP
- Queue Reform
- Deliverability
- Accredited Capacity
- Speculative Projects
- NERC Compliance
- Study Timeline
- Market Efficiency
- Transmission Planning

## 8. ITEMS THAT MAY NEED FOLLOW-UP

### Immediate/High Priority:

1. **Pre-FERC Implementation Risk** - SPP's stated intention to implement before FERC approval creates legal and operational risks requiring immediate clarification and possible reversal

2. **Stakeholder Process Extension** - Request for extended review period and working group vetting (especially ORWG) needs resolution before proceeding

3. **HILLGA Path 3 Elimination/Revision** - Fundamental design issue requiring resolution to avoid discrimination claims and potential FERC litigation

4. **90-Day Study Adequacy** - Critical gap in demonstrating how comprehensive reliability studies (voltage stability, transient stability, small signal stability, etc.) can be completed in compressed timeframe

### Regulatory/Compliance:

5. **FERC Filing Strategy** - Given discrimination concerns similar to ERAS proposal, likelihood of FERC challenges should be assessed

6. **NERC Alignment** - Coordination with NERC Large Load Task Force work and upcoming guidance (Q1 2026 Reliability Guideline) to ensure consistency

7. **Executed Agreement Requirement** - Need to formalize requirement for executed agreements before study and determine enforceability

8. **Fee Structure Implementation** - $100,000 additional fee proposal needs tariff language development and FERC justification

### Technical/Operational:

9. **Accredited vs. Nameplate Capacity** - Clarification needed in tariff language for generation cap calculation methodology

10. **Stability Study Protocol** - Detailed methodology documentation needed for:
    - Power quality assessment (harmonics, voltage fluctuations)
    - Transient stability and voltage recovery analysis
    - Small signal stability and forced oscillation analysis
    - Resonance stability impacts
    - Ramping rate and ride-through requirements
    - Affected system impact procedures

11. **Real-Time Curtailment Procedures** - CHILL curtailment for thermal overlo