# Final Combined Report

# REGULATORY MEETING ANALYSIS REPORT
**SPP CHILLS and PALS Stakeholder Engagement Forum**
**January 12, 2026**

---

## 1. Executive Summary

Southwest Power Pool (SPP) conducted a comprehensive stakeholder engagement forum on January 12, 2026, to advance two critical regulatory initiatives addressing large load growth in the region:

- **RR720 (CHILLS - Conditional High Impact Large Loads)**: A framework providing conditional transmission service options for large loads (data centers, industrial facilities) lacking sufficient Designated Network Resources or committed generation
- **SIR796 (PALS - Price Adaptive Load Service)**: A flexible, price-responsive transmission service for loads willing to curtail based on real-time market pricing

The CHILLS initiative addresses a critical gap identified in RR696 by enabling load connection studies without pre-existing generation commitments. SPP staff presented two refined options based on extensive stakeholder feedback from ~100+ touchpoints across 10 working groups over six months. Multiple working groups approved moving forward, though with notable abstentions and some opposition. MOPC endorsed the CHILLS policy with expectations that key stakeholder concerns would be mitigated.

The PALS initiative is in earlier stages, with design elements still under development including bid cap methodology, transmission service rates, resource adequacy treatment, and load factor caps. The combined initiatives represent SPP's strategic response to significant anticipated load growth requiring new transmission service models.

---

## 2. Key Topics

### **CHILLS Framework (RR720)**

**Three Service Types Proposed:**
1. **Conditional HILL (CHILL)**: Curtailable long-term transmission service with commitment to transition to firm service
2. **Firm HILL NITS or PTP**: Long-term firm transmission service when sufficient generation exists
3. **Price Adaptive Load (PAL)**: Service for loads willing to withdraw based on real-time pricing

**Problem Statement:**
- Current RR696 framework creates a gap: market participants cannot establish delivery points for High Impact Large Loads without existing Designated Network Resources or planned generation
- Attachment BC in RR720 provides methodology to study loads without these traditional requirements

**Two CHILLS Options Presented:**

**Option 1: Transmission Limitations CHILL**
- For entities with sufficient Designated Network Resources
- Allows connection pending transmission system upgrades
- Curtailed during local transmission issues and EEA2 events
- Net impact basis for system curtailments

**Option 2: HILLGA Generation-Supported CHILL**
- For entities with insufficient designated resources but with supporting generation
- Requires accredited equivalent supporting HILLGA generation
- Generation must be built and online before CHILL interconnection
- No cap on footprint CHILL load when supported by HILLGA
- Example: 100MW CHILL requires 500MW nameplate wind at 20% accreditation

**Service Limitations:**
- 7-year maximum service term (non-renewable)
- Subject to curtailment during transmission constraints and emergency conditions
- Must eventually transition to firm service

### **PALS Framework (SIR796)**

**Core Design Elements:**
- Non-firm transmission service for price-sensitive loads
- Ability to submit demand bids in Day-Ahead (DA) and Real-Time (RT) markets
- Flexibility for loads to respond to price signals

**Unresolved Design Questions:**
- Bid cap methodology (considering seasonal variability, system capacity, gas prices)
- Transmission service rate structure (energy-based vs. alternative)
- Resource adequacy modeling approach
- Load factor cap options
- Operational requirements alignment with HILLs and CHILLS

### **Key Policy Concerns Addressed**

**Market and Reliability Impacts:**
- Energy market price impact and LMP distortion
- Curtailment intensity and frequency
- Impact to permit-limited/emissions-limited generators
- Resource adequacy circumvention potential
- TCR (Transmission Congestion Rights) topology changes

**Operational Considerations:**
- SCUC (Security Constrained Unit Commitment) determination of CHILL availability
- Capacity curtailments prioritized before CODRPs
- Real-time curtailments based on net zero impact for Option 2
- Outage coordination methodology (conversion to business practice)
- Curtailment notice procedures (up to 7 days advance notice vs. real-time)

**Cost and Rate Concerns:**
- Cost causation and uplift charge allocation
- Bypass concerns and value proposition
- Price spike exposure
- ATRR (Annual Transmission Revenue Requirement) implications

---

## 3. Decisions or Actions

### **Working Group Approvals (CHILLS - December 2025 - January 2026)**

| Date | Group | Decision | Opposition/Abstentions |
|------|-------|----------|------------------------|
| 12/10/2025 | ESWG | Approved | Abstentions: WAPA, Basin, NextEra, East River, OPPD, NPPD |
| 12/10/2025 | TWG | Approved | Opposition: Sunflower, Xcel, NPPD |
| 12/15/2025 | MWG | Approved | Opposition: Heartland, WAPA |
| 12/18/2025 | SAWG | Approved | Opposition: Heartland |
| 12/18/2025 | RTWG | Approved | Multiple abstentions: MRES, KPP, WFEC, LES, KMEA, GSEC, KEPCO, OMPA, GRDA, MJEMUC, SEPC, ITC GP, ETEC, UGPM, CUS, EDE, NPRB |
| 01/06/2026 | CAWG | Approved | Opposition: MNPUC |
| 01/08/2026 | ORWG | Approved | Opposition: CUS Mo |

### **Policy Endorsements**
- **MOPC** endorsed CHILLS policy with expectation that key stakeholder concerns are mitigated
- Staff incorporated changes from stakeholder feedback
- Multiple working groups recommended narrowing scope of CHILL provision

### **Pending Decisions (PALS)**
- Bid cap methodology determination
- Transmission service rate structure
- Resource adequacy modeling approach
- Load factor cap options
- Language modifications through RR process for outage coordination

### **Actions in Progress**
- SPP staff conducting LMP impact analysis
- Developing updates to existing policies to account for CHILLS
- Exploring cap on allowable curtailments
- Converting RC outage coordination methodology document to business practice
- Developing straw proposals for bid cap methodology

---

## 4. Important Dates

### **Past Stakeholder Engagement (October 2025 - January 2026)**
- **October - November 2025**: CHILLS/PALS Education (11 education sessions, 2 Forums)
- **November 21, 2025**: Stakeholder Forum
- **December 2, 2025**: Stakeholder Forum
- **December 2025**: CHILLS Approval/PALS Education (7 approval meetings, 4 education sessions, 1 Forum)
- **December 10, 2025**: ESWG and TWG approvals
- **December 15, 2025**: MWG approval
- **December 18, 2025**: SAWG and RTWG approvals
- **January 6, 2026**: CAWG approval
- **January 8, 2026**: ORWG approval
- **January 12, 2026**: Current Stakeholder Engagement Forum (1:00 PM - 4:00 PM)

### **Future Stakeholder Engagement**
- **January 2026**: CHILLS MOPC (4 approval sessions, 4 PALS education sessions)
- **January 30, 2026**: Stakeholder Forum
- **February - March 2026**: PALS Education/Approval (9 education sessions, 6 approval meetings, 3 Forums)
- **February 27, 2026**: Stakeholder Forum
- **March 27, 2026**: PALS Stakeholder Forum
- **April 2026**: Final Approvals, PALS MOPC (2 approval sessions)
- **April 10, 2026**: Final Forum

### **Process Timeline Summary**
- **Total engagement duration**: ~6 months (October 2025 - April 2026)
- **Total touchpoints**: 100+ across 10

---

# Partial Chunk Reports

# Chunk 1 Analysis

# REGULATORY MEETING ANALYSIS REPORT

## 1. Executive Summary

This document presents SPP's stakeholder engagement forum held on January 12, 2026, focusing on two regulatory initiatives: RR720 (CHILLS - Conditional High Impact Large Loads) and SIR796 (PALS - Price Adaptive Load Service). The primary objective is to establish a modified framework to reliably and economically support large load growth in the SPP region. The CHILLS framework addresses a critical gap in the load connection process by providing conditional transmission service options for large loads (such as data centers and industrial facilities) that lack sufficient Designated Network Resources or committed generation. SPP staff presented two refined options based on stakeholder feedback and is seeking approval to move forward. Multiple working groups have already provided approval with varying levels of abstentions and limited opposition.

## 2. Key Topics

### CHILLS Framework Components
- **Three Service Types for Large Load Transmission:**
  - Conditional HILL (CHILL): Curtailable long-term transmission service with commitment to transition to firm
  - Firm HILL NITS or PTP: Long-term firm transmission service when sufficient generation exists
  - Price Adaptive Load (PAL): Service for loads willing to withdraw based on real-time pricing

### Problem Being Solved
- **HILL Study Gap under RR696:** Market participants cannot establish delivery points for High Impact Large Loads without existing Designated Network Resources or planned generation
- RR720 Attachment BC provides method to study loads without these requirements

### Two CHILLS Options Presented

**Option 1: Transmission Limitations CHILL**
- For entities with sufficient Designated Network Resources
- Allows connection pending transmission system upgrades
- Curtailed during local transmission issues and EEA2 events
- Net impact basis for system curtailments

**Option 2: HILLGA Generation-Supported CHILL**
- For entities with insufficient designated resources but supporting generation
- Requires accredited equivalent supporting HILLGA generation
- Generation must be built and online before CHILL interconnection
- No cap on footprint CHILL load when supported by HILLGA
- Example: 100MW CHILL requires 500MW nameplate wind at 20% accreditation

### Key Policy Concerns Addressed
- Energy market price impact
- Curtailment intensity and frequency
- Impact to permit limited generators
- Staff recommends narrowing CHILLS provision scope to mitigate concerns

### Market Operations Considerations
- SCUC (Security Constrained Unit Commitment) will determine CHILL availability
- Capacity curtailments prioritized before CODRPs (Conservative Operation Demand Response Programs)
- Real-time curtailments based on net zero impact for Option 2

## 3. Decisions or Actions

### Working Group Approvals (December 2025 - January 2026)
- **ESWG (12/10/2025):** Approved with abstentions from WAPA, Basin, NextEra, East River, OPPD, NPPD
- **TWG (12/10/2025):** Approved with opposition from Sunflower, Xcel, NPPD
- **MWG (12/15/2025):** Approved with opposition from Heartland, WAPA
- **SAWG (12/18/2025):** Approved with opposition from Heartland
- **RTWG (12/18/2025):** Approved with multiple abstentions
- **CAWG (01/06/2026):** Approved with opposition from MNPUC
- **ORWG (01/08/2026):** Approved with opposition from CUS Mo

### MOPC Endorsement
- MOPC endorsed CHILLS policy moving forward with expectation that key concerns are mitigated

### Modifications Made
- Updates in RR720 incorporate changes from stakeholder feedback
- Multiple working groups recommended narrowing the scope of CHILL provision
- Revised proposal reflects that direction

## 4. Important Dates

- **January 12, 2026:** Stakeholder Engagement Forum (1:00 PM - 4:00 PM)
- **December 10, 2025:** ESWG and TWG approvals
- **December 15, 2025:** MWG approval
- **December 18, 2025:** SAWG and RTWG approvals
- **January 6, 2026:** CAWG approval
- **January 8, 2026:** ORWG approval
- **~6 months:** Total duration of working group discussions (approximately July 2025 - January 2026)

## 5. Organizations and People Mentioned

### SPP Staff Presenters
- **Adriane Barnes:** Communications, Administrative Items
- **Jason Davis:** CHILL Solution presentation
- **Ainsley Anderson:** Timeline and Next Steps
- **Jonathan Hathhorn:** PALS Update
- **SPP CHILL Staff:** RR720 Read-Through and Q&A

### Organizations with Voting Positions

**Organizations That Abstained or Opposed:**
- WAPA (Western Area Power Administration)
- Basin Electric
- NextEra
- East River
- OPPD (Omaha Public Power District)
- NPPD (Nebraska Public Power District)
- MRES
- KPP (Kansas Power Pool)
- Sunflower
- Xcel Energy
- Heartland
- WFEC (Western Farmers Electric Cooperative)
- LES (Lincoln Electric System)
- KMEA (Kansas Municipal Energy Agency)
- GSEC
- KEPCO
- OMPA
- GRDA (Grand River Dam Authority)
- MJEMUC
- SEPC
- ITC GP
- ETEC
- UGPM
- CUS (City Utilities of Springfield)
- EDE
- NPRB
- PUCT (Public Utility Commission of Texas)
- KCC (Kansas Corporation Commission)
- NDPSC (North Dakota Public Service Commission)
- MNPUC (Minnesota Public Utilities Commission)
- CUS Mo

### Working Groups Involved
- MOPC (Markets and Operations Policy Committee)
- MWG (Market Working Group)
- ORWG (Operating Reliability Working Group)
- RTWG (Regional Tariff Working Group)
- SAWG (Seams Agreement Working Group)
- CAWG (Cost Allocation Working Group)
- RSC (Regional State Committee)
- TWG (Transmission Working Group)
- ESWG (Economic Studies Working Group)
- SPC (Strategic Planning Committee)

## 6. Links or References

### Regulatory/Process References
- **RR720:** Conditional High Impact Large Loads (CHILLS)
- **SIR796:** PALS (Price Adaptive Load Service)
- **RR696:** HILL/HILLGA (existing framework with identified gap)
- **Attachment AQ:** Load connection study process
- **Attachment AX:** Process requiring planned generation
- **Attachment BC:** New process for load study without Designated Network Resources
- **Attachment BA:** Delivery point process
- **Business Practice 7250:** Behind-The-Meter generation process
- **DISIS/CPP and Agg Study:** Generation conversion to DNR process

### Technical References
- **DNR:** Designated Network Resources
- **NITS:** Network Integration Transmission Service
- **PTP:** Point-to-Point transmission service
- **HILL:** High Impact Large Load
- **HILLGA:** High Impact Large Load Generator Attachment
- **SCUC:** Security Constrained Unit Commitment
- **CODRPs:** Conservative Operation Demand Response Programs
- **EEA2:** Energy Emergency Alert Level 2
- **LMP:** Locational Marginal Pricing
- **ATRR:** Annual Transmission Revenue Requirement

## 7. Suggested Tags

- RR720
- CHILLS
- Conditional-High-Impact-Large-Load
- SIR796
- PALS
- Price-Adaptive-Load
- SPP
- Southwest-Power-Pool
- Large-Load-Interconnection
- Data-Centers
- Transmission-Service
- Curtailable-Load
- HILLGA
- Generation-Interconnection
- Load-Connection-Study
- Designated-Network-Resources
- Transmission-Upgrades
- Market-Design
- Stakeholder-Engagement
- Attachment-BC
- Energy-Emergency
- Curtailment-Policy
- Co-location
- Industrial-Load-Growth

## 8.

---

# Chunk 2 Analysis

# REGULATORY MEETING ANALYSIS REPORT

## 1. Executive Summary

This presentation covers SPP's (Southwest Power Pool) CHILLS and PALS Stakeholder Engagement Forum held on January 12, 2026. The document outlines two new transmission service models: CHILLS (Conditional High Impact Load Service) and PALS (Price Adaptive Load Service). The presentation addresses stakeholder concerns, policy design elements, and provides an extensive engagement timeline spanning October 2025 through April 2026, with over 100 total touchpoints across 10 working groups. Key issues include curtailment risk, resource adequacy considerations, impact on existing generation, and the value proposition of these new service models.

## 2. Key Topics

- **CHILLS (Conditional High Impact Load Service)**: A non-firm transmission service with a 7-year service limit
- **PALS (Price Adaptive Load Service)**: A flexible, non-firm transmission service for price-sensitive loads that can submit demand bids in Day-Ahead (DA) and Real-Time (RT) markets
- **Stakeholder Engagement Process**: Comprehensive 6-month rollout from October 2025 through April 2026
- **Design Elements for PALS**:
  - Bid cap methodology
  - Transmission service rates
  - Resource adequacy considerations
  - Load factor caps
- **Stakeholder Concerns**:
  - Cost causation and uplift charges
  - Curtailment risk and bypass concerns
  - Price spike exposure
  - Impacts to existing generation and emissions-limited resources
  - LMP (Locational Marginal Pricing) impacts
  - TCR (Transmission Congestion Rights) topology changes
  - Resource adequacy circumvention

## 3. Decisions or Actions

**Pending Decisions:**
- Bid cap method determination for PALS to mitigate permit-limited resource concerns
- Transmission service rate structure for PALS
- Resource adequacy modeling approach for PAL
- Load factor cap options
- Language modifications through RR (Revision Request) process for outage coordination

**Actions Identified:**
- SPP staff working on LMP impact analysis
- SPP developing updates to existing policies to account for CHILLS
- Exploring cap on allowable curtailments
- Converting RC outage coordination methodology document to business practice
- Developing straw proposals for bid cap methodology

## 4. Important Dates

**Engagement Timeline:**
- **October - November 2025**: CHILLS/PALS Education (11 education sessions, 2 Forums)
- **December 2025**: CHILLS Approval/PALS Education (7 approval meetings, 4 education sessions, 1 Forum)
- **January 2026**: CHILLS MOPC (4 approval sessions, 4 PALS education sessions)
- **February - March 2026**: PALS Education/Approval (9 education sessions, 6 approval meetings, 3 Forums)
- **April 2026**: Final Approvals, PALS MOPC (2 approval sessions)

**Specific Forum Dates:**
- November 21, 2025
- December 2, 2025
- January 12, 2026 (current meeting)
- January 30, 2026
- February 27, 2026
- March 27, 2026 (PALS)
- April 10, 2026

## 5. Organizations and People Mentioned

**People:**
- **Ainsley Anderson** - Market Policy Coordination

**Organizations/Groups:**
- **SPP (Southwest Power Pool)** - Primary organization
- **MMU (Market Monitoring Unit)** - Raised concerns about transmission service loopholes
- **FERC** - Enforcement authority for tariff provisions

**Working Groups (10 total):**
- MOPC (Markets and Operations Policy Committee)
- MWG (Market Working Group)
- SAWG (Seams Analysis Working Group)
- RSC (Regional State Committee)
- ORWG (Operating Reliability Working Group)
- CAWG (Credit Analysis Working Group)
- RTWG (Real-Time Working Group)
- TWG (Transmission Working Group)
- ESWG (Energy Storage Working Group)
- SPC (Strategic Planning Committee)

## 6. Links or References

- **SPP.org** - Meeting materials location
- **Jan. 12 Stakeholder Feedback Survey LINK** - Post-forum feedback mechanism
- **RR720** - Revision Request related to CHILLS
- **RR696** - Previous framework revision request
- **Attachment BC** - Tariff provision for HILL study opportunities
- **GAP Process** - Generation and Outage Coordination process
- **LOLE** - Loss of Load Expectation modeling

## 7. Suggested Tags

- CHILLS
- PALS
- SPP
- Transmission Service
- Non-Firm Service
- Market Policy
- Stakeholder Engagement
- Resource Adequacy
- Curtailment
- Price-Sensitive Loads
- Demand Response
- MOPC
- Tariff Revision
- RR720
- LMP Impacts
- TCR
- High Impact Loads
- Market Integration

## 8. Items That May Need Follow-Up

**Critical Follow-Up Items:**

1. **Bid Cap Methodology**: Stakeholders request straw proposals for dynamic bid caps based on seasonal variability, system capacity, and gas prices

2. **LMP Impact Analysis**: SPP staff analysis in progress - results need to be brought to stakeholder groups with TCR impact discussion

3. **April 2026 Approval Timeline Concern**: Stakeholders indicate April RR approval is "too late" - may need timeline acceleration

4. **Load Factor Cap Options**: Stakeholders requesting potential options to be considered and presented

5. **Transmission Service Rate Structure**: Determination needed on whether PALS rates should be based on energy impact or alternative methodology

6. **Resource Adequacy Modeling**: Method for modeling PAL needs stakeholder discussion and consensus

7. **Outage Coordination Policy Updates**: RR720 language modifications pending conversion of RC methodology document to business practice

8. **7-Year Service Limit Enforcement**: Stakeholder concerns about strict enforcement mechanisms for CHILLS service limit

9. **Curtailment Notice Procedures**: Standard practices being developed; need clarification on advance notice timing (up to 7 days vs. real-time)

10. **Value Proposition Clarification**: Stakeholders seeking clearer use cases and value demonstration for both CHILLS and PALS models

11. **Operational Requirements Alignment**: Stakeholder request that PALS, HILLs, and CHILLS have same ramp rate and ride-through requirements

12. **Post-Forum Survey Responses**: Feedback collection through survey link needs review and incorporation into next steps