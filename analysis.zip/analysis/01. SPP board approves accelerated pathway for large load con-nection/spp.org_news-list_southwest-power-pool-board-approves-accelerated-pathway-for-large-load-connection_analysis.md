# Final Combined Report

# REGULATORY CONTENT ANALYSIS REPORT
## Southwest Power Pool - High Impact Large Load (HILL) Policy Approval

---

## 1. Executive Summary

On **September 16, 2025**, Southwest Power Pool's (SPP) Board of Directors approved a groundbreaking High Impact Large Load (HILL) Integration policy designed to accelerate the connection of large electricity consumers to the power grid. The policy establishes an unprecedented **90-day study-and-approval process** for interconnecting large loads—primarily AI-driven data centers and manufacturing facilities—when paired with new or existing generation resources.

This initiative responds to urgent market demands for rapid grid access while maintaining system reliability and protecting existing ratepayers. The policy was developed through months of collaborative stakeholder engagement, including refinement by the Regional State Committee, and represents a proactive regulatory approach to accommodate transformational load growth in SPP's footprint.

The HILL policy integrates four previously separate processes (transmission service studies, generation interconnection studies, load interconnection studies, and reliability assessments) into a single accelerated framework, providing enhanced market transparency, predictable cost signals, and early detection of system constraints.

---

## 2. Key Topics

### Primary Policy Elements
- **High Impact Large Load (HILL) Integration Policy** - New accelerated interconnection framework
- **90-Day Expedited Process** - Streamlined study-and-approval timeline for qualifying projects
- **Generation Pairing Requirement** - Large loads must connect with on-site or nearby generation resources
- **Integrated Study Framework** - Consolidation of four separate study types into single process

### Strategic Objectives
- **Grid Reliability and System Integrity** - Maintaining stable operations despite significant new load additions
- **Market Efficiency and Transparency** - Faster market entry with improved price signals
- **Cost Predictability** - Enhanced financial certainty for developers and existing ratepayers
- **Operational Preparedness** - Real-time coordination across entities for managing new load impacts

### Target Applications
- **AI-Driven Data Centers** - Primary customer segment driving demand
- **Manufacturing Facilities** - Industrial loads requiring significant power capacity
- **Large Electricity Users** - Customers with substantial grid impact requiring coordinated integration

### Governance and Process
- **Stakeholder Collaboration** - Multi-month development process with member engagement
- **Regional State Committee Refinement** - State regulator input and policy enhancement
- **Early Constraint Detection** - Proactive identification of potential reliability issues
- **Accelerated Design and Operations** - Integrated approach from planning through real-time operations

---

## 3. Decisions or Actions

### Board Actions
- ✅ **Official Policy Approval** - SPP Board of Directors formally approved HILL Integration policy (September 16, 2025)
- ✅ **90-Day Timeline Establishment** - Codified accelerated study-and-approval process for qualifying large loads
- ✅ **Dual Pathway Authorization** - Approved two connection methods:
  1. Large loads paired with new generation (on-site or nearby)
  2. Large loads utilizing current or planned generation resources

### Operational Implementation
- ✅ **Integrated Framework Adoption** - Consolidated four separate study processes:
  - Transmission service studies
  - Generation interconnection studies
  - Load interconnection studies
  - Reliability assessments
- ✅ **Early Detection Protocol** - Established system constraint identification mechanisms
- ✅ **Operator Preparation Commitment** - Enhanced real-time coordination for managing new load impacts
- ✅ **Accelerated Design Integration** - Streamlined interconnection through integrated design, study, registration, and operations

### Stakeholder Engagement Completed
- ✅ **Member Collaboration** - Months-long stakeholder development process
- ✅ **Regional State Committee Input** - Policy refinement incorporating state regulator perspectives
- ✅ **Transparency Enhancement** - Improved price signals and market information for developers

---

## 4. Important Dates

| Date | Event/Milestone |
|------|----------------|
| **September 16, 2025** | SPP Board of Directors approval of HILL policy |
| **90 days** | Maximum duration for study-and-approval process (ongoing timeline once implemented) |
| **TBD** | Effective implementation date (not specified in announcement) |
| **TBD** | First application acceptance date (not specified) |

### Date Anomaly
- ⚠️ **Document Footer Shows "© 2026"** - Likely typographical error or placeholder; requires verification

---

## 5. Organizations and People Mentioned

### Organizations

**Primary:**
- **Southwest Power Pool (SPP)** - Regional Transmission Organization approving and implementing policy
  - Address: 201 Worthen Drive, Little Rock, AR 72223-4936
  - Phone: (501) 614-3200

**Governance Bodies:**
- **SPP Board of Directors** - Policy approval authority
- **Regional State Committee** - Provided policy refinement and state regulator perspective
- **SPP Stakeholders/Members** - Participated in development process

**Referenced Entities:**
- **MISO** - Mentioned in related links section

### People

**Key Spokespeople:**

**Casey Cathey** - SPP Vice President for Engineering
- Quote: *"This innovative policy supports reliability by allowing SPP to prepare its operators for the real-time impacts of significant new loads, detect constraints early, and coordinate across the region and between entities."*

**Stuart Solomon** - SPP Board Member
- Quote: *"Our stakeholders collaborated for months with our talented staff to develop this integrated framework, and the Regional State Committee helped refine the policy. I believe this integrated approach benefits all parties as it promotes market efficiency and transparency, especially through faster market entry and the enhanced price signals."*

**Derek Wingfield** - Media Contact
- Title: SPP Media Relations
- Phone: 501-614-3394
- Email: dwingfield@spp.org

---

## 6. Links or References

### Primary Policy Resources
- **HILL Integration Program Page**: https://spp.org/markets-operations/high-impact-large-load-hill-integration/
- **SPP Portal**: https://portal.spp.org/
- **OASIS**: http://www.oasis.oati.com/SWPP/index.html
- **SPP Tariff Viewer**: https://sppviewer.etariff.biz

### Related Interconnection Processes
- **Generator Interconnection**: https://spp.org/engineering/generator-interconnection/
- **Transmission Services**: https://spp.org/engineering/transmission-services/
- **Stakeholder Groups**: https://spp.org/stakeholder-groups/
- **SPP Revision Requests**: http://www.spp.org/governance/spp-revision-requests/

### Contact Information
- **Media Inquiries**: dwingfield@spp.org
- **General Contact**: (501) 614-3200
- **Address**: Southwest Power Pool, 201 Worthen Drive, Little Rock, AR 72223-4936

---

## 7. Suggested Tags

### Policy & Process Tags
`High Impact Large Load (HILL)` `HILL Integration` `Accelerated Approval` `90-Day Study Process` `Interconnection Policy` `Integrated Framework` `Expedited Process`

### Technical & Operational Tags
`Grid Interconnection` `Load Interconnection` `Generator Interconnection` `Transmission Planning` `Grid Reliability` `System Integrity` `Constraint Detection` `Real-Time Operations`

### Market & Customer Tags
`Data Center Infrastructure` `AI Infrastructure` `Manufacturing Loads` `Large Loads` `Market Efficiency` `Market Transparency` `Price Signals` `Cost Predictability`

### Organizational Tags
`SPP Board Actions` `Southwest Power Pool` `Regional State Committee` `Stakeholder Engagement` `Stakeholder Collaboration` `Regional Planning`

### Date & Location Tags
`September 2025` `Little Rock Arkansas` `2025 Board Action`

---

## 8. Items That May Need Follow-Up

### Critical Implementation Questions

**🔴 HIGH PRIORITY**

1. **Effective Implementation Date**
   - When does the 90-day study process officially begin accepting applications?
   - Is there a phased rollout or immediate availability?
   - What preparatory steps must applicants complete before this date?

2. **FERC Regulatory Status**
   - Does this policy require Federal Energy Regulatory Commission approval or filing?
   - Has FERC been notified or consulted?
   - What is the timeline for

---

# Partial Chunk Reports

# Chunk 1 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

Southwest Power Pool's (SPP) Board of Directors has approved a new High Impact Large Load (HILL) policy to expedite the connection of large electricity users (such as AI-driven data centers and manufacturing facilities) to the power grid. The policy establishes a 90-day study-and-approval process for interconnecting large loads paired with new or existing generation. This initiative addresses the urgent need to accommodate significant demand growth while maintaining grid reliability and affordability. The policy resulted from months of stakeholder collaboration and represents a proactive approach to meeting emerging market demands.

## 2. Key Topics

- **High Impact Large Load (HILL) Policy**: New accelerated pathway for large load interconnection
- **Grid Reliability**: Maintaining system integrity while connecting significant new loads
- **90-Day Study Process**: Expedited interconnection study and approval timeline
- **Generation Pairing**: Requirements for large loads to connect with on-site or nearby generation
- **Stakeholder Collaboration**: Multi-month process involving members, staff, and Regional State Committee
- **AI Data Centers and Manufacturing**: Primary target customers for the new policy
- **Market Efficiency and Transparency**: Enhanced price signals and cost predictability for developers
- **System Constraint Detection**: Early identification and coordination of potential reliability issues

## 3. Decisions or Actions

- **Board Approval**: SPP Board of Directors officially approved the HILL policy
- **Process Implementation**: Established integrated framework combining:
  - Transmission service studies
  - Generation interconnection studies
  - Load interconnection studies
  - Reliability assessments
- **Timeline Establishment**: 90-day study-and-approval process for qualifying large loads
- **Operational Preparation**: Commitment to prepare operators for real-time impacts of new loads
- **Design Integration**: Accelerated interconnection through integrated design, study, registration, and operations

## 4. Important Dates

- **No specific future dates mentioned**
- Policy has been approved (announcement made from Little Rock, Arkansas)
- Document dated **© 2026** (note: this may be a typo or placeholder)

## 5. Organizations and People Mentioned

**Organizations:**
- Southwest Power Pool (SPP)
- Regional State Committee
- MISO (referenced in links)

**People:**
- **Derek Wingfield** - Media Contact, 501-614-3394, dwingfield@spp.org
- **Casey Cathey** - SPP Vice President for Engineering (quoted)
- **Stuart Solomon** - Board Member (quoted)

**Location:**
- Southwest Power Pool, 201 Worthen Drive, Little Rock, AR 72223-4936, (501) 614-3200

## 6. Links or References

**Key Policy Links:**
- High Impact Large Load (HILL) Integration: https://spp.org/markets-operations/high-impact-large-load-hill-integration/
- SPP Portal: https://portal.spp.org/
- OASIS: http://www.oasis.oati.com/SWPP/index.html
- SPP Tariff: https://sppviewer.etariff.biz

**Related Process Links:**
- Generator Interconnection: https://spp.org/engineering/generator-interconnection/
- Transmission Services: https://spp.org/engineering/transmission-services/
- Stakeholder Groups: https://spp.org/stakeholder-groups/
- SPP Revision Requests: http://www.spp.org/governance/spp-revision-requests/

## 7. Suggested Tags

- High Impact Large Load (HILL)
- Grid Interconnection
- Data Center Infrastructure
- Transmission Planning
- Grid Reliability
- Generator Interconnection
- Load Interconnection
- AI Infrastructure
- Manufacturing Loads
- Stakeholder Process
- SPP Board Actions
- 90-Day Study Process
- Market Efficiency
- Accelerated Approval Process
- Regional Planning

## 8. Items That May Need Follow-Up

1. **Implementation Timeline**: When will the 90-day study process officially begin accepting applications?

2. **Eligibility Criteria**: What are the specific thresholds or criteria that define a "large load" under the HILL policy?

3. **Cost Structure**: What are the expected costs for developers utilizing this accelerated process?

4. **Generation Requirements**: Specific requirements for pairing generation with large loads (capacity ratios, proximity requirements, etc.)

5. **FERC Approval**: Does this policy require Federal Energy Regulatory Commission approval or filing?

6. **Tariff Modifications**: What specific tariff changes were necessary to implement this policy?

7. **Regional State Committee Input**: What were the specific refinements made based on RSC feedback?

8. **Performance Metrics**: How will SPP measure success of the HILL policy? What reporting will be provided?

9. **Queue Priority**: How will HILL applications be prioritized against existing interconnection queue requests?

10. **Stakeholder Training**: Will SPP provide training or guidance documents for members and potential applicants?

11. **Date Verification**: Confirm the "© 2026" date in the document footer (likely should be 2025 or earlier)

12. **First Applications**: Monitor for announcement of first projects utilizing the HILL process

---

# Chunk 2 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary
Southwest Power Pool's (SPP) Board of Directors approved a new High Impact Large Load (HILL) Integration policy on September 16, 2025. This policy establishes an accelerated 90-day study-and-approval process for connecting large electricity users (such as AI-driven data centers and manufacturing facilities) to the power grid. The policy was developed through months of stakeholder collaboration and aims to balance the rapid connection of large loads with grid reliability and affordability for the entire region.

## 2. Key Topics
- **High Impact Large Load (HILL) Integration Policy**: New framework for connecting large electricity consumers to the grid
- **Accelerated interconnection process**: 90-day study-and-approval timeline
- **Grid reliability and system integrity**: Ensuring stable operations despite new large loads
- **Stakeholder collaboration**: Multi-month process involving members and Regional State Committee
- **Large load categories**: AI-driven data centers and manufacturing facilities
- **Integrated studies**: Combining transmission service, generation interconnection, load interconnection, and reliability studies into single framework
- **Market efficiency and transparency**: Faster market entry and improved price signals

## 3. Decisions or Actions
- **Board approval**: SPP Board of Directors approved the HILL policy
- **Establishment of 90-day process**: New accelerated study-and-approval timeline for large load interconnections
- **Two connection pathways approved**:
  1. Large loads paired with new generation (on-site or nearby)
  2. Large loads with current or planned generation
- **Integrated framework**: Consolidation of multiple study types into single process
- **Early detection systems**: Implementation of constraint identification protocols
- **Operational preparation**: Enhanced coordination across entities for real-time impacts

## 4. Important Dates
- **September 16, 2025**: Board approval date of HILL policy
- **90-day timeline**: Study-and-approval process duration for eligible projects
- No specific implementation or effective dates mentioned in the content

## 5. Organizations and People Mentioned

### Organizations:
- **Southwest Power Pool (SPP)** - Regional Transmission Organization
- **SPP Board of Directors** - Approving body
- **Regional State Committee** - Participated in policy refinement
- **SPP stakeholders/members** - Collaborated on policy development

### People:
- **Casey Cathey** - SPP Vice President for Engineering
- **Stuart Solomon** - SPP Board Member
- **Derek Wingfield** - Media contact, 501-614-3394, dwingfield@spp.org

### Location:
- Little Rock, Arkansas (SPP headquarters at 201 Worthen Drive)

## 6. Links or References
- **SPP Portal**: Referenced multiple times in navigation
- **OASIS**: Mentioned in navigation
- **High Impact Large Load (HILL) Integration**: Specific program page referenced
- **Markets+**: SPP market program
- **RTO Expansion**: Related initiative
- **Western Services**: Various programs listed
- **SPP Tariff**: Referenced in navigation
- **Contact**: dwingfield@spp.org for media inquiries

## 7. Suggested Tags
- High Impact Large Load (HILL)
- Large Load Interconnection
- Data Centers
- AI Infrastructure
- Grid Reliability
- Transmission Planning
- Generation Interconnection
- Accelerated Approval Process
- Stakeholder Engagement
- SPP Board Action
- Load Growth
- Manufacturing Facilities
- Market Entry
- Regulatory Policy
- September 2025

## 8. Items That May Need Follow-Up

### Policy Implementation:
- **Effective date**: When does the 90-day process become available to applicants?
- **Application procedures**: What are the specific requirements for HILL applicants?
- **Eligibility criteria**: What defines a "large load" or qualifies for HILL treatment?

### Technical Details:
- **Study methodology**: How will the integrated studies be conducted within 90 days?
- **Cost allocation**: How are costs distributed among stakeholders?
- **Generation pairing requirements**: Specific requirements for on-site vs. nearby generation

### Stakeholder Impact:
- **Tariff modifications**: Were tariff changes required or approved alongside this policy?
- **Regional State Committee position**: Was there unanimous support or conditions?
- **Member concerns**: Were there dissenting views or conditions placed on approval?

### Operational Questions:
- **Capacity limits**: Are there caps on total HILL connections or MW thresholds?
- **Queue management**: How does HILL interact with existing interconnection queues?
- **Reliability standards**: What specific reliability criteria must be met?

### Market Implications:
- **Price signal impacts**: How will large loads affect market pricing?
- **Existing customer protection**: Safeguards to prevent cost shifts to existing ratepayers?
- **Long-term planning**: How does this affect SPP's transmission planning processes?

### Documentation Needs:
- **Full policy document**: Access to complete HILL policy and procedures
- **Stakeholder meeting materials**: Records of collaboration and refinement process
- **Board resolution**: Formal approval documentation