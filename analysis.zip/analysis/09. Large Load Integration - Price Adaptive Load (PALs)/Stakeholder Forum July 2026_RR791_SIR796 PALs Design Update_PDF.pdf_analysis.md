# Final Combined Report

# REGULATORY MEETING ANALYSIS REPORT
**Stakeholder Forum July 2026 - RR791/SIR796 PALs Design Update**

---

## 1. Executive Summary

This comprehensive stakeholder forum from July 2026 presents Southwest Power Pool's (SPP) complete design framework for Price Adaptive Loads (PALs) - a new market participation model enabling flexible, price-responsive loads to participate in SPP's markets. PALs represents SPP's response to FERC's Large Load Show Cause Order (EL26-68-000), which identified deficiencies in SPP's tariff regarding flexible large load service. 

The PALs model allows dispatchable loads capable of 5-minute curtailment to zero to participate through non-firm transmission service, utilizing surplus energy while maintaining grid reliability through automatic curtailment during emergency conditions (starting at EEA1). The framework establishes dedicated tariff provisions (Attachment BG, Part VIII), specialized market participation rules, and a distinct cost/settlement structure. PALs are exempt from resource adequacy obligations and network upgrade requirements but pay non-firm transmission rates and contribute to operating reserve costs on a load-ratio share basis.

The initiative aims to improve system utilization, reduce renewable curtailment, and dilute costs for traditional loads while protecting grid reliability through multiple compliance mechanisms including Uninstructed Load Deviation penalties, remote breaker capabilities, and automatic demand bid overrides during capacity scarcity.

---

## 2. Key Topics

### **PALs Service Model & Market Participation**
- New participation option for price-sensitive, always-dispatchable loads alongside existing HILL service options (FIRM, CHILL, PAL)
- Participation in Day-Ahead Market (DAMKT), Real-Time Balancing Market (RTBM), and Reliability Unit Commitment (RUC)
- Demand bid curves up to 10 price/quantity pairs
- Maximum ramp rate capped at 20% of granted PAL capacity per minute
- 5-minute dispatchability requirement with curtailment to zero capability
- No must-offer requirements
- Not required to report outages

### **Demand Bid Price Cap**
- Under evaluation with static vs. dynamic approaches to prevent adverse LMP impacts
- Simulation study targeting July MWG discussion
- Annual evaluation required to maintain alignment with evolving generation mix

### **Reliability & Emergency Protections**
- Automatic curtailment to zero starting in Energy Emergency Alert 1 (EEA1)
- Demand bid override to $0 during capacity scarcity conditions:
  - Resource emergency limits triggered
  - Reliability Registered Demand Response Programs deployment
- PALs may be curtailed but ineligible for OOME (Out-of-Merit Energy) payments
- Emergency Operating Plan update required to reflect EEA1 curtailment policy

### **Compliance Mechanisms**
- Uninstructed Load Deviation (ULD) penalties (Att. AE 6.4.4)
- RUC MWP distribution charges for operating outside tolerance
- Unreserved use penalties when exceeding load limits
- Remote breaker capability requirement
- Tariff violation reporting
- Separate metering from Firm loads and co-located generation mandatory

### **Operating Reserves**
- **PALs increase requirements for:**
  - Regulation-Up
  - Regulation-Down
  - Ramp Capability Down
- **No impact to:** Spinning Reserve, Supplemental Reserve, Ramp Capability Up, Uncertainty Reserve, ILC
- PALs **ineligible** to provide Operating Reserves
- Allocated **load-ratio share** of all Operating Reserve costs

### **Energy Settlement & Make-Whole-Payments**
- Pay LMP for all cleared or metered withdrawals
- **Not compensated at LMP** for load reductions
- **Ineligible for MWP payments** (Make-Whole-Payments)
- Fund load-ratio share of DA MWP and RUC MWP under specific conditions
- Ramped Setpoint Instruction linear across entire Dispatch Interval

### **Transmission Service Framework**
- **New dedicated tariff rules:** Attachment BG and Part VIII
- **Non-Firm Structure:** Hourly peak and off-peak rates capped at monthly rate
- **No Network Upgrades required:** Uses load limits instead
- **90-day study period:** Network Study to establish maximum capacity
- **1-year minimum, 10-year maximum service term**
- **PALs and CHILLS prohibited** at same delivery point
- Service re-directs and secondary market re-sales prohibited
- Non-refundable application fee required

### **Transmission Service Study Requirements**
- Load Connection Study plus 90-day Network Study required
- Evaluates thermal, voltage, and stability constraints
- Establishes load limits based on system constraints
- Separate metering requirements from Firm loads and co-located generation

### **Rate Structure & Cost Allocation**
- Schedule 16 charges based on Schedule 8 Non-Firm Point-to-Point hourly rates
- Billed at hourly peak and off-peak rates during actual usage
- Multiple schedule assessments: 1, 1A, 2, 11, 12, 16, losses, market settlements
- **Charge capped to monthly rate** based on PALs usage
- Load-ratio share of various market uplifts
- Unreserved Use charges when exceeding limits
- 12 consecutive months of non-usage triggers potential termination

### **Resource Adequacy Treatment**
- **No RA obligations** under Attachment AA
- **No impact to Planning Reserve Margin (PRM)**
- Load Responsible Entities not required to secure accredited capacity for PALs
- Excluded from firm load forecasts
- No change to RA framework

### **Benefits Identified**
- Improved system utilization
- Reduced curtailment of renewables and baseload generation
- Diluted costs for traditional loads
- Economic optimization opportunities
- Utilization of surplus energy

---

## 3. Decisions or Actions

### **Recent Policy Changes (since June MWG & PALs Forum):**
1. Ramp rate limit set at **20% of PAL capacity per minute**
2. **All PALs curtailed to zero load starting in EEA1**
3. PAL bid override to **$0** triggered by:
   - Resource emergency limits
   - Reliability Registered Demand Response Programs deployment
4. PALs may be curtailed but **will not receive OOME payments**
5. **Tentatively removed** functionality for dispatching resources to use energy stranded behind GIA limits

### **Established Framework Decisions:**
1. **Eligibility determinations:**
   - PALs ineligible to provide Operating Reserves
   - Ineligible for MWP compensation
   - Ineligible for OOME payments
   - No resource adequacy obligations

2. **Operational parameters:**
   - 5-minute dispatchability to zero requirement
   - No outage reporting requirement
   - No must-offer requirements
   - Ramped Setpoint Instruction linear across Dispatch Interval
   - Generator Assessment Process (GAP) not impacted

3. **Transmission service structure:**
   - Non-firm service model adopted
   - No network upgrades requirement (load limits used instead)
   - 90-day study timeframe established
   - Separate metering mandate
   - 1-year minimum, 10-year maximum service term
   - PALs and CHILLS prohibited at same delivery point

4. **Cost allocation framework:**
   - Load-ratio share of Operating Reserve costs
   - Load-ratio share of various market uplifts
   - Unreserved Use charges when exceeding limits
   - Hourly peak/off-peak rates capped at monthly rate

### **Pending Actions:**
- Simulation study to determine optimal Demand Bid Price Cap approach (static vs. dynamic)
- Emergency Operating Plan update to reflect EEA1 curtailment policy
- Analysis results discussion targeted for July MWG
- Stakeholder feedback collection and incorporation

---

## 4. Important Dates

### **Historical/Reference Dates:**
- **March 18, 2026:** PALs Use Case Roundtable Discussion
- **March 27, 2026:** PALs Use Case Roundtable Discussion (NH3 topic)
- **July 2026:** Current stakeholder forum presentation date
- **July 2026:** Target date for MWG discussion of simulation analysis results

### **Approval Timeline (2026):**
- **August 18:** MWG

---

# Partial Chunk Reports

# Chunk 1 Analysis

# REGULATORY MEETING ANALYSIS REPORT

## 1. Executive Summary

This document presents SPP's (Southwest Power Pool) stakeholder forum from July 2026 regarding RR791/SIR796 - the Price Adaptive Loads (PALs) design update. PALs is a new participation model that allows flexible loads to participate in SPP markets by adjusting consumption based on real-time pricing. This initiative responds to FERC's Large Load Show Cause Order (EL26-68-000) which found SPP's tariff deficient in addressing flexible large loads. The PALs model offers non-firm transmission service for dispatchable loads that can curtail to zero within 5 minutes, creating opportunities to utilize surplus energy while protecting grid reliability through automatic curtailment during emergency conditions.

## 2. Key Topics

- **PALs Service Model**: A specialized participation option for price-sensitive, always-dispatchable loads alongside existing HILL (High Impact Large Load) service options (FIRM, CHILL, and PAL)

- **Market Participation**: PALs participate in Day-Ahead Market (DAMKT), Real-Time Balancing Market (RTBM), and Reliability Unit Commitment (RUC) with demand bid curves up to 10 price/quantity pairs

- **Demand Bid Price Cap**: Under evaluation with static vs. dynamic approaches to prevent adverse LMP impacts; simulation study targeting July MWG discussion

- **Reliability Protections**: 
  - Automatic curtailment to zero starting in Energy Emergency Alert 1 (EEA1)
  - Demand bid override to $0 during capacity scarcity conditions
  - 20% ramp rate limit per minute
  - 5-minute dispatchability requirement

- **Compliance Mechanisms**: Multiple layers including Uninstructed Load Deviation (ULD) penalties, RUC MWP distribution charges, unreserved use penalties, remote breaker capability, and tariff violation reporting

- **Benefits**: Improved system utilization, reduced curtailment of renewables/baseload, diluted costs for traditional loads, and economic optimization

## 3. Decisions or Actions

**Recent Policy Changes (since June MWG & PALs Forum):**
- Ramp rate limit set at 20% of PAL capacity per minute
- All PALs curtailed to zero load starting in EEA1
- PAL bid override to $0 triggered by Resource emergency limits and Reliability Registered Demand Response Programs deployment
- PALs may be curtailed but will not receive OOME (Out-of-Merit Energy) payments
- Tentatively removed functionality for dispatching resources to use energy stranded behind GIA limits

**Pending Actions:**
- Simulation study to determine optimal Demand Bid Price Cap approach (static vs. dynamic)
- Emergency Operating Plan update to reflect EEA1 curtailment policy
- Analysis results discussion targeted for July MWG

## 4. Important Dates

- **March 18th**: PALs Use Case Roundtable Discussion
- **March 27th**: PALs Use Case Roundtable Discussion (NH3 topic)
- **July 2026**: Target date for MWG discussion of simulation analysis results
- **July 2026**: Current stakeholder forum presentation date
- **Annual**: Demand Bid Price Cap evaluation to maintain alignment with evolving generation mix

## 5. Organizations and People Mentioned

**Individuals:**
- **Jonathan Hathhorn** - Lead Engineer, Market Design
- **Steve Davis** - Manager, Settlements - Transmission

**Organizations:**
- **SPP (Southwest Power Pool)** - Regional Transmission Organization
- **FERC (Federal Energy Regulatory Commission)** - Regulatory authority
- **MWG (Markets and Operations Working Group)** - Stakeholder working group
- **PJM** - Referenced in context of Co-Location Order

**FERC Docket:**
- EL26-68-000 (Large Load Show Cause Order)

## 6. Links or References

**Tariff/Protocol References:**
- Att. AE 2.2, 2.26 - PALs definitions and requirements
- Att. AE 4.3.4, 4.3.4.1 - Demand bid parameters and capacity shortage procedures
- Att. AE 5.1, 5.2 - Day-Ahead Market provisions
- Att. AE 6.1, 6.2, 6.4.4 - Real-Time Market and deviation provisions
- Att. AE 8.6.7 - RUC MWP distribution charges
- Protocols 4.2.3.4, 4.3.1, 4.3.2, 4.4.1, 4.4.2, 4.4.3.8 - Market participation protocols
- Protocols 6.2.11 - Metering requirements

**Key Documents:**
- RR791_SIR796 - PALs regulatory revision
- FERC PJM Co-Location Order
- Emergency Operating Plan (pending update)

## 7. Suggested Tags

`PALs`, `Price-Adaptive-Loads`, `SPP`, `RR791`, `SIR796`, `FERC-EL26-68-000`, `Flexible-Loads`, `Large-Loads`, `HILL`, `CHILL`, `Demand-Response`, `Market-Design`, `Transmission-Service`, `Non-Firm-Service`, `Energy-Emergency-Alert`, `Demand-Bid-Price-Cap`, `Grid-Reliability`, `Real-Time-Market`, `Day-Ahead-Market`, `Uninstructed-Load-Deviation`, `Stakeholder-Forum`, `July-2026`, `Data-Centers`, `Renewable-Integration`

## 8. Items That May Need Follow-Up

1. **Demand Bid Price Cap Methodology** - Awaiting simulation study results and decision between static vs. dynamic approach at July MWG meeting

2. **Emergency Operating Plan Updates** - Must be revised to reflect EEA1 automatic curtailment policy for PALs

3. **FERC Show Cause Order Response** - SPP must demonstrate whether PALs adequately addresses FERC's four categories of concern, particularly regarding flexible large load service gaps

4. **Stakeholder Feedback Collection** - Open discussion and feedback solicitation from stakeholders on PALs design

5. **Stranded Energy Behind GIA Limits** - Functionality tentatively removed; may need final decision confirmation

6. **Annual Bid Cap Evaluation Process** - Establish recurring review process to align with evolving generation mix

7. **RUC MWP Distribution Charge Implementation** - Confirm allocation methodology for operating outside tolerance (Att. AE 8.6.7)

8. **Remote Breaker Capability Requirements** - Technical implementation details and emergency protocols need definition

9. **Use Case Roundtable Follow-up** - Review outcomes from March 18th and 27th discussions and incorporate into policy development

10. **Uninstructed Load Deviation (ULD) Implementation** - Planned for Att. AE 6.4.4; confirm final tariff language and settlement system readiness

11. **Co-Location Framework Compliance** - Verify PALs addresses FERC's co-location concerns from Show Cause Order

12. **Transmission Cost Transparency** - Address FERC's concern about transparency into transmission cost and cost-shifting risk for PALs participants

---

# Chunk 2 Analysis

# Regulatory Meeting Analysis Report
## Stakeholder Forum July 2026 - RR791/SIR796 PALs Design Update

---

## 1. Executive Summary

This document presents a comprehensive design update for Price Adaptive Load Service (PALs) within the SPP market framework. The presentation covers market participation rules, operating reserves requirements, energy settlement procedures, transmission service structures, and resource adequacy requirements. PALs are positioned as interruptible/flexible load resources that can respond to price signals without traditional firm load obligations. The framework establishes separate tariff rules, non-firm transmission service rates, and specific operational parameters while exempting PALs from resource adequacy obligations and network upgrade requirements.

---

## 2. Key Topics

### Operating Reserves and ILC
- **PALs increase requirements for:**
  - Regulation-Up
  - Regulation-Down
  - Ramp Capability Down
- **PALs do not change requirements for:**
  - Spinning Reserve, Supplemental Reserve, Ramp Capability Up, Uncertainty Reserve, ILC
- PALs are **ineligible** to provide Operating Reserves
- PALs are allocated a **load-ratio share** of all Operating Reserve costs

### Energy Settlement and Make-Whole-Payments
- Pay LMP for all cleared or metered withdrawals
- **Not compensated at LMP** for load reductions
- PALs can be issued curtailments; **ineligible for OOME payments**
- **Ineligible to receive MWPs** (Make-Whole-Payments)
- Fund load ratio share of DA MWP and RUC MWP under specific conditions

### Market and Operational Rules
- **Max ramp rate capped at 20%** of granted service amount per minute
- Ramped Setpoint Instruction linear across entire Dispatch Interval
- **Not required to report outages**
- Generator Assessment Process (GAP) not impacted
- **No must-offer requirements**

### Transmission Service Framework
- **New dedicated tariff rules** (Attachment BG and Part VIII)
- **Non-Firm Structure:** Hourly peak and off-peak rates, capped at monthly rate
- **No Network Upgrades** required; uses load limits instead
- **90-day study** to establish maximum capacity
- **1-year minimum term** of service required
- **PALs and CHILLS at same delivery point prohibited**

### Transmission Service Study
- Requires Load Connection Study and 90-day Network Study
- Evaluates thermal, voltage, and stability constraints
- Establishes load limits based on system constraints
- Requires separate metering from Firm loads and co-located generation
- Non-refundable application fee required

### Rate Structure
- Billed at hourly peak and off-peak rates during actual usage
- Schedule 16 charges based on Schedule 8 Non-Firm Point-to-Point hourly rates
- Multiple schedule assessments (1, 1A, 2, 11, 12, 16, losses, market settlements)
- **Charge capped to monthly rate** based on PALs usage
- 1-year minimum, 10-year maximum term
- Service re-directs and secondary market re-sales prohibited

### Resource Adequacy Requirements
- **No RA obligations** under Attachment AA
- **No impact to Planning Reserve Margin (PRM)**
- Load Responsible Entities not required to secure accredited capacity for PALs
- No change to RA framework

---

## 3. Decisions or Actions

### Established Framework Decisions:
1. **Eligibility determinations:**
   - PALs ineligible to provide Operating Reserves
   - Ineligible for MWP compensation
   - Ineligible for OOME payments

2. **Operational parameters set:**
   - Max ramp rate: 20% of granted service per minute
   - No outage reporting requirement
   - No must-offer requirements

3. **Transmission service structure:**
   - Non-firm service model adopted
   - No network upgrades requirement
   - 90-day study timeframe established
   - Separate metering mandate
   - 1-year minimum service term

4. **Cost allocation:**
   - Load-ratio share of Operating Reserve costs
   - Load-ratio share of various market uplifts
   - Unreserved Use charges when exceeding limits

5. **Resource adequacy treatment:**
   - No RA obligations under Attachment AA
   - Excluded from firm load forecasts

---

## 4. Important Dates

### Approval Timeline:
- **August 18, 2026:** MWG (Market Working Group)
- **September 2, 2026:** ORWG (Operating Reliability Working Group)
- **September 23, 2026:** SAWG (Settlements & Billing Working Group)
- **September 24, 2026:** RTWG (Real-Time Working Group)
- **September 30, 2026:** TWG.ESWG (Transmission Working Group/Economic Studies Working Group)
- **October 1, 2026:** CAWG (Credit & Accounting Working Group)
- **October 13, 2026:** MOPC (Markets and Operations Policy Committee)
- **November 16, 2026:** RSC (Regional State Committee)

### Service Terms:
- **1-year minimum** service term
- **10-year maximum** service term with renewal option
- **12 consecutive months** of non-usage triggers potential termination
- **90-day** Network Study period

---

## 5. Organizations and People Mentioned

### People:
- **Jonathan Hathhorn** - Lead Engineer, Market Design (jhathhorn@spp.org)
- **Steve Davis** - Manager, Settlements - Transmission (sdavis@spp.org)

### Organizations/Groups:
- **SPP** (Southwest Power Pool) - primary organization
- **MWG** (Market Working Group)
- **ORWG** (Operating Reliability Working Group)
- **SAWG** (Settlements & Billing Working Group)
- **RTWG** (Real-Time Working Group)
- **TWG.ESWG** (Transmission Working Group/Economic Studies Working Group)
- **CAWG** (Credit & Accounting Working Group)
- **MOPC** (Markets and Operations Policy Committee)
- **RSC** (Regional State Committee)
- **PALS Transmission Customers (TC)**
- **Load Responsible Entities (LREs)**
- **High Impact Large Load (HILL)** entities

---

## 6. Links or References

### Protocol References:
- **Protocols 4.1.3** - Operating Reserves context
- **Protocols 6.2.11** - Energy settlement, max ramp rate, outage reporting
- **Protocols 4.4.3** - Ramped Setpoint Instructions

### Attachment References:
- **Attachment AE 8.5.1** - Operating Reserves allocation, market distributions
- **Attachment AE 2.26** - Curtailments
- **Attachment AE 8.5.10** - DA MWP funding
- **Attachment AE 8.6.7** - RUC MWP funding
- **Attachment AE 2.1.11** - Must-offer requirements
- **Attachment AE** - General requirements
- **Attachment BG** - New tariff framework
- **Attachment BA** - High Impact Large Load (HILL) requirements
- **Attachment AA** - Resource Adequacy

### Tariff/Schedule References:
- **Part VIII** - Transmission framework
- **Schedule 8** - Non-Firm Point-to-Point hourly rates (basis)
- **Schedule 16** - PALs charges (new)
- **Schedules 1, 1A, 2, 11, 12** - Various assessments

### Business Practice References:
- **Business Practice 10000 Section 3.6** - Generator Assessment Process

### Document References:
- **RR791** - Revision Request number
- **SIR796** - System Impact Request number
- **OASIS** - Open Access Same-Time Information System

---

## 7. Suggested Tags

- Price Adaptive Load Service (PALs)
- PALS
- Market Design
- Operating Reserves
- Transmission Service
- Non-Firm Service
- Energy Settlement
- Make-Whole-Payments
- Resource Adequacy
- Load Response
- Demand Response