# REGULATORY MEETING ANALYSIS REPORT

## 1. Executive Summary

This document presents SPP's (Southwest Power Pool) proposal for a new Price Adaptive Loads (PALs) participation model (RR999_SIR796) to be discussed at the June 2026 Stakeholder Forum. PALs is a specialized market participation framework designed for flexible, always-dispatchable demand that can rapidly curtail to zero and operate on price-driven load profiles. The service is structured as non-firm transmission with mandatory price-sensitive flexibility and no capacity requirements. Key benefits include expanded market participation, reduced transmission rates, improved baseload resource utilization, and better utilization of surplus energy. The proposal requires modifications to multiple tariff sections and governing documents, with an approval timeline running through various working groups from August through October 2026.

## 2. Key Topics

- **PALs Market Design**: Specialized participation model for flexible demand resources with rapid curtailment capabilities
- **Market Participation Parameters**: Demand bid curves, ramp rates, maximum daily/hourly withdrawal limits, SCADA-based real-time limits
- **Day-Ahead and Real-Time Operations**: Integration into DAMKT, RUC, and RTBM with price-sensitive clearing governed by Demand Bid Price Cap
- **System Reliability Protections**: Mandatory full dispatchability, remote breaker capability, real-time telemetry requirements
- **Transmission Service Structure**: Non-firm transmission service (Priority 2) with per-MW usage-based charging
- **Demand Bid Price Cap**: Two approaches under consideration (static vs. dynamic cap) to limit market impact
- **Rate Structure Options**: Four rate options being debated (existing non-firm hourly rates, average hourly rate, off-peak hourly rate, or MWh rate)
- **Eligibility Requirements**: Single-site, separately metered, non-critical commercial/industrial load with curtailment capability
- **Settlement and Charges**: PALs pay LMP for withdrawals, ineligible for make-whole payments, allocated load-ratio share of operating reserve costs

## 3. Decisions or Actions

**Decisions Needed:**
- Selection of Demand Bid Price Cap approach (static vs. dynamic)
- Final transmission rate structure selection among four options
- Determination of charge capping methodology for higher-tiered rates
- Resolution of whether PALs and CHILLS can coexist at same delivery point (currently proposed as not allowed)

**Actions Required:**
- SPP to conduct simulation study to determine optimal $/MWh bid cap
- Annual assessment of generation mix to determine if bid cap update needed
- Stakeholder feedback collection on PALs design
- Study cost billing and non-refundable application fee implementation
- Development of new tariff sections and attachments

## 4. Important Dates

**Approval Timeline (2026):**
- **August 18**: MWG (Market Working Group)
- **September 2**: ORWG (Operating Reliability Working Group)
- **September 23**: SAWG (Settlements and Billing Working Group)
- **September 24**: RTWG (Resource Adequacy TWG)
- **September 30**: TWG.ESWG (Transmission Working Group/Economic Studies Working Group)
- **October 1**: CAWG (Cost Allocation Working Group)
- **October 13**: MOPC (Markets and Operations Policy Committee)

**Other Timeline Elements:**
- Minimum service term: 1 year
- SPP may terminate for non-usage of 1 year or more
- 90-day study period for Network Study
- Presentation date: June 2026

## 5. Organizations and People Mentioned

**People:**
- **Jonathan Hathhorn** - Lead Engineer, Market Design (jhathhorn@spp.org)
- **Steve Davis** - Manager, Settlements - Transmission (sdavis@spp.org)

**Organizations:**
- **SPP (Southwest Power Pool)** - Primary organization
- **FERC (Federal Energy Regulatory Commission)** - Mentioned as enforcement authority for tariff violations
- **Transmission Operators** - Referenced for breaker control requirements
- **Transmission Owners** - Stakeholder group requested for input on rate structure

**Working Groups/Committees:**
- MWG, ORWG, SAWG, RTWG, TWG.ESWG, CAWG, MOPC

## 6. Links or References

**Regulatory References:**
- RR999_SIR796 (Price Adaptive Load revision request)
- RR774 (referenced regarding Resource & PAL co-location)
- Attachment AE (requirements)
- Attachment BA (HILL applicability)
- Attachment BC (similar structure referenced)
- New Attachment BG (to be created)
- New Part VIII (to be created)
- Schedule 16 (new schedule for PALS)
- Schedule 8, 11 (non-firm hourly rates)
- Schedules 1, 1A, 2, 11, 12 (rate schedules)
- Modified sections: Section 34.1, Schedule 11, Attachments L, P, and T

**Other Documents:**
- Resource Adequacy
- BP 8100
- BP 7850
- ITP Manual
- CPP Manual
- OASIS (transmission reservation system)

## 7. Suggested Tags

- Price Adaptive Loads
- PALs
- Market Design
- Non-Firm Transmission
- Demand Response
- Market Participation
- SPP Markets
- Transmission Service
- Real-Time Balancing Market
- Day-Ahead Market
- Reliability Unit Commitment
- Demand Bid Cap
- Settlement
- RR999_SIR796
- Flexible Load
- Grid Optimization
- Surplus Energy
- Operating Reserves

## 8. Items That May Need Follow-Up

**Technical/Operational:**
1. **Simulation study results** for optimal Demand Bid Price Cap determination
2. **Co-location rules** with generation resources (contingent on RR774 approval)
3. **Remote breaker operation protocols** and emergency response procedures
4. **SCADA telemetry requirements** and implementation specifications
5. **Settlement meter accuracy** standards for 5-minute revenue-quality metering

**Policy/Regulatory:**
1. **Final rate structure decision** - stakeholder input needed on four rate options
2. **Charge capping methodology** for usage-based pricing
3. **Annual bid cap reassessment process** and trigger criteria for updates
4. **FERC filing requirements** for tariff violations and reporting procedures
5. **PALs/CHILLS co-existence policy** at same delivery point

**Implementation/Timeline:**
1. **Working group approval progression** through seven groups (August-October 2026)
2. **OASIS system modifications** for PALs-specific TSR records
3. **Study process implementation** (Load Connection Study and Network Study procedures)
4. **Service agreement templates** development (PAL Service Agreement and PALS Operating Agreement)
5. **Transition plan** for existing customers potentially converting to PALs service

**Stakeholder Engagement:**
1. **Transmission Owner feedback** on rate construct preferences
2. **Market participant concerns** regarding market impact and LMP effects
3. **Eligibility criteria clarification** for specific customer types
4. **Study cost allocation** and non-refundable fee structure acceptance
5. **Operational experience** feedback after initial implementation period