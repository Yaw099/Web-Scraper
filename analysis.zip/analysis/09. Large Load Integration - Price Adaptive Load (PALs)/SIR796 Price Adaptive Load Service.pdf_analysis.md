# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document is an SPP (Southwest Power Pool) Initiative Submission Form proposing a new "Price Adaptive Load Service" (Initiative #796). Submitted by SPP staff member Ainsley Anderson on September 16, 2025, the initiative proposes creating a product allowing load entities to bid price-sensitive thresholds in the Real-Time Balancing Market, similar to existing Day-Ahead Market capabilities. The initiative would also introduce a usage-based Transmission Service billing structure. This is categorized as a high-complexity initiative requiring significant system changes and governing document modifications, with an anticipated start in Q4 2025 and Executive Committee approval targeted for Q4 2026.

## 2. Key Topics

- **Price-Sensitive Demand Bidding**: Extension of existing Day-Ahead Market price-sensitive demand capabilities to Real-Time Balancing Market
- **Usage-Based Billing**: New Transmission Service billing structure based on actual usage
- **Market Design Enhancement**: Expansion of demand-side participation mechanisms in real-time operations
- **Power Balance Optimization**: Mechanism to help balance power during high-price shortage events
- **Cost Management**: Tool for load entities to manage exposure to high LMP (Locational Marginal Pricing) costs
- **Strategic Alignment**: Initiative aligns with SPP's "Future Grid" strategic plan objective

## 3. Decisions or Actions

- **Initiative Submission**: Formally submitted through SPP Request Management System under "SPP Roadmap" category
- **Classification Determinations**:
  - Involves governing document changes (both corrections/clarifications AND new/enhanced language)
  - Requires member-facing system/process changes
  - Impacts reliability
  - Involves FERC action
  - Supports SPP BOD Directive/Strategic Plan
- **Prioritization**: Marked as "Directed" category, no additional prioritization needed
- **Complexity Ratings**: All rated as "High" (Design, Implementation, and Operational Impact)

## 4. Important Dates

- **Submission Date**: September 16, 2025
- **Desired Start Quarter**: Q4 2025
- **Target Executive Committee Approval**: Q4 2026
- **SPP Staff Review Timeline**: Within 5 business days of submission for posting to SPP.org

## 5. Organizations and People Mentioned

**People:**
- **Ainsley Anderson** - Submitter, Southwest Power Pool staff (ajanderson@spp.org)

**Organizations:**
- **Southwest Power Pool (SPP)** - Submitting organization and RTO
- **FERC** - Federal Energy Regulatory Commission (regulatory authority)
- **NERC** - North American Electric Reliability Corporation
- **NAESB** - North American Energy Standards Board
- **SPP Executive Committee** - Approval authority
- **SPP Board of Directors (BOD)** - Strategic directive authority

## 6. Links or References

**Systems/Processes:**
- SPP Request Management System (RMS)
- SPP.org - SPP Roadmap page
- Real-Time Balancing Market
- Day-Ahead Market

**Contact:**
- strategicservices@spp.org - Questions regarding initiative submissions

**Documents Referenced:**
- SPP Tariff
- Protocols
- Planning Criteria
- Operating Criteria
- Business Practices

## 7. Suggested Tags

- Price Adaptive Load
- Real-Time Balancing Market
- Demand Response
- Price-Sensitive Bidding
- Usage-Based Billing
- Transmission Service
- Market Enhancement
- Load Management
- LMP Cost Management
- Future Grid
- SPP Initiative 796
- Market Design
- Demand-Side Participation
- Power Balance

## 8. Items That May Need Follow-Up

1. **System Identification**: "Potential Impacted System(s)" listed as "TBD" - requires specification of which systems will be modified

2. **Compliance Risk Assessment**: "Known Risks/Impacts" section mentions "Compliance:" but provides no details - needs completion

3. **Related Initiatives**: Section for contingent/related initiatives is blank - should verify if any dependencies exist

4. **Supporting Documentation**: No mention of whether white papers, analysis, or presentations were attached to the RMS ticket

5. **Stakeholder Education Sessions**: Submitter agreed to participate in education/evaluation sessions - scheduling and participation tracking needed

6. **Secondary Functional Area Coordination**: Multiple areas impacted (Operations, Oversight, Supply Adequacy, Planning, Transmission Service) - coordination plan needed

7. **FERC Action Clarification**: Initiative box checked for "FERC Action or involves NERC/NAESB standard" but "NERC/NAESB Compliance Impact" marked "No" - apparent inconsistency needs clarification

8. **Implementation Timeline**: 12-month window between start and approval seems aggressive given high complexity ratings across all categories

9. **Cost-Benefit Analysis**: Expected benefits described qualitatively - quantitative analysis may be needed for stakeholder approval

10. **Market Participant Impact Assessment**: Given this affects billing and market participation, detailed impact assessment for various participant types needed