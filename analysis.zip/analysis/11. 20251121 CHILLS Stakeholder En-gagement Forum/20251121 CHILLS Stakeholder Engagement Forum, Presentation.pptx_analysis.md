# Final Combined Report

# COMPREHENSIVE REGULATORY MEETING ANALYSIS REPORT
**Southwest Power Pool (SPP) CHILLS Stakeholder Engagement Forum**

**Meeting Date:** November 21, 2025 (1:00 PM – 4:00 PM)  
**Source:** 20251121 CHILLS Stakeholder Engagement Forum, Presentation.pptx.txt

---

## 1. EXECUTIVE SUMMARY

Southwest Power Pool (SPP) held a comprehensive stakeholder engagement forum on November 21, 2025, to present its revised proposal for handling Conditional High Impact Large Loads (CHILLS) through Revision Request 720 (RR720) and the companion Price Adaptive Load Service (PALS) initiative (SIR796). This framework is designed to support large load growth—including data centers and industrial customers—while addressing reliability and market concerns.

The CHILLS proposal has been narrowed in scope following earlier stakeholder feedback and MOPC recommendations, now focusing on a "Supported CHILL Framework" with two conditional service options:
- **Option 1 (Transmission Limitations)**: For entities with sufficient Designated Network Resources (DNRs) awaiting transmission upgrades
- **Option 2 (Generation-Supported)**: Requires accredited equivalent supporting HILLGA generation to be built and operational before service

Additionally, SPP introduced the Price Adaptive Load Service (PALS), a flexible, non-firm transmission service allowing price-sensitive loads to submit demand bids in Day-Ahead and Real-Time markets. This market-based alternative is not limited to large loads and enables adaptive engagement during low-price periods.

The presentation outlined an ambitious stakeholder engagement timeline with 100+ touchpoints across 10 working groups over a 6-month period (October 2025 - April 2026). SPP sought feedback on the refined approach while addressing extensive stakeholder concerns regarding cost causation, curtailment risk, resource adequacy, and impacts to existing generation resources.

---

## 2. KEY TOPICS

### A. CHILLS Framework Structure

**Three Service Types:**
1. **Conditional HILL (CHILL)** - Curtailable long-term transmission service
2. **Firm HILL (NITS or PTP)** - Firm transmission service
3. **Price Adaptive Load (PAL)** - Real-time pricing-based service

**Two CHILL Service Options:**
- **Option 1 (Transmission Limitations)**: 
  - For entities with sufficient Designated Network Resources (DNRs)
  - Awaiting transmission upgrades
  - Capacity assessment determines if CHILL can be served
  
- **Option 2 (Generation-Supported)**:
  - Requires accredited equivalent supporting HILLGA generation
  - Generation must be built and operational before service
  - No footprint cap (Option 2 explicitly states "no cap")
  - Prescribed timelines for conversion from CHILL to firm transmission service

**Gap Closure:**
RR720 addresses a study gap under RR696 where loads couldn't establish delivery points without existing DNRs or planned generation.

### B. Price Adaptive Load Service (PALS)

**Concept:** Flexible, non-firm transmission service for price-sensitive loads

**Key Features:**
- Allows loads to submit price-sensitive demand bids in Day-Ahead (DA) and Real-Time (RT) markets
- Alternative to CHILLS focusing on market-based integration
- Not limited to large loads
- Enables adaptive engagement during low-price periods
- Requires decisions on bid cap methodology and transmission service rates

### C. Market & Operations Integration

**SCUC Integration:**
- CHILL capacity curtailments in Security-Constrained Unit Commitment
- Specific curtailment protocols being developed
- Net impact calculations for system CHILL curtailments
- Curtailment advisory process (up to 7 days advance vs. real-time)

**Tariff Structure:**
- **Attachment AQ** - Load connection submission process
- **Attachment AX** - Requires planned generation for DNRs
- **Attachment BC** - Allows load study without DNRs (new with RR720); includes opportunity for HILL study without sufficient DNRs
- **Attachment BA** - Delivery point establishment

### D. Major Stakeholder Concerns Addressed

**Impact Concerns:**
- Effects on existing generation and emissions-limited/permit-limited resources
- Energy market price impacts and LMP impacts
- Curtailment intensity, frequency, and predictability
- TCR topology changes
- Outage coordination process impacts
- Financial exposure to price spikes (PALS)

**Process Concerns:**
- Resource adequacy circumvention
- Transmission service loopholes (raised by MMU)
- ARR/TCR participation limitations
- Service limit enforcement (7-year limit)
- Cost causation and uplift charge assessment

**Value Proposition Concerns:**
- Undefined target customer base for PALS
- Unclear value compared to existing RR696 framework
- Need for RR720 justification

### E. Stakeholder Engagement Structure

**Scale of Engagement:**
- 100+ total touchpoints planned
- 6-month structured rollout (October 2025 - April 2026)
- 10 Working Groups involved: MOPC, MWG, SAWG, RSC, ORWG, CAWG, RTWG, TWG, ESWG, SPC

**Forum Schedule:**
- Multiple forums scheduled from November 2025 through April 2026
- Combination of education sessions, approval meetings, and stakeholder forums

---

## 3. DECISIONS OR ACTIONS

### A. Decisions Made

1. **MOPC Endorsement**: MOPC endorsed the CHILLS policy moving forward with expectation that key concerns are mitigated
2. **Scope Narrowing**: Scope narrowed to "Supported CHILL Framework" in response to stakeholder feedback from MWG

### B. Decisions Requested

1. **PALS Bid Cap Method** - Determination needed on threshold for maximum bid amounts in DA and RT to address permit-limited resource concerns; stakeholders requesting straw proposals with consideration of:
   - Seasonal variability
   - Excess capacity
   - Gas prices

2. **PALS Transmission Service Rate** - Decision needed on whether to base on energy impact or other factors

3. **Resource Adequacy Modeling** - Modeling method for PAL needs stakeholder discussion (LOLE modeling, PRM considerations)

4. **Load Factor Cap Options** - Stakeholders requesting potential options to be considered

### C. Actions Requested from Stakeholders

- Submit feedback on the refined CHILLS approach and modified supported CHILL provision
- Provide broader input to ensure proposal is workable and aligned with operational and market impacts
- Submit questions via chat, surveys, or Q&A discussion
- Provide additional recommendations to achieve consensus and approval
- Complete post-forum survey: https://app.keysurvey.com/f/41813577/4411/

### D. Pending SPP Actions

1. **Market Impact Analysis**: Staff continues to evaluate CHILLS impacts to market and predictability of curtailments
2. **LMP Impact Analysis**: SPP staff analysis in progress; results to be brought to stakeholder groups with TCR impact discussion
3. **Policy Updates**: SPP staff developing updates to existing policies to account for CHILLS
4. **Language Modifications**: SPP plans to modify RR720 language through RR process once RC outage coordination methodology converts to business practice
5. **Straw Proposals**: Development of straw proposals for bid cap methodology

---

## 4. IMPORTANT DATES

### Stakeholder Forums
- **November 21, 2025** - CHILLS/PALS Forum (current meeting)
- **December 2, 2025** - Forum
- **January 12, 2026** - Forum
- **January 30, 2026** - Forum
- **February 27, 2026** - Forum
- **March 27, 2026** - PALS Forum
- **April 10, 2026** - Forum

### Engagement Timeline Phases

**October - November 2025**: CHILLS/PALS Education
- 11 education sessions
- 2 forums

**December 2025**: CHILLS Approval/PALS Education
- 7 approval meetings
- 4 education sessions
- 1 forum

**January 2026**: CHILLS MOPC
- 4 approval sessions
- 4 PALS education sessions

**February - March 2026**: PALS Education/

---

# Partial Chunk Reports

# Chunk 1 Analysis

# Regulatory Meeting Analysis Report

## 1. Executive Summary

This presentation outlines SPP's (Southwest Power Pool) revised proposal for handling Conditional High Impact Large Loads (CHILLS) through Revision Request 720 (RR720) and the companion Price Adaptive Load Service (PALS) initiative (SIR796). The meeting, held November 21, 2025, sought stakeholder feedback on a modified framework designed to support large load growth (including data centers and industrial customers) while addressing reliability and market concerns. The proposal has been narrowed in scope following earlier stakeholder feedback and MOPC recommendations. SPP is positioning this framework to reliably and economically support large load growth through two conditional service options: one for loads with adequate generation awaiting transmission upgrades (Option 1), and another requiring supporting generation to be built and operational (Option 2).

## 2. Key Topics

- **CHILLS Framework**: Two-option approach for conditional transmission service for High Impact Large Loads
  - **Option 1 (Transmission Limitations)**: For entities with sufficient Designated Network Resources (DNRs) awaiting transmission upgrades
  - **Option 2 (Generation-Supported)**: Requires accredited equivalent supporting HILLGA generation before service

- **Gap Closure**: RR720 addresses a study gap under RR696 where loads couldn't establish delivery points without existing DNRs or planned generation

- **Three Service Types**: 
  - Conditional HILL (CHILL) - curtailable long-term transmission service
  - Firm HILL (NITS or PTP) - firm transmission service
  - Price Adaptive Load (PAL) - real-time pricing-based service

- **Market & Operations Integration**: CHILL capacity curtailments in SCUC (Security-Constrained Unit Commitment) with specific curtailment protocols

- **Stakeholder Concerns Addressed**:
  - Energy market price impacts
  - Curtailment intensity and frequency
  - Impact to permit-limited generators

## 3. Decisions or Actions

**Decisions Made:**
- MOPC endorsed the CHILLS policy moving forward with expectation that key concerns are mitigated
- Scope narrowed to "Supported CHILL Framework" in response to stakeholder feedback

**Actions Requested:**
- SPP seeking stakeholder feedback on the refined approach and modified supported CHILL provision
- Need broader input to ensure proposal is workable and aligned with operational and market impacts
- Stakeholders to submit questions via chat, surveys, or Q&A discussion
- Additional recommendations requested to achieve consensus and approval

**Pending Actions:**
- Staff continues to evaluate CHILLS impacts to market and predictability of curtailments
- Future approval discussions planned for subsequent sessions

## 4. Important Dates

- **November 21, 2025**: Stakeholder Engagement Forum (1:00 PM – 4:00 PM)
- **Timeline**: Referenced but specific dates for next steps not provided in this chunk

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)** - Primary organization hosting the forum
- **MOPC** (Markets and Operations Policy Committee) - Endorsed the policy
- **MWG** (Market Working Group) - Recommended narrowing CHILL provision scope
- **Transmission Owners** - Beneficiaries of additional transmission revenue

**People:**
- **Adriane Barnes** - Communications; Administrative Items and Agenda
- **Yasser Bahbaz** - Sr. Director, Operations; CHILL Solution presenter
- **Ainsley Anderson** - Market Policy Coordination; Timeline and Next Steps

## 6. Links or References

**Regulatory Documents:**
- **RR720** - Revision Request for Conditional High-Impact Large Loads (CHILLS)
- **RR696** - HILL/HILLGA framework (existing baseline)
- **SIR796** - PALS (Price Adaptive Load Service)

**Tariff Attachments:**
- **Attachment AQ** - Load connection submission process
- **Attachment AX** - Requires planned generation for DNRs
- **Attachment BC** - Allows load study without DNRs (new with RR720)
- **Attachment BA** - Delivery point establishment

**Other References:**
- **Business Practice 7250** - Behind-the-meter generation
- **HILLGA** - High Impact Large Load Generator Aggregation
- **DISIS/CPP and Agg Study** - Generation conversion to DNR processes
- **SCUC** - Security-Constrained Unit Commitment
- **CODRPs** - Conservative Operation Demand Response Programs
- **EEA2** - Energy Emergency Alert Level 2
- **ATRR** - Annual Transmission Revenue Requirement

## 7. Suggested Tags

- CHILLS
- Conditional_High_Impact_Large_Loads
- RR720
- SIR796
- PALS
- Large_Load_Interconnection
- Data_Centers
- Transmission_Service
- SPP
- HILLGA
- Curtailable_Service
- Generation_Support
- Market_Policy
- Stakeholder_Engagement
- MOPC
- Designated_Network_Resources
- Transmission_Upgrades
- Load_Study_Process

## 8. Items That May Need Follow-Up

**Technical/Operational:**
1. **Curtailment Predictability**: Staff continues to evaluate impacts to market and predictability of curtailments - metrics and assessment timeline needed
2. **Capacity Assessment Methodology**: Details on how capacity assessments determine if CHILL can be served under Option 1
3. **Net Impact Calculations**: Clarification on "net impact for system CHILL curtailments" methodology
4. **SCUC Integration Details**: Full implementation details for CHILL capacity curtailments in market operations
5. **Accreditation Requirements**: Specific accreditation standards for supporting generation (example shows wind at 20%)

**Policy/Regulatory:**
6. **Transition Timelines**: "Prescribed timelines" for conversion from CHILL to firm transmission service (Option 2) not specified
7. **CHILL Cap Determination**: Whether footprint caps apply to Option 1 (only Option 2 states "no cap")
8. **Unreserved Use Charges**: Specific pricing methodology for accounting for curtailments
9. **Anti-Competitive Concerns**: How the framework addresses potential anti-trust issues mentioned in opening
10. **Survey Results**: Post-forum stakeholder feedback compilation and response

**Commercial/Implementation:**
11. **Transmission Revenue Allocation**: How additional CHILL transmission revenue offsets ATRR across stakeholders
12. **Network Upgrade Responsibility**: Cost allocation for upgrades between load and generation under Option 2
13. **Permit-Limited Generator Impacts**: Specific mitigation measures not detailed
14. **Behind-the-Meter vs. Common Bus**: Distinction in treatment and requirements
15. **Conversion Process**: Detailed steps and requirements for transitioning CHILL to NITS service

**Stakeholder Consensus:**
16. **Consensus Building**: Track stakeholder positions on Option 1 vs. Option 2 preferences
17. **Additional Recommendations**: Compilation of stakeholder suggestions from forum
18. **MOPC Approval Path**: Next steps and timing for final MOPC consideration

---

# Chunk 2 Analysis

# REGULATORY MEETING ANALYSIS REPORT

## 1. Executive Summary

This document presents the second chunk of a November 21, 2025 CHILLS Stakeholder Engagement Forum presentation. The content covers a comprehensive stakeholder engagement timeline spanning October 2025 through April 2026, introduces the Price Adaptive Load Service (PALS) concept, and addresses extensive stakeholder concerns regarding both CHILLS and PALS services. The presentation outlines over 100 planned touchpoints across 10 working groups over a 6-month period. Key issues addressed include cost causation, curtailment risk, resource adequacy considerations, and impacts to existing generation resources.

## 2. Key Topics

### PALS (Price Adaptive Load Service)
- **Concept**: Flexible, non-firm transmission service for price-sensitive loads
- **Key Features**: 
  - Allows loads to submit price-sensitive demand bids in Day-Ahead (DA) and Real-Time (RT) markets
  - Alternative to CHILLS focusing on market-based integration
  - Not limited to large loads
  - Enables adaptive engagement during low-price periods

### Stakeholder Engagement Structure
- 100+ total touchpoints planned
- 6-month structured rollout (October 2025 - April 2026)
- 10 Working Groups involved: MOPC, MWG, SAWG, RSC, ORWG, CAWG, RTWG, TWG, ESWG, SPC

### Major Stakeholder Concerns Addressed

**Impact Concerns:**
- Effects on existing generation and emissions-limited resources
- Reliability and predictability of curtailments
- LMP impacts and TCR topology changes
- Outage coordination process impacts

**Process Concerns:**
- Resource adequacy circumvention
- Transmission service loopholes
- ARR/TCR participation limitations
- Service limit enforcement (7-year limit)

**Value Proposition Concerns:**
- Undefined target customer base
- Unclear value compared to existing RR696 framework
- Need for RR720 justification

## 3. Decisions or Actions

### Decisions Requested (PALS-related)
1. **Bid cap method** - Determination needed on threshold for maximum bid amounts in DA and RT to address permit-limited resource concerns
2. **Transmission Service rate for PALS** - Decision needed on whether to base on energy impact or other factors
3. **Resource Adequacy considerations** - Modeling method for PAL needs discussion

### Actions Identified
- SPP staff working on LMP impact analysis for stakeholder groups
- SPP staff developing updates to existing policies to account for CHILLS
- SPP plans to modify language through RR process once RC outage coordination methodology converts to business practice
- Development of straw proposals for bid cap methodology requested

## 4. Important Dates

### Stakeholder Forums
- **November 21, 2025** - CHILLS/PALS Forum (current meeting)
- **December 2, 2025** - Forum
- **January 12, 2026** - Forum
- **January 30, 2026** - Forum
- **February 27, 2026** - Forum
- **March 27, 2026** - PALS Forum
- **April 10, 2026** - Forum

### Engagement Timeline
- **October - November 2025**: CHILLS/PALS Education (11 education sessions, 2 forums)
- **December 2025**: CHILLS Approval/PALS Education (7 approval meetings, 4 education sessions, 1 forum)
- **January 2026**: CHILLS MOPC (4 approval sessions, 4 PALS education sessions)
- **February - March 2026**: PALS Education/Approval (9 education sessions, 6 approval meetings, 3 forums)
- **April 2026**: Final Approvals (2 approval sessions, PALS MOPC)

### Critical Concern
- **April RR approval timeline** identified as stakeholder concern for being too late

## 5. Organizations and People Mentioned

### Organizations
- **SPP** (Southwest Power Pool) - Primary organization
- **FERC** (Federal Energy Regulatory Commission) - Enforcement authority mentioned
- **MMU** (Market Monitor Unit) - Raised concerns about transmission service loopholes

### Working Groups/Committees
- MOPC (Markets and Operations Policy Committee)
- MWG (Market Working Group)
- SAWG (Seams Analysis Working Group)
- RSC (Regional State Committee)
- ORWG (Operating Reliability Working Group)
- CAWG (Cost Allocation Working Group)
- RTWG (Resource Adequacy Working Group - inferred)
- TWG (Transmission Working Group)
- ESWG (Economic Studies Working Group)
- SPC (Strategic Planning Committee)

### Teams
- **CHILL Team** - Presentation team

## 6. Links or References

### URLs Provided
- **Survey/Feedback Link**: https://app.keysurvey.com/f/41813577/4411/
- **Meeting Materials**: SPP.org (recording link to be shared post-meeting)

### Referenced Documents/Frameworks
- **RR720** - Related to outage coordination process documentation and GAP process
- **RR696** - Existing framework mentioned as potentially sufficient
- **Attachment BC** - Includes opportunity for HILL study without sufficient Designated Network Resources

### Technical References
- GAP process (Generation Availability Process - inferred)
- RC outage coordination methodology document
- LOLE (Loss of Load Expectation) modeling
- PRM (Planning Reserve Margin)

## 7. Suggested Tags

- CHILLS
- PALS
- Price Adaptive Load
- Non-Firm Transmission Service
- Stakeholder Engagement
- SPP Markets
- Resource Adequacy
- Curtailment
- Day-Ahead Market
- Real-Time Market
- LMP Impacts
- TCR
- ARR
- Demand Response
- MOPC
- Market Integration
- Transmission Service
- Load Flexibility
- Price-Sensitive Loads
- RR720
- FERC

## 8. Items That May Need Follow-Up

### High Priority Follow-Ups

1. **PALS Bid Cap Methodology** - Decision needed on method; stakeholders requesting straw proposals with consideration of seasonal variability, excess capacity, gas prices

2. **LMP Impact Analysis** - SPP staff analysis in progress; results need to be brought to stakeholder groups with discussion of TCR impacts

3. **Transmission Service Rate for PALS** - Fundamental pricing structure decision pending

4. **Resource Adequacy Modeling** - Method for modeling PAL needs stakeholder discussion

5. **Load Factor Cap Options** - Stakeholders requesting potential options to be considered

6. **April RR Approval Timeline** - Stakeholder concern that this is too late; may need timeline acceleration

### Medium Priority Follow-Ups

7. **Policy Updates for CHILLS** - SPP working on updates to existing policies; timeline and scope need clarification

8. **Language Modifications for RR720** - Pending conversion of RC outage coordination methodology to business practice

9. **Seven-Year Service Limit Enforcement** - Clarification needed on enforcement mechanism given stakeholder concerns about circumventing resource adequacy

10. **Curtailment Limitation Caps** - Exploration of caps on allowable CHILLS curtailments as mitigation method

11. **HILLGA Generation Hedging** - Details needed on how CHILLS can utilize HILLGA generation to hedge curtailments

12. **Curtailment Advisory Process** - Standard practice development for notices (up to 7 days advance vs. real-time)

### Lower Priority Follow-Ups

13. **Operational Requirements Alignment** - Stakeholder request that PALS, HILLs, and CHILLs have same ramp rate and ride-through requirements

14. **Uplift Charge Assessment** - Fair cost causation assessment methodology needed

15. **Financial Exposure to Price Spikes** - Risk mitigation considerations for PALS

16. **Post-Forum Survey Analysis** - Review responses from feedback survey link

17. **Recording Distribution** - Ensure recording link shared after meeting as promised

---

**Note**: This analysis is based on slides 27-40 of the presentation (chunk 2 of 2), which focuses primarily on engagement timelines, PALS introduction, and stakeholder feedback responses. Context from chunk 1 would provide additional background on CHILLS fundamentals.