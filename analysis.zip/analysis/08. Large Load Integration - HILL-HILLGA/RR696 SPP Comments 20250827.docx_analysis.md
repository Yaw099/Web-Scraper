# Final Combined Report

# REGULATORY CONTENT ANALYSIS REPORT - CONSOLIDATED

**Source:** RR696 SPP Comments 20250827.docx.txt (All 27 Chunks)

---

## 1. Executive Summary

This comprehensive document represents SPP's (Southwest Power Pool) comments on Revision Request 696 (RR696), dated August 27, 2025, which proposes to establish a High Impact Large Load (HILL) integration assessment framework. This is the fourth iteration of comments with progressive modifications highlighted in different colors (yellow for July 11, green for August 15, gray for August 27). 

The RR696 revision aims to accelerate large load interconnections while maintaining grid reliability through integrated design, study, registration, and operations processes. Key changes include:
- Removal of Conditional HILL (CHILL) concepts based on stakeholder feedback
- Shift from nameplate values to accredited capacity for maximum injection limits
- Alignment of resource requirements
- Clarification of study processes across multiple tariff attachments
- Adjustments to capacity calculations and timing requirements

The document comprises extensive tariff language covering transmission service rates, market operations procedures, planning criteria, and administrative processes across SPP's 19+ transmission zones. It establishes detailed frameworks for revenue requirements, cost allocation, resource commitment protocols, delivery point assessments, and generator interconnection procedures.

---

## 2. Key Topics

### HILL Framework (Primary Focus)
- **High Impact Large Load (HILL) Integration Assessment**: New framework for significant load interconnections
- **Capacity Accreditation Changes**: Transition from nameplate to projected capacity accreditation MW values
- **Study Process Modifications**: Updates to Attachments AQ, AE, AX, and BB
- **Timeline Adjustments**: Modified review periods (60 vs. 90 days for HILL cases)
- **Metering Requirements**: New specifications for HILL metering in Protocols
- **CHILL Concept Removal**: Elimination of Conditional High Impact Large Load provisions
- **Resource Day Ahead Must Offer**: Alignment with existing resource requirements
- **WAPA Division Provisions**: Special GIA provisions for Western Area Power Administration
- **Ramp Rate Requirements**: 20 MW requirement relocation to Integrated Marketplace Protocols

### Transmission Service & Rates
- **Point-To-Point Transmission Service**: Detailed rate structures for 19+ zones (Firm and Non-Firm)
- **Network Integration Transmission Service**: Schedule 9 provisions and billing determinants
- **Formula Rate Structures**: Multiple Attachment H addendums (over 50 referenced)
- **On-Peak vs. Off-Peak Pricing**: Time-based rate differentials
- **Revenue Crediting Mechanisms**: Schedule 7 and 8 revenues, Attachment AU allocations
- **Balanced Portfolio Reallocation**: Zonal ATRR adjustment mechanisms
- **ERCOT Interface Discount**: 45.27% discount for specific transactions

### Market Operations
- **Day-Ahead Market Execution**: SCUC and SCED algorithms
- **Reliability Unit Commitment (RUC)**: Day-Ahead and Intra-Day processes
- **Must-Offer Requirements**: 90% compliance threshold for net resource capacity
- **Manual Commitment Procedures**: Transmission system security and local reliability issues
- **Operating Reserve Requirements**: Co-optimization logic and marginal capacity pricing
- **Multi-Configuration Resources (MCRs)**: Eligibility restrictions and transition limitations
- **Emergency Capacity Protocols**: Maximum/Minimum emergency operating limits

### Planning & Studies
- **Integrated Transmission Planning (ITP)**: Comprehensive transmission expansion planning
- **SPP Transmission Expansion Plan (STEP)**: Annual project listing and approval process
- **Delivery Point Assessment Process**: Attachment AQ procedures
- **Provisional Load Process**: Attachment AX for insufficient designated resources
- **Generator Interconnection**: Attachment V procedures and material modifications
- **HILLGA Studies**: Generation addition network study procedures
- **Load Forecasting**: Requirements for non-conforming load and demand response

### Cost Allocation & Recovery
- **Annual Transmission Revenue Requirements (ATRR)**: Regional and zonal allocations
- **Base Plan Upgrades**: Cost recovery through Schedule 11
- **Sponsored Upgrades**: Payment options and ILTCR compensation
- **Canceled Project Recovery**: Specific provisions for AEP and Sunflower Electric
- **Regional vs. Local Cost Collection**: Distinction for reliability commitments
- **JTIQ ATRR Balance**: Joint transmission queue revenue reconciliation

### Operational Procedures
- **ICCP Requirements**: Inter-Control Center Communications Protocol standards
- **Emergency Operating Plans**: Load shedding and critical gas load protection
- **Non-Conforming Load**: Registration requirements for assets ≥50 MW
- **Local Reliability Issues**: Coordination between SPP and local transmission operators
- **Meter Agent Requirements**: Data submission protocols and agreements

---

## 3. Decisions or Actions

### HILL Framework Decisions (August 27, 2025)
- **Struck** change from 90 to 60 days in Attachment AQ 3.2; adjusted to "within sixty (60) Calendar Days, or ninety (90) in the case of a HILL"
- **Modified** Attachment BB 3.1.1 (2) from 100% to 110%
- **Relocated** 20 MW ramp rate requirement from Tariff Attachment AE Section 2.22 and Attachment BB Section 3.1.1 to Integrated Marketplace Protocols
- **Added** additional detail to Attachment BB Section 3 on Affected System Studies
- **Corrected** calculation in Attachment BB 3.1.1

### Previous HILL Changes Incorporated
- **Removed** CHILL, CHILLS, and Deliverability Area path for generation (August 15)
- **Made** HILL independent of Non-Conforming Load (August 15)
- **Added** Attachment BB Appendix 3 for WAPA Division GIA (July 28)
- **Changed** capacity limits to accredited capacity basis (July 28)

### Rate and Revenue Actions
- **Annual Rate Determinations**: Schedule 1-A1 service rates calculated annually
- **FERC Assessment Charge**: Posted by March 1 annually, effective March 1
- **Formula Rate Updates**: Various deadlines by entity:
  - Prairie Wind: September 1
  - Evergy Kansas Central: October 15
  - Multiple entities: October 1
  - NPPD: December 15
  - OPPD: July 20
- **Revenue Adjustments**: Schedule 7 and 8 revenue crediting per Section 34.1(2)

### Market Operation Actions
- **SCUC Algorithm Priorities**: Defined sequential steps for capacity shortages/surpluses
- **Manual Commitment Authority**: SPP may override algorithmic solutions for reliability
- **Market Monitor Verification**: Required for non-discriminatory resource selection
- **Must-Offer Compliance**: 90% threshold enforcement with penalty assessment
- **Operating Guides Development**: Required for recurring local reliability issues

### Study and Planning Actions
- **Study Timeline Requirements**:
  - Load Connection Study: 60 days (standard), 90 days (for HILL)
  - Delivery Point Network Study: Specified timelines by service type
  - Provisional Load Process Study: 90 days
- **HILLGA Study Approach**: Serial for Electrically-Equivalent requests, parallel otherwise
- **Transmission Expansion Plan**: Quarterly updates and annual Board approval
- **Preliminary Assessment**: 10 business days (with potential 10-day extension)

### Cost Recovery Decisions
- **AEP Canceled Project Recovery**: $3,264,402.55 over 12 months starting April 1, 2018
- **Additional AEP Recovery**: $414,465 commencing March 1, 2019
- **Sunflower Electric Recovery**: $718,359 commencing January 1, 2024
- **Interest Calculations**: Per 18 C.F.R. § 35.19a(a)(2)
- **Joint Informational Filings**: Required upon full recovery completion

---

## 4. Important Dates

### HILL Framework Timeline
- **July 11, 2025**: First round of SPP comments (yellow highlights)
- **July 28, 2025**: Second round of SPP comments (teal highlights)
- **July 2025**: MOPC meeting for Energy Storage Resource Load Assessment language approval (pending)
- **August 15, 2025**: Third

---

# Partial Chunk Reports

# Chunk 1 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document contains SPP's (Southwest Power Pool) comments on Revision Request 696 (RR696), which proposes to establish a High Impact Large Load (HILL) integration assessment framework. The revision is dated August 27, 2027 (likely 2025 based on context), and represents the fourth iteration of comments with progressive modifications highlighted in different colors (yellow for July 11, green for August 15, gray for August 27). The RR aims to accelerate large load interconnections while maintaining grid reliability through integrated design, study, registration, and operations processes. Key changes include removal of Conditional HILL (CHILL) concepts, alignment of resource requirements, clarification of study processes, and adjustments to capacity calculations and timing requirements.

## 2. Key Topics

- **High Impact Large Load (HILL) Framework**: Establishment of integration assessment processes for significant loads
- **Capacity Accreditation**: Shift from nameplate values to accredited capacity for maximum injection limits
- **Study Process Modifications**: Changes to Attachment AQ, AE, AX, and BB regarding HILL assessment procedures
- **Timeline Adjustments**: Modifications to study review periods (60 vs 90 days)
- **Metering Requirements**: Specifications for HILL metering in Protocols
- **CHILL Concept Removal**: Elimination of Conditional High Impact Large Load provisions based on stakeholder feedback
- **Resource Day Ahead Must Offer**: Alignment with existing resource requirements
- **Western Area Power Administration**: Special GIA provisions for WAPA Division
- **Ramp Rate Requirements**: 20 MW ramp rate requirement relocation to Integrated Marketplace Protocols
- **Capacity Calculation Adjustments**: Change from 100% to 110% in specific calculations

## 3. Decisions or Actions

### Approved Changes (August 27, 2025):
- Struck change from 90 to 60 days in Attachment AQ 3.2; adjusted to "within sixty (60) Calendar Days, or ninety (90) in the case of a HILL"
- Modified Attachment BB 3.1.1 (2) from 100% to 110%
- Relocated 20 MW ramp rate requirement from Tariff Attachment AE Section 2.22 and Attachment BB Section 3.1.1 to Integrated Marketplace Protocols
- Added additional detail to Attachment BB Section 3 on Affected System Studies
- Corrected calculation in Attachment BB 3.1.1

### Previous Changes Incorporated:
- Removed CHILL, CHILLS, and Deliverability Area path for generation (August 15)
- Made HILL independent of Non-Conforming Load (August 15)
- Added Attachment BB Appendix 3 for WAPA Division GIA (July 28)
- Changed capacity limits to accredited capacity basis (July 28)

## 4. Important Dates

- **July 11, 2025**: First round of SPP comments (highlighted in yellow)
- **July 28, 2025**: Second round of SPP comments (highlighted in teal)
- **July 2025**: MOPC meeting for Energy Storage Resource Load Assessment language approval (pending)
- **August 15, 2025**: Third round of SPP comments (highlighted in green)
- **August 27, 2025**: Fourth round of SPP comments (highlighted in gray) - latest version
- **Document date header**: 8/27/2027 (likely typo; should be 2025)
- **Study timeline**: 60 Calendar Days standard; 90 Calendar Days for HILL cases

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)**: Transmission Provider submitting comments
- **NERC**: Referenced for standards alignment
- **Western Area Power Administration (WAPA) Division**: Special GIA provisions included
- **MOPC**: Meeting body for pending approval
- **FERC/Commission**: Referenced for filing requirements
- **American Electric Power**: Zone 1 Transmission Owner
- **Southwestern Public Service**: Zone 11 Transmission Owner

### People:
- **Caroline Chapman**: Submitter, SPP representative
  - Email: cchapman@spp.org
  - Role: Company representative for SPP

## 6. Links or References

### Tariff Attachments Referenced:
- **Attachment AE**: Resource Day Ahead Must Offer requirements
- **Attachment AQ**: HILL study process (Section 3.2 modified)
- **Attachment AX**: HILL study process clarity
- **Attachment BB**: HILL GIA provisions (Sections 3.1.1, 3, and new Appendix 3)
- **Attachment H**: Zonal Annual Transmission Revenue Requirement
- **Attachment J**: Reallocation provisions
- **Attachment L**: Schedule 7 and 8 revenue distribution
- **Attachment AU**: Revenue distribution and allocation
- **Part I, Common Service Provisions**: Definitions section
- **Part II, III, IV**: Transmission service provisions
- **Schedule 1-A**: Tariff Administration Services
- **Schedule 7 and 8**: Revenue schedules

### Protocols Referenced:
- **Integrated Marketplace Protocols**: Destination for ramp rate requirements
- **Marketplace Protocols**: HILL provisions modifications

### Other Documents:
- **RR696 Form**: Original Revision Request objectives
- **GIA (Generator Interconnection Agreement)**: Referenced for WAPA provisions

## 7. Suggested Tags

- RR696
- High Impact Large Load (HILL)
- HILL Integration
- Large Load Interconnection
- SPP Tariff Revision
- Attachment BB
- Attachment AE
- Attachment AQ
- Capacity Accreditation
- WAPA GIA
- Load Assessment
- Transmission Planning
- Grid Reliability
- NERC Compliance
- Study Process
- Energy Storage Resource
- Network Integration
- Stakeholder Comments
- MOPC
- Ramp Rate Requirements
- Non-Conforming Load
- Transmission System
- Schedule 1-A

## 8. Items That May Need Follow-Up

### Pending Approvals:
1. **Energy Storage Resource Load Assessment language** - pending approval at July 2025 MOPC meeting (status unclear)

### Implementation Questions:
2. **CHILL Removal Impact**: Full implications of removing Conditional HILL provisions on existing or pending projects
3. **110% Calculation Change**: Rationale and impact of changing from 100% to 110% in Attachment BB 3.1.1 (2) needs documentation
4. **Ramp Rate Relocation**: Ensure 20 MW ramp rate requirement is properly incorporated into Integrated Marketplace Protocols
5. **Stakeholder Feedback**: Document specific stakeholder concerns that led to CHILL removal and HILL independence from Non-Conforming Load

### Coordination Items:
6. **WAPA Appendix 3**: Coordination with Western Area Power Administration on new GIA appendix
7. **Affected System Studies Detail**: Review additional detail added to Attachment BB Section 3 for completeness
8. **Corrected Calculation**: Verify the correction made to Attachment BB 3.1.1 calculation is accurate

### Documentation Gaps:
9. **Date Discrepancy**: Clarify document header showing 8/27/2027 vs. 2025 dates in content
10. **Incomplete Tariff Text**: Document appears to cut off mid-sentence in Schedule 1-A section - need complete version
11. **Benefits Quantification**: Itemized benefits listed (planning reserve margin, upgrade avoidance, etc.) need quantitative support
12. **Metering Requirements**: Specific HILL metering requirements mentioned but not detailed in this excerpt

### Process Clarifications:
13. **90 vs 60 Day Timeline**: Ensure consistent application of extended 90-day timeline for HILL studies
14. **Accredited Capacity Methodology**: Need clear definition of how "projected capacity accreditation MW value" is calculated
15. **Definition Updates**: Verify all defined terms (CHILL, CHILLS removed; HILL modified) are consistent throughout all tariff sections

---

# Chunk 2 Analysis

# Regulatory Analysis Report: RR696 SPP Comments

## 1. Executive Summary

This document is chunk 2 of 27 from SPP (Southwest Power Pool) tariff comments, specifically addressing RR696. The content focuses on detailed transmission service rate schedules and methodologies, including:

- **Schedule 1-A1**: Network Integration and Point-to-Point Transmission Service billing determinants and rate formulas
- **Schedule 1**: Scheduling, System Control and Dispatch Service for power movement operations
- **Schedule 2**: Reactive Supply and Voltage Control from Generation services, including compensation methodology
- **Schedule 11**: Base Plan Zonal Charges and Region-wide Charges (partially included)

The document establishes comprehensive rate structures, billing determinants, and revenue distribution mechanisms for various transmission services within the SPP region.

## 2. Key Topics

### Transmission Service Types
- Network Integration Transmission Service
- Firm Point-To-Point Transmission Service  
- Non-Firm Point-To-Point Transmission Service
- Grandfathered Agreements treatment

### Rate Schedules and Methodologies
- **Schedule 1-A1**: Billing determinants based on resident load or MW hours reserved
- **Schedule 1**: System control and dispatch rates for through/out and sinking transactions
- **Schedule 2**: Reactive power compensation at $2.26 per MVArh
- On-Peak vs. Off-Peak rate differentials

### Service Categories
- Through and Out Transactions
- Transactions Sinking within the Transmission System
- Multi-owner Zones
- Joint Owned Units
- Multiple Generators Behind Common Meter

### Technical Specifications
- Power factor requirements (0.95 PF)
- Dead Band calculations
- Reactive Power Outside the Dead Band (RPOD) methodology
- Qualified Generator (QG) compensation

## 3. Decisions or Actions

### Rate Calculations
- Annual determination of Schedule 1-A1 Service rate for each calendar year
- Monthly, weekly, daily, and hourly rate divisions specified
- Schedule 1 revenue requirement adjustments for Point-to-Point transactions
- Reactive Compensation Rate (RCR) set at $2.26 per MVArh with periodic review provision

### Exemptions
- Western-UGP exempted from Region-wide Charge under Schedule 11 per Section 39.3(e)

### Billing Procedures
- SPP to bill customers for monthly Schedule 2 charges in next billing cycle after sufficient data available
- Prompt posting of applicable monthly Schedule 2 charges required
- No true-ups for monthly calculations

## 4. Important Dates

### Rate Period Definitions
- **Calendar Year**: Annual rate determinations
- **Monthly**: Yearly rate divided by 12
- **Weekly**: Yearly rate divided by 52
- **Daily (On-Peak)**: Yearly rate divided by 260
- **Daily (Off-Peak)**: Yearly rate divided by 365
- **Hourly (On-Peak)**: Yearly rate divided by 4,160
- **Hourly (Off-Peak)**: Yearly rate divided by 8,760

### On-Peak Hours
- **On-Peak Days**: All days except Saturdays, Sundays, and NERC holidays
- **On-Peak Hours**: HE 0700 through HE 2200 Central Prevailing Time
- **Off-Peak**: All other hours and days

### Reference Periods
- Prior calendar year's average of 12 monthly peaks (for Schedule 1 calculations)
- Previous calendar year Schedule 1 Point-to-Point revenues

## 5. Organizations and People Mentioned

### Organizations
- **SPP (Southwest Power Pool)** - Transmission Provider
- **Transmission Owners** - Multiple entities with approved/accepted rates
- **Transmission Customers** - Service recipients
- **Network Customers** - Integration service customers
- **NERC** - North American Electric Reliability Corporation (referenced for holidays)
- **Western-UGP** - Exempted entity

### Entities/Roles (Generic)
- Qualifying Generators (QGs)
- Point of Delivery locations
- Balancing Authority Area entities
- Multi-owner Zones participants

## 6. Links or References

### Internal References
- **Addendum 1 of Schedule 1-A** - Rate formula details
- **Section 31.4** - Network Load designation provisions
- **Part V of this Tariff** - Base Plan charges provisions
- **Section 39.3(e)** - Western-UGP exemption authority
- **Revenue Requirements and Rates File (RRR File)** - Posted on SPP website
  - Schedule 1 tab
  - Zonal Sch 1 tab
  - Table 1 ("Schedule 1 RR")
  - Table 2 of Schedule 1

### External References
- **NERC holidays** - Referenced for Off-Peak period determination
- **Eastern Interconnection** - Geographic applicability scope

## 7. Suggested Tags

- Transmission Tariff
- Rate Schedules
- SPP Tariff
- RR696
- Network Integration Service
- Point-to-Point Transmission
- Reactive Power Compensation
- Scheduling and Dispatch
- Billing Determinants
- Zonal Rates
- Revenue Requirements
- Qualified Generators
- Grandfathered Agreements
- On-Peak/Off-Peak Rates
- System Control Services
- Voltage Control
- Transmission Service
- FERC Regulatory

## 8. Items That May Need Follow-Up

### Rate Review Requirements
1. **Periodic RCR Review** - Schedule 2 states Transmission Provider "may periodically review" the $2.26/MVArh rate to ensure it remains at upper end of reasonable cost range - no specific timeline provided
2. **Annual Rate Formula Updates** - Confirmation that Schedule 1-A1 annual determinations are occurring as specified

### Data and Posting Requirements
3. **RRR File Maintenance** - Verify all required tabs and tables are current on SPP website:
   - Schedule 1 tab
   - Zonal Sch 1 tab
   - Table 1 and Table 2 postings
4. **Monthly Schedule 2 Charge Postings** - Confirm SPP is posting charges "promptly after it possesses the data necessary"

### Revenue Reconciliation
5. **Zonal Revenue Mismatches** - Section III.D.2 addresses situations where monthly revenue doesn't match ZRC - track frequency and magnitude of mismatches
6. **Schedule 1 Revenue Requirement Adjustments** - Verify proper crediting of Point-to-Point revenues per Section D

### Methodology Clarifications
7. **Multi-owner Zone Calculations** - Confirm summation methodology for zones with multiple Transmission Owners
8. **Grandfathered Agreements Treatment** - Verify proper exclusion/inclusion in billing determinants per specified conditions
9. **Joint Owned Units Compensation** - Confirm designated entity arrangements and revenue disbursement among owners

### Compliance Items
10. **Western-UGP Exemption** - Verify Section 39.3(e) authority and continued applicability
11. **Eastern Interconnection Scope** - Confirm service applicability boundaries
12. **Formula Rate vs. Stated Rate Treatment** - Section D.1 and D.2 create different treatment - verify proper categorization of all Transmission Owners

### Technical Implementation
13. **RPOD Calculation Verification** - Dead Band and power factor calculations appear complex - validate implementation accuracy
14. **Billing Cycle Timing** - Schedule 2 billing in "next billing cycle" after data availability - confirm no undue delays
15. **Peak Demand Determinations** - Verify accuracy of zonal peak demand data used in Schedule 2 rate calculations

---

# Chunk 3 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document contains detailed tariff language from SPP (Southwest Power Pool) relating to transmission revenue requirements, cost allocation, and billing procedures. The content primarily focuses on Schedule 11 (Base Plan charges), Schedule 12 (FERC Assessment Charge), and Attachment H (Annual Transmission Revenue Requirements). Key provisions address how transmission costs are calculated and allocated across different zones, how point-to-point transmission revenues offset revenue requirements, special exemptions for Western-UGP Federal Service, and the methodology for recovering FERC assessment costs from transmission customers.

## 2. Key Topics

- **Base Plan Zonal Charges and Region-wide Charges**: Calculation methodology for annual transmission revenue requirements across different zones
- **Revenue Adjustments**: How point-to-point revenue and Attachment AU distributions reduce annual transmission revenue requirements
- **Load Ratio Share Calculations**: Different methodologies for calculating resident load across zones (Zones 1-9, 10, 11-18, and 19)
- **Western-UGP Federal Service Exemptions**: Special provisions excluding certain federal power transmissions from Schedule 11 charges
- **Formula Rate vs. Stated Rate Treatment**: Different revenue credit mechanisms for transmission owners using formula rates versus stated rates
- **FERC Assessment Charge Recovery**: Annual charge mechanism to recover FERC regulatory fees
- **SATOA Dispatch Revenue**: Revenue from dispatches into Energy and Operating Reserve Markets

## 3. Decisions or Actions

- Transmission Provider shall sum Commission-approved annual transmission revenue requirements for upgrades eligible under Schedule 11
- Revenue requirements shall be reduced by previous calendar year's point-to-point revenue, Attachment AU distributions, and SATOA dispatch revenue
- For formula rate transmission owners: No adjustment if revenue is already credited and updated annually
- For stated rate transmission owners: Adjust only for the difference between actual and credited revenue
- Transmission Provider shall calculate and post FERC Assessment Charge Rate (FACR) prior to March 1 each year
- FERC Assessment Charge Rate becomes effective March 1 annually
- Transmission Provider shall bill customers according to Section 7 of the Tariff

## 4. Important Dates

- **March 1 (annual)**: Deadline for Transmission Provider to calculate and post FERC Assessment Charge Rate
- **March 1 (annual)**: FERC Assessment Charge Rate becomes effective
- **Calendar year basis**: Revenue adjustments based on previous calendar year amounts
- **Monthly billing cycle**: Charges calculated on monthly basis (1/12 of annual amounts)

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)**: Transmission Provider
- **FERC/Commission**: Federal Energy Regulatory Commission - regulatory authority
- **Western-UGP**: Federal power entity with specific service exemptions
- **Transmission Owners**: Various entities operating transmission facilities
- **Network Customers**: Entities receiving network integration transmission service
- **SATOA**: Specific entity type with dispatch revenue provisions

### People:
- None specifically mentioned

## 6. Links or References

### Internal Tariff References:
- **Schedule 9**: Network Integration Transmission Service
- **Schedule 11**: Base Plan charges and provisions
- **Schedule 12**: FERC Assessment Charge
- **Section III of Schedule 11**: Point-to-point revenue charges
- **Section 7 of Tariff**: Billing procedures
- **Section 31.3**: Network Load designation provisions
- **Section 34.5**: Transmission System load determination
- **Section 34.9**: Federal-Power Southwestern identification
- **Section 39.2**: Bundled Retail and Grandfathered Loads provisions
- **Attachment AU (Sections IV and V)**: Revenue distribution and allocation
- **Attachment H**: Annual Transmission Revenue Requirements
  - Table 1, Column (3), Section I
  - Table 2-A, Section I
  - Table 2-B, Section I
  - Table 3, Section 1
- **Attachment J (Section IV.A)**: Reallocation provisions

### External References:
- **FERC Part 382 regulations**: FERC Assessment requirements
- **FERC Form 582**: Megawatt-hour reporting form

## 7. Suggested Tags

- Transmission Revenue Requirements
- Cost Allocation
- Rate Design
- Zonal Charges
- Point-to-Point Transmission
- Network Integration Service
- FERC Assessment
- Formula Rates
- Load Ratio Share
- Western-UGP
- Federal Service Exemption
- Base Plan Upgrades
- Revenue Credits
- Tariff Schedules
- SPP Transmission

## 8. Items That May Need Follow-Up

1. **Annual FERC Assessment Calculation**: Monitor posting of FACR calculation by March 1 deadline each year
2. **Revenue Credit Reconciliation**: Verify proper crediting of point-to-point revenue for both formula rate and stated rate transmission owners
3. **Table Updates in Attachment H**: Confirm that revenue amounts already credited are accurately reflected in Table 3, Section 1
4. **Western-UGP Service Tracking**: Monitor instances where Non-Federal Service is provided to Western-UGP's Statutory Load Obligations and ensure proper billing
5. **Zone-Specific Load Calculations**: Verify correct application of special provisions for:
   - Zone 10 (Federal-Power Southwestern reductions)
   - Zone 19 (Western Interconnection and Federal Service Exemption exclusions)
6. **SATOA Dispatch Revenue**: Track and verify proper accounting of SATOA dispatch revenue in ATRR calculations
7. **Commission Filing Requirements**: Note that Schedule 11 charges cannot be changed absent FERC filing
8. **RRR File Updates**: Ensure point-to-point revenue adjustments are properly documented in the RRR File
9. **Notification to Construct (NTC) Tracking**: Monitor which Base Plan Upgrades received NTC prior to relevant dates for cost recovery eligibility

---

# Chunk 4 Analysis

# REGULATORY ANALYSIS REPORT
**Source:** RR696 SPP Comments 20250827.docx.txt - chunk 4 of 27

---

## 1. Executive Summary

This document contains detailed tariff provisions from Southwest Power Pool (SPP) regarding Annual Transmission Revenue Requirements (ATRR) and cost allocation methodologies. The content focuses on the calculation, allocation, and recovery of transmission costs across different zones and projects, including specific provisions for individual Transmission Owners like Southwestern Public Service Company (SPS) and American Electric Power (AEP). Key elements include regional vs. zonal cost allocations, formula rate procedures, and special recovery mechanisms for canceled projects.

---

## 2. Key Topics

- **Annual Transmission Revenue Requirements (ATRR)** calculations and allocations across multiple zones
- **Base Plan Upgrades** and their cost recovery through Schedule 11
- **Region-wide vs. Zonal ATRR** distinctions and allocation methodologies
- **Network Upgrades** categorization (pre and post October 1, 2015)
- **Balanced Portfolio** revenue requirements
- **Interregional Planning** cost allocations
- **JTIQ (Joint Tariff Integration Queue) Upgrades** and their impact on regional costs
- **Formula rate processes** for Transmission Owners
- **Revenue crediting mechanisms** including:
  - Schedule 7 and 8 revenues
  - Point-to-Point Transmission Service revenues
  - Energy and Operating Reserve Markets revenues
  - SATOA (Short-term Agreement for Transmission Operator Agreement) revenues
- **Transmission Owner-specific provisions** for SPS and AEP
- **Canceled project cost recovery** for AEP-related projects

---

## 3. Decisions or Actions

- **ATRR Posting Requirements:** Revenue requirements must be posted on the SPP website in the RRR File
- **Formula Rate Updates:** Transmission Owners with approved formula rates can update revenue requirements without Commission filing upon successful completion of annual update procedures
- **Cost Allocation Directive:** Base Plan Upgrade costs allocated per Attachment J to Region-wide ATRRs and appropriate zonal ATRRs
- **AEP Canceled Project Recovery:** $3,264,402.55 to be recovered over 12-month period in equal monthly installments with interest, starting April 1, 2018
- **Public Review Requirement:** Transmission Owners must post populated formula rates for public review and comment
- **Joint Filing Requirement:** SPP and AEP must make joint informational filing upon full recovery of canceled project costs

---

## 4. Important Dates

- **June 19, 2010:** Threshold date for Base Plan Upgrades NTC (Notice to Construct) categorization
- **October 1, 2015:** Critical date distinguishing Network Upgrade treatment (Table 2-A vs. 2-B)
- **October 1 (annually):** Deadline for SPS formula calculation posting
- **October 31 (annually):** Deadline for AEP ATRR posting
- **January 1 (annually):** Effective date for updated revenue requirements (following year)
- **April 1, 2018:** Commencement date for AEP canceled project cost recovery
- **12-month recovery period:** Duration for AEP canceled project cost collection

---

## 5. Organizations and People Mentioned

### Organizations:
- **Southwest Power Pool, Inc. (SPP)** - Transmission Provider
- **Southwestern Public Service Company (SPS)** - Transmission Owner (Zone 11)
- **Xcel Energy Operating Companies** - Parent organization of SPS
- **American Electric Power (AEP)** - Transmission Owner with specific cost recovery provisions
- **Associated Electric Cooperative, Inc.** - Party to cost sharing agreements
- **Federal Energy Regulatory Commission (FERC/Commission)** - Regulatory authority
- Multiple unnamed Transmission Owners (Zones 1-19 referenced)

### People:
None specifically mentioned

---

## 6. Links or References

### Internal Tariff References:
- **Attachment J** - Cost allocation methodology
- **Attachment Z2** - Upgrade Sponsor payment provisions
- **Attachment O** - General provisions
- **Addendum 1 to Attachment O** - Coordination agreements
- **Attachment AU** - Revenue distribution provisions (Sections IV and V)
- **Attachment L** - Point-to-Point transmission revenue allocation
- **Attachment H, Addendum 1** - AEP formula rate
- **Attachment O – SPS of Xcel Energy OATT** - SPS formula rate and Implementation Procedures

### Schedules:
- **Schedule 7 and 8** - Revenue provisions
- **Schedule 9** - SATOA ATRR recovery charges
- **Schedule 11** - Zonal charges and Point-to-Point Transmission Service

### External References:
- **18 C.F.R. § 35.19a(a)(2)(iii)** - Commission interest rate regulations
- **RRR File (Revenue Requirements and Rates File)** - Posted on SPP website
- **SPS OASIS website** - Where formula calculations are posted

### Specific Projects Mentioned:
- **Morgan Transformer Project** (Cost Sharing Agreement with AECI)
- **Blackberry Substation Upgrade** (Cost and Usage Agreement with AECI)
- **Canceled Multi - Shipe Road - East Rogers - Kings River 345 kV project** (Network Upgrades 10656, 10659, and 10660)
- **Canceled Line - Georgia Pacific - Keatchie 138 kV Ckt 1 project** (Network Upgrade 10616)

---

## 7. Suggested Tags

- Annual Transmission Revenue Requirements (ATRR)
- Cost Allocation
- Formula Rates
- Transmission Upgrades
- SPP Tariff
- Network Integration
- Point-to-Point Service
- FERC Compliance
- Revenue Requirements
- Base Plan Upgrades
- Balanced Portfolio
- Interregional Planning
- Zone-specific Provisions
- SPS/Xcel Energy
- American Electric Power
- Canceled Projects
- JTIQ Upgrades
- Regional Cost Sharing
- Transmission Owner Rights
- OATT (Open Access Transmission Tariff)

---

## 8. Items That May Need Follow-Up

### Immediate/Near-Term:
1. **Verification of AEP Canceled Project Recovery Completion:** Confirm whether the 12-month recovery period starting April 1, 2018 has been completed and joint informational filing made
2. **Current RRR File Review:** Access and verify current ATRR values posted on SPP website match tariff provisions
3. **Zone 19 Special Treatment:** Clarify why Zone 19 only uses Table 2-B for Region-wide Charges (unlike Zones 1-18)

### Compliance/Procedural:
4. **Annual Formula Rate Updates:** Confirm SPS and AEP are meeting October posting deadlines
5. **Public Review Process:** Verify populated formula rates are being posted for public comment as required
6. **Commission Filing Requirements:** Track which revenue requirement changes require FERC filings vs. automatic updates
7. **JTIQ ATRR Balance Tracking:** Monitor positive/negative amounts included in Region-wide ATRR from JTIQ Upgrades

### Clarification Needed:
8. **SATOA Revenue Crediting:** Understand complete scope and application of SATOA dispatch revenue crediting mechanisms
9. **Upgrade Sponsor Payments (Attachment Z2):** Review details of how Upgrade Sponsors are compensated
10. **Interregional Project Allocations:** Clarify methodology for allocating costs of projects in other Interregional Planning Regions
11. **Table 3 Entries:** Determine current values in Columns 3 and 4 for all Transmission Owners
12. **Section 34.1 Adjustments:** Understand why SPS Zone 11 is exempt from these adjustments

### Documentation:
13. **Cost Support Documentation:** Ensure all non-formula rate revenue requirements have necessary cost support filed with Commission
14. **Coordination Agreement Details:** Review specific agreements listed in Addendum 1 to Attachment O
15. **Implementation Procedures:** Examine SPS-specific Implementation Procedures in Appendix 1 of Attachment O – SPS

---

**Note:** This analysis is based on chunk 4 of 27. Complete understanding may require review of other document

---

# Chunk 5 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document appears to be chunk 5 of 27 from SPP (Southwest Power Pool) comments dated August 27, 2025 (file: RR696). The content primarily addresses cost recovery mechanisms for network upgrades under Attachment J and related provisions. It details specific canceled projects for American Electric Power (AEP) and Sunflower Electric Power Corporation, outlining recovery amounts, timeframes, and filing requirements. The document also covers rate calculation methodologies for Southwestern Power Administration and provisions for various types of network upgrades including Sponsored Upgrades, Service Upgrades, and Generation Interconnection Related Network Upgrades.

## 2. Key Topics

- **Cost Recovery for Canceled Network Upgrade Projects**
  - American Electric Power (AEP) canceled projects recovery mechanisms
  - Sunflower Electric Power Corporation canceled project recovery
  - 12-month recovery periods with equal monthly installments
  
- **Annual Transmission Revenue Requirement (ATRR)**
  - Formula rate structures and adjustments
  - RRR File tracking and reporting requirements
  
- **Network Upgrade Classifications**
  - Sponsored Upgrades and payment options
  - Service Upgrades (Creditable and non-Creditable)
  - Generation Interconnection Related Network Upgrades
  - Zonal Reliability Upgrades
  
- **Compensation Mechanisms**
  - Incremental Long-Term Congestion Rights (ILTCRs)
  - Transmission revenue credits
  - 10-20 year term specifications

- **Southwestern Power Administration Rate Methodology**
  - NITS ATRR component calculations
  - Power Repayment Study requirements
  - 872,000 kilowatt capacity reference

## 3. Decisions or Actions

**Specific Recovery Authorizations:**
- AEP authorized to recover $414,465 for canceled Chapel Hill REC – Welsh Reserve 138 kV Ckt 1 (Network Upgrade 50697) and Welsh Reserve - Wilkes 138 kV Ckt 1 (Network Upgrade 11423) projects commencing March 1, 2019
- Sunflower Electric Power Corporation authorized to recover $718,359 for canceled Device – Russell 115 kV (Network Upgrade 122803) commencing January 1, 2024

**Required Actions:**
- Joint informational filings required by SPP and transmission owners upon:
  - Full recovery of canceled project costs
  - Sale or disposition of property during recovery period
- Transmission Provider must file Agreement for Sponsored Upgrades with good faith cost estimates
- True-up of costs to actual construction costs upon project completion
- Southwestern Power Administration must provide supporting documentation when NITS ATRR is revised

**Credits and Adjustments:**
- Revenues from property sales must be credited against ATRR
- Credits reflected in RRR File
- Post-recovery replacement of amounts with $0 in RRR File

## 4. Important Dates

- **March 1, 2019**: Commencement date for AEP ATRR inclusion of $414,465 for canceled projects
- **January 1, 2024**: Commencement date for Sunflower Electric Power Corporation ATRR inclusion of $718,359
- **April 2017**: Reference date for Formula Rate Posting Information Notification List access information
- **Recovery Period**: 12 months for all canceled project cost recovery
- **ILTCR Terms**: Minimum 10 years, maximum 20 years
- **Sponsored Upgrade Periodic Charges**: 20-year period (unless different term established in agreement)

## 5. Organizations and People Mentioned

**Organizations:**
- **American Electric Power (AEP)**
- **Sunflower Electric Power Corporation**
- **Southwestern Power Administration**
- **Southwest Power Pool (SPP)** - The Transmission Provider
- **Western-UGP** (referenced regarding Sponsored Upgrade payment options)
- **FERC (Federal Energy Regulatory Commission)** - "The Commission"
- **Georgia Pacific** (referenced in connection with Keatchie 138 kV project)

**Roles Referenced (no specific individuals named):**
- Transmission Provider
- Transmission Owners
- Transmission Customers
- Project Sponsors
- Interconnection Customers
- JTIQ Generation Interconnection Customers
- Market Participants

## 6. Links or References

**Regulatory References:**
- Federal Power Act
- FERC approval requirements
- Section VIII of Attachment J
- Attachment H (various sections and tables)
  - Column (3) in Table 1
  - Sections 10a and 10a(i)
- Schedule 11
- Attachment Z1
- Attachment Z2 (Sections I, II, and IV)
- Attachment V
- Attachment AH
- Schedule 1 of Attachment J
- Rate Schedule NFTS-13A, Section 2.3.3

**Website Reference:**
- SPP website for Formula Rate Posting Information Notification List
- Exploder List: http://www.spp.org/stakeholder-center/exploder-lists/ (as of April 2017)

**Specific Network Upgrades Referenced:**
- Network Upgrade 10616 (Georgia Pacific - Keatchie 138 kV Ckt 1)
- Network Upgrade 50697 (Line – Chapel Hill REC – Welsh Reserve 138 kV Ckt 1)
- Network Upgrade 11423 (Line – Welsh Reserve - Wilkes 138 kV Ckt 1)
- Network Upgrade 122803 (Device – Russell 115 kV)

**Supporting Documentation:**
- RRR File
- Power Repayment Study
- Agreement for Sponsored Upgrade

## 7. Suggested Tags

- Cost Recovery
- Network Upgrades
- ATRR (Annual Transmission Revenue Requirement)
- Canceled Projects
- FERC Compliance
- SPP Tariff
- Attachment J
- Attachment H
- ILTCRs (Incremental Long-Term Congestion Rights)
- Transmission Revenue Credits
- Rate Formulas
- Sponsored Upgrades
- Service Upgrades
- Generation Interconnection
- AEP
- Sunflower Electric
- Southwestern Power Administration
- NITS (Network Integration Transmission Service)
- RRR File
- Revenue Requirements
- Informational Filings

## 8. Items That May Need Follow-Up

**Completion Tracking:**
1. Monitor AEP's 12-month recovery period completion for $414,465 (starting March 1, 2019) - **Should be complete; verify joint informational filing was submitted**
2. Monitor Sunflower Electric's 12-month recovery period for $718,359 (starting January 1, 2024) - **Should complete January 1, 2025; verify final filing**
3. Verify RRR File updates reflecting $0 upon full recovery for both entities

**Verification Needs:**
4. Confirm whether any property associated with the canceled projects has been sold or disposed of during recovery periods
5. Verify all required joint informational filings between SPP and AEP/Sunflower have been submitted to FERC
6. Confirm total amounts recovered including interest calculations

**Documentation Requirements:**
7. Ensure Southwestern Power Administration provides updated supporting documentation when NITS ATRR calculations are revised
8. Verify Power Repayment Study filings are current and consistent with FERC confirmations
9. Confirm Formula Rate Posting Information Notification List is maintained and accessible (website link from 2017 may need updating)

**Pending Items:**
10. Section D on Zonal Reliability Upgrades appears incomplete ("placed in se") - **requires full text review**
11. Verify ILTCR agreements contain proper MW specifications and source-to-sink paths for all applicable upgrades
12. Confirm Market Participant status and Attachment AH execution for Project Sponsors receiving candidate ILTCRs

**Policy/Procedural Clarifications:**
13. Clarify whether Western-UGP lump sum payment limitation for Sponsored Upgrades affects any current projects
14. Review true-up procedures for Sponsored Upgrade actual vs. estimated construction costs
15. Verify allocation methodologies under Attachments Z1, Z2, and V are being properly applied

**Compliance Monitoring:**
16. Track FERC acceptance/approval status for any rate ratio

---

# Chunk 6 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document (chunk 6 of 27) contains detailed tariff provisions from SPP (Southwest Power Pool) governing the allocation and distribution of transmission service revenues. The content focuses on how different types of transmission upgrades are treated in revenue requirements, and establishes detailed methodologies for distributing revenues from Network Integration Transmission Service and Point-to-Point Transmission Service across different zones and transmission owners. The document includes provisions for both single-owner and multi-owner zones, with special treatment for Grandfathered Agreements and creditable upgrades under Attachment Z2.

## 2. Key Topics

- **Zonal Reliability Upgrades**: Cost allocation prior to and after January 1, 2008
- **JTIQ Upgrades**: Treatment in Region-wide Charge per Attachments L and AV
- **Grandfathered Agreements**: Protection of existing contractual rights and revenue streams
- **Revenue Distribution Mechanisms**:
  - Network Integration Transmission Service (Schedule 9)
  - Point-to-Point Transmission Service (Schedules 7 and 8)
- **Owner-Specific Zonal Annual Revenue Requirement (OZRR)**: Calculations and adjustments
- **Multi-Owner vs. Single-Owner Zones**: Different revenue distribution methodologies
- **Load Ratio Shares**: Calculation methodology per Section 34.4
- **MW-mile Impact Methodology**: Revenue distribution based on transmission impact
- **Creditable Upgrades**: Revenue credits pursuant to Attachment Z2
- **Zone-Specific Provisions**: Special rules for Zone 1 and Zone 19

## 3. Decisions or Actions

- **Revenue Allocation for Zonal Reliability Upgrades**: Costs for upgrades placed in service prior to January 1, 2008 allocated per Section III; all other costs included in Zonal ATRR
- **Grandfathered Agreement Treatment**: Transmission Provider has no claim to revenues; payments continue directly to Transmission Owner
- **Network Load Designation**: When designated outside the Transmission System (Section 31.4), revenues distributed to the zone where load is included in Load Ratio Share denominator
- **Multi-Owner Zone Revenue Distribution**: 
  - Revenues distributed proportionally to OZRR
  - Adjustments for Grandfathered Agreement sellers (OZRR reduced) and purchasers (OZRR increased)
  - Hypothetical NITS payment calculations for owners not taking service
- **Point-to-Point Revenue Distribution**: 50% distributed by OZRR proportion, 50% by MW-mile impacts
- **Creditable Upgrade Priority**: Revenue from reservations requiring Creditable Upgrades first paid to Upgrade Sponsors per Attachment Z2

## 4. Important Dates

- **January 1, 2008**: Threshold date for Zonal Reliability Upgrades cost allocation treatment
- **October 1, 2015**: Cutoff date for Zone 19 Network Load designation exemption from Section II.B.2(f)

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)**: Transmission Provider
- **Transmission Owners**: Various entities owning transmission facilities in different zones
- **American Electric Power**: Specifically mentioned regarding Zone 1
- **Network Customers**: Entities taking Network Integration Transmission Service
- **FERC (Federal Energy Regulatory Commission)**: Dispute resolution authority

### Zones Mentioned:
- **Zone 1**: Special provisions; multi-owner zone with American Electric Power
- **Zone 19**: Special provisions for pre-October 1, 2015 Network Load designations
- **Multi-owner Zones**: General category requiring special revenue distribution
- **Single-owner Zones**: Simplified revenue distribution methodology

## 6. Links or References

### Tariff Sections:
- **Section 31.4**: Network Load designation outside Transmission System
- **Section 34.1(2)**: OZRR adjustment procedures
- **Section 34.4**: Load Ratio Share calculation
- **Section 39**: Service provisions for Transmission Owners in Zone 1

### Attachments:
- **Attachment H**: OZRR listings
- **Attachment L**: Treatment of Revenues (this document)
- **Attachment S**: MW-mile impact calculation procedures
- **Attachment AV**: JTIQ ATRR Balance calculation
- **Attachment Z2**: Creditable Upgrades provisions

### Schedules:
- **Schedule 7**: Point-to-Point Transmission Service (rates/charges)
- **Schedule 8**: Point-to-Point Transmission Service (rates/charges)
- **Schedule 9**: Network Integration Transmission Service rates

## 7. Suggested Tags

- Revenue Distribution
- Transmission Service
- Tariff Provisions
- SPP OATT
- Network Integration
- Point-to-Point Service
- Grandfathered Agreements
- Zonal Rates
- OZRR
- Multi-Owner Zones
- Load Ratio Share
- MW-mile Methodology
- Creditable Upgrades
- Revenue Requirements
- JTIQ Upgrades
- Attachment L
- FERC Compliance

## 8. Items That May Need Follow-Up

1. **Grandfathered Agreement Dispute Resolution**: Section II.B.2(e) indicates parties may need to reach agreements on treatment; unresolved disputes may require FERC determination

2. **OZRR Adjustments**: Verification needed that Grandfathered Agreement charges are properly credited/debited to avoid double recovery (Sections II.B.2(b))

3. **Hypothetical NITS Calculations**: For Transmission Owners not taking service under Schedule 9, ensure proper calculation methodology is being applied (Section II.B.2(c))

4. **Network Load Outside System**: Verify proper revenue distribution when Network Customers designate load outside SPP's system per Section 31.4

5. **Creditable Upgrade Revenue Credits**: Ensure Attachment Z2 procedures are properly implemented for revenue distribution to Upgrade Sponsors

6. **Zone 1 Special Treatment**: Monitor compliance with unique Zone 1 provisions, particularly regarding American Electric Power and other Transmission Owners

7. **Zone 19 Legacy Designations**: Track Network Load designated before October 1, 2015 to ensure proper revenue distribution exception applies

8. **MW-mile Impact Calculations**: Verify Attachment S procedures are correctly applied for Point-to-Point revenue distribution

9. **Zone Designation Requests**: Monitor any Transmission Owner requests to establish separate zones within multi-owner zones (Section II.B.2(i))

10. **Section III Content**: This chunk ends at the beginning of Section III; need to review subsequent content for Base Plan Zonal Charges and Region-wide Charges distribution

---

# Chunk 7 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document section (chunk 7 of 27) from RR696 SPP Comments dated August 27, 2025, details the SPP (Southwest Power Pool) tariff provisions governing revenue distribution mechanisms and transmission planning processes. The content primarily covers:
- Distribution methodologies for Annual Transmission Revenue Requirements (ATRR) among Transmission Owners
- Revenue allocation for various upgrade types including Base Plan, Balanced Portfolios, Interregional Projects, and JTIQ (jointly-funded transmission interconnection queue) Upgrades
- Loss compensation procedures for transmission services
- The comprehensive Transmission Planning Process framework
- Components and development of the SPP Transmission Expansion Plan (STEP)

## 2. Key Topics

### Revenue Distribution Framework
- **ATRR Distribution**: Revenue distribution proportionate to Transmission Owners' annual transmission revenue requirements for Base Plan Upgrades, Balanced Portfolios, and Interregional Projects
- **Point-to-Point Revenue Distribution**: Allocated based on Zonal ATRR reallocation under Attachment J
- **Creditable Upgrades**: Revenue distribution to Upgrade Sponsors per Attachment Z2
- **JTIQ ATRR Balance**: Monthly reconciliation mechanism between generator charges and revenue requirements

### Loss Compensation
- **Network Integration Service**: Losses calculated using Zone Delivery Loss Factors (DLF) applied to Network Load
- **Point-to-Point Service**: Loss responsibility under Schedules 7 and 8
- **Integrated Marketplace**: Loss energy settled under Energy and Operating Reserve Markets (Attachment AE)

### Transmission Planning Process
- **Multiple Planning Sources**: 10+ distinct processes contributing to comprehensive planning
- **SPP Transmission Expansion Plan (STEP)**: Annual comprehensive listing of all transmission projects
- **Stakeholder Engagement**: Open process with written comment opportunities

## 3. Decisions or Actions

### Revenue Distribution Actions
1. Monthly JTIQ ATRR Balance charges/credits (one-twelfth annually) applied to Resident Load through Region-wide Charge
2. Revenue distribution to Transmission Owners proportionate to their respective annual revenue requirements
3. Distribution of revenues to Interregional Planning Regions for approved Interregional Projects
4. Compensation to other transmission providers for coordinated upgrades

### Planning Process Actions
1. Transmission Provider prepares draft project list upon completion of planning studies
2. Draft project list posted on SPP website with process identification
3. Transmission Provider invites and reviews written stakeholder comments
4. Projects must receive endorsement or approval through proper process for STEP inclusion

## 4. Important Dates

**No specific dates mentioned in this content section**, though the following timeframes are referenced:
- **Monthly**: JTIQ ATRR Balance distribution (one-twelfth of annual amount)
- **Annual**: SPP Transmission Expansion Plan reporting
- **Hourly**: Loss responsibility calculations for Network Load coincident with Zone monthly peak load hour

## 5. Organizations and People Mentioned

### Organizations
- **SPP (Southwest Power Pool)** - Transmission Provider
- **Transmission Owners** - Recipients of revenue distributions
- **Transmission Customers** - Responsible for transmission losses
- **Network Customers** - Responsible for Network Integration Service losses
- **Upgrade Sponsors** - Recipients of Creditable Upgrade revenues
- **Interregional Planning Regions** - Recipients of Interregional Project revenues
- **Western-UGP** - Federal power entity with statutory load obligations
- **Stakeholders** - Participants in planning process review

### People
No individual names mentioned in this section.

## 6. Links or References

### Tariff Attachments Referenced
- **Attachment H**: Base Plan Zonal ATRR and Region-wide ATRR specifications
- **Attachment J, Section IV.A**: Zonal ATRR reallocation procedures
- **Attachment L, Section II.A, II.C, III.A**: Revenue distribution provisions
- **Attachment AU**: Revenue distribution and allocation procedures
- **Attachment Z2, Sections II.D and III.C.2**: Creditable Upgrade revenue distribution
- **Attachment O**: Transmission Planning Process (including Addendum 1)
- **Attachment AE**: Energy and Operating Reserve Markets settlement procedures
- **Attachment AQ**: Delivery point facility changes
- **Attachment AX**: Additional study requests
- **Attachment V**: Generator Interconnection Requests
- **Attachment AV (including Appendix 2)**: JTIQ ATRR Balance calculation and Formula Rate template
- **Attachment Y**: Competitive Upgrades definition
- **Attachment M (including Appendix 1)**: Loss Compensation Procedure and loss factors

### Tariff Schedules Referenced
- **Schedule 7**: Point-to-Point Transmission Service
- **Schedule 8**: Point-to-Point Transmission Service
- **Schedule 9**: Network Integration Transmission Service charges
- **Schedule 11**: Transmission service revenue collection

### Other References
- **RRR File**: Posted on SPP website containing JTIQ ATRR Balance by upgrade
- **SPP Website**: Location for draft project list postings
- **Figure 1**: Illustration of planning processes (referenced but not included in this chunk)

## 7. Suggested Tags

- Revenue Distribution
- Annual Transmission Revenue Requirements (ATRR)
- JTIQ (Joint Transmission Interconnection Queue)
- Transmission Planning
- SPP Transmission Expansion Plan (STEP)
- Loss Compensation
- Base Plan Upgrades
- Balanced Portfolios
- Interregional Projects
- Network Integration Service
- Point-to-Point Service
- Tariff Provisions
- Stakeholder Process
- Transmission Owners
- Zone Loss Factors
- Creditable Upgrades
- Generator Interconnection
- Integrated Marketplace
- RR696
- Southwest Power Pool (SPP)

## 8. Items That May Need Follow-Up

### Clarification Needed
1. **JTIQ ATRR Balance Calculation**: Specific methodology for determining positive vs. negative balances and reconciliation processes
2. **Zone-Specific Loss Factors**: Current values in Column D of Appendix 1 to Attachment M (referenced but not provided)
3. **Revenue Exclusions**: Specific nature of revenues excluded under Sections III.B, III.C, and III.F of Attachment L
4. **Competitive Upgrade Reliability Violations**: Process for identifying and addressing violations on adjacent neighboring systems (Section V.7)

### Process Questions
5. **Stakeholder Comment Procedures**: Timeline and requirements for written comments on draft project lists
6. **Project Endorsement vs. Approval**: Distinction between "endorsed" and "approved" project statuses
7. **Multiple Revenue Reduction Calculations**: Coordination of Schedule 11 point-to-point revenue reductions across Base Plan, Balanced Portfolios, and Interregional Projects
8. **Federal Power-Western-UGP Settlement**: Specific procedures for Statutory Load Obligation transmission loss calculations

### Documentation Gaps
9. **Incomplete Section**: Section V.1.c appears to be cut off ("The Transmission Provider shall review the draft project list with the stakeholder worki")
10. **Figure 1 Reference**: Planning process illustration mentioned but not included in this chunk
11. **Complete List of Planning Sources**: Full descriptions of all 10 sources of potential upgrades referenced
12. **20-Year Assessment Details**: Process and criteria not fully described in this section

### Coordination Issues
13. **Interregional Cost Allocation**: Coordination mechanisms with adjacent planning regions
14. **Generator Retirement Process**: Integration with transmission planning (newly referenced process)
15. **High Priority Study Process**: Criteria and procedures for designation

---

# Chunk 8 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document is a section from SPP (Southwest Power Pool) tariff documentation, specifically focusing on Attachment O regarding transmission planning procedures and Attachment P covering transmission service timing requirements. The content details the regulatory framework for the SPP Transmission Expansion Plan, including stakeholder review processes, approval procedures, plan modifications, and transmission service request timing protocols. It establishes the governance structure involving the Markets and Operations Policy Committee, SPP Board of Directors, and various stakeholder groups in the transmission planning and approval process.

## 2. Key Topics

- **SPP Transmission Expansion Plan Development and Approval Process**
  - ITP (Integrated Transmission Planning) Upgrades
  - Balanced Portfolios
  - High Priority Upgrades
  - 20-Year Assessment Upgrades
  - Sponsored Upgrades

- **Stakeholder Engagement and Disclosure Requirements**
  - Planning summits and working group meetings
  - Public website posting of study results and plans
  - CEII (Critical Energy Infrastructure Information) protection protocols

- **Governance and Approval Hierarchy**
  - Markets and Operations Policy Committee recommendations
  - SPP Board of Directors final approval authority
  - Regional State Committee involvement

- **Plan Maintenance and Updates**
  - Quarterly modifications
  - Out-of-cycle adjustments
  - Upgrade removal procedures

- **Transmission Service Timing Requirements**
  - Various service request deadlines
  - Priority assignment systems
  - NERC priority classifications

## 3. Decisions or Actions

**Required Actions:**
- Markets and Operations Policy Committee must make recommendations on all upgrade types before Board approval
- SPP Board of Directors must provide final approval for inclusion of upgrades in the Transmission Expansion Plan
- Transmission Provider must post projects list at least 10 days prior to Board action
- Quarterly posting of plan modifications required
- Quarterly status reporting to Markets and Operations Policy Committee, Regional State Committee, and Board of Directors

**Decision Points:**
- Board of Directors may approve upgrades different from Committee recommendations (requires explanation)
- SPP not required to have a Balanced Portfolio each year
- Transmission Provider may remove upgrades in consultation with stakeholders
- Transmission Owner reimbursement for costs related to removed upgrades

## 4. Important Dates

**Recurring Deadlines:**
- **10 days prior to Board meeting**: Posting and email notice of projects requiring Board action
- **Quarterly basis**: Posting of Transmission Expansion Plan modifications
- **Quarterly basis (minimum)**: Status reporting on upgrades to stakeholders and Board
- **Annual**: SPP Transmission Expansion Plan presentation to Board of Directors

**Transmission Service Timing:**
- Various timing requirements referenced but specific times not fully detailed in this excerpt
- 23:00 previous day deadline mentioned for first hour of day requests
- 15:00 day prior for non-firm schedules (conditional)
- 09:55:00-10:05:00 a.m. CPT window for DC tie requests (3 request limit)
- 5-minute window for simultaneous request consideration

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)** - Transmission Provider
- **Markets and Operations Policy Committee** - Recommendation body
- **SPP Board of Directors** - Final approval authority
- **Regional State Committee** - Review body
- **Stakeholder working groups** - Advisory/endorsement role
- **Transmission Owners** - Local system operators
- **NERC (North American Electric Reliability Corporation)** - Standards authority
- **FERC/Commission** - Regulatory oversight (referenced for filings)

**People:**
No specific individuals mentioned in this section.

## 6. Links or References

**Internal Document References:**
- Section II of Attachment O (stakeholder participation procedures)
- Section III of Attachment O (analysis methodology)
- Section IV.7 of Attachment O (Interregional Projects)
- Section V of Attachment O (stakeholder consultation)
- Section VII of Attachment O (Transmission Owner local plans)
- Section VIII of Attachment J (cost reimbursement)
- Attachment Z1 (transmission service upgrades)
- Attachment V (Generator Interconnection Service)
- Attachment AB (Generator Retirement Upgrades)
- Attachment P (Transmission Service Timing Requirements)
- Sections 13.2 and 14.2 of SPP OATT

**External References:**
- SPP Tariff
- SPP Membership Agreement
- NERC TLR (Transmission Loading Relief) procedures
- CEII requirements

**Website References:**
- SPP website (for posting plans, study results, and status updates)

## 7. Suggested Tags

- Transmission Planning
- SPP Governance
- Regulatory Compliance
- ITP Upgrades
- Balanced Portfolio
- Stakeholder Process
- Board Approval
- CEII Protection
- Transmission Expansion Plan
- NERC Standards
- Generator Interconnection
- Sponsored Upgrades
- Markets and Operations Policy Committee
- Quarterly Reporting
- Transmission Service Requests
- Priority Assignment
- OATT (Open Access Transmission Tariff)

## 8. Items That May Need Follow-Up

**Process Clarifications:**
1. **Definition gaps**: Specific definitions for "high priority upgrades" and criteria for designation not fully explained in this excerpt
2. **Lottery system details**: Methodology for simultaneous request lottery system needs documentation
3. **Deviation explanation requirements**: Format and detail level required when Board deviates from Committee recommendations

**Compliance Monitoring:**
1. **10-day notice requirement**: Tracking mechanism to ensure consistent compliance with pre-meeting posting requirements
2. **Quarterly posting schedule**: Establish calendar for regular quarterly updates to avoid lapses
3. **CEII access protocols**: Verification that password protection systems meet regulatory requirements

**Stakeholder Engagement:**
1. **Comment incorporation process**: How written comments from stakeholders are considered and addressed
2. **Sub-regional planning meeting coordination**: Ensuring adequate notice and participation opportunities
3. **Transmission Owner coordination**: Process for reviewing and linking local plans

**Financial Implications:**
1. **Reimbursement procedures**: Implementation of cost recovery for removed upgrades (Section VIII of Attachment J reference)
2. **Adjacent system impact costs**: Clarification on who bears costs when SPP upgrades cause violations on neighboring systems
3. **Competitive Upgrade cost allocation**: Further review of competitive upgrade provisions

**Administrative Items:**
1. **Document version control**: This appears to be chunk 8 of 27 - ensure all sections are consistent
2. **Timing requirement tables**: Complete timing requirements table in Attachment P appears truncated
3. **NERC Holiday definition**: Confirm current list of applicable NERC Holidays for timing calculations

---

# Chunk 9 Analysis

# REGULATORY CONTENT ANALYSIS REPORT
## Document: RR696 SPP Comments 20250827.docx.txt - Chunk 9 of 27

---

## 1. Executive Summary

This document segment details transmission service rate structures and administrative procedures within the Southwest Power Pool (SPP) tariff framework. It establishes service increments, rate calculation methodologies, and specific rate sheets for Point-To-Point Transmission Service across multiple transmission owners in the American Electric Power - West (AEPW) rate zone and City Utilities of Springfield, Missouri. The content includes detailed rate formulas, discount provisions for ERCOT transactions, and revenue crediting mechanisms. The document references multiple attachments and formula rates approved by FERC for various transmission entities.

---

## 2. Key Topics

- **Transmission Service Increments**: Fixed Hourly, Fixed Daily, Extended Weekly, Extended Monthly, and Extended Yearly service windows
- **Rate Structures**: Separate rates for Firm and Non-Firm Point-To-Point Transmission Service
- **On-Peak vs. Off-Peak Definitions**: Different calculation bases (260 days vs. 365 days for daily; 4,160 hours vs. 8,760 hours for hourly)
- **AEPW Rate Zone**: Multi-owner transmission service rates and allocations
- **Balanced Portfolio Reallocation**: Adjustment mechanisms for revenue requirements
- **ERCOT Interface Discount**: 45.27% discount for specific transactions via AEP pricing zone
- **Revenue Crediting**: Schedule 7 and 8 revenue adjustments under Attachment AU
- **NAESB Standards**: Incorporation of WEQ-001 Business Practice Standards

---

## 3. Decisions or Actions

- **Service Offerings**: SPP offers only five specific service increment and window combinations (Fixed Hourly, Fixed Daily, Extended Weekly, Extended Monthly, Extended Yearly)
- **Time Zone Standard**: All transmission service products offered and processed in Central Prevailing Time using 24-hour clock convention
- **Rate Posting**: All effective rates to be posted in the Revenue Requirements and Rates File (RRR File) on SPP website
- **ERCOT Discount Application**: 45.27% zonal rate reduction applied to Schedules 7 and 8 for qualifying Load Serving Entities importing resources into ERCOT through AEP pricing zone
- **Holiday Definition**: NERC Holidays adopted for Off-Peak period determination

---

## 4. Important Dates

- **On-Peak Days**: Calculated using 260-day basis for daily rates
- **Annual Basis**: 365 days for Off-Peak daily rates
- **Hourly Calculations**: On-Peak uses 4,160 hours; Off-Peak uses 8,760 hours annually
- **Service Windows**: Various extended periods defined (weekly >1 week to <4 weeks; monthly >1 month to <12 months; yearly >1 year)
- **Daily Service Window**: Starts at 00:00 and stops at 24:00 of same calendar day
- **On-Peak Hours**: HE 0700 through HE 2200, Central Time Zone

**Note**: No specific meeting dates or deadlines are mentioned in this content chunk.

---

## 5. Organizations and People Mentioned

### Organizations:

**Transmission Owners in AEPW Rate Zone:**
- American Electric Power (AEP)
- East Texas Electric Cooperative, Inc.
- Deep East Electric Cooperative, Inc. (collectively "Texas Electric Cooperatives")
- Oklahoma Municipal Power Authority (OMPA)
- AEP West Transmission Companies (AEP-West Transco)
- Coffeyville Municipal Light and Power (CMLP)
- Arkansas Electric Cooperative Corporation (AECC)
- Transource Oklahoma (TROK)
- City Utilities of Springfield, Missouri

**ERCOT-Related Entities:**
- AEP Texas Central Company (TCC)
- AEP Texas North Company (TNC)
- Public Service Company of Oklahoma
- Southwestern Electric Power Company

**Other Organizations:**
- Southwest Power Pool (SPP)
- Electric Reliability Council of Texas (ERCOT)
- North American Electric Reliability Corporation (NERC)
- North American Energy Standards Board (NAESB)
- Federal Energy Regulatory Commission (Commission/FERC - implied)

### People:
No specific individuals are mentioned in this content.

---

## 6. Links or References

### Tariff Attachments Referenced:
- **Attachment T**: Rate Sheets for Point-To-Point Transmission Service
- **Attachment R-1**: NAESB WEQ-001 Business Practice Standards incorporation
- **Attachment X**: Time definitions
- **Attachment J, Section IV.A**: Balanced Portfolio Reallocation provisions
- **Attachment AU**: Revenue distribution and allocation
- **Attachment H**: Formula rates and protocols
  - Addendum 4: AEP Formula Rate
  - Addendum 12: AEP-West Transco Formula Rate
  - Addendum 17: City Utilities of Springfield Formula Rate
  - Addendum 38: AECC Formula Rate
  - Addendum 48: TROK Formula Rate

### Tariff Sections Referenced:
- **Section 34.1(2)**: Schedule 7 and 8 revenue adjustments
- **Part II**: SPP Tariff transmission service provisions
- **Part IV**: AEP Operating Companies' ERCOT Regional Transmission Service

### External References:
- **NAESB WEQ-001**: Wholesale Electric Quadrant Business Practice Standards
- **RRR File**: Revenue Requirements and Rates File (posted on SPP website)
- **AEP Operating Companies' Tariff**: Open access transmission service tariff on file with FERC

### Specific Rate Tabs:
- "AEP-West PTP Rate Att T" tab in RRR File

---

## 7. Suggested Tags

- Transmission Service Rates
- Point-To-Point Transmission
- SPP Tariff
- AEPW Rate Zone
- Formula Rates
- ERCOT Interface
- Network Integration
- On-Peak/Off-Peak Rates
- Revenue Requirements
- NAESB Standards
- Balanced Portfolio
- Firm Transmission Service
- Non-Firm Transmission Service
- Rate Schedules 7 and 8
- Attachment T
- Service Increments
- Transmission Pricing
- FERC Tariff
- City Utilities Springfield

---

## 8. Items That May Need Follow-Up

### Rate Verification and Updates:
1. **RRR File Accessibility**: Verify current posting location and accessibility of the Revenue Requirements and Rates File on SPP website
2. **Formula Rate Reviews**: Confirm annual updates for all referenced formula rates (AEP, AEP-West Transco, AECC, TROK, City Utilities)
3. **Fixed Rate Updates**: Verify current status of fixed rates mentioned (e.g., Texas Electric Cooperatives $2,053.993/MW, OMPA $91.51/MW, CMLP $47.32/MW)

### Discount Provision Compliance:
4. **ERCOT 45.27% Discount**: Track applications and verify qualification criteria for Load Serving Entities claiming this discount
5. **Planned vs. Unplanned Resources**: Monitor designation processes and potential disputes

### Administrative Clarifications:
6. **Service Increment Definitions**: Clarify "Extended Weekly" duration ambiguity (states "more than one week later, but less than four weeks later")
7. **Calendar vs. Business Day Issues**: Confirm handling of service requests spanning NERC holidays
8. **Central Prevailing Time**: Verify handling of daylight saving time transitions

### Regulatory Compliance:
9. **NAESB Standards Updates**: Monitor for revisions to WEQ-001 standards requiring tariff modifications
10. **Schedule 7 and 8 Revenue Crediting**: Verify calculation and distribution methodologies under Attachment AU
11. **Balanced Portfolio Reallocation**: Track Section IV.A of Attachment J implementation and adjustments

### Multi-Party Coordination:
12. **Revenue Allocation Among Multiple TOs**: Monitor potential disputes among seven transmission owners in AEPW zone
13. **ERCOT/SPP Interface**: Track changes to AEP Operating Companies' Tariff affecting discount provisions

### Documentation Completeness:
14. **Document Continuity**: This is chunk 9 of 27

---

# Chunk 10 Analysis

# REGULATORY ANALYSIS REPORT
## Source: RR696 SPP Comments 20250827.docx.txt - chunk 10 of 27

---

## 1. Executive Summary

This document section contains detailed tariff provisions for Point-To-Point (PTP) Transmission Service rates across multiple transmission zones within the Southwest Power Pool (SPP) system. It outlines rate structures, calculation methodologies, and billing procedures for both Firm and Non-Firm transmission services across several utility zones including Empire District Electric Company, Evergy Kansas Central, Inc., and Evergy Metro, Inc. The document specifies formula rate references, revenue crediting mechanisms, balanced portfolio reallocation adjustments, and various delivery period options (yearly, monthly, weekly, daily, and hourly) with corresponding rate calculations.

---

## 2. Key Topics

- **Point-To-Point Transmission Service Rate Structures**
  - Firm PTP Transmission Service rates and calculation methods
  - Non-Firm PTP Transmission Service rates and calculations
  - Multiple delivery period options (yearly, monthly, weekly, daily, hourly)
  - On-Peak and Off-Peak rate distinctions

- **Formula Rate References and Addendums**
  - Multiple formula rates referenced in Attachment H (Addendums 3, 10, 15, 16, 18, 43, 44)
  - Revenue Requirements and Rates File (RRR File) posting requirements

- **Rate Adjustments and Credits**
  - Balanced Portfolio Reallocation Adjustment (per Attachment J, Section IV.A)
  - Revenue crediting for Schedule 7 and 8 revenues
  - Attachment AU revenue distribution and allocation

- **Zonal Annual Transmission Revenue Requirements (Zonal ATRR)**
  - Calculation and posting procedures
  - Zone-specific requirements for multiple transmission zones

- **Demand Charge Caps**
  - Weekly caps for daily delivery reservations
  - Daily caps for hourly delivery reservations

---

## 3. Decisions or Actions

- **Rate Posting Requirements:** Multiple entities must post rates on SPP website:
  - Prairie Wind Formula Rate: by September 1 annually
  - Evergy Kansas Central, Inc. Formula Rate: by October 15 annually
  - South Central MCN Formula Rate: by October 1 annually
  - Kansas Power Pool Formula Rate: by October 1 annually
  - NextEra Energy Transmission Southwest Formula Rate: by October 1 annually

- **Rate Effectiveness:** All posted rates effective January 1 of the following year

- **Revenue Crediting Implementation:** Adjustments for Schedule 7 and 8 revenues and Attachment AU revenues to be implemented per Section 34.1(2)

- **Reallocation Adjustments:** PTP rates to be adjusted to reflect reallocations from Zonal ATRR per Attachment J, Section IV.A

---

## 4. Important Dates

- **September 1:** Prairie Wind Formula Rate ATRR posting deadline (annual)
- **October 1:** Posting deadline for:
  - South Central MCN Formula Rate ATRR
  - Kansas Power Pool Formula Rate ATRR
  - NextEra Energy Transmission Southwest Formula Rate ATRR
- **October 15:** Evergy Kansas Central, Inc. Formula Rate ATRR posting deadline (annual)
- **January 1:** Effective date for all posted rates (following year)

---

## 5. Organizations and People Mentioned

**Transmission Owners/Utilities:**
- The Empire District Electric Company
- Evergy Kansas Central, Inc.
- Evergy Kansas South, Inc.
- Evergy Metro, Inc.
- City of Independence, Missouri (INDP)
- Prairie Wind Transmission LLC
- South Central MCN LLC
- Kansas Power Pool
- NextEra Energy Transmission Southwest, LLC (NEET Southwest)

**Organization:**
- Southwest Power Pool (SPP)

**Roles Mentioned:**
- Transmission Customer
- Transmission Provider

---

## 6. Links or References

**Tariff Attachments:**
- Attachment T (Point-To-Point Transmission Service rates)
- Attachment H with multiple Addendums:
  - Addendum 3 (Evergy Kansas Central, Inc. Formula Rate)
  - Addendum 10, Parts 1 and 2 (EMe formula rate)
  - Addendum 15 (Prairie Wind Formula Rate)
  - Addendum 16 (Kansas Power Pool Formula Rate)
  - Addendum 18 (Empire District Electric Company formula rate)
  - Addendum 43 (South Central MCN Formula Rate)
  - Addendum 44 (NEET Southwest Formula Rate)
- Attachment J, Section IV.A (Balanced Portfolio Reallocation)
- Attachment AU (Revenue distribution and allocation)

**Other References:**
- Section 34.1(2) of the Tariff
- Revenue Requirements and Rates File (RRR File) - posted on SPP website
- Schedule 7 and 8 revenues
- Attachment H, Section I, Table 1 (various lines and columns referenced)

---

## 7. Suggested Tags

- Point-To-Point Transmission
- Transmission Rates
- SPP Tariff
- Formula Rates
- Revenue Requirements
- Firm Transmission Service
- Non-Firm Transmission Service
- Zonal ATRR
- Rate Adjustments
- Revenue Crediting
- Evergy
- Empire District Electric
- Prairie Wind Transmission
- Kansas Power Pool
- NEET Southwest
- Balanced Portfolio
- RRR File

---

## 8. Items That May Need Follow-Up

1. **Annual Rate Posting Compliance:** Verify all entities meet their respective posting deadlines (September 1, October 1, October 15) for 2025 rates

2. **RRR File Updates:** Confirm Revenue Requirements and Rates File is updated with all applicable adjustments on SPP website

3. **Formula Rate Reconciliation:** Track completion of formula rate calculations across all referenced Addendums (3, 10, 15, 16, 18, 43, 44)

4. **Revenue Crediting Implementation:** Verify proper implementation of Schedule 7 and 8 revenue adjustments per Section 34.1(2)

5. **Balanced Portfolio Reallocation:** Monitor any reallocations from Zonal ATRR per Attachment J, Section IV.A and their impact on rates

6. **Rate Zone Consolidation:** Track status of Evergy Kansas South, Inc. and Evergy Kansas Central, Inc. consolidation/merger noted in parenthetical

7. **Demand Charge Cap Calculations:** Ensure billing systems properly implement weekly and daily demand charge caps for short-term reservations

8. **Attachment AU Revenue Distribution:** Verify proper allocation of revenues distributed under Attachment AU across affected zones

9. **January 1 Rate Effectiveness:** Confirm all new rates become effective January 1 following posting

10. **Missing Document Content:** Note that text appears truncated at end ("one-twelfth of the sum of (a) the ra...") - obtain complete document

---

# Chunk 11 Analysis

# REGULATORY DOCUMENT ANALYSIS REPORT

## 1. Executive Summary

This document (chunk 11 of 27) from "RR696 SPP Comments 20250827.docx.txt" contains detailed tariff rate schedules for Point-To-Point Transmission Service for multiple transmission providers within the SPP (Southwest Power Pool) system. The content outlines rate structures, calculation methodologies, and delivery terms for both Firm and Non-Firm transmission services across four specific zones: Evergy Missouri West, Grand River Dam Authority, and Kansas City Board of Public Utilities. The document references multiple formula rates, revenue crediting mechanisms, and balanced portfolio reallocation adjustments.

## 2. Key Topics

- **Point-To-Point Transmission Service Rates** - Both Firm and Non-Firm service types
- **Rate Calculation Methodologies** - Including EMe formula rates and various addenda
- **Transmission Service Delivery Terms** - Yearly, monthly, weekly, daily (on-peak/off-peak), and hourly options
- **Reserved Capacity Pricing** - Per MW or kW basis depending on provider
- **Balanced Portfolio Reallocation Adjustments** - Zonal Annual Transmission Revenue Requirement modifications
- **Revenue Crediting Mechanisms** - Schedule 7 and 8 revenues and Attachment AU allocations
- **Demand Charge Caps** - Weekly and daily maximums based on peak capacity usage
- **Formula Rate References** - Multiple Attachment H Addenda (10, 11, 13, 21, 46)

## 3. Decisions or Actions

No specific decisions or actions are identified in this content. This appears to be a tariff schedule document outlining established rate structures and methodologies rather than meeting minutes or action items.

## 4. Important Dates

- **20250827** - Document date (from filename, August 27, 2025)
- **No specific effective dates mentioned** in this chunk for the rates described

## 5. Organizations and People Mentioned

### Organizations:
- **Southwest Power Pool (SPP)** - Regional Transmission Organization
- **Evergy Missouri West, Inc.** - Transmission Owner
- **Transource Missouri, LLC** - Transmission Owner in Evergy Missouri West zone
- **Grand River Dam Authority (GRDA)** - Transmission Provider/Owner
- **Kansas City Board of Public Utilities (BPU)** - Transmission Provider/Owner
- **INDP** - Rate component entity (specific expansion not provided)

### People:
None mentioned

## 6. Links or References

### Internal Document References:
- **RRR File (Revenue Requirements and Rates File)** - Posted on SPP website
- **Attachment H** - Formula rate attachments
  - Addendum 10, Parts 1 and 2 (EMe formula)
  - Addendum 11, Parts 1 and 2 (Evergy Missouri West formula)
  - Addendum 13 (Grand River Dam Authority formula)
  - Addendum 21 (Transource Missouri, LLC rate formula and protocols)
  - Addendum 46 (Kansas City Board of Public Utilities formula)
- **Attachment J, Section IV.A** - Balanced Portfolio Reallocation methodology
- **Attachment T** - Point-To-Point Transmission Service rates
- **Attachment AU** - Revenue allocation provisions
- **Section 34.1(2) of the Tariff** - Revenue crediting implementation
- **Schedule 7 and 8** - Revenue schedules

### Specific Rate Tabs in RRR File:
- "EMW PTP Rate Att T" (Evergy Missouri West)
- "GRDA PTP Rate Att T" (Grand River Dam Authority)
- "BPU PTP Rate Att T" (Kansas City Board of Public Utilities)

## 7. Suggested Tags

- Transmission Tariff
- Point-To-Point Service
- SPP
- Rate Schedules
- Formula Rates
- Firm Transmission
- Non-Firm Transmission
- Reserved Capacity
- Revenue Requirements
- Evergy Missouri West
- Grand River Dam Authority
- Kansas City BPU
- Transource Missouri
- Demand Charges
- Revenue Crediting
- FERC Regulation
- RRR File

## 8. Items That May Need Follow-Up

1. **INDP Rate Component** - The specific $2,442.048 INDP rate is mentioned but the entity/component definition is not explained; clarification needed on what INDP represents

2. **Commission Approval Status** - Document references "Commission approved rate(s)" but no specific FERC docket numbers or approval dates are provided

3. **Current Rate Values** - All rates reference the RRR File on SPP website; actual numerical values are not included in this chunk

4. **Incomplete Kansas City BPU Section** - The Firm Point-To-Point Transmission Service section for Kansas City BPU appears to be cut off mid-sentence ("shall not exceed t")

5. **Formula Rate Updates** - No indication of when the various Attachment H Addenda were last updated or their effective dates

6. **Balanced Portfolio Reallocation Amounts** - Methodology referenced but actual reallocation amounts not specified

7. **Schedule 7 and 8 Revenue Amounts** - Revenue crediting mechanisms referenced but specific amounts not provided

8. **Cross-Reference Verification** - Need to verify that all referenced attachments (H, J, T, AU) and addenda exist and are current

9. **Rate Differentiation** - Some providers use MW basis while Grand River Dam Authority uses kW basis; consistency/conversion factors may need clarification

---

# Chunk 12 Analysis

# Regulatory Document Analysis Report

## 1. Executive Summary

This document (chunk 12 of 27) from "RR696 SPP Comments 20250827.docx.txt" contains detailed rate schedules and transmission service tariff provisions for multiple utility zones within the Southwest Power Pool (SPP). The content primarily consists of standardized rate structures for Point-To-Point (PTP) transmission services, covering both Firm and Non-Firm service categories. The document details specific rate methodologies for Kansas City Board of Public Utilities, Lincoln Electric System, Midwest Energy Inc., and Nebraska Public Power District (NPPD) zones, including compensation structures, delivery periods, and revenue adjustment mechanisms.

## 2. Key Topics

- **Point-To-Point Transmission Service Rate Structures**: Detailed pricing frameworks for both Firm and Non-Firm transmission services across multiple delivery timeframes (yearly, monthly, weekly, daily, hourly)
- **Balanced Portfolio Reallocation Adjustments**: Mechanisms for adjusting rates based on Zonal Annual Transmission Revenue Requirements per Attachment J
- **Revenue Crediting Provisions**: Adjustments for Schedule 7 and 8 revenues and Attachment AU allocations
- **On-Peak vs. Off-Peak Pricing**: Differential rates based on time-of-use (HE 0700-2200 Central Time, excluding Sundays and NERC holidays)
- **Formula Rate References**: Multiple references to Attachment H addenda containing specific calculation methodologies
- **Reserved Capacity Compensation**: Various measurement units (MW, kW, MWh) and maximum charge provisions

## 3. Decisions or Actions

No specific decisions or actions are identified in this chunk. The content is purely descriptive of existing tariff rate structures and calculation methodologies.

## 4. Important Dates

- **December 15**: Deadline for NPPD formula calculation results to be posted (effective January 1 of following year)
- **June 15**: Deadline for Tri-State formula calculation results to be posted (effective July 1 of same year)
- **January 1**: Effective date for NPPD formula rate updates
- **July 1**: Effective date for Tri-State formula rate updates
- **On-Peak Hours**: HE 0700 through HE 2200, Central Time Zone
- **NERC Holidays**: New Year's Day, Memorial Day, Independence Day, Labor Day, Thanksgiving Day, Christmas Day

## 5. Organizations and People Mentioned

### Organizations:
- **Southwest Power Pool (SPP)** - Regional transmission organization
- **Kansas City, Kansas Board of Public Utilities** - Transmission provider/zone
- **Lincoln Electric System (LES)** - Transmission provider/zone
- **Midwest Energy, Inc.** - Transmission provider/zone
- **Nebraska Public Power District (NPPD)** - Transmission provider/zone
- **Tri-State** - Formula rate provider
- **Central Nebraska Public Power and Irrigation District (CNPPID)** - Rate component provider
- **NERC (North American Electric Reliability Corporation)** - Holiday definition authority

### People:
None mentioned

## 6. Links or References

### Internal Document References:
- **Attachment H** - Contains formula rates
  - Addendum 46 (Kansas City BPU)
  - Addendum 6 (Lincoln Electric System)
  - Addendum 14 (Midwest Energy, Inc.)
  - Addendum 7 (NPPD Formula Rate)
  - Addendum 36 (Tri-State Formula Rate)
- **Attachment J, Section IV.A** - Balanced Portfolio Reallocation provisions
- **Attachment T** - Point-To-Point Transmission Service rates
- **Attachment AU** - Revenue distribution and allocation
- **Section 34.1(2)** - Revenue crediting implementation
- **Schedule 7 and 8** - Revenue schedules

### Files Referenced:
- **Revenue Requirements and Rates File (RRR File)** - Posted on SPP website, containing multiple tabs:
  - "LES PTP Rate Att T" tab
  - "Midwest PTP Rate Att T" tab
  - "NPPD PTP Rate Att T" tab
  - Other zone-specific tabs

### External References:
- **SPP Website** - Location for RRR File posting
- **NPPD Website** - Location for formula rate results
- **Tri-State Website** - Location for formula rate results

## 7. Suggested Tags

- Transmission Service Rates
- Point-to-Point Transmission
- SPP Tariff
- Formula Rates
- Firm Transmission Service
- Non-Firm Transmission Service
- Revenue Requirements
- Balanced Portfolio
- Reserved Capacity
- On-Peak/Off-Peak Rates
- NPPD
- Lincoln Electric System
- Midwest Energy
- Kansas City BPU
- Zonal Rates
- Attachment H
- RRR File
- Transmission Pricing

## 8. Items That May Need Follow-Up

1. **Rate Discrepancy Review**: Lincoln Electric System Non-Firm service lists "rate per MWh of Reserved Capacity per week" for Off-Peak Hourly delivery, which appears inconsistent with other zones using "per hour" - potential typo requiring verification

2. **CNPPID Rate Updates**: Static rates listed for CNPPID ($128.961/MW annual, $10.747/MW monthly) - verify whether these are subject to periodic updates or require separate filings

3. **Formula Rate Posting Compliance**: Verify that all referenced entities (NPPD, Tri-State, LES, Midwest, Kansas City BPU) are meeting their posting deadlines (December 15 and June 15)

4. **RRR File Tab Completeness**: Confirm all referenced tabs exist in the current RRR File on the SPP website

5. **Unit Consistency**: Different zones use different units (MW vs. kW) - verify this is intentional and properly reflected in billing systems

6. **Weekly Rate Section**: The document cuts off at "3. Weekly delivery" for NPPD - the complete rate structure for this delivery type needs to be reviewed in subsequent chunks

7. **Attachment AU Integration**: Verify proper implementation of revenue distribution adjustments under Attachment AU across all zones

8. **Tri-State Applicability**: Clarify the scope and applicability of Tri-State Formula Rate within the NPPD Zone calculation

9. **Maximum Charge Provisions**: Confirm that billing systems properly implement the "shall not exceed" provisions for weekly and daily charge caps across all zones

---

# Chunk 13 Analysis

# Regulatory Document Analysis Report

## 1. Executive Summary

This document is chunk 13 of 27 from "RR696 SPP Comments 20250827.docx.txt" and contains detailed rate schedules for Point-to-Point Transmission Service across multiple transmission providers within the Southwest Power Pool (SPP) system. The content specifies tariff structures, pricing formulas, and billing periods for both Firm and Non-Firm transmission services. Key providers detailed include NPPD, CNPPID, Tri-State, Oklahoma Gas and Electric Company (OG&E), Arkansas Electric Cooperative Corporation (AECC), People's Electric Cooperative (PEC), NextEra Energy Transmission Southwest (NEET Southwest), Oklahoma Municipal Power Authority, and Omaha Public Power District (OPPD).

## 2. Key Topics

- **Point-to-Point Transmission Service Rates** - Detailed pricing structures for multiple delivery periods (yearly, monthly, weekly, daily, hourly)
- **Firm vs. Non-Firm Service Distinctions** - Different rate structures and calculation methodologies
- **On-Peak vs. Off-Peak Pricing** - Time-based rate differentiations with specific hours defined
- **Formula Rate Templates** - References to multiple addendums in Attachment H for rate calculations
- **Zonal Annual Transmission Revenue Requirements (Zonal ATRR)** - Core component of rate calculations
- **Revenue Crediting and Reallocation** - Adjustments for Schedule 7 and 8 revenues and Balanced Portfolio Reallocation
- **Reserved Capacity Charges** - Rates based on MW or kW of reserved transmission capacity
- **Loss Inclusive Pricing** - Capacity designations at Point(s) of Receipt inclusive of losses

## 3. Decisions or Actions

- **Rate Posting Requirements**: OG&E Formula Rate results must be posted on the SPP website by September 1 of each calendar year, effective January 1 of the following year
- **OPPD Rate Posting Requirements**: Formula calculation results must be posted by July 20 of each calendar year, effective August 1 of that year
- **Service Direction Treatment**: Service in the opposite direction of the original schedule is considered a new and separate service requiring separate charges
- **Peak Hour Definitions**: On-Peak defined as HE 0700-2200 Central Time, excluding weekends and NERC-defined holidays
- **Weekly Demand Charge Caps**: Total demand charge in any week for daily delivery cannot exceed weekly rate multiplied by highest MW of Reserved Capacity

## 4. Important Dates

- **September 1** - Annual deadline for posting OG&E Existing Zonal ATRR on SPP website
- **January 1** - Effective date for OG&E rates (following September posting)
- **July 20** - Annual deadline for posting OPPD formula calculation results
- **August 1** - Effective date for OPPD rates
- **On-Peak Hours**: HE 0700 through HE 2200, Central Time Zone
- **NERC Holidays**: New Year's Day, Memorial Day, Independence Day, Labor Day, Thanksgiving Day, Christmas Day

## 5. Organizations and People Mentioned

### Organizations:
- **NPPD** (Nebraska Public Power District)
- **CNPPID** (Central Nebraska Public Power and Irrigation District)
- **Tri-State** (Tri-State Generation and Transmission)
- **OG&E** (Oklahoma Gas and Electric Company)
- **AECC** (Arkansas Electric Cooperative Corporation)
- **PEC** (People's Electric Cooperative)
- **NEET Southwest** (NextEra Energy Transmission Southwest, LLC)
- **Oklahoma Municipal Power Authority**
- **OPPD** (Omaha Public Power District)
- **SPP** (Southwest Power Pool)
- **NERC** (North American Electric Reliability Corporation)

### People:
None specifically mentioned

## 6. Links or References

### Tariff References:
- **Attachment H** - Multiple Addendums containing Formula Rate Templates
  - Addendum 2-A: OG&E Formula Rate
  - Addendum 2-B: OG&E Formula Rate Implementation Protocols
  - Addendum 7: NPPD Formula Rate Template
  - Addendum 38: AECC Formula Rate
  - Addendum 44: NEET Southwest Formula Rate
  - Addendum 51: PEC Formula Rate
  - Addendum 8: OPPD Formula-based Rate Template
- **Attachment H, Section I, Table 1** - Existing Zonal ATRR specifications (Lines 7, 7a, 7c, 7d, 7e, Column 3)
- **Attachment J, Section IV.A** - Balanced Portfolio Reallocation
- **Attachment AU** - Revenue distribution and allocation
- **Attachment T** - Point-To-Point Transmission Service rates
- **Section 34.1(2)** - Schedule 7 and 8 revenue adjustments
- **RRR File** (Revenue Requirements and Rates File) - Posted on SPP website with specific tabs for each provider

## 7. Suggested Tags

- Point-to-Point Transmission
- Transmission Service Rates
- SPP Tariff
- Formula Rates
- FERC Regulatory
- Firm Transmission Service
- Non-Firm Transmission Service
- Revenue Requirements
- Zonal ATRR
- On-Peak/Off-Peak Pricing
- Reserved Capacity
- Transmission Pricing
- Rate Schedules
- OG&E
- NPPD
- OPPD
- Balanced Portfolio Reallocation

## 8. Items That May Need Follow-Up

1. **Rate File Verification** - Confirm that all referenced RRR Files and specific tabs are properly posted on SPP website by required deadlines
2. **Formula Rate Accuracy** - Verify calculations in all referenced Addendums (2-A, 2-B, 7, 8, 38, 44, 51) for consistency
3. **Annual Rate Updates** - Track September 1 and July 20 posting deadlines for OG&E and OPPD respectively
4. **Revenue Crediting Methodology** - Clarify Schedule 7 and 8 revenue adjustment calculations and their impact on final rates
5. **Balanced Portfolio Reallocation** - Understand mechanics of reallocation from Zonal ATRR per Attachment J, Section IV.A
6. **Divisor Calculations** - Verify 12-CP divisor methodology referenced in OG&E Formula Rate
7. **Loss Factor Treatment** - Confirm how losses are calculated when capacity designations are "inclusive of losses"
8. **Rate Caps Enforcement** - Ensure weekly and daily demand charge caps are properly implemented in billing systems
9. **Holiday Definition Updates** - Monitor NERC for any changes to holiday definitions that would affect On-Peak/Off-Peak periods
10. **Cross-Zone Rate Coordination** - Verify consistency across multiple rate zones and providers within SPP system

---

# Chunk 14 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary
This document section (chunk 14 of 27) contains detailed transmission service rate schedules and methodologies for multiple utility zones within the SPP (Southwest Power Pool) system. It specifically covers Point-To-Point Transmission Service rates for OPPD (Omaha Public Power District), Southwestern Power Administration, and Southwestern Public Service Company zones. The content outlines rate calculations, revenue crediting mechanisms, and various service delivery options (monthly, weekly, daily, hourly) for both firm and non-firm transmission services.

## 2. Key Topics
- **Point-To-Point Transmission Service rates** across multiple utility zones
- **Balanced Portfolio Reallocation Adjustments** to transmission rates
- **Revenue crediting mechanisms** for Schedule 7 and 8 revenues
- **Formula-based rate calculations** specific to each utility provider
- **Service delivery classifications**: Firm vs. Non-Firm service
- **Time-based rate structures**: Monthly, Weekly, Daily, and Hourly delivery charges
- **On-Peak vs. Off-Peak rate differentials**
- **Reserved Capacity billing** methodologies
- **Multi-entity rate aggregation** (particularly for Southwestern Zone combining multiple providers)

## 3. Decisions or Actions
- Rate adjustments shall be posted to the **RRR File (Revenue Requirements and Rates File)** on the SPP website
- Formula calculations for SPS must be posted by **October 1** of each calendar year
- SPS rates become **effective January 1** of the following calendar year
- Results must be posted on both the SPP website and SPS OASIS website
- Rate calculations must reflect adjustments per Section 34.1(2) of the Tariff
- Balanced Portfolio Reallocation adjustments must be implemented per Section IV.A of Attachment J

## 4. Important Dates
- **October 1** (annual): Deadline for posting SPS formula calculation results
- **January 1** (annual): Effective date for new SPS transmission rates
- **NERC Holidays** (affecting On-Peak/Off-Peak designation):
  - New Year's Day
  - Memorial Day
  - Independence Day
  - Labor Day
  - Thanksgiving Day
  - Christmas Day
- **On-Peak Hours**: HE 0700 through HE 2200 (Monday-Friday, excluding holidays)

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)** - Regional transmission organization
- **OPPD (Omaha Public Power District)** - Transmission provider
- **Southwestern Power Administration (Southwestern)** - Federal power marketing agency
- **South Central MCN LLC (South Central MCN)** - Rate zone participant
- **Missouri Joint Municipal Electric Utility Commission (MEUC)** - Rate zone participant
- **People's Electric Cooperative (PEC)** - Rate zone participant
- **Southwestern Public Service Company (SPS)** - Xcel Energy entity
- **Xcel Energy Operating Companies** - Parent company for SPS
- **Lea County Electric Cooperative, Inc. (LCEC)** - Rate zone participant
- **NERC (North American Electric Reliability Corporation)** - Referenced for holiday definitions

### People:
None specifically mentioned.

## 6. Links or References

### Internal Tariff References:
- **Attachment T** - Point-To-Point Transmission Service rates
- **Attachment J, Section IV.A** - Balanced Portfolio Reallocation methodology
- **Attachment H**:
  - Addendum 8 (OPPD Formula Rate)
  - Addendum 43 (South Central MCN Formula Rate)
  - Addendum 50 (MEUC Formula Rate)
  - Addendum 51 (PEC Formula Rate)
  - Addendum 52 (LCEC Formula Rate)
- **Attachment O - SPS** (Xcel Energy OATT)
- **Attachment AU** - Revenue distribution and allocation
- **Section 34.1(2)** - Revenue adjustment implementation

### External References:
- **SPP Website** - RRR File posting location
- **SPS OASIS Website** - Alternative rate posting location
- **Xcel Energy Operating Companies Joint Open Access Transmission Tariff**

### Specific Rate Templates:
- Formula-based Rate Template for OPPD, page 1, lines 13-18a
- "SPA PTP Rate Att T" tab in RRR File
- "SPS PTP Rate Att T" tab in RRR File

## 7. Suggested Tags
- Transmission Rates
- Point-To-Point Service
- OPPD
- Southwestern Power Administration
- SPS/Xcel Energy
- Formula Rates
- Revenue Requirements
- Tariff Administration
- Reserved Capacity
- Firm Transmission Service
- Non-Firm Transmission Service
- Rate Schedules
- On-Peak/Off-Peak Pricing
- FERC Regulation
- Open Access Transmission
- RRR File
- Balanced Portfolio

## 8. Items That May Need Follow-Up

### Compliance & Administrative:
1. **Annual rate posting verification** - Confirm October 1 deadline compliance for SPS rate postings
2. **RRR File updates** - Verify all rate adjustments are properly reflected in the posted RRR File
3. **Multi-website posting coordination** - Ensure consistency between SPP website and SPS OASIS postings
4. **Formula rate calculation accuracy** - Audit complex multi-entity rate calculations (especially Southwestern Zone with 4 separate entities)

### Operational Questions:
5. **Reserved Capacity determination** - Clarify methodology for calculating 12 coincident system peaks referenced in Southwestern Zone yearly rates
6. **Southwestern-specific billing** - Verify implementation of the 11-month lookback provision for directly connected loads
7. **Secondary Transmission Service limitations** - Monitor compliance with capacity limits for Southwestern customers
8. **Weekly rate caps** - Ensure billing systems properly enforce weekly maximum charges for daily/hourly reservations

### Documentation Gaps:
9. **Cross-reference verification** - Validate all Attachment H addendums are current and accessible
10. **Holiday calendar maintenance** - Confirm annual update of NERC holiday definitions
11. **On-Peak hour definition consistency** - Verify HE 0700-2200 definition aligns with all referenced documents

### Financial/Rate Design:
12. **Revenue crediting reconciliation** - Track Schedule 7 and 8 revenue adjustments and their impact on final rates
13. **Balanced Portfolio reallocation impacts** - Monitor magnitude and frequency of Attachment J adjustments
14. **Attachment AU allocation** - Verify proper distribution of revenues per allocation methodology

---

# Chunk 15 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary

This document chunk (15 of 27) from "RR696 SPP Comments 20250827.docx.txt" contains detailed tariff rate sheets for Point-To-Point Transmission Service across multiple utility zones within the Southwest Power Pool (SPP) system. The content focuses on rate calculation methodologies, revenue crediting mechanisms, and service conditions for both Firm and Non-Firm Point-To-Point Transmission Services. Three primary rate zones are covered: Southwestern Public Service Company (SPS), Sunflower Electric Power Corporation, and Upper Missouri Zone (UMZ), each with specific formula rates and delivery charge structures.

## 2. Key Topics

- **Point-To-Point Transmission Service Rate Structures** (Firm and Non-Firm)
- **Revenue Crediting Mechanisms** (Schedule 7 and 8 revenues, Attachment AU allocations)
- **Rate Zone Specifications** for SPS, Sunflower Electric, and Upper Missouri Zone
- **Delivery Charge Calculations** (Yearly, Monthly, Weekly, Daily, Hourly)
- **On-Peak vs. Off-Peak Rate Differentials**
- **Balanced Portfolio Reallocation Adjustments**
- **Reserved Capacity Compensation Methodologies**
- **Formula Rate References** (Multiple Attachment H Addendums)
- **Lamar Tie Line Special Rate Treatment** (50% discount for cross-system service)
- **Revenue Requirements and Rates File (RRR File)** posting requirements

## 3. Decisions or Actions

- Rates shall be **set forth in the RRR File** posted on the SPP website for all zones
- **Adjustments for Schedule 7 and 8 revenues** implemented in accordance with Section 34.1(2)
- **Balanced Portfolio Reallocation** adjustments applied per Section IV.A of Attachment J
- Service in the **opposite direction of original schedule** treated as new and separate service requiring separate charges
- **Discounted rate of one-half** applicable for Point-to-Point Transmission Service across Lamar Tie Line to/from PSCo system
- **Maximum weekly charges capped** at weekly rate multiplied by highest daily Reserved Capacity
- **Maximum daily charges capped** at daily rate multiplied by highest hourly Reserved Capacity

## 4. Important Dates

**No specific calendar dates mentioned in this chunk.**

However, the document references:
- **NERC Holiday Definitions**: New Year's Day, Memorial Day, Independence Day, Labor Day, Thanksgiving Day, and Christmas Day
- **On-Peak Hours**: HE 0700 to HE 2200 (Central Time Zone)
- **Off-Peak Hours**: All hours not designated as On-Peak
- **Sundays excluded** from On-Peak designation

## 5. Organizations and People Mentioned

### Organizations:

**Primary Transmission Providers:**
- Southwest Power Pool (SPP)
- Southwestern Public Service Company (SPS)
- Xcel Energy
- Sunflower Electric Power Corporation (SECC)
- Public Service Company of Colorado (PSCo)

**Upper Missouri Zone (UMZ) Transmission Owners:**
- Basin Electric Power Cooperative
- Heartland Consumers Power District
- Missouri River Energy Services (MRES)
- East River Electric Power Cooperative, Inc.
- Corn Belt Power Cooperative
- NorthWestern Energy Public Service Corporation (NWPS)
- Northwest Iowa Power Cooperative (NIPCO)
- Harlan Municipal Utilities (HMU)
- Western Area Power Administration, Upper Great Plains Region (Western-UGP)
- Central Electric Power Cooperative, Inc.
- Mountrail-Williams Electric Cooperative
- Mor-Gran-Sou Electric Cooperative, Inc.
- Roughrider Electric Cooperative, Inc.
- L and O Power Cooperative (LOPC)
- ITC Great Plains, LLC
- Prairie Wind Transmission, LLC
- LCEC (La Plata Electric Cooperative)

**MRES Members:**
- Moorhead Public Service
- Orange City Municipal Utilities
- City of Pierre, South Dakota
- City of Sioux Center, Iowa
- Watertown Municipal Utility Department
- Denison Municipal Utilities
- Vermillion Light & Power

### Regulatory Bodies:
- FERC (Federal Energy Regulatory Commission) - implied by "Commission approved rates"
- NERC (North American Electric Reliability Corporation)

**No individual people mentioned.**

## 6. Links or References

### Internal Tariff References:
- **Attachment T** - Point-To-Point Transmission Service rates
- **Attachment H** - Formula rates (multiple addendums)
  - Addendum 5 (SPS)
  - Addendum 9 (ITC Great Plains, LLC)
  - Addendum 15 (Prairie Wind Transmission, LLC)
  - Addendum 20 (Sunflower Electric Power Corporation)
- **Attachment O - SPS** (Xcel Energy OATT)
- **Attachment J, Section IV.A** - Balanced Portfolio Reallocation
- **Attachment AU** - Revenue distribution and allocation
- **Section 34.1(2) of this Tariff** - Revenue crediting implementation
- **Schedule 7 and 8** - Revenue sources

### External Files/Systems:
- **Revenue Requirements and Rates File (RRR File)** - Posted on SPP website
  - "SECC PTP Rate Att T" tab
  - "UMZ PTP Rate Att T" tab
- **Xcel Energy OATT** (Open Access Transmission Tariff)

### Rate Calculation References:
- Page 1, Line 11 (Monthly delivery rates)
- Page 1, Line 12 (Weekly delivery rates)
- Page 1, Line 13, Column 3 & 5 (Daily delivery rates)
- Page 1, Line 14, Column 3 & 5 (Hourly delivery rates)

## 7. Suggested Tags

`Point-To-Point Transmission` `Transmission Rates` `SPP Tariff` `Firm Transmission Service` `Non-Firm Transmission Service` `Revenue Crediting` `Southwestern Public Service` `Sunflower Electric` `Upper Missouri Zone` `Formula Rates` `OATT` `Reserved Capacity` `On-Peak Rates` `Off-Peak Rates` `Balanced Portfolio` `RRR File` `Schedule 7` `Schedule 8` `Attachment H` `Lamar Tie Line` `Rate Zones` `Transmission Service Charges` `FERC Tariff` `Electric Cooperative` `Municipal Utilities` `Western Area Power Administration`

## 8. Items That May Need Follow-Up

### Rate Reconciliation Issues:
1. **Verification of RRR File accuracy** - Confirm that all rates posted on SPP website match approved formula rate calculations
2. **Schedule 7 and 8 revenue adjustments** - Track implementation and proper allocation across zones
3. **Attachment AU revenue distribution** - Ensure proper allocation methodology is applied

### Regulatory Compliance:
4. **Commission approval status** for all UMZ transmission owner rates - Verify all listed entities have current approved rates
5. **NERC holiday definition updates** - Monitor for any changes to holiday definitions that would affect On-Peak/Off-Peak designations
6. **Formula rate update cycles** - Track when Attachment H addendums require updates or true-ups

### Operational Concerns:
7. **Lamar Tie Line discount justification** - Document rationale for 50% discount and monitor for potential challenges
8. **Opposite direction service treatment** - Clarify implementation of "new and separate service" charges
9. **Maximum charge cap calculations** - Ensure billing systems properly implement weekly/daily maximum charge limitations
10. **LCEC Formula Rate details** - Referenced but not fully detailed; obtain complete rate calculation methodology

### Cross-Reference Verification:
11. **Attachment references completeness** - Verify all referenced attachments (H, J, T, AU, O) are current and internally consistent
12. **Zone boundary definitions** - Confirm service territories and rate zone boundaries for all listed transmission owners
13. **Time zone consistency** - Ensure all On-Peak/Off-Peak definitions consistently apply Central Time Zone across all zones

### Stakeholder Communication:
14. **MRES member alignment** - Verify all seven listed MRES members are properly included in formula rate calculations
15. **New transmission owner additions** -

---

# Chunk 16 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document contains technical tariff specifications for transmission service rates and integrated marketplace operations within the SPP (Southwest Power Pool) system. The content covers two main areas: (1) Rate schedules for Point-To-Point Transmission Service in the UMZ (Upper Missouri Zone) and WFEC (Western Farmers Electric Cooperative) rate zones, including both firm and non-firm service calculations, and (2) Technical provisions for the Integrated Marketplace operations including must-offer requirements, market execution procedures, and Day-Ahead Market protocols. The document appears to be part of RR696 SPP Comments dated August 27, 2025.

## 2. Key Topics

- **UMZ Rate Zone Point-to-Point Transmission Service**: Detailed rate calculation methodologies for multiple transmission owners (Basin Electric, Heartland, MRES, East River, Corn Belt, NWPS, NIPCO, HMU, Western-UGP, Central Power, Mountrail-Williams, Mor-Gran-Sou, Roughrider, and LOPC)
- **WFEC Rate Zone Transmission Service**: Rate structures for Western Farmers Electric Cooperative and People's Electric Cooperative
- **Balanced Portfolio Reallocation Adjustments**: Revenue requirement reallocation procedures
- **Point-To-Point Revenue Crediting**: Schedule 7 and 8 revenue adjustments under Attachment AU
- **Must-Offer Requirements**: Compliance obligations for Market Participants in Day-Ahead Markets
- **Day-Ahead Market Execution**: SCUC (Security Constrained Unit Commitment) algorithm operations
- **Meter Agent Requirements**: Data submission protocols and registration procedures
- **Market Participant Compliance**: Penalty assessment for must-offer requirement violations

## 3. Decisions or Actions

- **Rate Calculation Methodologies Established**: Specific formulas defined for yearly, monthly, weekly, daily, and hourly delivery rates for both firm and non-firm transmission services
- **Revenue Requirements File (RRR) Implementation**: Rates to be posted on SPP website
- **Must-Offer Compliance Standards**: 90% threshold established for deemed compliance with net resource capacity requirements
- **Market Monitor Oversight**: Assigned to monitor Market Participant compliance with must-offer obligations
- **Meter Agent Agreement Requirement**: Entities performing Meter Agent functions must execute Attachment AM agreement
- **SCUC Algorithm Priority Actions**: Defined sequential steps for capacity shortages including curtailment of non-firm exports and incorporation of emergency capacity limits

## 4. Important Dates

- **Document Date**: August 27, 2025 (RR696 SPP Comments 20250827)
- **Hourly Calculation Basis**: 730 hours per month (standard)
- **Weekly Calculation Basis**: 52 weeks per year
- No specific implementation or compliance deadlines mentioned in this excerpt

## 5. Organizations and People Mentioned

### Organizations - Transmission Owners (UMZ Rate Zone):
- Basin Electric
- Heartland
- MRES (Missouri River Energy Services)
- MRES Members
- East River
- Corn Belt
- NWPS (Nebraska Public Power System)
- NIPCO
- HMU
- Western-UGP
- Central Power
- Mountrail-Williams
- Mor-Gran-Sou
- Roughrider
- LOPC

### Organizations - WFEC Rate Zone:
- Western Farmers Electric Cooperative (WFEC)
- People's Electric Cooperative (PEC)

### Other Entities:
- SPP (Southwest Power Pool) - Transmission Provider
- Market Monitor
- Market Participants (general)
- Meter Agents
- Asset Owners

**Note**: No individual persons are mentioned in this excerpt.

## 6. Links or References

### Tariff Attachments Referenced:
- **Attachment H**: Contains Addendums 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 37, 39, 40, 41, 42, 45, 47, 49, and 51 (formula rates and protocols)
- **Attachment J, Section IV.A**: Zonal Annual Transmission Revenue Requirement reallocation
- **Attachment T**: Point-To-Point Transmission Service specifications
- **Attachment AU**: Revenue distribution and allocation procedures
- **Attachment AE**: Integrated Marketplace provisions (current document)
- **Attachment AF, Section 3.9**: Penalty assessment provisions
- **Attachment AM**: Meter Agent Agreement

### Other References:
- **Revenue Requirements and Rates File (RRR File)**: Posted on SPP website
- **Market Protocols**: Timeline specifications for data submission
- **Section 34.1(2) of Tariff**: Schedule 7 and 8 revenue adjustments
- **Section 2.2(2) of Attachment AE**: Market registration descriptions
- **Section 4.1(10)**: Resource commitment status categories

## 7. Suggested Tags

- Transmission Service Rates
- Point-to-Point Service
- UMZ Rate Zone
- WFEC Rate Zone
- Day-Ahead Market
- Must-Offer Requirements
- Market Compliance
- SCUC Algorithm
- Formula Rates
- Revenue Requirements
- SPP Tariff
- Integrated Marketplace
- Meter Agent
- Market Participant Obligations
- Operating Reserves
- Resource Commitment
- Non-Firm Service
- Firm Service
- Balanced Portfolio

## 8. Items That May Need Follow-Up

1. **RRR File Posting Verification**: Confirm current rates are properly posted on SPP website for both UMZ and WFEC rate zones, including all referenced tabs ("WFEC PTP Rate Att T")

2. **Formula Rate Updates**: Verify all Addendums (22-51) in Attachment H are current and Commission-approved for respective transmission owners

3. **Must-Offer Compliance Monitoring**: Establish tracking mechanism for the 90% threshold compliance and penalty assessments under Section 3.9 of Attachment AF

4. **Meter Agent Agreement Execution**: Ensure all entities performing Meter Agent functions have executed required Attachment AM agreements

5. **Data Submission Timeline Compliance**: Verify Market Participants and Meter Agents are meeting timeline requirements specified in Market Protocols for actual/estimated data submission

6. **SCUC Algorithm Implementation**: Confirm Day-Ahead Market SCUC algorithm is properly handling priority sequences for capacity shortages and surplus situations

7. **Revenue Crediting Adjustments**: Track implementation of Schedule 7 and 8 revenue adjustments and Attachment AU distributions

8. **Facility Credits**: Verify proper inclusion of ATRR (Annual Transmission Revenue Requirements) associated with facility credits in UMZ rate zone calculations

9. **Market Monitor Reports**: Request regular compliance reports on Market Participant must-offer obligation adherence

10. **Emergency Capacity Procedures**: Clarify and document procedures for incorporating Resources' Maximum Emergency Capacity Operating Limits when capacity shortages occur

---

# Chunk 17 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary
This document chunk (17 of 27) from SPP Comments dated August 27, 2025 (RR696) contains detailed technical specifications for Day-Ahead Market operations and Day-Ahead Reliability Unit Commitment (RUC) processes. The content focuses on Security Constrained Unit Commitment (SCUC) and Security Constrained Economic Dispatch (SCED) algorithms, procedures for handling capacity surpluses/shortages, manual commitment protocols, Local Reliability Issues, and compensation mechanisms. The text appears to be regulatory tariff language defining market operations and reliability coordination procedures.

## 2. Key Topics

- **Day-Ahead Market SCUC/SCED Operations**
  - Capacity surplus elimination procedures
  - Emergency capacity operating limits (minimum/maximum)
  - Regulation-down requirements maintenance
  - Resource commitment and decommitment protocols

- **Manual Commitment Procedures**
  - Transmission system security constraints
  - Non-discriminatory selection requirements
  - Market Monitor verification process (Section 6.1.2.1)
  - Cost minimization requirements

- **Local Reliability Issues and Emergency Conditions**
  - Manual commitment/decommitment for local issues
  - Local transmission operator coordination
  - Distinction between Local Reliability Issues and Local Emergency Conditions

- **Compensation and Cost Recovery**
  - Regional cost collection (Section 8.5.10)
  - Local cost collection (Section 8.6.44)
  - Resource compensation methodology (Section 8.5.9, 8.6.5)

- **Day-Ahead Reliability Unit Commitment**
  - Capacity adequacy analysis
  - Priority order for addressing capacity shortages/surpluses
  - Curtailment of non-firm transactions
  - Emergency capacity incorporation

- **Operating Reserve Requirements**
  - Co-optimization logic
  - Marginal Capacity Price (MCP) calculations
  - Multi-Configuration Resource (MCR) eligibility restrictions
  - Shadow price calculations

## 3. Decisions or Actions

**Algorithmic Actions:**
- SCUC algorithm will curtail non-firm Export/Import Interchange Transactions in priority order
- Incorporate emergency capacity limits when standard capacity insufficient
- De-commit charging resources when capacity surplus exists
- Re-run Day-Ahead SCUC algorithm after manual commitments (time permitting)

**Transmission Provider Responsibilities:**
- Manually commit/decommit resources for transmission system security constraints not addressable by algorithm
- Issue instructions for Local Reliability Issues at local transmission operator request
- Verify non-discriminatory selection of manual commitments
- Notify Market Participants when units manually committed
- Perform capacity adequacy analysis for upcoming Operating Day

**Operating Guide Development:**
- Transmission Provider, local transmission operators, and Resource owners will develop operating guides for manual commitments addressing known and recurring Local Reliability Issues

## 4. Important Dates
- **Upcoming Operating Day** - Referenced throughout as the timeframe for Day-Ahead Market and RUC processes
- **30 minutes** - MCR Transition State Time threshold for Operating Reserve eligibility

*Note: No specific calendar dates mentioned in this chunk; document dated 20250827 (August 27, 2025)*

## 5. Organizations and People Mentioned

**Organizations:**
- **Transmission Provider** (SPP - Southwest Power Pool, implied)
- **Market Monitor**
- **Local transmission operators**
- **Resource owners**
- **Market Participants**
- **Reliability Coordinator**

**Roles Referenced:**
- No individual names mentioned
- Multiple organizational roles defined with specific responsibilities

## 6. Links or References

**Internal Cross-References:**
- Section 4.1(10)(c) - MSR reliability only use designations
- Section 4.1(10)(b) - Market commitment status
- Section 3.3.1 - SCED algorithm description
- Section 6.1.2.1 - Market Monitor verification process
- Section 8.3.2 - VRL application in SCED
- Section 8.5.9 - Resource compensation
- Section 8.5.10 - Regional cost recovery
- Section 8.6.5 - RUC resource compensation
- Section 8.6.7(A) - Regional cost collection for RUC
- Section 8.6.44 - Local cost collection
- **Attachment AE** - Referenced throughout (appears to be the main tariff attachment)

**External References:**
- None explicitly mentioned in this chunk

## 7. Suggested Tags

`Day-Ahead Market` `SCUC` `SCED` `Reliability Unit Commitment` `Manual Commitment` `Local Reliability Issue` `Emergency Capacity` `Operating Reserve` `Market Monitor` `Cost Recovery` `Transmission System Security` `Resource Commitment` `SPP Markets` `Capacity Adequacy` `Interchange Transactions` `MCR` `Regulation Service` `Shadow Pricing` `Virtual Resource Limits` `Operating Guides` `Reliability Coordinator`

## 8. Items That May Need Follow-Up

**Clarification Needed:**
1. **Definition gaps** - Several acronyms need verification: MSR (likely Market Storage Resource?), VRL (Virtual Resource Limits?), MCR (Multi-Configuration Resource confirmed in text)
2. **Market Monitor verification process** - Details of Section 6.1.2.1 process not included in this chunk
3. **Incomplete sentence** - Document cuts off mid-sentence at "(5) The Transmission Provider, local transmission operator, and Resource owners will develop operating guides to be applied to manual commitments made by the Transm..."

**Policy Questions:**
4. **Non-discriminatory selection criteria** - What specific criteria/methodology ensures non-discriminatory selection of manually committed resources?
5. **Cost minimization verification** - How is "commitment costs are minimized" verified in practice?
6. **Emergency limit frequency** - What triggers use of emergency capacity operating limits vs. economic limits?
7. **Local vs. Regional cost allocation** - Clear distinction needed on when costs are collected locally vs. regionally

**Procedural Follow-ups:**
8. **Operating guide development timeline** - No timeline specified for development of operating guides
9. **MCR transition limitations** - 30-minute threshold for operating reserve eligibility may need operational clarification
10. **Re-run protocols** - "Time permitting" for SCUC re-runs needs operational definition

**Coordination Issues:**
11. **Local transmission operator coordination** - Protocols for requesting Transmission Provider actions for Local Reliability Issues
12. **Market Participant notification** - Format and timing of notifications for manual commitments not specified

---

# Chunk 18 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary

This document is chunk 18 of 27 from "RR696 SPP Comments 20250827.docx.txt" and contains detailed operational procedures for two key areas: (1) Intra-Day Reliability Unit Commitment (RUC) execution processes, including resource commitment procedures, capacity shortage protocols, and local reliability issue management; and (2) Delivery Point Assessment Process procedures for changes to delivery point facilities. The content outlines the Security Constrained Unit Commitment (SCUC) algorithm methodology, Market Monitor verification requirements, compensation mechanisms, and cost recovery allocation between regional and local transmission operators.

## 2. Key Topics

- **Intra-Day Reliability Unit Commitment (RUC) Execution**
  - SCUC algorithm operation and objectives
  - Resource commitment optimization and cost minimization
  - Capacity adequacy analysis procedures

- **Resource Commitment Hierarchy**
  - Economic vs. reliability-only resource designation
  - Maximum/Minimum Economic and Emergency Capacity Operating Limits
  - Market Storage Resources (MSRs) and Multiple Configuration Resources (MCRs)

- **Capacity Shortage/Surplus Management**
  - Priority order for curtailment of non-firm transactions
  - Emergency capacity utilization protocols
  - Charging resource de-commitment procedures

- **Local Reliability Issues**
  - Manual commitment/decommitment procedures
  - Local Emergency Condition protocols
  - Coordination between Transmission Provider and local transmission operators

- **Market Monitor Oversight**
  - Non-discriminatory selection verification
  - Affiliation review for compensation eligibility
  - Standards and procedures reference (Section 6.1.2.1)

- **Cost Recovery Mechanisms**
  - Regional vs. local cost allocation (Sections 8.6.7(A) and 8.6.44)
  - Compensation under Section 8.6.5

- **Delivery Point Assessment Process (Attachment AQ)**
  - Procedures for delivery point facility changes
  - Load Connection Study requirements
  - Study request criteria and exemptions

## 3. Decisions or Actions

**Established Procedures:**
- SCUC algorithm will prioritize resources not designated for reliability-only use
- In capacity shortages, system will: (1) curtail non-firm exports, (2) incorporate emergency capacity/reliability resources, (3) de-commit market-committed charging resources, (4) de-commit self-committed charging resources
- In capacity surplus: (1) curtail non-firm imports, (2) incorporate minimum emergency limits, (3) de-commit non-self-committed resources, (4) de-commit self-committed resources

**Manual Intervention Authority:**
- Transmission Provider may manually commit/decommit resources for reliability issues not addressable within SCUC algorithm
- Local transmission operators may issue instructions during Local Emergency Conditions when time doesn't permit normal coordination
- Market Monitor will verify non-discriminatory selection of manually committed resources

**Required Coordination:**
- Local transmission operators must notify Transmission Provider of instructions given to resources
- Subsequent instructions must be coordinated through Transmission Provider
- Operating guides must be developed for known and recurring Local Reliability Issues

**Study Requirements:**
- Host Transmission Owner must respond within 10 business days to delivery point change requests
- Load Connection Study Agreement required unless exempted
- Advance deposit may be required (lesser of estimated cost or $25,000)

## 4. Important Dates

- **10 Business Days**: Host Transmission Owner response time for delivery point change requests (Section 3.1)

**Note:** This chunk references processes occurring during the "Operating Day" and "Day-Ahead Market" but does not specify particular calendar dates.

## 5. Organizations and People Mentioned

**Organizations:**
- **Transmission Provider** - Primary entity conducting RUC and SCUC processes
- **Market Monitor** - Oversight entity verifying non-discriminatory resource selection
- **Local Transmission Operators** - Entities managing local reliability issues
- **Host Transmission Owner** - Owner of transmission system portion for delivery point connections
- **Transmission Customer** - Entity requesting delivery point changes
- **Resource Owners** - Entities owning generation/storage resources

**Note:** No specific individual names are mentioned in this content.

## 6. Links or References

**Internal Document References:**
- Section 4.1(10)(b) - Resource commitment status descriptions
- Section 4.1(10)(c) - Reliability-only resource designations
- Section 6.1.1 - Inputs for RUC process
- Section 6.1.2.1 - Market Monitor verification standards and procedures
- Section 8.6.5 - Resource compensation provisions
- Section 8.6.7(A) - Regional cost recovery
- Section 8.6.44 - Local cost recovery
- Section 20 - Network Operating Agreement specifications
- Section 8 - Point to Point Transmission Service Agreement specifications
- Attachment AE - Primary attachment containing RUC procedures
- Attachment AQ - Delivery Point Assessment Process
- Addendum 1 - Sample Request for Change in Local Delivery Facilities

**Market Components:**
- RTBM Offers (Real-Time Balancing Market Offers)
- Day-Ahead Market/RUC processes

## 7. Suggested Tags

- Reliability Unit Commitment
- SCUC Algorithm
- Resource Commitment
- Capacity Adequacy
- Local Reliability Issues
- Emergency Procedures
- Market Monitor
- Cost Recovery
- Manual Commitment
- Transmission System Security
- Operating Reserves
- Delivery Point Assessment
- Load Connection Study
- Network Operating Agreement
- SPP Markets
- Transmission Operations
- Energy Storage Resources
- Regulation Services

## 8. Items That May Need Follow-Up

**Procedural Clarifications:**
1. **Section 6.1.2.1 Standards** - The specific standards and procedures used by Market Monitor for non-discriminatory selection verification are referenced but not detailed in this chunk
2. **Operating Guides Development** - Process and timeline for developing operating guides for known and recurring Local Reliability Issues needs definition
3. **Affiliation Determination** - Criteria for determining when a resource is "affiliated" with local transmission operator requires clarification

**Policy Questions:**
4. **Manual Commitment Discretion** - Boundaries and criteria for when Transmission Provider can override SCUC algorithm results
5. **Time Permitting Definition** - No clear definition of what constitutes insufficient time for normal coordination in Local Emergency Conditions
6. **Discriminatory Selection Consequences** - Beyond compensation denial, what other consequences exist for discriminatory resource selection?

**Cost Recovery Issues:**
7. **Regional vs. Local Allocation** - Criteria distinguishing when costs are recovered regionally (8.6.7(A)) versus locally (8.6.44) may need clarification
8. **Study Cost Recovery** - Mechanism for actual cost settlement in Load Connection Studies when advance deposit is insufficient

**Coordination Gaps:**
9. **Logging Requirements** - Specific format and timeline requirements for local transmission operator logging of manual instructions
10. **Multi-Party Coordination** - Process when multiple local transmission operators have overlapping reliability concerns

**Delivery Point Assessment:**
11. **Study Exemption Criteria** - Verification process for determining if delivery point changes meet exemption criteria (capacity increases, transformer changes, rating increases)
12. **Host Transmission Owner Definition** - Process for determining Host Transmission Owner when delivery point is near multiple system boundaries

**Incomplete Content:**
13. **Section 3.1 Cut-off** - The document ends mid-sentence: "assess the feasibility of modify..." - full content needed

---

# Chunk 19 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document contains sections from SPP (Southwest Power Pool) regulatory filing RR696, specifically covering Attachment AQ (Delivery Point Assessment Process) and the beginning of Attachment AX (Provisional Load Process). The content establishes detailed procedures for transmission customers requesting changes to local delivery facilities, including study requirements, timelines, cost allocation, and responsibilities for Load Connection Studies (LCS) and Delivery Point Network Studies (DPNS). The document outlines a structured process with specific deadlines for preliminary assessments, study agreements, and reporting, along with integration requirements with SPP's Integrated Transmission Planning Assessment.

## 2. Key Topics

- **Load Connection Study (LCS) Process**: Procedures for Host Transmission Owner to assess impacts of delivery point changes on local facilities
- **Delivery Point Network Study (DPNS) Process**: Transmission Provider's assessment of broader transmission system impacts
- **Study Timelines and Deposits**: 30-day execution requirements, 60-day completion for LCS, specified deposits ($10,000 or estimated cost, whichever is less for DPNS)
- **Preliminary Assessment Process**: 10 business day timeline for initial impact determination, with potential 10-day extension
- **Network Upgrade Evaluation**: Integration with Integrated Transmission Planning Assessment for requests requiring network upgrades
- **Cost Recovery**: Reimbursement procedures with interest calculations per 18 C.F.R. § 35.19a(a)(2)
- **Provisional Load Process**: New attachment (AX) for handling increased load situations where existing Designated Resources are insufficient
- **Study Modification Rights**: Process for revising planned facilities during study conduct
- **Posting Requirements**: Monthly public posting of requests on SPP website by the 20th day

## 3. Decisions or Actions

- **Required Actions by Transmission Customer**:
  - Execute LCS Agreement within 30 calendar days of receipt
  - Execute DPNS Agreement within 30 calendar days of receipt
  - Provide study deposits as specified
  - Submit detailed Request for Change in Local Delivery Facilities with required information
  - Reimburse unpaid study costs exceeding deposits
  
- **Required Actions by Host Transmission Owner**:
  - Complete LCS within 60 calendar days after receipt of executed agreement, deposit, and data
  - Issue Load Connection Report to Transmission Customer and Transmission Provider
  - Refund excess deposit amounts with interest
  - Coordinate completion of changes with no significant transmission system impact
  
- **Required Actions by Transmission Provider**:
  - Complete preliminary assessment within 10 business days
  - Post all requests receiving preliminary assessment by 20th of each month
  - Deliver DPNS Agreement within 5 business days of preliminary assessment (if significant impact found)
  - Issue study report within [timeframe not specified in text]
  - Provide explanation if unable to complete study in allotted time

- **Study Withdrawal Provisions**: Either party may deem request withdrawn if agreements not executed within 30 days

## 4. Important Dates

- **30 Calendar Days**: Deadline for executing LCS Agreement and DPNS Agreement (or mutually agreed later date)
- **60 Calendar Days**: Completion deadline for LCS after receipt of executed agreement, deposit, and data
- **10 Business Days**: Preliminary assessment completion deadline
- **Up to 10 Additional Business Days**: Potential extension for preliminary assessment for out-of-scope elements
- **5 Business Days**: Delivery of DPNS Agreement after preliminary assessment showing significant impact
- **20th Day of Each Month**: SPP website posting deadline for all requests that received preliminary assessment during prior calendar month
- **Study Report Deadline**: [Incomplete in source text - appears blank in original]

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)**: Transmission Provider
- **Host Transmission Owner**: Entity owning the portion of Transmission System for connection/modification
- **Transmission Customer**: Entity requesting delivery point changes
- **Transmission Provider**: SPP in its provider role

**Referenced Entities:**
- Federal Energy Regulatory Commission (FERC) - through regulatory reference

**Roles/Titles Referenced:**
- Representative of Transmission Customer
- No specific individuals named in this section

## 6. Links or References

**Regulatory References:**
- **18 C.F.R. § 35.19a(a)(2)**: Interest calculation methodology for deposit refunds
- **Attachment AQ**: Delivery Point Assessment Process
- **Attachment AX**: Provisional Load Process
- **Section 20 of the Network Operating Agreement**: Submittal specifications
- **Section 8 of the Point-to-Point Transmission Service Agreement**: Submittal specifications
- **SPP Business Practices**: Standardized project timelines
- **Integrated Transmission Planning Assessment**: Evaluation process for Network Upgrades

**Website References:**
- SPP website: For posting of requests and DPNS reports

**Document References:**
- Tariff
- Load Connection Report
- DPNS Report

## 7. Suggested Tags

- SPP
- RR696
- Attachment-AQ
- Attachment-AX
- Delivery-Point-Assessment
- Load-Connection-Study
- Network-Study
- DPNS
- LCS
- Transmission-Service
- Study-Process
- Network-Upgrades
- Integrated-Transmission-Planning
- Provisional-Load
- FERC-Tariff
- Cost-Recovery
- Transmission-Customer
- Host-Transmission-Owner
- Study-Timelines
- Deposit-Requirements

## 8. Items That May Need Follow-Up

1. **Missing Timeframe**: The DPNS study report completion deadline is blank in the source text (Section 3.2: "Transmission Provider shall issue a study report to the Transmission Customer and Host Transmission Owner within ___ of the receipt...")

2. **Interest-Bearing Account Clarification**: Need confirmation on whether interest-bearing accounts are required for all deposits or if alternative interest calculation method per 18 C.F.R. § 35.19a(a)(2) is standard

3. **Scope Definition**: Clarification needed on what constitutes "elements that are not applicable to the scope of Attachment AQ process" that would trigger the 10-day extension

4. **"Significant Impact" Criteria**: No definition provided for what constitutes "significant impact on the Transmission System" triggering DPNS requirement vs. local coordination

5. **Incomplete Section**: Attachment AX appears to begin but is cut off mid-sentence ("as set forth i...")

6. **Study Cost Reimbursement Timeline**: No specific deadline mentioned for when Transmission Customer must reimburse excess study costs

7. **Network Upgrade Need Date**: Process for "SPP determined Network Upgrade(s) need date" not fully explained

8. **Mutual Agreement Process**: Multiple references to "later date as the Parties may mutually agree" but no process described for reaching such agreements

9. **Study Modification Approval**: Standard for "not to be unreasonably withheld" acceptance of revised plans needs clarification

10. **Idev Modeling Files**: Required attachment (item 3) references "Idev modeling file(s)" but no specifications for format or content provided

---

# Chunk 20 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary
This document contains portions of SPP's (Southwest Power Pool) Tariff governing the Provisional Load Process for transmission customers requesting delivery point modifications. The content outlines detailed procedures for study requests, timing requirements, cost allocation, and responsibilities among Transmission Customers, Host Transmission Owners, and Transmission Providers. The document also includes sections on Market Protocols related to Non-Conforming Load forecasting requirements and must-offer obligations for market participants.

## 2. Key Topics
- **Provisional Load Process Study (PLPS)** - Procedures for requesting and conducting studies for delivery point changes
- **Load Connection Study (LCS)** - Host Transmission Owner assessment of delivery point modifications
- **Transmission System Study** - Impact assessment on the transmission system
- **Study Cost Allocation** - Transmission Customer responsibility for actual study costs and deposit requirements
- **Delivery Point Transfers** - Process for moving delivery points when insufficient designated resources exist
- **Non-Conforming Load** - Forecasting requirements for loads not following normal predictable patterns, including ESR (Energy Storage Resource) charging capabilities
- **Must-Offer Requirement** - Market participant obligations to offer available resources

## 3. Decisions or Actions
- **Study Request Submission**: Transmission Customer must submit request using standardized form (Addendum 1) with executed PLPS agreement
- **Deposit Requirement**: Host Transmission Owner may require advance deposit of estimated study cost or $25,000 (whichever is less)
- **Study Withdrawal**: Request deemed withdrawn if executed LCS agreement not returned within 30 Calendar Days with required deposit
- **Cost Reimbursement**: Transmission Customer must reimburse actual study costs upon completion
- **PLPS Report Posting**: Must be posted on SPP website when Network Upgrade is identified and customer requests agreement update
- **Hourly Load Forecasts**: Market Participants with Non-Conforming Load must submit forecasts before Day-Ahead RUC process

## 4. Important Dates
- **10 Business Days**: Host Transmission Owner response time for study request receipt
- **30 Calendar Days**: Deadline for returning executed LCS agreement with deposit
- **90 Calendar Days**: Standard completion time for Load Connection Study after receipt of executed agreement, deposit, and data
- **90 Calendar Days**: Standard completion time for Transmission System Study after all parties agree to study assumptions
- **1 Year**: Validity period for PLPS results after study report issuance
- **30 minutes**: Deadline before Operating Hour for Non-Conforming Load forecast submission
- **15 minutes**: Rolling basis for Non-Conforming Load forecast submissions

## 5. Organizations and People Mentioned
### Organizations:
- **SPP (Southwest Power Pool)** - Transmission Provider
- **Host Transmission Owner** - Entity conducting Load Connection Studies
- **Transmission Customer** - Entity requesting delivery point modifications
- **Transmission Provider** - Conducting Provisional Load Process Studies
- **Market Participants** - Entities with load forecasting and resource offering obligations

### Roles Referenced:
- Representative of Transmission Customer
- Requestor Contact (with various contact details required)

## 6. Links or References
- **Attachment AX** - Provisional Load Process procedures
- **Addendum 1 to Attachment AX** - Sample Request for Provisional Load Process
- **Addendum 2 and Addendum 3** - Provisional Load Process Agreements (referenced)
- **18 C.F.R. § 35.19a(a)(2)** - Federal regulation for interest calculation
- **SPP OASIS** - Where PLPS agreement is available
- **SPP website** - Where PLPS reports are posted
- **Section 6.2.2** - Non-Conforming Load description (Market Protocols)
- **Section 8.3** - Referenced but content not fully provided

## 7. Suggested Tags
- Provisional Load Process
- Transmission Planning
- Load Connection Study
- Delivery Point Modifications
- Study Procedures
- Cost Allocation
- Network Upgrades
- Non-Conforming Load
- Energy Storage Resources
- Market Protocols
- Must-Offer Requirements
- Day-Ahead Market
- RUC (Reliability Unit Commitment)
- RTBM (Real-Time Balancing Market)
- Tariff Requirements
- SPP Procedures

## 8. Items That May Need Follow-Up

### Procedural Clarifications:
1. **Study Extension Protocol**: Process when 90-day study completion timeline cannot be met requires explanation and estimate
2. **Mutual Agreement Terms**: Multiple instances of "as Parties may mutually agree" may need specific guidelines
3. **"Significant Impact" Definition**: Criteria for determining significant impact on Transmission System not defined
4. **Restudy Triggers**: Section 2.3 modifications process needs criteria for "not to be unreasonably withheld"

### Missing Information:
5. **Section 8.3 Content**: Referenced but appears incomplete in this chunk
6. **Addendum 2 and 3 Details**: Provisional Load Process Agreement forms referenced but not provided
7. **Must-Offer Section Continuation**: Section 4.2.1.1 appears cut off

### Technical Requirements:
8. **ESR Registration**: Process for determining when ESRs must be registered as MSR vs. Non-Conforming Load
9. **Idev Modeling Files**: Format and submission requirements for modeling files (referenced multiple times)
10. **Communications Configuration**: Meter communications requirements need specification

### Compliance Monitoring:
11. **15-Minute Forecast Compliance**: Enforcement mechanism for rolling 15-minute Non-Conforming Load forecasts
12. **Study Cost Overruns**: Process for handling significant cost deviations from estimates
13. **Interest-Bearing Account**: Verification that Host Transmission Owner maintains proper deposit accounts per 18 C.F.R. § 35.19a(a)(2)

---

# Chunk 21 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary
This document contains detailed regulatory language from SPP (Southwest Power Pool) tariff provisions governing market participant obligations, specifically focusing on must-offer requirements, Day-Ahead Market execution procedures, and resource commitment protocols. The content outlines calculation methodologies for load obligations, resource capacity requirements, compliance thresholds, and market clearing processes. It establishes a 90% compliance threshold for net resource capacity and details procedures for handling capacity shortages, surpluses, and local reliability issues.

## 2. Key Topics
- **Must-Offer Obligations**: Requirements for market participants with registered load to offer resources
- **Load Calculation Methodology**: Maximum hourly reported load calculations including bilateral contract adjustments and MSR self-charging considerations
- **Operating Reserve Obligations**: Daily calculations including Regulation-Up/Down, Contingency Reserve, Ramp Capability, and Uncertainty Reserve
- **Net Resource Capacity**: Determination including firm power purchases/sales and jointly owned unit considerations
- **Compliance Thresholds**: 90% net resource capacity requirement relative to load
- **GFA Carve Out Requirements**: Resource offering requirements for GFA carve out schedules
- **Day-Ahead Market Execution**: SCUC and SCED algorithm processes for market clearing
- **Emergency Procedures**: Capacity shortage/surplus handling protocols
- **Local Reliability Issues**: Manual commitment/decommitment procedures for transmission constraints
- **Market Monitor Role**: Verification and compliance monitoring responsibilities

## 3. Decisions or Actions
- Market Participants must offer resources with Commitment Status of Market, Self, or Reliability to satisfy must-offer obligations
- Market Monitor will contact Market Participants if firm power purchase/sale information is not input into the website
- Market Monitor may confirm firm purchases/sales with counterparties
- SPP may manually commit/decommit resources for transmission security constraints not addressable within DA Market SCUC algorithm
- Manual commitments must be selected in a non-discriminatory manner, verified by Market Monitor
- In capacity shortage situations, DA Market SCUC will: (1) curtail non-firm fixed Export Interchange Transaction Bids, then (2) incorporate emergency capacity limits
- In capacity surplus situations, DA Market SCUC will: (1) curtail non-firm fixed Import Interchange Transaction Offers, then (2) incorporate minimum emergency limits
- Local transmission operators may request SPP to issue instructions for Local Reliability Issues

## 4. Important Dates
- **Operating Day**: Referenced throughout as the timeframe for compliance and market execution
- **Upcoming Operating Day**: Day-Ahead Market clears for each hour of the upcoming Operating Day
- No specific calendar dates mentioned in this excerpt

## 5. Organizations and People Mentioned
**Organizations:**
- **SPP (Southwest Power Pool)**: Market operator and Reliability Coordinator
- **Market Monitor**: Compliance verification and monitoring entity
- **Market Participants**: Load-serving entities and resource owners
- **Asset Owners**: Entities with registered load and resources
- **Local transmission operators**: Request SPP instructions for local reliability issues

**People:**
- No specific individuals mentioned

## 6. Links or References
**Internal Document References:**
- Section 4.2.1.1 (must-offer obligation)
- Section 6.2.8 (bilateral contract load registration)
- Section 4.1.3(4) (Operating Reserve calculation)
- Section 4.2.2.5.4 (JOU Individual Resource Option)
- Section 6.1.14 (Combined Interest Resource modeling)
- Section 4.2.1.1.1 (penalty assessment)
- Section 4.5.9.12 (compensation for committed resources)
- Section 4.5.9.13 (regional cost recovery)
- Section 6.1.2.1 of Attachment AE to the Tariff (Market Monitor verification process)
- Section 6.1.7.1 (MCR registration options)

**External References:**
- Firm Point-To-Point Transmission Service
- Firm Network Integration Transmission Service
- Market Monitor website (for firm power purchase/sale information input)

## 7. Suggested Tags
- Must-Offer Obligation
- Market Participant Compliance
- Day-Ahead Market
- Resource Commitment
- Operating Reserves
- Net Resource Capacity
- SCUC Algorithm
- SCED Algorithm
- Market Monitor
- Bilateral Contracts
- Firm Power Transactions
- GFA Carve Out
- Capacity Shortage
- Capacity Surplus
- Local Reliability Issues
- Emergency Conditions
- Transmission Constraints
- Jointly Owned Units
- MSR Self-Charging
- Compliance Threshold

## 8. Items That May Need Follow-Up

**Compliance Monitoring:**
- Market Participant compliance with 90% net resource capacity threshold
- Verification of firm power purchase/sale documentation by Market Monitor
- Monitoring of GFA Carve Out source resource offerings

**Process Clarifications:**
- Dispute resolution process when counterparties disagree on firm purchases/sales
- Specific penalties referenced in Section 4.2.1.1.1 (not detailed in this excerpt)
- Cost recovery methodology for manual commitments under Section 4.5.9.13

**Operational Considerations:**
- How MCR transition limitations affect regulation selection availability
- Coordination between SPP and local transmission operators for Local Reliability Issues
- Non-discriminatory selection criteria for manual commitments/decommitments

**Documentation Requirements:**
- Supporting documentation requirements for firm power transactions
- Market Participant input process for Market Monitor website
- Verification procedures between Market Monitor and market participants

**Market Design Issues:**
- Priority order application in capacity shortage vs. surplus scenarios
- Treatment of bilateral contracts in load calculations
- Emergency capacity limit incorporation methodology

---

# Chunk 22 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document (chunk 22 of 27) details SPP's Day-Ahead Market and Reliability Unit Commitment (RUC) operational procedures. The content focuses on algorithm execution processes (SCUC and SCED), manual commitment procedures for addressing reliability issues, resource compensation mechanisms, and capacity adequacy analysis. Key emphasis is placed on distinguishing between regional and local reliability issues, the treatment of Multi-Configuration Resources (MCRs), and the hierarchy of actions taken when capacity is insufficient or excessive. The text represents technical tariff language governing market operations and cost recovery mechanisms.

## 2. Key Topics

- **Day-Ahead Market SCUC/SCED Execution**: Algorithms for clearing resource offers, managing demand bids, virtual energy bids, and operating reserves while optimizing costs
- **Manual Commitment Procedures**: Processes for SPP to commit resources outside algorithmic solutions for reliability issues
- **Local vs. Regional Reliability Issues**: Differentiation between local transmission operator issues and system-wide reliability concerns
- **Cost Recovery Mechanisms**: Local vs. regional collection of compensation for manually committed resources
- **RUC (Reliability Unit Commitment) Operations**: Day-Ahead and Intra-Day capacity adequacy analysis
- **Multi-Configuration Resources (MCRs)**: Special restrictions on MCRs with transition times >30 minutes regarding contingency reserve and regulation eligibility
- **Violation Relaxation Limits (VRLs)**: Application in SCED when constraints cannot be satisfied
- **Resource Commitment Hierarchy**: Priority ordering for addressing capacity shortages and surpluses

## 3. Decisions or Actions

**Automatic Actions by Algorithms:**
- SCUC algorithm commits resources to meet demand at minimum cost
- SCED algorithm clears resource offers using marginal loss sensitivity factors
- Re-run Day-Ahead SCUC after manual commitments (time permitting)

**Manual Actions by SPP:**
- Manual commitment of resources for reliability issues not addressable within SCUC
- Application of VRLs when shadow prices are insufficient
- Notification to Market Participants when units are manually committed

**Priority Actions for Capacity Shortage:**
1. Curtail non-firm Export Interchange Transactions
2. Incorporate capacity up to Maximum Emergency Capacity Operating Limits
3. De-commit charging resources committed in DA Market
4. De-commit self-committed charging resources

**Priority Actions for Capacity Surplus:**
1. Curtail non-firm fixed Import Interchange Transactions
2. Incorporate capacity down to Minimum Emergency levels
3. Commit available reliability resources capable of charging
4. De-commit Market-committed resources
5. De-commit self-committed resources

**Required Collaborative Actions:**
- SPP, local transmission operators, and resource owners must develop operating guides for manual commitments addressing known and recurring Local Reliability Issues

## 4. Important Dates

- No specific calendar dates mentioned
- References to operational timeframes:
  - **Operating Day**: The upcoming day for which market is being cleared
  - **30 minutes**: Transition time threshold for MCR eligibility restrictions
  - **Day-Ahead timeline**: Market execution occurring before the operating day
  - **Intra-Day timeline**: Market execution throughout the operating day

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)**: Primary operator and market administrator
- **Local transmission operators**: Entities operating within SPP footprint with local reliability responsibilities
- **Market Participants**: Resource owners and other market entities
- **Market Monitor**: Entity overseeing non-discriminatory resource selection (Section 6.1.2.1 reference)

**Roles (no individual names mentioned):**
- SPP Operators
- SPP RUC Operators
- Day-Ahead RUC Operators
- Intra-Day RUC Operators
- Reliability Coordinator
- Resource owners

## 6. Links or References

**Internal Document References:**
- Section 4.5.8.12 (compensation for committed resources)
- Section 4.5.9.10(1) (local cost recovery)
- Section 4.5.9.12 (compensation mechanism)
- Section 3.1.1 (resource operating constraints and transmission constraints)
- Section 4.1.3.3 (VRL application in SCED)
- Section 6.1.7.1 (MCR registration option)
- Section 4.5.9.8 (RUC compensation)
- Section 4.5.9.10 (regional cost recovery)
- Section 6.1.2.1 of Attachment AE to the Tariff (Market Monitor process)

**Referenced Processes/Algorithms:**
- SCUC (Security Constrained Unit Commitment) algorithm
- SCED (Security Constrained Economic Dispatch) algorithm
- Day-Ahead RUC
- Intra-Day RUC

**Referenced Concepts:**
- Shadow Price calculation
- Violation Relaxation Limits (VRLs)
- Marginal loss sensitivity factors
- Co-optimization logic

## 7. Suggested Tags

- Day-Ahead-Market
- RUC-Operations
- SCUC-Algorithm
- SCED-Algorithm
- Manual-Commitment
- Local-Reliability-Issues
- Cost-Recovery
- Resource-Compensation
- Operating-Reserves
- Multi-Configuration-Resources
- Capacity-Adequacy
- Transmission-Constraints
- Market-Clearing
- Reliability-Coordinator
- Emergency-Operations
- Interchange-Transactions
- Market-Tariff
- SPP-Operations

## 8. Items That May Need Follow-Up

**Clarification Needed:**
1. **Operating Guide Development**: What is the timeline and process for SPP, local transmission operators, and resource owners to develop operating guides for known and recurring Local Reliability Issues?
2. **MCR Transition Time Verification**: How are transition times >30 minutes measured and verified for MCR eligibility determinations?
3. **Local vs. Regional Cost Allocation**: What criteria definitively determine whether cost recovery is collected locally vs. regionally under Section 4.5.9.10?

**Process/Implementation Questions:**
4. **Manual Commitment Notification**: What specific information must be included when SPP notifies Market Participants of manual commitments?
5. **Market Monitor Review**: What is the timeline for Market Monitor review of non-discriminatory resource selection under Section 6.1.2.1?
6. **SCUC Re-run Decisions**: Under what circumstances would time not permit re-running the Day-Ahead SCUC after manual commitments?

**Operational Concerns:**
7. **RUC Advisory vs. Binding**: How do RUC Operators determine which advisory actions to implement and timing thereof?
8. **Local Transmission Operator Coordination**: What communication protocols exist between SPP and local transmission operators for Local Reliability Issue identification and resource commitment requests?
9. **VRL Application**: What constitutes "appropriately priced VRL" and who determines when shadow prices are insufficient?

**Stakeholder Impact:**
10. **Resource Owner Compensation Equity**: How is "same manner as any other Resource" compensation verified for manually committed resources addressing Local Reliability Issues?
11. **Self-Committed Resource De-commitment**: What notice is provided to resource owners when self-committed resources are de-committed due to capacity surplus?

---

# Chunk 23 Analysis

# Regulatory Document Analysis Report

## 1. Executive Summary
This document (chunk 23 of 27) from SPP Comments dated 2025-08-27 contains detailed technical and procedural specifications related to SPP's (Southwest Power Pool) operational procedures and planning criteria. The content covers three main regulatory frameworks: market operations procedures (focusing on resource commitment and dispatch during reliability events), operating criteria (including emergency operations and communication protocols), and planning criteria (defining transmission system requirements and modifications). The document emphasizes coordination between SPP, local transmission operators, and resources to maintain system reliability while ensuring non-discriminatory practices verified by the Market Monitor.

## 2. Key Topics

- **Resource Commitment and Dispatch Protocols**: Procedures for managing excess capacity situations and reliability issues through SCUC (Security Constrained Unit Commitment)
- **Local Reliability Issues Management**: Protocols for out-of-merit commitments and emergency dispatch instructions
- **Compensation Recovery Mechanisms**: Regional vs. local collection of costs for reliability commitments
- **Non-Conforming Load Registration**: Requirements for identifying and registering loads of 50 MW or greater
- **Emergency Operating Plans (EOPs)**: Guidelines for operator-controlled load shedding and critical natural gas load protection
- **ICCP (Inter-Control Center Communications Protocol) Requirements**: Connectivity and redundancy standards for TOPs and GOPs
- **Transmission Planning Criteria**: Definitions and requirements for transmission system modifications and qualified changes
- **Material Modification Standards**: Criteria for evaluating permanent changes to transmission, generation, and end-user facilities

## 3. Decisions or Actions

### Procedural Actions Required:
- **Resource Commitment Hierarchy**: Established order for addressing capacity surplus: (1) curtail non-firm imports, (2) incorporate emergency capacity limits, (3) commit reliability resources capable of charging, (4) de-commit day-ahead market resources, (5) de-commit self-committed resources
- **Manual Commitment Protocol**: SPP may manually commit/de-commit resources for transmission reliability issues not addressed within SCUC algorithm
- **Local Transmission Operator Authority**: During Local Emergency Conditions when time doesn't permit, operators may issue instructions directly to resources, with subsequent SPP coordination required
- **Non-Discriminatory Selection Verification**: Market Monitor must verify resource selection through Section 6.1.2.1 process
- **Operating Guides Development**: SPP, local transmission operators, and resource owners must develop operating guides for manual commitments addressing recurring local reliability issues

### Compliance Requirements:
- **Non-Conforming Load Identification**: Market participants must identify any Non-Conforming Load assets of 50 MW or greater
- **ICCP Node Configuration**: TOPs must configure ICCP nodes to connect to both SPP primary and backup sites concurrently
- **240-Second Reconnection Standard**: TOPs and GOPs must configure alternate ICCP nodes to reconnect within 240 seconds of failure
- **Concurrent Connection for Large GOPs**: GOPs with >1500 MW or 15+ capacity resources must read setpoint instructions from both primary and secondary ICCP nodes concurrently

## 4. Important Dates

**No specific dates or deadlines are mentioned in this document chunk.** The content focuses on ongoing operational procedures and compliance requirements rather than time-bound actions.

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)** - Primary organization; serves as Transmission Provider, Planning Coordinator, and Reliability Coordinator
- **Market Monitor** - Verification and oversight entity for non-discriminatory practices
- **NERC (North American Electric Reliability Corporation)** - Standards-setting body referenced multiple times
- **Local Transmission Operators** - Entities with authority during Local Emergency Conditions
- **TOPs (Transmission Operators)** - Entities registered with NERC within SPP RC Area
- **GOPs (Generator Operators)** - Generation facility operators within SPP BA Area
- **Market Participants** - Entities participating in SPP's Integrated Marketplace
- **Asset Owners** - Owners of Non-Conforming Load assets
- **Resource Owners** - Entities owning generation or other resources
- **Transmission Owners** - Host entities for delivery point facilities

### People:
**No individual persons are mentioned in this document chunk.**

## 6. Links or References

### Internal SPP Document References:
- **Section 4.5.9.8** (Attachment AE to the Tariff) - Resource compensation provisions
- **Section 4.5.9.10** (Attachment AE to the Tariff) - Cost recovery collection procedures
- **Section 6.1.2.1** (Attachment AE to the Tariff) - Market Monitor verification process for non-discriminatory selection
- **Attachment O** (OATT) - Transmission Planning Process
- **Attachment V** (OATT) - Generation interconnection procedures and Material Modification definitions
- **Attachment AB** (OATT) - Retirement assessment procedures
- **Attachment AQ** (OATT) - Delivery point establishment procedures
- **Section 5 of the SPP Criteria** - Transmission system definitions
- **Sections 5.4 and 5.5 of SPP Planning Criteria** - Transmission Material Modification details
- **Section 3.6** - SPP Reliability Coordinator EOP Reviews
- **Section 5.2** - Node Connectivity Requirement

### External References:
- **NERC Reliability Standards** - General reference to compliance requirements
- **NERC Glossary of Terms** - Definitions for capitalized terms
- **NERC Standard FAC-002-041** - Mandatory reliability standard for qualified changes
- **RDS (Telemetering and Control System Status)** - Outage Scheduling Information

### Processes Referenced:
- **SCUC (Security Constrained Unit Commitment)** algorithm
- **Day-Ahead RUC (Reliability Unit Commitment)** process
- **Intra-Day RUC** process
- **DA Market (Day-Ahead Market)**
- **RTBM (Real-Time Balancing Market)** Offers

## 7. Suggested Tags

### Primary Tags:
- Resource Commitment
- Reliability Operations
- Local Reliability Issues
- Emergency Operations
- Market Operations

### Secondary Tags:
- SCUC Algorithm
- Manual Commitment
- Non-Discriminatory Selection
- Market Monitor
- Compensation Recovery
- Non-Conforming Load
- ICCP Requirements
- Transmission Planning
- Material Modification
- Emergency Operating Plans
- Load Shedding
- Critical Gas Loads
- Connectivity Standards
- BES (Bulk Electric System)
- NERC Compliance

### Technical Tags:
- Real-Time Balancing Market
- Day-Ahead Market
- Reserve Zones
- Transmission Constraints
- Operating Limits
- PNode/APNode
- OATT (Open Access Transmission Tariff)

## 8. Items That May Need Follow-Up

### Operational Clarifications Needed:
1. **Market Monitor Verification Timeline**: What is the timeframe for Market Monitor to complete non-discriminatory selection verification under Section 6.1.2.1?
2. **Affiliated Resource Compensation Denial**: What constitutes an "affiliated Resource" for purposes of denying compensation for discriminatory selection?
3. **Operating Guides Development Status**: Have the operating guides for manual commitments addressing recurring Local Reliability Issues been completed between SPP, local transmission operators, and resource owners?
4. **Non-Conforming Load Registration Compliance**: What is the current compliance rate for Market Participants identifying Non-Conforming Load assets ≥50 MW?

### Technical Implementation Questions:
5. **ICCP Reconnection Compliance**: Are all TOPs and GOPs currently meeting the 240-second reconnection requirement for alternate ICCP nodes?
6. **Third-Party Contract Specifications**: For TOPs/GOPs using third-party ICCP contracts, what specific contractual language ensures the 240-second reconnection requirement?
7. **Concurrent Connection for Large GOPs**: How many GOPs currently meet the threshold of >1500 MW or 15+ capacity resources requiring concurrent primary/secondary ICCP connections?

### Cost Recovery and Compensation Issues:
8. **Regional vs. Local Cost Allocation**: What are the specific criteria determining whether compensation recovery is collected regionally vs. locally under Section 4.5.9.10?
9. **Local Emergency Condition Compensation**: When local transmission operators issue direct instructions during emergencies, what documentation is required to ensure resource eligibility for compensation?

### Planning and Coordination:
10. **Transmission Material Modification Backlog**: How many pending Transmission Material

---

# Chunk 24 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document chunk (24 of 27) from RR696 SPP Comments contains detailed procedural language regarding SPP's (Southwest Power Pool) transmission system studies, generator interconnection processes, and delivery point evaluation procedures. The content focuses on three main areas: (1) system studies for non-jurisdictional facilities and their interconnection requirements, (2) HILLGA (High Impact/Low List Generation Addition) network study procedures and modeling requirements, and (3) Business Practice 7850 governing Delivery Point Additions, Modifications, and Retirements under Attachment AQ and AX processes. The document establishes responsibilities for Transmission Owners, interconnection customers, and SPP in conducting studies and completing required network upgrades.

## 2. Key Topics

- **Non-Jurisdictional Generator Interconnection Studies**: Procedures for SPP studies of generators outside SPP's jurisdictional authority, including affected system analysis requirements
- **Transmission Owner Responsibilities**: Requirements for Transmission Owners to conduct impact studies and coordinate with SPP on system impacts
- **Network Upgrade Requirements**: Processes for identifying, funding, and completing network upgrades before generator facility operation
- **HILLGA Study Procedures**: Detailed methodology for studying generation additions, including queue positioning, modeling requirements, and serial vs. parallel study approaches
- **Short-Circuit Analysis**: Procedures for fault current calculations consistent with ITP Manual standards
- **Delivery Point Evaluation Process**: Business Practice 7850 defining evaluation of Delivery Point Additions, Modifications, and Retirements
- **Attachment AQ and AX Processes**: Planning processes to assess impacts of delivery point changes and identify necessary upgrades
- **Model Development**: Requirements for updating HILL models to include electrically-equivalent generation and affected system resources

## 3. Decisions or Actions

- Transmission Owners must conduct required studies when notified of generator interconnection requests that may impact the Transmission System
- SPP will determine what additional studies are required as an impacted system, potentially including Definitive Interconnection System Impact Studies
- Transmission Owner/distribution provider must require completion of all SPP-required studies as a condition of interconnection
- Either Transmission Owner or interconnection customer must enter into Affected System study agreements and assume financial responsibility
- All Network Upgrades must be completed prior to Generating Facility operation unless SPP approves alternative mitigations
- Transmission Customers are responsible for notifying SPP to update NITS Agreements or Provisional Load Process Agreements after Attachment AQ/AX review
- HILLGA Requests will be studied serially if Electrically-Equivalent, or in parallel if not Electrically-Equivalent

## 4. Important Dates

- No specific dates are mentioned in this document chunk
- References to timing include:
  - Network Upgrades completion required "prior to operation of the Generating Facility"
  - Study timelines must meet "standardized project timelines as provided in BP 7060"
  - References to "quarterly" project tracking reports

## 5. Organizations and People Mentioned

**Organizations:**
- SPP (Southwest Power Pool) - primary regulatory organization
- Associated Electric Cooperatives, Inc.
- California Independent System Operator Corporation
- Electric Reliability Council of Texas (ERCOT)
- Midcontinent Independent System Operator, Inc. (MISO)
- Peak
- Public Service Company of Colorado
- Saskatchewan Power Corporation
- Southwestern Power Administration
- Tennessee Valley Authority
- Transmission Owners (multiple, unspecified)
- Distribution providers
- Interconnection customers

**People:** None specifically mentioned

## 6. Links or References

**Referenced Documents:**
- SPP Open Access Transmission Tariff (OATT)
- Generator Interconnection Procedures (Attachment V)
- SPP Business Practices (BP 7250, BP 7060, BP 7850)
- Attachment BB (various sections: 4.1.1, 8.4.1)
- Attachment AQ
- Attachment AX
- ITP Manual (Short-Circuit Analysis section)
- SPP Model Development Procedure Manual
- Seams Agreements (multiple organizations listed)
- SPP Disturbance Performance Requirements
- SPP Quarterly Project Tracking Report
- Request Management System
- NITS Agreement
- Provisional Load Process Agreement

**Online Resources Mentioned:**
- Reference materials available at unspecified sites

## 7. Suggested Tags

- Generator Interconnection
- Transmission Planning
- Network Upgrades
- HILLGA Studies
- Non-Jurisdictional Facilities
- Affected System Studies
- Delivery Points
- Attachment AQ
- Attachment AX
- Short-Circuit Analysis
- Business Practice 7850
- Transmission System Studies
- SPP Tariff
- NITS (Network Integration Transmission Service)
- Model Development
- Queue Management
- Cost Allocation
- Seams Agreements

## 8. Items That May Need Follow-Up

1. **Incomplete Section**: HILLGA Network studies section contains "(Placeholder)" indicating unfinished content requiring completion

2. **Financial Responsibility Clarification**: The dual-option approach (Transmission Owner vs. interconnection customer bearing study costs) may require clearer guidelines on decision-making criteria

3. **Definition Alignment**: Business Practice definitions for Delivery Point-related terms are "not currently defined in the SPP OATT" - formal tariff amendments may be needed for consistency

4. **Aggregation Criteria**: The section on "Aggregation of Requests" appears incomplete (cuts off mid-sentence) and needs completion

5. **Model Update Timing**: Clarification may be needed on the timing of incorporating "GIAs that have occurred prior to the commencement of the study and subsequent to the publishing of the ITP models"

6. **Mitigation Alternatives**: The provision allowing operation before Network Upgrades completion "unless other mitigations have been approved by SPP" lacks detailed criteria for such approvals

7. **Study Agreement Templates**: References to "appropriate study agreements" and "applicable Affected System study agreements" may benefit from standardized templates

8. **Cross-Process Coordination**: The interaction between Attachment AQ, Attachment AX, and ITP Assessment processes may require workflow documentation

9. **Electrically-Equivalent Definition**: The criteria for determining when HILLGA Requests are "Electrically-Equivalent" needs clarification for consistent application

10. **Cost Recovery Mechanisms**: How network upgrade costs are allocated and recovered when multiple parties have optionality in funding responsibilities may need additional detail

---

# Chunk 25 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary
This document section (chunk 25 of 27) from SPP's regulatory comments covers multiple technical and operational procedures. The content primarily focuses on three areas: (1) delivery point study processes and aggregation protocols (Attachments AQ and AX), (2) resource adequacy requirements for demand response programs and behind-the-meter generation (Business Practice 8100), and (3) integrated transmission planning procedures. Additionally, it includes two revenue requirement tables listing transmission owners and their associated financial metrics.

## 2. Key Topics

- **Delivery Point Network Study (DPNS) and Provisional Load Process Study (PLPS) Aggregation**
  - Consolidation of multiple study requests into single analyses
  - Transmission Provider approval requirements for aggregation
  - Comprehensive system analysis approach

- **Attachment AQ Process Criteria**
  - Applicable when Transmission Customer has sufficient Designated Resources
  - Covers Delivery Point additions, modifications, and retirements
  - Specific exclusions defined (transfers between customers, non-interconnected points)

- **Attachment AX Process Criteria**
  - Applies when insufficient Designated Resources exist
  - Focuses on new delivery point additions
  - Different scope than AQ process

- **Demand Response Programs (Business Practice 8100)**
  - Measurable load reduction programs
  - Controllable/dispatchable vs. non-controllable/non-dispatchable classifications
  - Peak Demand reduction requirements and reporting

- **Behind-The-Meter Generation**
  - Resources under 10 MW
  - Treatment as load modifier vs. resource capacity
  - Non-controllable resources (e.g., rooftop solar) considerations

- **Integrated Transmission Planning (ITP) Manual**
  - Load forecast requirements for SPP transmission owners
  - Non-coincident peak conditions methodology
  - Persistent operational needs assessment criteria

- **Revenue Requirements**
  - Through and Out transaction allocations
  - Schedule 1 Point-to-Point revenue credits
  - Multiple transmission owner listings

## 3. Decisions or Actions

- **Study Aggregation Protocol**: Transmission Provider must propose aggregated study approach to all Parties and evaluate feedback before making aggregation decision

- **Resource Adequacy Reporting**: Each Load Responsible Entity (LRE) must report projected MW level of Peak Demand reduction as informational line item in the Workbook

- **Load Forecast Submission**: Load forecasts must be submitted to SPP using Model Development Procedure Manual process

- **Additional Needs Identification**: SPP may propose additional operational needs beyond criteria thresholds; these will be presented to ESWG and TWG for review and endorsement

- **Peak Demand Forecasting**: Non-controllable demand response programs must be incorporated into forecasted Peak Demand using 50-50 probability methodology

## 4. Important Dates
No specific dates are mentioned in this document section.

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)** - Transmission Provider
- **ESWG** - Economic Studies Working Group
- **TWG** - Transmission Working Group

### Transmission Owners Listed (24 entities):
- AEP West Transmission Companies
- American Electric Power (PSO and SWEPCO)
- Arkansas Electric Cooperative Corporation (Zones 1 and 7)
- City Utilities of Springfield
- Corn Belt Power Cooperative
- Empire District Electric Company
- Evergy Kansas Central, Inc.
- Evergy Metro, Inc.
- Evergy Missouri West, Inc.
- Grand River Dam Authority
- Kansas City Board of Public Utilities
- Lincoln Electric System
- Midwest Energy, Inc
- Missouri Joint Municipal Electric Utility Commission
- Nebraska Public Power District
- Oklahoma Gas and Electric
- Omaha Public Power District
- Southwestern Power Administration
- Southwestern Public Service Company
- Sunflower Electric Power Corporation
- Tri-State G&T Association
- Western Farmers Electric Cooperative
- Western-UGP

### Entity Types:
- Network Customers
- Transmission Customers
- Load Responsible Entities (LREs)
- Market Participants

## 6. Links or References

### Referenced Documents/Processes:
- **Attachment AQ** - Delivery point study process
- **Attachment AX** - Alternative delivery point study process
- **Attachment AA** - Resource Adequacy Requirement and Winter Season Obligation
- **Business Practice 8100** - Resource adequacy for demand response and BTM generation
- **ITP Manual** - Integrated Transmission Planning Manual
- **Model Development Procedure Manual** - Load forecast submission process
- **RRR File** - Revenue Requirement Reference File (referenced throughout tables)

### Referenced Sections:
- Section II.3 (American Electric Power)
- Section 2.1.3 (Load Forecasts)
- Section 4.4 (Persistent Operational Needs Assessment)

## 7. Suggested Tags

- Transmission Planning
- Delivery Point Studies
- Resource Adequacy
- Demand Response
- Behind-the-Meter Generation
- Load Forecasting
- Network Upgrades
- SPP Tariff
- Revenue Requirements
- Point-to-Point Transmission
- DPNS
- PLPS
- ITP
- Transmission Service Agreements
- Local Delivery Facilities

## 8. Items That May Need Follow-Up

1. **Study Aggregation Decisions**: How and when will Transmission Provider communicate aggregation decisions to all Parties? What is the feedback timeline?

2. **Resource Adequacy Reporting**: What is the deadline for LREs to submit Peak Demand reduction projections in the Workbook? What format is required?

3. **Revenue Requirement Details**: All tables reference "See RRR File" - the actual revenue requirement values need to be obtained from the referenced file for complete analysis.

4. **Historical Data Requirements**: Section 3.0 mentions "historical hourly demand data sufficient to establish reduction" - what constitutes "sufficient" data? What is the minimum timeframe?

5. **Non-Controllable Resource Classification**: What are the specific criteria for determining whether a demand response program or BTM resource is controllable/dispatchable?

6. **ESWG and TWG Review Process**: What is the timeline for presentation and endorsement of additional operational needs?

7. **50-50 Forecast Methodology**: What statistical methods and assumptions should be used to ensure proper 50-50 probability in Peak Demand forecasts?

8. **Interface Transmission Service**: Clarification needed on what constitutes "transmission service has already been granted across the interface" for delivery points not physically interconnected with SPP system.

9. **Local Delivery Facilities Definition**: The term appears multiple times but specific definition may need verification in other tariff sections.

10. **Schedule 1 PTP Revenue Credits**: Many transmission owners show "N/A" or "$0" - clarification needed on why certain owners have no credits.

---

# Chunk 26 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary
This document appears to be chunk 26 of 27 from SPP (Southwest Power Pool) comments on Revision Request 696 (RR696), dated August 27, 2025. The content consists primarily of detailed rate allocation tables showing zonal and region-wide Annual Transmission Revenue Requirements (ATRR) for various transmission providers and utilities across the SPP footprint. The tables reference "Attachment H" for detailed financial figures and include provisions for base plan allocations, balanced portfolio allocations, and upgrade sponsor payments.

## 2. Key Topics
- **Annual Transmission Revenue Requirements (ATRR)** allocation across zones and region-wide
- **Zonal rate structures** for 19+ transmission zones within SPP
- **Base Plan vs. Balanced Portfolio** ATRR allocations
- **Upgrade Sponsor payments** methodology
- **Interregional planning** cost allocations
- **Network Integration Transmission Service (NITS)** ATRR
- **Transmission cost allocation** following June 19, 2010 regulatory changes
- **Joint Transmission Improvement Queue (JTIQ)** ATRR balances

## 3. Decisions or Actions
- Specific ATRR amounts allocated to several entities:
  - East Texas Electric Cooperative, Inc.: $14,567,983
  - Deep East Texas Electric Cooperative, Inc.: $2,576,698
  - Oklahoma Municipal Power Authority (Zone 1e): $768,624
  - Coffeyville Municipal Light and Power: $391,790
  - City of Independence, Missouri: $7,043,930
  - Oklahoma Municipal Power Authority (Zone 7b): $368,501
  - Southwestern Power Administration (Non-Federal): $15,533,800
  - Central Nebraska Public Power and Irrigation District: $327,891
- Zones 1c and 15 marked as "Reserved for Future Use"
- Most detailed financial information deferred to "Att. H tab, posted RRR File"

## 4. Important Dates
- **June 19, 2010**: Significant regulatory transition date referenced throughout tables; appears to be a dividing line for Base Plan Zonal ATRR calculations and cost allocation methodologies

## 5. Organizations and People Mentioned

**Transmission Providers/Utilities (19 Zones):**
- American Electric Power-West and subsidiaries (multiple sub-zones)
- Kansas City Board of Public Utilities
- City Utilities of Springfield, Missouri
- Empire District Electric Company
- Grand River Dam Authority
- Evergy entities (Metro, Missouri West, Kansas Central/South)
- Oklahoma Gas and Electric
- Midwest Energy, Inc.
- Southwestern Power Administration
- Southwestern Public Service Company
- Sunflower Electric Power Corporation
- Western Farmers Electric Cooperative
- Lincoln Electric System
- Nebraska Public Power District
- Omaha Public Power District
- Upper Missouri Zone participants (Basin Electric, Western-UGP, etc.)

**Cooperatives and Municipal Utilities:**
- East Texas Electric Cooperative, Inc.
- Deep East Texas Electric Cooperative, Inc.
- Oklahoma Municipal Power Authority
- Arkansas Electric Cooperative Corporation (AECC)
- People's Electric Cooperative
- Multiple municipal utilities in Iowa, South Dakota, and other states

**Transmission Companies:**
- Transource Oklahoma, LLC
- Transource Missouri, LLC
- ITC Great Plains, LLC
- NextEra Energy Transmission Southwest, LLC
- Prairie Wind Transmission, LLC
- South Central MCN LLC

## 6. Links or References
- **Attachment H tab** - Referenced throughout as containing detailed ATRR figures in "posted RRR File"
- **Section II.2** - Referenced for American Electric Power details
- **Column (6), Section I, Table 1** - Referenced for ATRR reallocation figures
- **RRR File** (Revision Request Record File) - Repository for detailed financial data

## 7. Suggested Tags
- ATRR
- Transmission-Cost-Allocation
- SPP-Tariff
- Zonal-Rates
- Region-Wide-Rates
- Base-Plan
- Balanced-Portfolio
- Upgrade-Sponsorship
- Interregional-Planning
- RR696
- Southwest-Power-Pool
- FERC-Compliance
- Network-Transmission-Service

## 8. Items That May Need Follow-Up

1. **Missing Financial Data**: Most ATRR amounts reference "Att. H tab" - need to obtain and verify Attachment H for complete financial picture

2. **Reserved Zones**: Zones 1c and 15 are "Reserved for Future Use" - may need clarification on future allocation plans

3. **Regulatory Context**: June 19, 2010 date appears significant but lacks explanation - may need background on what regulatory change occurred

4. **Document Completeness**: This is chunk 26 of 27 - need to review full document for complete context of RR696

5. **Upgrade Sponsor Details**: Column 7 references payments to upgrade sponsors but methodology not detailed in these tables

6. **JTIQ Balance**: Table 5, Line 9 references JTIQ ATRR Balance - may need clarification on queue status and outstanding balances

7. **Interregional Coordination**: Tables 4 and 5 include "Other Interregional Planning Region ATRR" and "Other transmission provider ATRR" - may need details on which other regions/providers

8. **Effective Date**: Document dated 20250827 (August 27, 2025) - appears to be future date; verify if this is intended implementation date or filing date

9. **Rate Impact Analysis**: No narrative explanation of rate impacts on customers - may need supporting analysis

10. **NextEra Entries**: NextEra Energy Transmission Southwest appears in multiple zones (7e, 14e) with dual column references - may need clarification on allocation methodology

---

# Chunk 27 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document (chunk 27 of 27) contains the final sections of SPP (Southwest Power Pool) regulatory filing RR696 dated August 27, 2025. The content consists primarily of technical reference tables including:
- A comprehensive zonal structure listing all transmission owners and their ATRR (Annual Transmission Revenue Requirement) and Schedule 11 credit status across 19 zones
- Detailed transmission service request timelines and procedures for various service types (Long-Term Firm, Short-Term Firm, Non-Firm, and Next Hour Market)
- A complete acronym glossary defining technical terms used throughout the SPP regulatory framework

This appears to be the appendix/reference section of a larger tariff or regulatory filing document.

## 2. Key Topics

- **Zonal Transmission Structure**: Detailed breakdown of 19 transmission zones within SPP, including sub-zones (e.g., 1a-1i, 6a-6b, 19a-19n)
- **Transmission Owner Credits**: ATRR credits and Schedule 11 credits by zone/transmission owner (most entries marked N/A or $0)
- **Transmission Service Types**: Four categories defined with specific timelines:
  - Long-Term Firm (1 year or more)
  - Short-Term Firm (varying durations from 1 day to over 1 month)
  - Non-Firm (hourly to monthly)
  - Next Hour Market (hourly)
- **Service Request Procedures**: Detailed timelines for transmission requests, provider responses, study processes, customer responses, and energy scheduling changes
- **Technical Terminology**: Comprehensive acronym definitions related to transmission planning, interconnection, and grid operations

## 3. Decisions or Actions

No explicit decisions or actions are documented in this chunk. The content is purely informational/reference material consisting of:
- Established zonal designations
- Pre-defined transmission service request timelines
- Standard operating procedures for various service types
- Standardized terminology definitions

## 4. Important Dates

**Transmission Service Request Deadlines (by service type):**

**Long-Term Firm:**
- 90 days prior to service start (for expedited process)
- Open season schedule per Attachment Z1

**Short-Term Firm:**
- Monthly (>1 month): 31 days prior
- Monthly (1 month): 8 days prior
- Weekly (>1 week to 1 month): 8 days prior
- Weekly (1 week): 2 days prior
- Daily (>1 day to 1 week): 2 days prior
- Daily (1 day): 10:00 day prior

**Non-Firm:**
- Monthly: 3 days prior
- Weekly to monthly: 2 days prior
- Daily: 10:00 day prior
- Hourly: 30 minutes prior

**Next Hour Market:**
- 20 minutes prior to hour

**Response/Scheduling Deadlines:**
- Energy scheduling changes: Generally 12:00 day prior (Firm) or 15:00 day prior (Non-Firm)
- Final changes: 20 minutes prior to start of schedule (most service types)

## 5. Organizations and People Mentioned

**Organizations (Transmission Owners/Operators):**

*Zone 1 - AEP West:*
- American Electric Power (Public Service Company of Oklahoma and Southwestern Electric Power Company)
- East Texas Electric Cooperative, Inc.
- Deep East Texas Electric Cooperative, Inc.
- Oklahoma Municipal Power Authority
- AEP Oklahoma Transmission Company, Inc.
- AEP Southwestern Transmission Company, Inc.
- Coffeyville Municipal Light and Power (CMLP)
- Arkansas Electric Cooperative Corporation (AECC)
- Transource Oklahoma, LLC

*Individual Zones (2-14):*
- Kansas City Board of Public Utilities
- City Utilities of Springfield, Missouri
- Empire District Electric Company
- Grand River Dam Authority
- Evergy Metro, Inc.
- City of Independence, Missouri
- Oklahoma Gas and Electric
- People's Electric Cooperative
- NextEra Energy Transmission Southwest, LLC
- Midwest Energy, Inc.
- Evergy Missouri West, Inc.
- Transource Missouri, LLC
- Southwestern Power Administration
- South Central MCN LLC
- Missouri Joint Municipal Electric Utility Commission
- Southwestern Public Service Company
- Lea County Electric Cooperative, Inc.
- Sunflower Electric Power Corporation
- ITC Great Plains, LLC
- Prairie Wind Transmission, LLC
- Western Farmers Electric Cooperative
- Evergy Kansas Central, Inc.
- Evergy Kansas South, Inc.
- Kansas Power Pool

*Zones 16-19 (Nebraska/Upper Missouri):*
- Lincoln Electric System
- Nebraska Public Power District
- Central Nebraska Public Power and Irrigation District
- Tri-State G&T Association
- Omaha Public Power District
- Western-UGP
- Basin Electric Power Cooperative
- Heartland Consumers Power District
- Missouri River Energy Services
- Moorhead Public Service
- Orange City Municipal Utilities
- City of Pierre, South Dakota
- City of Sioux Center, Iowa
- Watertown Municipal Utility Department
- Denison Municipal Utilities
- Vermillion Light & Power
- East River Electric Power Cooperative, Inc.
- Corn Belt Power Cooperative
- NorthWestern Energy Public Service Corporation
- Northwest Iowa Power Cooperative
- Harlan Municipal Utilities
- Central Power Electric Cooperative
- Mountrail-Williams Electric Cooperative
- Mor-Gran-Sou Electric Cooperative, Inc.
- Roughrider Electric Cooperative, Inc.
- L and O Power Cooperative

**Regulatory/Industry Organizations:**
- Southwest Power Pool (SPP)
- Federal Energy Regulatory Commission (FERC)
- North American Electric Reliability Corporation (NERC)

**No individuals mentioned by name**

## 6. Links or References

**Internal Document References:**
- Section II of Attachment Z1 (open season specifications)
- Section 30.2.2 (expedited designation process)
- Sections 19.4 and 32.4 (study schedules)
- Section II.3 (related to AEP zone)
- Schedule 11 (credit provisions)
- Open Access Transmission Tariff (OATT)

**Technical Standards/Requirements:**
- NERC TPL (Transmission System Planning Performance Requirement)
- PSS/E (Power System Simulator for Engineering)

**No external URLs or web links provided**

## 7. Suggested Tags

- SPP_Tariff
- Transmission_Service
- OATT
- Zonal_Structure
- Transmission_Owners
- Service_Timelines
- Long_Term_Firm
- Short_Term_Firm
- Non_Firm_Service
- Next_Hour_Market
- ATRR_Credits
- Schedule_11
- Generator_Interconnection
- Energy_Scheduling
- Transmission_Planning
- RR696
- Southwest_Power_Pool
- FERC_Regulatory
- Network_Resource
- Acronym_Reference

## 8. Items That May Need Follow-Up

1. **Reserved Zones**: Multiple zones marked "Reserved for Future Use" (Zone 1c, Zone 11b, Zone 15) - may require tracking for future allocation

2. **Zero Dollar Credits**: Several transmission owners show $0 for ATRR or Schedule 11 credits - may need verification:
   - East Texas Electric Cooperative (Zone 1b)
   - Deep East Texas Electric Cooperative (Zone 1d)
   - Oklahoma Municipal Power Authority (Zones 1e, 7b)
   - City of Independence, Missouri (Zone 6b)
   - Southwestern Power Administration (Zone 10, 10a)
   - Central Nebraska Public Power and Irrigation District (Zone 17b)
   - Basin Electric Power Cooperative (Zone 19b)
   - NorthWestern Energy Public Service Corporation (Zone 19g)

3. **N/A Entries**: Majority of transmission owners listed as "N/A" for both credit columns - clarification may be needed on whether this indicates non-participation, different billing arrangements, or data pending

4. **Study Timeline Variations**: Different study completion timeframes based on queue timing (e.g., ">24 hrs to start: 30 days" vs. "<24 hrs to start: best effort") - operational readiness should be confirmed