# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document is a technical manual (Version 1.0) describing SPP's High Impact Large Load Delivery Point Study (HDPS) process. The manual establishes a comprehensive framework for evaluating the interconnection of High Impact Large Loads (HILLs), which present unique reliability and operational challenges to the transmission system. The study process consists of two stages: Base Studies (including thermal overload, voltage stability, short circuit, RMS dynamic performance, and EMT screening) and Supplemental Studies (detailed EMT analyses required if projects fail initial screening). The framework aligns with SPP Tariff requirements (Attachments AQ, AX, BA, and BB), Business Practice 7850, SPP Planning Criteria, and NERC standards. The document is submitted for approval under Revision Request 696 (RR696).

## 2. Key Topics

- **High Impact Large Load (HILL) Interconnection Studies**: Comprehensive technical evaluation framework for large load projects
- **Two-Stage Study Process**: 
  - Base Studies Stage (mandatory for all projects)
  - Supplemental Studies Stage (triggered by EMT screening failures)
- **Base Studies Components**:
  - Thermal Overload Analysis
  - Voltage Stability (Steady State)
  - Short Circuit Duty Assessment
  - RMS Dynamic Performance
  - EMT Screening
- **Supplemental Studies Components**:
  - EMT Dynamic Performance
  - Sub-Synchronous Oscillation (SSO) Studies (screening and detailed)
  - Converter-Driven Stability (screening and detailed)
  - Emergency Power Control (EPC)
  - Active/Reactive Power Capability and Controller Studies
  - Power Quality Studies
  - Fault Ride-through EMT Studies
  - Model Verification (Network and HILL)
- **Screening Methodologies**:
  - SCRCCT approach using SCR, WSCR, CSCR metrics
  - Thresholds: SCR/WSCR/CSCR ≥ 6.0 and CCT ≥ 0.15 seconds
  - EPRI Grid Assessment Tool (GSAT) utilization
  - wMIIF for converter interaction assessment
- **Compliance Framework**: NERC TPL-001-5, SPP Disturbance Performance Requirements (DPR), CIGRE Technical Brochure 909

## 3. Decisions or Actions

- **Study Responsibility**: SPP shall conduct all base studies and supplemental studies
- **EMT Screening Decision Trigger**: Projects failing EMT screening thresholds must proceed to supplemental study stage
- **Screening Thresholds Established**: 
  - SCR/WSCR/CSCR ≥ 6.0
  - Critical Clearing Time (CCT) ≥ 0.15 seconds
- **Collaborative Resolution**: SPP and Transmission Customer(s) will work with affected third parties to resolve converter-driven stability concerns identified in screening studies
- **Model Requirements**: Transmission Customers must provide both RMS and EMT models for HILL equipment
- **Mitigation Identification**: Each study type identifies specific mitigation needs when performance standards are not met
- **Approval Sought**: Document submitted for RR696 approval

## 4. Important Dates

- **07/22/2025**: Version 1.0 revision date (Document prepared for RR696 Approval)
  - Authors: Mostafa Sedighizadeh/Jason Davis

*Note: This appears to be the only explicit date in the document, likely representing the target approval date.*

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)**: Primary organization conducting studies and managing the HDPS process
- **NERC (North American Electric Reliability Corporation)**: Standards authority
- **EPRI (Electric Power Research Institute)**: Developer of Grid Assessment Tool (GSAT)
- **CIGRE**: Technical guidance provider (Technical Brochure 909)

### People:
- **Mostafa Sedighizadeh**: Co-author
- **Jason Davis**: Co-author

### Stakeholder Categories Referenced:
- Transmission Customer(s)
- Network Customer(s)
- Study Engineers
- Third Parties (affected parties in converter-driven stability issues)
- HILL Vendors

## 6. Links or References

### SPP Documents:
- **SPP Tariff**: Attachments AQ, AX, BA, and BB
- **BP 7850**: Business Practice related to HDPS process
- **SPP Planning Criteria**
- **SPP Disturbance Performance Requirements (DPR)**

### Industry Standards:
- **NERC TPL-001-5**: Transmission planning and performance requirements
- **CIGRE Technical Brochure 909**: Guidelines for sub-synchronous oscillation studies

### Tools:
- **EPRI Grid Assessment Tool (GSAT)**: Rapid screening tool for system strength assessment

### Technical References:
- Short Circuit Ratio (SCR) methodology
- Weighted SCR (WSCR)
- Composite SCR (CSCR)
- Weighted Multi-Infeed Interaction Factor (wMIIF)
- SCRCCT screening approach

### Document Reference:
- **Source File**: SPP HDPS Overview-V1.0-MS.docx.txt
- **Revision Request**: RR696

## 7. Suggested Tags

- HILL (High Impact Large Load)
- HDPS (High Impact Large Load Delivery Point Study)
- Interconnection Studies
- EMT (Electromagnetic Transient) Analysis
- RMS Modeling
- Power Flow Studies
- Voltage Stability
- Short Circuit Analysis
- Transient Stability
- Sub-Synchronous Oscillation (SSO)
- Converter-Driven Stability
- System Strength Assessment
- SCR (Short Circuit Ratio)
- NERC TPL-001-5
- SPP Tariff
- Emergency Power Control
- Power Quality
- Fault Ride-Through
- Model Verification
- GSAT
- RR696
- Transmission Planning
- Grid Reliability

## 8. Items That May Need Follow-Up

### Immediate Follow-Up:
1. **RR696 Approval Status**: Track the approval process for this manual (target date 07/22/2025)
2. **Implementation Timeline**: No implementation timeline is specified in the document—needs clarification on when this process becomes effective

### Technical Development Items:
3. **WSCR and CSCR Methodology Refinement**: Document notes these methods are "with ongoing development" for multi-HILL scenarios—track completion status
4. **GSAT Tool Refinement**: Document mentions "supports its refinement for use in evaluating HILL-related reliability concerns"—monitor progress

### Process Clarifications Needed:
5. **Cost Allocation**: No mention of study costs or who bears financial responsibility for base vs. supplemental studies
6. **Study Timeline/Deadlines**: No timeframes specified for completing base or supplemental studies
7. **Model Submission Requirements**: Detailed requirements for when and how Transmission Customers must submit RMS and EMT models
8. **Retool Study Triggers**: Clarify circumstances requiring study updates or re-evaluation

### Stakeholder Coordination:
9. **Third-Party Coordination Process**: Document mentions working with "affected third parties" but doesn't detail the coordination process
10. **Dispute Resolution**: No mechanism outlined for resolving disagreements on study results or mitigation requirements

### Documentation Gaps:
11. **Mitigation Cost Responsibility**: Who pays for identified network upgrades or HILL equipment modifications?
12. **Study Report Format**: No mention of deliverable formats or content requirements for study reports
13. **Confidentiality/Data Sharing**: No provisions outlined for handling proprietary HILL vendor data or competitive information

### Compliance Monitoring:
14. **Post-Installation Verification**: No mention of follow-up studies or monitoring after HILL commissioning
15. **Standard Updates**: Process for updating manual when NERC standards or SPP criteria change

### Specific Technical Items:
16. **Contingency Definitions**: "Contingencies up to N-5" mentioned for SSO studies—confirm alignment with NERC standards
17. **Threshold Justification**: Document basis for SCR ≥ 6.0 and CCT ≥ 0.15 second thresholds
18. **VSC vs. Thyristor Requirements**: