# Final Combined Report

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT
## High Impact Large Load Ride Through Requirements

---

## 1. EXECUTIVE SUMMARY

This draft document (version 0.1, dated August 4, 2025) establishes binding ride-through requirements for High Impact Large Loads (HILLs) interconnecting to the SPP (Southwest Power Pool) Transmission System. The proposal addresses growing grid reliability concerns from large facilities such as data centers, industrial facilities, and cryptocurrency mining operations that can destabilize the grid during disturbances.

**Core Requirement:** HILLs must remain connected during voltage and frequency disturbances (similar to generator requirements), rather than tripping offline and potentially exacerbating grid instability.

**Applicability Thresholds:**
- Loads >10 MW at 69 kV transmission voltage, OR
- Loads >50 MW at voltages above 69 kV

The requirements align with multiple industry standards (NERC PRC-024, PRC-029-1, IEEE 2800-2022) and apply only to new interconnections. The document is subject to technical refinement, stakeholder approval, and incorporation into SPP governing documents before implementation.

**Critical Innovation:** Mandates constant current control (not constant power control) for power electronic loads during disturbances to prevent voltage collapse scenarios.

---

## 2. KEY TOPICS

### A. High Impact Large Load (HILL) Classification
- Size-based thresholds for automatic classification
- Applies to new interconnections only
- Includes paired generation resources on common buses
- Covers both inverter-based and synchronous generation-supported loads

### B. Voltage Ride-Through (VRT) Requirements
- **High Voltage Conditions:** Equipment must withstand voltages up to 1.20 p.u. (120% of nominal)
- **Low Voltage Conditions:** Must remain connected during sags as low as 0.45 p.u. (45% of nominal)
- Time-based requirements: deeper sags require shorter ride-through periods
- Alignment with ITIC curve, IEEE 1668-2017, IEEE 2800-2022, and NERC PRC-029-1

### C. Frequency Ride-Through Requirements
- **Continuous Operation Zone:** 58.8-61.2 Hz (indefinite operation required)
- **Extended Tolerance:** 57.8-61.8 Hz range with time-limited requirements
- Logarithmic time formulas for frequency excursions outside continuous zone
- Designed to prevent cascading failures during grid frequency events

### D. Fault Ride-Through (FRT) Requirements
- **IBR-Supported HILLs:** IEEE 2800-2022 Clause 7 standards
- **Synchronous Generator/Type 1 & 2 Wind-Supported HILLs:** NERC PRC-024-4 standards
- Common bus configurations require aligned performance for all resources
- Prevents conflicting control strategies from destabilizing the grid

### E. Control Methodology Mandates
- **Required:** Constant current control during disturbances for power electronic loads
- **Prohibited:** Constant power control (can worsen voltage sags)
- Positive and negative sequence reactive current relationships must be documented

### F. Compliance and Evaluation Framework
- Integration with SPP Open Access Transmission Tariff study processes
- Dynamic load modeling requirements and validation
- Performance demonstration and monitoring protocols
- Data retention requirements following disturbance events

---

## 3. DECISIONS OR ACTIONS

### Documented Decisions:
1. **HILLs must comply** with specified voltage ride-through requirements (Table 4):
   - 1.20 p.u. voltage: minimum 3 seconds
   - 0.45 p.u. voltage: minimum 0.15 seconds
   - Multiple intermediate thresholds specified

2. **HILLs must comply** with frequency ride-through requirements (Table 6):
   - Continuous operation: 58.8-61.2 Hz
   - Time-limited operation: 57.8-61.8 Hz with logarithmic time calculations

3. **Control strategy mandate:** Power electronic loads must use constant current control (not constant power control) during disturbances

4. **Common bus requirement:** Both HILLs and paired generation resources electrically connected at common buses must meet identical performance standards

### Pending Actions:
- [ ] Technical refinement of requirements (scope and participants TBD)
- [ ] Stakeholder approval process (timeline not specified)
- [ ] Incorporation into SPP governing documents
- [ ] Compliance mechanism determination through stakeholder discussions
- [ ] Finalization of HILLGIA Agreement provisions

### Required Submissions from HILLs:
- [ ] IBR Plant controls default relationship documentation (positive/negative sequence reactive currents per IEEE 2800 Subclause 7.2.2.3.4)
- [ ] Dynamic load modeling validation
- [ ] Ride-through performance demonstration (commissioning tests)
- [ ] Data retention and performance logs following disturbance events
- [ ] Nominal voltage specifications coordination with Transmission Owner

---

## 4. IMPORTANT DATES

| Date | Event/Milestone |
|------|----------------|
| **August 4, 2025** | Initial draft version 0.1 created by Daniel Baker/Mostafa Sedighizadeh |
| **TBD** | Stakeholder approval process (not specified) |
| **TBD** | Technical refinement completion (not specified) |
| **TBD** | Implementation/effective date (not specified) |
| **TBD** | Incorporation into SPP governing documents (not specified) |

**Note:** Document is currently in draft status with no published implementation timeline.

---

## 5. ORGANIZATIONS AND PEOPLE MENTIONED

### People:
- **Daniel Baker** - Document Author
- **Mostafa Sedighizadeh** - Document Co-Author

### Primary Organizations:

**Regulatory/Standards Bodies:**
- **SPP (Southwest Power Pool)** - Primary issuing authority; transmission system operator
- **NERC (North American Reliability Corporation)** - Reliability standards authority
- **FERC (Federal Energy Regulatory Commission)** - Federal regulatory oversight (reviewing PRC-029-1)

**Standards Development Organizations:**
- **IEEE (Institute of Electrical and Electronics Engineers)** - Technical standards (2800-2022, 1547, 1668-2017)
- **ITIC (Information Technology Industry Council)** - Industry voltage tolerance standards (ITIC/CBEMA curve)
- **ANSI (American National Standards Institute)** - Voltage standards (C84.1-2016)

**Industry Working Groups:**
- **NERC Large Load Task Force (LLTF)** - Operational considerations
- **NERC Load Modeling Task Force (LMTF)** - Dynamic modeling efforts
- **ESIG (Energy Systems Integration Group) - Large Load Task Force** - Industry coordination
- **EPRI (Electric Power Research Institute)** - Research (Large Load subprogram, White Paper on Grid Flexibility & Data Centers)

---

## 6. LINKS OR REFERENCES

### Standards Referenced:

**NERC Standards:**
- **NERC PRC-024** - Generator Ride-Through Requirements (general)
- **NERC PRC-024-4** - Specific version for synchronous generators and Type 1/2 wind resources
- **NERC PRC-029-1** - Frequency and Voltage Ride-through Requirements for IBR (currently under FERC review)

**IEEE Standards:**
- **IEEE 2800-2022** - Standard for Interconnection and Interoperability of IBR with Transmission Systems (Clause 7 specifically referenced)
- **IEEE 1547** - Standard for Interconnection of Distributed Energy Resources
- **IEEE 1668-2017** - Voltage Sag and Short Interruption Ride-Through Testing

**Other Standards:**
- **ANSI C84.1-2016** - Voltage standards
- **ITIC Curve (2000)** - Voltage tolerance curve (formerly CBEMA Curve) - https://www.itic.org/

### Internal SPP Documents:
- **SPP Open Access Transmission Tariff** - Study process integration
- **HILLGIA Agreement** - High Impact Large Load Generator Interconnection Agreement (referenced but not detailed)

### Research References:
- **EPRI White Paper on Grid Flexibility & Data Centers** - Referenced for context on large load impacts

---

## 7. SUGGESTED

---

# Partial Chunk Reports

# Chunk 1 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document establishes binding requirements for High Impact Large Loads (HILLs) interconnecting to the SPP (Southwest Power Pool) Transmission System. It addresses growing reliability concerns from large facilities such as data centers, industrial facilities, and crypto mining operations. The proposal mandates that HILLs must "ride through" (remain connected during) voltage and frequency disturbances, similar to requirements already imposed on generators. This is a draft document (version 0.1, dated 2025-08-04) subject to technical refinement, stakeholder approval, and potential incorporation into SPP governing documents.

**Key thresholds:**
- Loads >10 MW at 69 kV, or
- Loads >50 MW at voltages above 69 kV

The requirements align with industry standards including NERC PRC-024, NERC PRC-029-1, and IEEE 2800-2022.

## 2. Key Topics

1. **High Impact Large Load (HILL) Definition and Applicability**
   - Size-based thresholds for classification
   - Application to new interconnections only
   - Coverage of paired inverter-based resources (IBR) and synchronous generators

2. **Voltage Ride-Through (VRT) Requirements**
   - Alignment with ITIC curve, IEEE 1668-2017, IEEE 2800-2022, and NERC PRC-029-1
   - Specific voltage ranges and minimum ride-through times

3. **Frequency Ride-Through Requirements**
   - Continuous operation requirements between 58.8-61.2 Hz
   - Extended ride-through times for broader frequency ranges

4. **Fault Ride-Through (FRT) Requirements**
   - Separate requirements for IBR-supported HILLs (IEEE 2800-2022 based)
   - Requirements for synchronous generator/Type 1 & 2 wind-supported HILLs (PRC-024-4 based)
   - Common bus configurations requiring aligned performance

5. **Control Methodology**
   - Mandatory constant current control during disturbances for power electronic loads
   - Prohibition of constant power control to prevent exacerbating voltage sags

6. **Evaluation and Compliance**
   - Integration with SPP Open Access Transmission Tariff study processes
   - Dynamic load modeling validation
   - Performance demonstration and monitoring

## 3. Decisions or Actions

**Documented Decisions:**
- HILLs must comply with specified voltage and frequency ride-through requirements
- Power electronic loads must use constant current control (not constant power control)
- Both HILLs and paired generation resources on common buses must meet the same performance standards

**Pending Actions:**
- Technical refinement of requirements
- Stakeholder approval process
- Incorporation into SPP governing documents
- Compliance mechanism determination through stakeholder discussions

**Required Submissions:**
- IBR Plant controls default relationship between positive and negative sequence reactive currents (per Subclause 7.2.2.3.4)
- Dynamic load modeling validation
- Ride-through performance demonstration
- Data retention and performance logs following disturbance events

## 4. Important Dates

- **August 4, 2025**: Initial draft version 0.1 created by Daniel Baker/Mostafa Sedighizadeh
- No specific implementation dates or deadlines mentioned
- Document is currently in draft status awaiting stakeholder approval

## 5. Organizations and People Mentioned

**People:**
- Daniel Baker (Author)
- Mostafa Sedighizadeh (Author)

**Organizations:**
- **SPP (Southwest Power Pool)** - Primary regulatory body
- **NERC (North American Reliability Corporation)** - Standards authority
- **IEEE (Institute of Electrical and Electronics Engineers)** - Technical standards body
- **ITIC (Information Technology Industry Council)** - Industry standards organization (formerly CBEMA)
- **NERC Large Load Task Force (LLTF)** - Operational considerations
- **NERC Load Modeling Task Force (LMTF)** - Dynamic modeling efforts
- **ESIG (Energy Systems Integration Group)** - Large Load Task Force
- **EPRI (Electric Power Research Institute)** - Large Load subprogram research

## 6. Links or References

**Standards Referenced:**
- NERC PRC-024 (Generator Ride-Through Requirements)
- NERC PRC-024-4 (for synchronous generators and Type 1/2 wind)
- NERC PRC-029-1 (Frequency and Voltage Ride-through Requirements for IBR) - under FERC review
- IEEE 2800-2022 (Standard for Interconnection and Interoperability of IBR with Transmission Systems) - Clause 7
- IEEE 1547 (Standard for Interconnection of Distributed Energy Resources)
- IEEE 1668-2017 (Voltage Sag and Short Interruption Ride-Through Testing)
- ANSI C84.1-2016 (voltage standards)

**Other References:**
- ITIC Curve (CBEMA Curve Update), 2000 - https://www.itic.org/
- SPP Open Access Transmission Tariff
- EPRI White Paper on Grid Flexibility & Data Centers

## 7. Suggested Tags

- High Impact Large Load (HILL)
- Ride-Through Requirements
- Voltage Ride-Through (VRT)
- Frequency Ride-Through
- Fault Ride-Through (FRT)
- SPP Transmission System
- Data Centers
- Grid Reliability
- Inverter-Based Resources (IBR)
- NERC Standards
- IEEE Standards
- Power Quality
- Interconnection Requirements
- Load Performance
- Crypto Mining
- Industrial Facilities
- Transmission Planning
- Generator Interconnection

## 8. Items That May Need Follow-Up

**Immediate Follow-Up:**
1. **Stakeholder engagement process** - No timeline or process details provided
2. **Technical refinement schedule** - Scope and participants not specified
3. **Compliance mechanism finalization** - Multiple options listed but no decision process outlined
4. **Chunk 2 review** - This is only chunk 1 of 2; remaining content needs analysis

**Technical Clarifications Needed:**
1. **Retroactive application** - Document only mentions "new" HILLs; unclear how existing loads are addressed
2. **Nominal voltage specifications** - Transmission Owner discretion mentioned (Subclause 7.2.2.1) but process unclear
3. **HILLGIA Agreement details** - Referenced but not defined in this chunk
4. **Exemption process** - No mention of hardship cases or technical impossibility scenarios

**Regulatory Dependencies:**
1. **FERC approval of NERC PRC-029-1** - Currently under review
2. **Future NERC reliability standards** - Document defers to more stringent future requirements
3. **Integration with SPP tariff** - Incorporation process not detailed

**Implementation Questions:**
1. How will commissioning tests be standardized?
2. What are consequences for non-compliance?
3. Will existing interconnection agreements need modification?
4. How will "electrically connected at a common bus" be precisely defined?
5. What modeling software and validation methods will be required?

**Cost/Benefit Analysis:**
1. No economic impact assessment included
2. No comparison of transmission reinforcement costs vs. load ride-through requirements
3. Burden on load customers vs. system reliability benefits not quantified

---

# Chunk 2 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary
This document section (chunk 2 of 2) from "High Impact Large Load Ride Through Requirements" contains technical specifications for electrical system performance requirements. It presents detailed voltage and frequency ride-through parameters that large loads must withstand, including specific time thresholds for various voltage deviations and frequency excursions. The content is highly technical and appears to establish minimum operational standards for grid-connected equipment.

## 2. Key Topics
- **Voltage Ride-Through Requirements**: Specifications for how long equipment must remain operational during high and low voltage conditions
- **Frequency Ride-Through Requirements**: Operational duration requirements during frequency deviations from nominal (60 Hz)
- **Grid Stability Standards**: Performance criteria for large load interconnections
- **Power Quality Thresholds**: Defined voltage levels ranging from 0.45 to 1.20 per unit (p.u.) of nominal voltage
- **Frequency Tolerance Ranges**: Acceptable frequency deviations from 57.8 Hz to 61.8 Hz

## 3. Decisions or Actions
No explicit decisions or action items are present in this document section. The tables appear to establish already-determined technical requirements rather than propose new actions.

## 4. Important Dates
No specific dates are mentioned in this content section.

## 5. Organizations and People Mentioned
- **Southwest Power Pool (SPP)**: The only organization explicitly identified in the acronym table

## 6. Links or References
No URLs, hyperlinks, or document references are present in this section. The content is the second chunk of a larger document titled "High Impact Large Load Ride Through Requirements.docx"

## 7. Suggested Tags
- Voltage Ride-Through
- Frequency Ride-Through
- Grid Compliance
- Large Load Requirements
- Power System Stability
- SPP (Southwest Power Pool)
- Interconnection Standards
- Transmission System Requirements
- High Impact Loads
- Power Quality

## 8. Items That May Need Follow-Up
1. **Complete Document Review**: This is only chunk 2 of 2; review of chunk 1 needed for full context, including introductory information, applicability criteria, and any implementation deadlines
2. **Acronym Table Completion**: Table 7 appears incomplete (shows "..." suggesting additional acronyms may be defined)
3. **Frequency Formula Clarification**: The logarithmic formulas in Table 6 (e.g., "10(90.935-1.45713*f)") may require validation or clarification regarding calculation methodology
4. **Compliance Timeline**: Determine when these requirements become effective and any grandfathering provisions for existing installations
5. **SPP Applicability**: Confirm whether these requirements apply solely within SPP territory or have broader application
6. **Testing and Verification**: Determine what documentation or testing is required to demonstrate compliance with these ride-through requirements
7. **Penalty Provisions**: Identify consequences for non-compliance with stated requirements