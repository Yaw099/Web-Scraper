# Final Combined Report

# CONSOLIDATED REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document establishes comprehensive and binding fault ride-through requirements for High Impact Large Loads (HILLs) interconnecting to the Southwest Power Pool (SPP) Transmission System. Driven by reliability concerns from rapidly expanding data centers, industrial facilities, and crypto mining operations, these requirements mandate specific performance standards during voltage and frequency disturbances to prevent grid destabilization.

**Key Provisions:**
- **HILL Definition**: Loads ≥10 MW (for ≤69 kV connections) or ≥50 MW (for >69 kV connections)
- **Applicability**: New interconnection requests submitted after the effective date of RR696
- **Differentiated Requirements**: Separate standards for standalone HILLs versus those paired with generation resources
- **Technical Standards**: Voltage ride-through profiles aligned with ITIC curves and ERCOT proposals; transient overvoltage and frequency ride-through per IEEE 2800-2022 and NERC PRC-029-1
- **Control Mandate**: Mandatory constant current mode operation (constant power mode prohibited)
- **Evaluation Process**: Requirements assessed through SPP's generator interconnection and load addition study processes

This represents a significant regulatory development addressing emerging grid stability challenges from large-scale power electronic loads.

## 2. Key Topics

### HILL Definition and Scope
- **Size Thresholds**: 10 MW minimum (≤69 kV); 50 MW minimum (>69 kV)
- **Target Facilities**: Data centers, industrial facilities, crypto mining operations
- **Categories**: Standalone HILLs vs. HILLs paired with generation resources

### Voltage Ride-Through Requirements
- **RMS Voltage Profiles**: Aligned with ITIC curves and ERCOT proposals (Table 1, Figure 1)
- **Control Methodology**: Constant current mode operation mandatory; constant power mode prohibited
- **Recovery Performance**: 90% recovery within 5 cycles after voltage restoration
- **Voltage Range**: Specific tolerances for voltages from 0 p.u. to >1.80 p.u.

### Transient Overvoltage Ride-Through (Table 2)
- **Voltage Levels**: Instantaneous phase-to-phase or phase-to-ground voltages from 1.20 to 1.80 p.u.
- **Time Requirements**: Minimum ride-through from 0.2 milliseconds (at 1.80 p.u.) to 15.0 milliseconds (at 1.20 p.u.)
- **Cumulative Limits**: Within 1-minute time window
- **Trip Permission**: May trip for voltages >1.80 p.u.
- **Standard Reference**: IEEE 2800-2022 Table 14

### Frequency Ride-Through Requirements (Table 3)
- **Operating Range**: 57.0 Hz to 61.8 Hz
- **Continuous Operation Zone**: 58.8 Hz to 61.2 Hz (mandatory)
- **Extended Ride-Through**: Specific time requirements for frequencies outside continuous zone
- **Trip Permission**: May trip for f≥61.8 Hz or f<57.0 Hz
- **Standard Reference**: NERC PRC-029-1

### Resource-Specific Requirements (Table 5)

**Standalone HILLs:**
- Voltage: Section 4.1.1 specifications
- Frequency: Section 4.1.2 specifications  
- Transient Overvoltage: Section 4.1.3 specifications

**IBRs Paired with HILLs:**
- Voltage: IEEE 2800-2022 Table 11 & 12
- Frequency: IEEE 2800-2022 Table 15
- Transient Overvoltage: IEEE 2800-2022 Table 14

**Non-IBRs Paired with HILLs:**
- Voltage: NERC PRC-024-4 Table 5
- Frequency: NERC PRC-024-4 Table 1
- Transient Overvoltage: No requirement specified

### Control and Performance Requirements
- **Fault Clearing Capability**: Remain connected through 6 fault clearing attempts in 90 seconds
- **Dynamic Load Modeling**: Validation required
- **Performance Demonstration**: Ride-through capabilities must be proven
- **Data Retention**: Performance logs must be maintained

### Evaluation and Compliance
- **Study Processes**: Generator interconnection and load addition study procedures
- **HILLGIA Agreement**: High Impact Large Load Generator Interconnection Assessment
- **Documentation Requirements**: Transmission Customers must submit reactive current relationships and ride-through performance data

## 3. Decisions or Actions

### Binding Decisions Established

**Technical Requirements:**
1. All new HILLs meeting size thresholds must comply with specified ride-through requirements
2. Standalone HILLs must follow voltage profiles in Table 1 and Figure 1
3. IBRs paired with HILLs must adhere to IEEE 2800-2022 Clause 7 standards
4. Non-IBRs paired with HILLs must meet NERC PRC-024-4 requirements
5. Power electronic loads must use constant current control (constant power control explicitly prohibited)
6. HILLs must remain connected through transient overvoltages per Table 2 specifications
7. Continuous operation required for frequency range 58.8-61.2 Hz

**Administrative Decisions:**
8. Requirements apply to interconnection requests submitted on/after RR696 effective date
9. Transmission Owners shall specify nominal voltage for Subclause 7.2.2.1
10. Different obligations apply for HILLs with requests submitted before RR696 effective date

### Pending Actions (Require Completion)

**Critical TBD Items:**
1. **Insert effective date for RR696 implementation** [HIGH PRIORITY]
2. **Determine specific current limitation values** (marked as "TBD" in Section 4.1.1) [HIGH PRIORITY]
3. **Finalize compliance mechanisms** through stakeholder discussions
4. **Incorporate requirements into SPP governing documents** pending stakeholder approval

**Procedural Requirements:**
5. Update HILLGIA Agreement templates to include new requirements
6. Develop modeling validation procedures for dynamic load modeling
7. Create standardized commissioning test protocols for ride-through demonstration
8. Specify data retention requirements and formats

### Required Actions by Transmission Customers

9. Submit default relationship between positive and negative sequence reactive currents
10. Provide documentation of ride-through efforts for pre-existing interconnection requests
11. Coordinate ride-through performance for resources sharing common Point of Interconnection (POI) with HILLs
12. Demonstrate compliance through testing and validation

## 4. Important Dates

### Document Version History
- **July 24, 2025 (v.0.1)**: Initial draft created by Daniel Baker and Mostafa Sedighizadeh
- **August 19, 2025 (v.1.0)**: Updated version finalized

### Critical Implementation Dates
- **[Insert Effective Date of RR696]**: **[TBD - REQUIRES IMMEDIATE DETERMINATION]**
  - Determines applicability threshold for new vs. pre-existing interconnection requests
  - HILLs with requests submitted before this date have different obligations
  - HILLs with requests on/after this date must fully comply with all requirements

### Performance Time Requirements

**Immediate Response (Sub-Second):**
- **5 cycles**: Maximum time for load to return to 90% pre-disturbance consumption after voltage recovery
- **0.2-15.0 milliseconds**: Transient overvoltage ride-through durations (voltage-dependent)

**Short-Term Response:**
- **90 seconds**: Period within which HILL must remain connected through 6 fault clearing attempts
- **1 minute**: Time window for measuring cumulative transient overvoltage duration

**Continuous Requirements:**
- **Ongoing**: Continuous operation required for frequency range 58.8-61.2 Hz

## 5. Organizations and People Mentioned

### Primary Regulatory and Standards Organizations

**Southwest Power Pool (SPP)**
- Primary regulatory authority issuing requirements
- Transmission Provider
- Administers generator interconnection and load addition study processes
- Manages Open Access Transmission Tariff (OATT)

**North American Electric Reliability Corporation (NERC)**
- Develops

---

# Partial Chunk Reports

# Chunk 1 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document establishes binding fault ride-through requirements for High Impact Large Loads (HILLs) interconnecting to the Southwest Power Pool (SPP) Transmission System. The requirements address growing reliability concerns from rapidly expanding data centers, industrial facilities, and crypto mining operations that could destabilize the grid during voltage and frequency disturbances. HILLs are defined as loads of 10 MW or more (≤69 kV) or 50 MW or more (>69 kV). The requirements distinguish between standalone HILLs and those paired with generation resources, mandating specific voltage, overvoltage, and frequency ride-through capabilities. These requirements will apply to new interconnection requests submitted after the effective date of RR696 and will be evaluated through SPP's generator interconnection and load addition study processes.

## 2. Key Topics

- **High Impact Large Loads (HILLs) Definition and Applicability**
  - 10 MW minimum threshold for ≤69 kV connections
  - 50 MW minimum threshold for >69 kV connections
  - Applicability to data centers, industrial facilities, and crypto mining operations

- **Voltage Ride-Through Requirements**
  - RMS voltage profiles aligned with ITIC curves and ERCOT proposals
  - Constant current mode operation (not constant power mode)
  - 90% recovery requirement within 5 cycles after voltage restoration

- **Transient Overvoltage and Frequency Ride-Through**
  - Compliance with IEEE 2800-2022 Table 14 standards
  - Frequency ride-through per NERC PRC-029-1 requirements

- **Paired Resource Requirements**
  - IEEE 2800-2022 Clause 7 requirements for IBRs paired with HILLs
  - PRC-024-4 requirements for synchronous generators and Type 1/2 wind resources

- **Control Methodology**
  - Mandatory constant current control during disturbances
  - Prohibition of constant power control
  - Capability to remain connected through 6 fault clearing attempts in 90 seconds

- **Evaluation and Compliance Mechanisms**
  - Dynamic load modeling validation
  - Ride-through performance demonstration
  - Data retention and performance logs

## 3. Decisions or Actions

**Established Decisions:**
- All new HILLs meeting size thresholds must comply with specified ride-through requirements
- Standalone HILLs must follow voltage profiles in Table 1 and Figure 1
- IBRs paired with HILLs must adhere to IEEE 2800-2022 Clause 7
- Power electronic loads must use constant current control (constant power control prohibited)
- Transmission Owners shall specify nominal voltage for Subclause 7.2.2.1

**Pending Actions:**
- Insert effective date for RR696 implementation
- Determine specific current limitation values (marked as "TBD")
- Finalize compliance mechanisms through stakeholder discussions
- Incorporate requirements into SPP governing documents pending stakeholder approval

**Requirements for Transmission Customers:**
- Submit default relationship between positive and negative sequence reactive currents
- Provide documentation of ride-through efforts for pre-existing interconnection requests
- Coordinate ride-through performance for resources sharing common POI with HILLs

## 4. Important Dates

- **07/24/2025 v.0.1**: Initial draft created by Daniel Baker/Mostafa Sedighizadeh
- **[Insert Effective Date of RR696]**: Implementation date for requirements (TBD)
  - HILLs with requests submitted before this date have different obligations
  - HILLs with requests on/after this date must fully comply

**Time-Based Requirements:**
- 5 cycles: Maximum time for load to return to 90% pre-disturbance consumption after voltage recovery
- 90 seconds: Period within which HILL must remain connected through 6 fault clearing attempts
- 1 minute: Time window for measuring cumulative transient overvoltage duration

## 5. Organizations and People Mentioned

**Organizations:**
- **Southwest Power Pool (SPP)** - Primary regulatory authority
- **NERC (North American Reliability Corporation)** - Standards body (PRC-024-4, PRC-029-1, LLTF, LMTF)
- **ERCOT (Electric Reliability Council of Texas)** - Referenced for voltage ride-through proposals
- **IEEE (Institute of Electrical and Electronics Engineers)** - Standards development (2800-2022, 1547, 1668-2017)
- **ITIC (Information Technology Industry Council)** - Formerly CBEMA, voltage curve standards
- **FERC** - Federal regulator reviewing NERC PRC-029-1
- **ESIG (Energy Systems Integration Group)** - Large Load Task Force
- **EPRI (Electric Power Research Institute)** - Large Load subprogram research

**People:**
- **Daniel Baker** - Co-author (Initial Draft)
- **Mostafa Sedighizadeh** - Co-author (Initial Draft)

**Referenced Entities:**
- Transmission Owners
- Transmission Customers
- Transmission Provider
- Interconnection Customers

## 6. Links or References

**Standards and Regulations:**
- NERC PRC-024-4 (Frequency and Voltage Protection Settings)
- NERC PRC-029-1 (Frequency and Voltage Ride-through Requirements for IBRs)
- IEEE 2800-2022 (IBR Interconnection with Transmission Systems)
- IEEE 1547 (Distributed Energy Resources Interconnection)
- IEEE 1668-2017 (Voltage Sag Ride-Through Testing)
- ANSI C84.1-2016 (voltage standards)

**Documents and Resources:**
- SPP Open Access Transmission Tariff (OATT)
- HILLGIA (High Impact Large Load Generator Interconnection Assessment) Agreement
- EPRI White Paper on Grid Flexibility & Data Centers
- ITIC Curve documentation: https://www.itic.org/

**Task Forces and Working Groups:**
- NERC Large Load Task Force (LLTF)
- NERC Load Modeling Task Force (LMTF)
- ESIG Large Load Task Force

## 7. Suggested Tags

- High Impact Large Loads (HILL)
- Fault Ride-Through
- SPP Requirements
- Voltage Ride-Through
- Data Centers
- Grid Reliability
- Interconnection Requirements
- Power Electronic Loads
- Inverter-Based Resources (IBR)
- Transmission System Stability
- RR696
- IEEE 2800-2022
- NERC Standards
- Load Modeling
- Frequency Protection
- UPS Systems
- Crypto Mining
- Industrial Loads

## 8. Items That May Need Follow-Up

**Critical Pending Items:**
1. **Effective Date for RR696** - Must be determined and inserted
2. **Current Limitation Values (TBD)** - Reasonable current limitation parameters need specification in Section 4.1.1
3. **Stakeholder Approval Process** - Timeline and mechanism for obtaining stakeholder approval
4. **Compliance Mechanism Finalization** - Stakeholder discussions needed to determine final compliance approach

**Technical Clarifications Needed:**
5. **Pre-Existing HILL Documentation** - Process for reviewing and accepting "reasonable efforts" documentation from HILLs with requests prior to RR696 effective date
6. **Transmission Owner Voltage Specifications** - Each Transmission Owner must specify nominal voltages per Subclause 7.2.2.1
7. **Default Reactive Current Relationships** - Template or guidelines for Interconnection Customer submissions under Subclause 7.2.2.3.4

**Integration and Coordination:**
8. **Incorporation into SPP Governing Documents** - Timeline and process for formal integration
9. **HILLGIA Agreement Updates** - Ensure agreement templates include new requirements
10. **Coordination with NERC PRC-029-1** - Monitor FERC review status and ensure alignment
11. **Study Process Updates** - Update generator interconnection and load addition study procedures to include HILL ride-through evaluation

**Implementation Support:**
12. **Modeling Validation Procedures** - Develop specific procedures for dynamic load modeling validation
13. **Commissioning Test Protocols** - Create standardized testing procedures for ride-through demonstration
14. **Data Retention Requirements** - Specify

---

# Chunk 2 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document segment contains technical specifications for Fault Ride-Through (FRT) requirements for High-Impact Large Loads (HILLs) in the Southwest Power Pool (SPP) system. The content consists of detailed tables specifying voltage and frequency ride-through parameters, a comprehensive mapping of requirements by resource category, and standard acronym definitions. These requirements appear to be part of Version 1.0 dated August 19, 2025, establishing critical performance standards for grid-connected loads and resources.

## 2. Key Topics

- **Transient Overvoltage Ride-Through Requirements**: Instantaneous phase-to-phase or phase-to-ground voltage tolerances ranging from 1.20 to 1.80 p.u. with corresponding minimum ride-through times from 0.2 to 15.0 milliseconds
- **Frequency Ride-Through Requirements**: System frequency tolerance ranges from 57.0 Hz to 61.8 Hz with varying ride-through times (continuous operation required between 58.8-61.2 Hz)
- **Category-Based Requirements Matrix**: Different FRT standards for:
  - Standalone HILLs
  - Inverter-Based Resources (IBRs) paired with HILLs
  - Non-IBRs paired with HILLs
- **Cross-Reference to Industry Standards**: IEEE 2800-2022 and NERC PRC-024-4 standards

## 3. Decisions or Actions

- **Established voltage thresholds** for mandatory ride-through vs. permissible tripping (voltages >1.80 p.u. may trip)
- **Defined continuous operation requirement** for frequency range 58.8-61.2 Hz
- **Differentiated requirements** based on resource type (standalone HILL, IBR-paired, non-IBR-paired)
- **Adopted industry standards** by reference (IEEE 2800-2022 for IBRs, PRC-024-4 for non-IBRs)

## 4. Important Dates

- **August 19, 2025**: Document version date (V1.0 - Updated Version)
- **Cumulative time window**: 1-minute window for transient overvoltage events

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)**: Primary regulatory authority issuing requirements
- **ERCOT (Electric Reliability Council of Texas)**: Referenced organization
- **FERC (Federal Energy Regulatory Commission)**: Federal regulatory body
- **NERC (North American Electric Reliability Corporation)**: Reliability standards organization
- **IEEE (Institute of Electrical and Electronics Engineers)**: Standards development organization
- **CBEMA (Computer & Business Equipment Manufacturers Association)**: Industry association
- **ITIC (Information Technology Industry Council)**: Industry council

### People:
None specifically mentioned

## 6. Links or References

- **IEEE 2800-2022**: 
  - Table 11 and Table 12 (Voltage Ride-Through for IBRs)
  - Table 15 (Frequency Ride-Through for IBRs)
  - Table 14 (Transient Overvoltage Ride-Through for IBRs)
- **NERC PRC-024-4**:
  - Table 5 (Voltage Ride-Through for non-IBRs)
  - Table 1 (Frequency Ride-Through for non-IBRs)
- **Document Sections**:
  - Section 4.1.1 (Standalone HILL)
  - Section 4.2.1 (IBRs paired with HILL)
  - Section 4.2.2 (Non-IBRs paired with HILL)

## 7. Suggested Tags

- Fault-Ride-Through
- HILL-Requirements
- Voltage-Ride-Through
- Frequency-Ride-Through
- Grid-Reliability
- SPP-Standards
- Inverter-Based-Resources
- IEEE-2800-2022
- NERC-PRC-024-4
- Transient-Overvoltage
- Large-Load-Interconnection
- Grid-Stability

## 8. Items That May Need Follow-Up

1. **Implementation Timeline**: No effective date or compliance deadline specified for these requirements
2. **Gap in Requirements**: Non-IBRs paired with HILL show no Transient Overvoltage Ride-Through requirement (blank cell in Table 5)
3. **Voltage Measurement Clarification**: Footnote indicates "residual voltages with surge arresters applied" - may need clarification on measurement methodology
4. **Missing Content**: This is "chunk 2 of 2" - requires review of chunk 1 for complete context, including document purpose, scope, and applicability criteria
5. **Exemption Criteria**: Conditions under which "May Trip" is acceptable (V>1.80 p.u., f≥61.8 Hz, f<57.0 Hz) may need additional operational guidance
6. **Cumulative Time Window**: The 1-minute time window application and reset criteria needs clarification
7. **Coordination with Existing Standards**: How these SPP requirements interact with or supersede existing NERC/IEEE standards
8. **Testing and Verification**: Methods for demonstrating compliance not specified in this section