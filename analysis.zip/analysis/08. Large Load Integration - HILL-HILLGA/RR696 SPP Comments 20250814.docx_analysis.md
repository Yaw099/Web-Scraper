# Final Combined Report

# Regulatory Content Analysis Report

## 1. Executive Summary

This is the final chunk (27 of 27) of SPP's RR696 Comments dated August 14, 2025. The content serves as comprehensive reference material including: (1) a complete table of transmission zones and ownership with associated ATRR and Schedule 11 credits, (2) detailed procedural timelines for various transmission service request types, and (3) a technical glossary of acronyms. This appendix-style content provides operational definitions and structured processes for transmission service administration across SPP's multi-state footprint.

## 2. Key Topics

- **Transmission Zone Structure & Ownership**: Complete listing of 19 zones plus sub-zones covering Oklahoma, Kansas, Missouri, Nebraska, Iowa, South Dakota, North Dakota, and Texas
- **Credit Allocation Framework**: ATRR and Schedule 11 credits (predominantly N/A or $0)
- **Transmission Service Categories**:
  - Long-Term Firm (≥1 year)
  - Short-Term Firm (daily to monthly)
  - Non-Firm (hourly to monthly)
  - Next Hour Market service
- **Service Request Timelines**: Detailed scheduling windows from 20 minutes to 120 days advance notice
- **Energy Scheduling Procedures**: Standardized change cutoff times
- **Technical Terminology**: Comprehensive acronym glossary (NERC, FERC, GIA, OATT, NRIS, ERIS, etc.)

## 3. Decisions or Actions

**No active decisions or action items are present.** This chunk consists entirely of reference material:
- Established zone designations and credit structures
- Standardized operational procedures already in effect
- Defined terminology for ongoing operations

This represents the administrative/reference appendix portion of the larger RR696 regulatory filing.

## 4. Important Dates

### Operational Timing Requirements (Standardized Protocols):

**Long-Term Firm Service:**
- Request window: 90 days prior to service start
- Response time: 10 days from application receipt
- Customer response deadline: 3 days

**Short-Term Firm Service:**
- Monthly requests: 8-31 days advance notice
- Weekly requests: 2-8 days advance notice
- Daily requests: 10:00 day prior through 3 days prior
- Response time: 24 hours
- Study completion: 30-60 days

**Non-Firm Service:**
- Monthly requests: 3-60 days advance notice
- Daily requests: 10:00 day prior through 2 days prior
- Hourly requests: 30 minutes through 10:00 day prior
- Next Hour Market: 20 minutes prior

**Universal Energy Scheduling Deadlines:**
- Firm service schedule changes: 12:00 day prior
- Non-firm service schedule changes: 15:00 day prior
- All services final cutoff: 20 minutes before schedule hour

**Note:** All dates are relative to service start; no specific calendar dates provided.

## 5. Organizations and People Mentioned

### Primary Transmission Entities by Zone:

**Zone 1 (American Electric Power-West):**
- Public Service Company of Oklahoma / Southwestern Electric Power Company
- East Texas Electric Cooperative, Inc. / Deep East Texas Electric Cooperative, Inc.
- Oklahoma Municipal Power Authority (two sub-zones)
- AEP Oklahoma/Southwestern Transmission Companies
- Coffeyville Municipal Light and Power
- Arkansas Electric Cooperative Corporation
- Transource Oklahoma, LLC

**Zones 2-18 (Other Major Entities):**
- Kansas City Board of Public Utilities (Zone 2)
- City Utilities of Springfield, Missouri (Zone 3)
- Empire District Electric Company (Zone 4)
- Grand River Dam Authority (Zone 5)
- Evergy Metro, Inc. (Zone 6)
- Oklahoma Gas and Electric (Zone 7)
- Midwest Energy, Inc. (Zone 8)
- Evergy Missouri West, Inc. (Zone 9)
- Southwestern Power Administration (Zone 10)
- Southwestern Public Service Company (Zone 11)
- Sunflower Electric Power Corporation (Zone 12)
- Western Farmers Electric Cooperative (Zone 13)
- Evergy Kansas Central/South (Zone 14)
- Lincoln Electric System (Zone 16)
- Nebraska Public Power District (Zone 17)
- Omaha Public Power District (Zone 18)

**Zone 19 (Upper Missouri Zone - Multi-Entity):**
- Western-UGP
- Basin Electric Power Cooperative
- Heartland Consumers Power District
- Missouri River Energy Services (with 8 municipal sub-members)
- East River Electric Power Cooperative, Inc.
- Corn Belt Power Cooperative
- NorthWestern Energy Public Service Corporation
- Northwest Iowa Power Cooperative
- Harlan Municipal Utilities
- Central Power Electric Cooperative
- Mountrail-Williams Electric Cooperative
- Mor-Gran-Sou Electric Cooperative, Inc.
- Roughrider Electric Cooperative, Inc.
- L and O Power Cooperative

**Supporting Transmission Companies:**
- ITC Great Plains, LLC
- Prairie Wind Transmission, LLC
- NextEra Energy Transmission Southwest, LLC
- Transource Missouri, LLC
- South Central MCN LLC
- Missouri Joint Municipal Electric Utility Commission
- Lea County Electric Cooperative, Inc.
- Kansas Power Pool
- Tri-State G&T Association
- Central Nebraska Public Power and Irrigation District

**Regulatory/Standards Bodies (from glossary):**
- Federal Energy Regulatory Commission (FERC)
- North American Electric Reliability Corporation (NERC)
- Southwest Power Pool (SPP)

**No individual people mentioned.**

## 6. Links or References

### Internal Document Cross-References:
- **Section II.3** - Referenced for AEP Public Service Company structure details
- **Section II of Attachment Z1** - Open season specifications
- **Sections 19.4 and 32.4** - Schedule specifications
- **Section 30.2.2** - Expedited designation process
- **Generator Interconnection Procedures (GIP)** - General reference
- **Open Access Transmission Tariff (OATT)** - Governing document
- **Integrated Transmission Planning (ITP)** - Planning framework

### Industry Standards:
- **NERC Transmission System Planning Performance Requirement (TPL)** - Reliability standard
- **Power System Simulator for Engineering (PSS/E)** - Industry-standard analysis software

### Regulatory Framework Elements:
- **Schedule 11** - Credit allocation structure
- **Attachment Z1** - Transmission service request procedures

**No URLs or external hyperlinks present.**

## 7. Suggested Tags

**Primary Tags:**
- SPP_Tariff
- Transmission_Zones
- OATT
- Service_Request_Procedures
- Southwest_Power_Pool
- RR696

**Operational Tags:**
- Long_Term_Firm_Service
- Short_Term_Firm_Service
- Non_Firm_Service
- Energy_Scheduling
- ATRR_Credits
- Schedule_11
- Transmission_Service_Timelines

**Geographic Tags:**
- Oklahoma
- Kansas
- Missouri
- Nebraska
- Texas
- Iowa
- South_Dakota
- North_Dakota
- Multi_State_RTO

**Technical Tags:**
- Generator_Interconnection
- Network_Resource_Interconnection_Service
- Energy_Resource_Interconnection_Service
- Variable_Energy_Resource
- Transmission_Rights
- NRIS
- ERIS

**Organizational Tags:**
- American_Electric_Power
- Evergy
- Southwestern_Power_Administration
- Basin_Electric
- AECC
- Upper_Missouri_Zone

**Regulatory Tags:**
- FERC_Tariff
- NERC_Standards
- Utility_Regulation
- Transmission_Planning

## 8. Items That May Need Follow-Up

### Missing or Incomplete Information:

1. **Reserved Future Zones**: Multiple zones marked "Reserved for Future Use" (Zone 1c, Zone 1b under Zone 11 section, Zone 15) - monitor for future assignments or confirm these are intentionally placeholder

2. **Empty Tables**: Tables 11-46 are structurally referenced but contain no data in this chunk - verify these are intentionally blank or if content exists elsewhere

3. **Footnote Disconnection**: Tables include footnote markers (1/, 2/, 3/, 4/, 5/, 

---

# Partial Chunk Reports

# Chunk 1 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document contains SPP's comments on Revision Request RR696, which proposes to implement a High Impact Large Load (HILL) integration assessment framework. The submission, dated August 14, 2025, by Caroline Chapman of SPP, outlines a comprehensive framework for accelerating large load interconnections while maintaining grid reliability. 

**Key Development:** The latest revision (August 15, 2025) removes the Conditional High Impact Large Load (CHILL) concept and CHILL Service based on stakeholder feedback, representing a significant shift from earlier versions.

The RR addresses market efficiency, reliability, and administrative benefits by establishing clear processes for studying and integrating significant new loads into SPP's transmission system, with particular attention to Energy Storage Resource Load Assessment and alignment with NERC standards.

## 2. Key Topics

### Primary Topics:
- **High Impact Large Load (HILL) Integration Framework** - Core proposal to create systematic process for large load interconnections
- **Removal of CHILL Service** - Elimination of Conditional High Impact Large Load service based on stakeholder feedback
- **Tariff Amendments** - Modifications to SPP Open Access Transmission Tariff (OATT) including Attachments AE, AQ, AX, and BB
- **Energy Storage Resource Load Assessment** - Integration of energy storage-specific language pending MOPC approval
- **Study Process Modifications** - Updates to interconnection study requirements and procedures
- **Metering Requirements** - New specifications for HILL and CHILL metering in Protocols
- **Capacity Accreditation** - Shift from nameplate capacity to projected capacity accreditation MW values for High Impact Large Generation Assets (HILGA)

### Secondary Topics:
- **Load Ratio Share calculations** for Network Customers
- **Monthly Demand Charge** structures across different zones
- **Transmission Administration Services** cost recovery
- **Day-Ahead Must Offer requirements** alignment with existing Resource requirements
- **Western Area Power Administration (WAPA)** specific GIA provisions

## 3. Decisions or Actions

### Completed Actions:
1. **July 11, 2025 Updates:**
   - Added Energy Storage Resource Load Assessment language to Attachment BB
   - Modified maximum injection limit methodology to use capacity accreditation MW value
   - Updated "shall" usage throughout documents

2. **July 28, 2025 Updates:**
   - Added Attachment BB Appendix 3 for WAPA Division GIA scenarios
   - Aligned Resource Day-Ahead Must Offer requirements with existing standards
   - Implemented capacity limits based on accredited capacity
   - Specified HILL and CHILL metering requirements

3. **August 15, 2025 Updates (Major Revision):**
   - **Removed CHILL, CHILLS, and Deliverability Area path for generation** based on stakeholder feedback
   - Updated Attachment BB Section 3.1.1 per stakeholder input
   - Revised HILL definition in Part 1, Common Service Provisions
   - Made HILL independent of Non-Conforming Load classification
   - Enhanced clarity in Attachments AQ and AX regarding HILL study process

### Pending Actions:
- Energy Storage Resource Load Assessment language pending approval at July 2025 MOPC
- Implementation of modified tariff language across multiple attachments
- Stakeholder review and comment incorporation

## 4. Important Dates

| Date | Event/Milestone |
|------|----------------|
| **July 11, 2025** | First set of SPP comments submitted (highlighted in yellow) |
| **July 2025** | MOPC meeting for Energy Storage Resource Load Assessment approval |
| **July 28, 2025** | Second set of SPP comments submitted (highlighted in teal) |
| **August 14, 2025** | Current comment form submission date |
| **August 15, 2025** | Third set of SPP comments submitted (highlighted in green) - major revisions |

**Note:** The document indicates this is "chunk 1 of 27," suggesting substantial additional content exists with potentially more dates and milestones.

## 5. Organizations and People Mentioned

### Organizations:
- **Southwest Power Pool (SPP)** - Transmission Provider and submitting organization
- **Markets and Operations Policy Committee (MOPC)** - Approval body for Energy Storage language
- **Federal Energy Regulatory Commission (FERC/Commission)** - Regulatory authority
- **North American Electric Reliability Corporation (NERC)** - Standards setting body
- **Western Area Power Administration (WAPA)** - Federal power administration requiring specific GIA provisions
- **American Electric Power** - Transmission Owner in Zone 1
- **Southwestern Public Service** - Transmission Owner in Zone 11
- **Transmission Owners** (various) - Multiple entities referenced throughout

### People:
- **Caroline Chapman** - SPP representative submitting comments (cchapman@spp.org)

## 6. Links or References

### Document References:
- **Source File:** RR696 SPP Comments 20250814.docx.txt (chunk 1 of 27)
- **SPP Open Access Transmission Tariff** - Multiple parts and attachments:
  - Part I: Common Service Provisions
  - Part II: Point-to-Point Transmission Service
  - Part III: Network Integration Transmission Service
  - Part IV: (referenced)
  - **Attachment AE** - Resource requirements
  - **Attachment AQ** - Study process provisions
  - **Attachment AX** - Study process provisions
  - **Attachment BB** - HILL integration requirements (including new Appendix 3)
  - **Attachment H** - Zonal ATRR specifications
  - **Attachment J** - Reallocation provisions
  - **Attachment L** - Revenue distribution
  - **Attachment AU** - Revenue allocation
  - **Addendum 1 to Attachment H** - American Electric Power revenue requirements
  - **Addendum 5 of Attachment H** - Southwestern Public Service revenue requirements
  - **Addendum 1 to Schedule 1-A** - Formula rate template
- **Schedule 1-A** - Tariff Administration Services
- **Schedule 7 & 8** - Revenue provisions
- **Marketplace Protocols** - Modified for HILL provisions

### Email Contact:
- cchapman@spp.org

## 7. Suggested Tags

**Primary Tags:**
- RR696
- High Impact Large Load (HILL)
- Large Load Integration
- Transmission Planning
- Interconnection Studies
- OATT Revision
- Grid Reliability

**Secondary Tags:**
- CHILL (removed)
- Energy Storage
- Capacity Accreditation
- NERC Compliance
- Stakeholder Process
- SPP Tariff
- MOPC
- WAPA
- Metering Requirements
- Must Offer Requirements
- Load Assessment
- Transmission Service
- Network Integration

**Process Tags:**
- Comment Period
- Stakeholder Feedback
- Regulatory Compliance
- FERC Filing

## 8. Items That May Need Follow-Up

### Critical Follow-Up Items:

1. **MOPC Approval Status**
   - **Issue:** Energy Storage Resource Load Assessment language pending approval at July 2025 MOPC
   - **Action Needed:** Confirm approval status and any modifications required
   - **Timeline:** July 2025 (may already be completed given August submission date)

2. **CHILL Service Removal Impact Analysis**
   - **Issue:** Major change removing CHILL/CHILLS concept based on stakeholder feedback
   - **Action Needed:** 
     - Document rationale for removal
     - Assess impact on customers who may have planned for CHILL service
     - Review if alternative solutions needed for conditional service scenarios
   - **Stakeholder:** All potential large load developers

3. **Stakeholder Feedback Integration**
   - **Issue:** Multiple substantial changes made "based off stakeholder feedback"
   - **Action Needed:** 
     - Document specific stakeholder concerns that drove changes
     - Confirm all stakeholder issues addressed
     - Verify consensus on August 15 revisions
   - **Timeline:** Before final filing

4. **Definition Consistency Review**
   - **Issue:** HILL definition revised and made independent of Non-Conforming Load
   - **Action Needed:**
     - Ensure consistency across all 27 document chunks
     - Review impact on existing agreements and classifications
     - Verify no conflicts with other tariff provisions

5. **WAPA-

---

# Chunk 2 Analysis

# Regulatory Analysis Report
## RR696 SPP Comments - Chunk 2 of 27

---

## 1. Executive Summary

This document contains detailed tariff language governing transmission service pricing and billing for the Southwest Power Pool (SPP) Region. The content focuses on three primary tariff schedules:

- **Schedule 1-A1**: Transmission revenue requirements and rate formulas for Point-to-Point service
- **Schedule 1**: Scheduling, System Control and Dispatch Service charges for various transaction types
- **Schedule 2**: Reactive Supply and Voltage Control compensation methodology
- **Schedule 11**: Base Plan Zonal Charges and Region-wide Charges (introduction only)

The document establishes complex rate calculation methodologies, differentiates between on-peak and off-peak periods, and defines how revenues are collected from transmission customers and distributed to qualifying generators (QGs) and transmission owners.

---

## 2. Key Topics

1. **Point-to-Point Transmission Service Billing**
   - Zone of Point of Delivery billing determinants
   - MW hours reserved as billing basis
   - Annual rate formula determination via Addendum 1

2. **Scheduling, System Control and Dispatch Service (Schedule 1)**
   - Through and Out Transactions vs. Transactions Sinking within the System
   - Differentiated charging for Firm/Non-Firm Point-to-Point vs. Network Integration Service
   - Multi-owner Zone rate calculations
   - Revenue requirement adjustments for Point-to-Point revenues

3. **On-Peak vs. Off-Peak Rate Structure**
   - Off-Peak days: Saturdays, Sundays, and all NERC holidays
   - On-Peak hours: HE 0700 through HE 2200 Central Prevailing Time
   - Rate divisors for monthly, weekly, daily, and hourly calculations

4. **Reactive Power Compensation (Schedule 2)**
   - Reactive Compensation Rate (RCR) set at $2.26 per MVArh
   - Qualifying Generator (QG) compensation methodology
   - Dead Band calculation (power factor of 0.95)
   - Reactive Power Outside the Dead Band (RPOD) calculations

5. **Revenue Distribution Mechanisms**
   - Zonal Revenue Collection (ZRC) methodology
   - Through and Out Reactive Revenue allocation
   - Monthly reconciliation and true-up processes

6. **Base Plan Zonal Charges (Schedule 11)**
   - Assessment based on Resident Load for Network Customers
   - Reserved Capacity basis for Point-to-Point customers
   - Western-UGP exemption from Region-wide Charge
   - Eastern Interconnection limitation

---

## 3. Decisions or Actions

**Established Decisions:**

1. **Fixed Reactive Compensation Rate**: RCR established at $2.26 per MVArh with periodic review authority granted to Transmission Provider

2. **Rate Calculation Methodology**: Annual determination of Schedule 1-A1 Service rate by Transmission Provider as described in Addendum 1

3. **Time Period Definitions**: 
   - On-Peak hours: HE 0700-2200 Central Prevailing Time
   - Off-Peak days: Saturdays, Sundays, NERC holidays

4. **Revenue Requirement Adjustments**: Transmission Provider shall adjust Schedule 1 RR for Point-to-Point revenues except where formula rates already include annual updates

5. **Zonal Charge Applications**: Charges based on physical location of load or Point of Delivery zone

**Pending/Conditional Actions:**

1. Periodic review of RCR to ensure it remains at upper end of reasonable cost range for reactive power production

2. Monthly calculations and billing cycles for Schedule 2 charges after sufficient RPOD data availability

---

## 4. Important Dates

**Recurring Timeframes:**

- **Annual**: Schedule 1-A1 rate determination for each calendar year
- **Monthly**: 
  - Zonal Peak Demand measurements
  - RPOD calculations and QG compensation
  - Schedule 2 billing cycles (next cycle after data availability)
  - Coincident peak determinations for Network Customers
- **Prior calendar year**: Basis for 12-month average of monthly peaks for rate calculations

**Rate Calculation Divisors:**
- Yearly rate divided by 12 (monthly)
- Yearly rate divided by 52 (weekly)
- On-Peak: yearly rate divided by 260 (daily), 4160 (hourly)
- Off-Peak: yearly rate divided by 365 (daily), 8760 (hourly)

**Time-of-Day Definitions:**
- On-Peak hours: HE 0700 through HE 2200 Central Prevailing Time

**No specific calendar dates are mentioned in this chunk.**

---

## 5. Organizations and People Mentioned

### Organizations:

1. **SPP (Southwest Power Pool)** - The Transmission Provider
   - Operates Balancing Authority Area
   - Calculates and posts rates in RRR File
   - Bills customers and distributes revenues
   - Posts Schedule 2 charges

2. **Transmission Owners** - Multiple entities
   - Have approved/accepted revenue requirements
   - May be single or multiple owners per Zone
   - Have Schedule 1 charges
   - May have formula rate calculations

3. **Transmission Customers** - Service recipients
   - Take Firm or Non-Firm Point-to-Point Transmission Service
   - Subject to Schedule 1 and Schedule 2 charges

4. **Network Customers** - Specific customer class
   - Take Network Integration Transmission Service
   - May have Load not physically interconnected

5. **Qualifying Generators (QGs)** - Generator owners
   - Receive reactive power compensation
   - Must be certified by Transmission Provider
   - Subject to Dead Band calculations

6. **NERC (North American Electric Reliability Corporation)** - Referenced for holiday definitions

7. **Western-UGP** - Specific transmission entity
   - Exempt from Region-wide Charge under Schedule 11
   - Has Statutory Load Obligations for Federal Power

### People:
**None specifically named in this chunk**

---

## 6. Links or References

### Internal Tariff References:

1. **Addendum 1** of Schedule 1-A - Rate formula details
2. **Section 31.4** - Network Load designation procedures
3. **Part V of this Tariff** - Base Plan charges context
4. **Section 39.3(e)** - Western-UGP exemption authority
5. **Section II.B.1** - Joint owned unit designation procedures

### External Files/Postings:

1. **Revenue Requirements and Rates File (RRR File)** - Posted on SPP website
   - Schedule 1 tab
   - Zonal Sch 1 tab
   - Contains Transmission Owner rates and adjustments

2. **Table 1** ("Schedule 1 RR") - Revenue requirements listing
3. **Table 2** of Schedule 1 - Point-to-Point revenues already credited amounts

### Referenced Standards:

- **Power Factor of 0.95** - Dead Band calculation standard
- **Central Prevailing Time** - Time zone for on-peak/off-peak definitions
- **NERC holidays** - Official holiday schedule

---

## 7. Suggested Tags

### Primary Tags:
- Transmission Tariff
- Rate Design
- SPP (Southwest Power Pool)
- Point-to-Point Service
- Network Integration Service
- Reactive Power Compensation

### Secondary Tags:
- Schedule 1
- Schedule 1-A1
- Schedule 2
- Schedule 11
- Revenue Requirements
- Zonal Charges
- On-Peak/Off-Peak Rates
- Qualifying Generators
- Transmission Pricing
- Formula Rates

### Functional Tags:
- Billing Determinants
- Cost Allocation
- Revenue Distribution
- Ancillary Services
- Voltage Control
- System Control and Dispatch

### Geographic/Organizational Tags:
- Eastern Interconnection
- Western-UGP
- Multi-owner Zones
- SPP Region
- Balancing Authority Area

---

## 8. Items That May Need Follow-Up

### Clarification Needed:

1. **Addendum 1 Details**: The actual rate formula methodology referenced for Schedule 1-A1 is not included in this chunk - requires review of Addendum 1

2. **Table 1 and Table 2 Contents**: Specific revenue requirements and Point-to-Point credits are referenced but not shown in this

---

# Chunk 3 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary

This document contains detailed tariff provisions from SPP's (Southwest Power Pool) Rate Schedule governing transmission service charges, specifically Schedule 11 (Base Plan Zonal Charges) and Schedule 12 (FERC Assessment Charge). The content outlines methodologies for calculating Annual Transmission Revenue Requirements (ATRR), how charges are allocated to Network Customers and Transmission Owners across different zones, and the process for recovering FERC assessment costs. The provisions distinguish between transmission owners using formula rates versus stated rates and establish special provisions for Western-UGP Federal Service Exemptions.

## 2. Key Topics

- **Annual Transmission Revenue Requirement (ATRR) Calculation**: Methods for calculating Base Plan Zonal and Region-wide transmission revenue requirements
- **Revenue Adjustments and Credits**: Treatment of point-to-point revenue, Attachment AU distributions, and SATOA dispatch revenues
- **Zonal Charge Allocation**: How Base Plan Zonal Charges are allocated to Resident Load across multiple zones (Zones 1-19)
- **Regional Load Determinations**: Specific calculation methodologies for different zones, particularly special provisions for Zones 10 and 19
- **Formula Rate vs. Stated Rate Treatment**: Different revenue crediting approaches for transmission owners
- **FERC Assessment Charge**: Annual charge mechanism to recover FERC Part 382 regulatory assessments
- **Western-UGP Federal Service Exemptions**: Special provisions for statutory load obligations

## 3. Decisions or Actions

- **Annual FACR Calculation**: Transmission Provider shall calculate the FERC Assessment Charge Rate (FACR) and post results on SPP website prior to March 1 of each year
- **Monthly Billing**: Transmission Provider shall bill Transmission Customers and Transmission Owners according to specified schedules
- **Revenue Requirement Adjustments**: Transmission Provider shall adjust annual transmission revenue requirements based on previous calendar year point-to-point revenues (subject to limitations)
- **RRR File Updates**: Revenue adjustments shall be set forth in the RRR File
- **Formula Rate Updates**: For transmission owners with formula rates, annual updates of Schedule 11 revenue credits must reduce ATRR for eligible upgrades

## 4. Important Dates

- **June 19, 2010**: Critical date distinguishing treatment of Base Plan Upgrades based on NTC (Notification to Construct) issuance date
- **March 1 (Annual)**: Deadline for Transmission Provider to calculate and post FERC Assessment Charge Rate; effective date for FACR each year
- **Calendar Year Basis**: Point-to-point revenue adjustments based on previous calendar year amounts
- **Monthly**: Billing and charge calculation frequency for Base Plan Zonal Charges and Region-wide Charges

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)**: The Transmission Provider
- **FERC (Federal Energy Regulatory Commission)**: Regulatory authority ("the Commission")
- **Transmission Owners**: Entities owning transmission facilities (multiple zones)
- **Network Customers**: Entities receiving network integration transmission service
- **Western-UGP**: Entity with Federal Service Exemption and statutory load obligations
- **SATOA (Specific entity type)**: Entities dispatching into Energy and Operating Reserve Markets

### People:
- None specifically mentioned

## 6. Links or References

### Internal Tariff References:
- **Schedule 9**: Network Integration Transmission Service
- **Schedule 11**: Base Plan transmission charges (multiple sections)
- **Schedule 12**: FERC Assessment Charge
- **Attachment H**: Annual Transmission Revenue Requirement documentation (Tables 1, 2-A, 2-B, Table 3 Section 1)
- **Attachment J**: Cost allocation provisions (Section IV.A)
- **Attachment AU**: Revenue distribution provisions (Sections IV and V)
- **Section 7**: Billing procedures
- **Section 31.3**: Provisions for designated Network Load not physically interconnected
- **Section 34.5**: Transmission System load determination
- **Section 34.9**: Federal-Power Southwestern identification
- **Section 39.2**: Bundled Retail and Grandfathered Loads provisions

### External References:
- **FERC Part 382**: Regulations governing FERC annual assessments
- **FERC Form 582**: Reporting form for megawatt-hours transmitted in interstate commerce
- **SPP Website**: Location for posting FACR calculations

## 7. Suggested Tags

- Transmission Tariff
- Rate Schedule
- ATRR (Annual Transmission Revenue Requirement)
- Zonal Charges
- Region-wide Charges
- Revenue Allocation
- Formula Rate
- FERC Assessment
- Point-to-Point Service
- Network Integration Service
- SPP
- Base Plan Upgrades
- Load Ratio Share
- Western-UGP
- Transmission Revenue
- Cost Recovery

## 8. Items That May Need Follow-Up

1. **Verification of RRR File Updates**: Confirm that revenue adjustments are properly documented and filed with the Commission as referenced in Section II.A
2. **March 1 Compliance**: Track annual FACR calculation and website posting deadline
3. **Zone-Specific Load Calculations**: Ensure proper implementation of different methodologies for Zones 10 and 19 versus other zones
4. **Formula Rate Revenue Credit Updates**: Verify that transmission owners using formula rates are properly crediting Schedule 11 revenues annually
5. **SATOA Dispatch Revenue Treatment**: Clarify and monitor how revenue from SATOA dispatches into Energy and Operating Reserve Markets is tracked and credited
6. **Western-UGP Federal Service Exemption**: Monitor instances where non-federal service is provided to Western-UGP's statutory load obligations and ensure proper charge application
7. **Balance Account Reconciliation**: Track Schedule 12 account balances for accurate true-up in subsequent year FACR calculations
8. **NTC Date Verification**: Confirm proper classification of Base Plan Upgrades based on June 19, 2010 NTC issuance date threshold
9. **Table 3 Section 1 Updates**: Ensure Attachment H Table 3 Section 1 accurately reflects revenue already credited in transmission owner ATRR calculations
10. **Multi-Zone Network Customer Allocations**: Verify proper separate calculations for customers with Resident Load in multiple zones

---

# Chunk 4 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document is chunk 4 of 27 from SPP (Southwest Power Pool) Comments file RR696 dated August 14, 2025. The content consists of detailed tariff provisions governing Annual Transmission Revenue Requirements (ATRR) calculations, cost allocation methodologies, and specific transmission owner requirements. It establishes the framework for how transmission costs are calculated, allocated, and recovered across SPP's service zones, with particular focus on Region-wide ATRR calculations, Base Plan upgrades, and transmission owner-specific formula rates. The document includes specific provisions for Southwestern Public Service Company (SPS) and American Electric Power (AEP), including recovery mechanisms for canceled transmission projects.

## 2. Key Topics

- **Annual Transmission Revenue Requirements (ATRR) Structure**: Multiple categories including Base Plan Zonal ATRR, Region-wide ATRR, Balanced Portfolio ATRR, and Interregional Planning Region ATRR
- **Cost Allocation Methodologies**: Different treatment for network upgrades before and after October 1, 2015
- **Formula Rate Mechanisms**: Commission-approved formula rate processes and annual update procedures
- **Transmission Owner Revenue Requirements**: Procedures for changing, filing, and updating revenue requirements
- **Upgrade Sponsor Payments**: Base Plan Zonal ATRR payments according to Attachment Z2
- **JTIQ (Joint Transmission Interconnection Queue) Upgrades**: Provisions for positive or negative amounts in Region-wide ATRR
- **Revenue Credits**: Treatment of Schedule 7, 8, and 11 revenues, Attachment AU distributions, and SATOA dispatch revenues
- **Transmission Owner-Specific Requirements**: Detailed provisions for SPS (Zone 11) and AEP
- **Canceled Project Recovery**: Specific cost recovery for canceled Multi-Shipe Road and Georgia Pacific projects

## 3. Decisions or Actions

- **AEP Cost Recovery**: $3,264,402.55 to be included in AEP ATRR commencing April 1, 2018, for canceled projects:
  - $3,068,489.38 for Multi-Shipe Road - East Rogers - Kings River 345 kV project (Network Upgrades 10656, 10659, 10660)
  - $195,913.17 for Line - Georgia Pacific - Keatchie 138 kV Ckt 1 project (Network Upgrade 10616)
- **Recovery Period**: 12-month period with equal monthly installments plus interest at Commission rate (18 C.F.R. § 35.19a(a)(2)(iii))
- **Update Authorization**: Transmission Provider authorized to update Transmission Owner revenue requirements upon successful completion of approved annual formula rate update procedures
- **Filing Requirement**: Joint informational filing by SPP and AEP required after full recovery of canceled project costs
- **Revenue Requirement Changes**: Changes require Commission filing with cost support unless using Commission-approved formula rate processes

## 4. Important Dates

- **October 1, 2015**: Dividing line for treatment of Network Upgrades (pre vs. post date has different ATRR calculation methodologies in Tables 2-A and 2-B)
- **April 1, 2018**: Commencement date for inclusion of canceled project costs in AEP ATRR
- **October 1 (annually)**: SPS formula rate results posting deadline
- **October 31 (annually)**: AEP ATRR posting deadline on SPP website
- **January 1 (annually)**: Effective date for updated revenue requirements (following year after posting)

## 5. Organizations and People Mentioned

### Organizations:
- **Southwest Power Pool, Inc. (SPP)** - Transmission Provider
- **Southwestern Public Service Company (SPS)** - Transmission Owner for Zone 11
- **Xcel Energy Operating Companies** - Parent entity with Joint Open Access Transmission Tariff
- **American Electric Power (AEP)** - Transmission Owner with specific formula rate provisions
- **Associated Electric Cooperative, Inc.** - Party to cost sharing agreements
- **Federal Energy Regulatory Commission (FERC/Commission)** - Regulatory authority
- Multiple unnamed Transmission Owners across Zones 1-19

### Specific Projects Referenced:
- Morgan Transformer Project
- Blackberry Substation Upgrade
- Multi-Shipe Road - East Rogers - Kings River 345 kV project (canceled)
- Line - Georgia Pacific - Keatchie 138 kV Ckt 1 project (canceled)

## 6. Links or References

### Internal Tariff References:
- **Attachment J** - Cost allocation procedures for Base Plan Upgrades
- **Attachment Z2** - Upgrade Sponsor payment provisions
- **Attachment H** - This attachment (self-referential), includes Addendum 1 for AEP formula rate
- **Attachment O** - Coordination agreements (Addendum 1), SPS provisions in Xcel Energy OATT
- **Attachment AU** - Revenue distribution provisions (Sections IV and V)
- **Attachment L** - Point-to-Point transmission revenue allocation
- **Schedule 7** - Network Integration Transmission Service
- **Schedule 8** - [Not specified in text]
- **Schedule 9** - SATOA ATRR recovery
- **Schedule 11** - Point-to-Point Transmission Service charges

### External References:
- **Xcel Energy OATT, Attachment O – SPS** - Contains formula rate and Implementation Procedures (Appendix 1)
- **18 C.F.R. § 35.19a(a)(2)(iii)** - Commission regulation specifying interest rate
- **Cost Sharing and Usage Agreement Between SPP and Associated Electric Cooperative, Inc.** (Morgan Transformer Project)
- **Cost and Usage Agreement Between SPP and Associated Electric Cooperative, Inc.** (Blackberry Substation Upgrade)
- **Revenue Requirements and Rates File (RRR File)** - Posted on SPP website

### Data Sources:
- Section I, Tables 1, 2-A, 2-B, and 3 (with Notes A, B, C, D)
- RRR File on SPP website
- SPS OASIS website

## 7. Suggested Tags

- Annual Transmission Revenue Requirements (ATRR)
- Cost Allocation
- Formula Rates
- Network Upgrades
- Base Plan
- Balanced Portfolio
- Interregional Planning
- JTIQ Upgrades
- Transmission Owner Requirements
- Revenue Requirement Updates
- FERC Tariff
- SPP Tariff
- Zone 11
- Southwestern Public Service Company
- American Electric Power
- Canceled Projects
- Cost Recovery
- Schedule 11
- Attachment J
- Attachment Z2
- Point-to-Point Service
- Network Integration Service
- Upgrade Sponsors
- Commission Approval

## 8. Items That May Need Follow-Up

1. **Canceled Project Recovery Status**: Monitor completion of 12-month recovery period for AEP canceled projects ($3,264,402.55) and confirm joint informational filing has been made to FERC
   
2. **RRR File Updates**: Verify that canceled project costs are removed from RRR File after full recovery and replaced with $0

3. **Property Disposition**: Track if any property associated with canceled projects (Multi-Shipe Road and Georgia Pacific) has been sold or disposed of, as revenues would need to be credited (note: text appears truncated on this provision)

4. **Annual Formula Rate Updates**: 
   - Confirm SPS posting by October 1 with January 1 effectiveness
   - Confirm AEP posting by October 31 with January 1 effectiveness

5. **Compliance with Posting Requirements**: Verify public review and comment processes are being followed per protocols for formula rate updates

6. **Revenue Credit Tracking**: Ensure proper crediting of Schedule 7, 8, and 11 revenues, Attachment AU distributions, and SATOA dispatch revenues for both formula and non-formula rate transmission owners

7. **Interregional Project Allocations**: Monitor any new Interregional Projects and proper allocation of costs to customers under the tariff

8. **JTIQ ATRR Balance**: Track current value and upgrade-specific components posted in RRR File (Line 9, Table 2-B)

9. **Coordination Agreement Compliance**: Verify continued compliance with Morgan Transformer and Blackberry Substation Upgrade cost sharing agreements with

---

# Chunk 5 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document is chunk 5 of 27 from SPP (Southwest Power Pool) regulatory comments dated August 14, 2025 (file: RR696 SPP Comments 20250814.docx.txt). The content consists of detailed tariff provisions governing the recovery of costs for canceled transmission network upgrade projects and procedures for handling various types of transmission system upgrades. Specific provisions address American Electric Power (AEP), Sunflower Electric Power Corporation, and Southwestern Power Administration's Annual Transmission Revenue Requirements (ATRR). The document also outlines compensation mechanisms through candidate ILTCRs (Incremental Long-Term Congestion Rights) and cost allocation methodologies for different upgrade categories.

## 2. Key Topics

- **Canceled Project Cost Recovery**: Detailed procedures for recovering costs from two canceled transmission projects for AEP and one for Sunflower Electric
- **ATRR (Annual Transmission Revenue Requirement)**: Calculation and adjustment procedures for multiple utilities
- **Network Upgrade Classification**: Multiple categories including:
  - Sponsored Upgrades
  - Service Upgrades
  - Generation Interconnection Related Network Upgrades
  - Zonal Reliability Upgrades
  - JTIQ (Joint Targeted Interconnection Queue) Upgrades
- **Cost Allocation Methodologies**: Different allocation mechanisms based on upgrade type
- **Compensation Mechanisms**: ILTCR (Incremental Long-Term Congestion Rights) and transmission revenue credits
- **Regulatory Filing Requirements**: Joint informational filings with FERC upon project completion or asset disposition

## 3. Decisions or Actions

### American Electric Power (AEP):
- **ATRR includes $414,465** for canceled projects (Network Upgrades 50697 and 11423)
- Recovery over 12-month period in equal monthly installments
- Joint informational filing required with SPP upon full recovery
- Credits required for any property sales during recovery period

### Sunflower Electric Power Corporation:
- **ATRR includes $718,359** for canceled Device – Russell 115 kV (Network Upgrade 122803)
- Recovery over 12-month period in equal monthly installments
- Same filing and credit requirements as AEP upon completion

### Southwestern Power Administration:
- NITS ATRR calculation based on capacity ratio methodology
- Must provide supporting documentation when NITS ATRR calculation is revised
- Electronic notice required to Formula Rate Posting Information Notification List

### General Provisions:
- Project Sponsors may elect lump sum or periodic payment options (except Western-UGP which requires lump sum)
- Periodic charges paid monthly over 20-year period unless otherwise specified
- ILTCR terms must be 10-20 years when applicable

## 4. Important Dates

- **March 1, 2019**: Commencement date for AEP ATRR inclusion of $414,465 for canceled projects
- **January 1, 2024**: Commencement date for Sunflower Electric ATRR inclusion of $718,359
- **January 1, 2008**: Cutoff date for 2005 SPP Transmission Expansion Plan Zonal Reliability Upgrades cost allocation methodology
- **April 2017**: Reference date for Formula Rate Posting Information Notification exploder list
- **20-year periods**: Standard recovery/plant life period for Sponsored Upgrades
- **12-month recovery periods**: Standard recovery timeframe for canceled project costs

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)** - Transmission Provider
- **American Electric Power (AEP)** - Transmission Owner
- **Sunflower Electric Power Corporation** - Transmission Owner
- **Southwestern Power Administration** - Federal power marketing agency
- **Western-UGP** - Transmission entity with specific payment restrictions
- **FERC (Federal Energy Regulatory Commission)** - Regulatory authority
- **Commission** - Reference to FERC

### Roles Referenced (no specific individuals named):
- Transmission Provider
- Transmission Owner
- Project Sponsor
- Transmission Customer
- Interconnection Customer
- JTIQ Generation Interconnection Customer
- Market Participant

## 6. Links or References

### External Reference:
- **http://www.spp.org/stakeholder-center/exploder-lists/** - Exploder List access point (as of April 2017: "Formula Rate Posting Information Notification")

### Internal Document References:
- **Attachment H** - Table 1, Column (3) containing ATRR calculations
- **Attachment J** - Recovery of Costs Associated with New Facilities (this document)
  - Section VII (revenue credits)
  - Section VIII (canceled project cost recovery)
- **Schedule 11** - Recovery mechanism
- **Attachment Z1** - Service Upgrade cost allocation
- **Attachment Z2** - ILTCR provisions and candidate ILTCR compensation (Sections I, II, and IV)
- **Attachment V** - Generation interconnection Network Upgrade cost allocation
- **Attachment L** - JTIQ ATRR Balance calculations
- **Attachment AV** - JTIQ ATRR Balance calculations
- **Attachment AH** - Market Participant execution requirements
- **Schedule 1** - Sponsored Upgrade Agreement
- **Rate Schedule NFTS-13A** (Section 2.3.3) - Southwestern Power Administration capacity specifications (872,000 kilowatts)
- **Addendum 20** - Rate establishment provisions for Sunflower Electric

### Referenced Projects:
- Line – Chapel Hill REC – Welsh Reserve 138 kV Ckt 1 (Network Upgrade 50697) - CANCELED
- Line – Welsh Reserve - Wilkes 138 kV Ckt 1 (Network Upgrade 11423) - CANCELED
- Device – Russell 115 kV (Network Upgrade 122803) - CANCELED
- 2005 SPP Transmission Expansion Plan

## 7. Suggested Tags

- ATRR
- Cost Recovery
- Canceled Projects
- Network Upgrades
- ILTCR
- Transmission Revenue Requirements
- FERC Tariff
- SPP Tariff
- Sponsored Upgrades
- Service Upgrades
- Generation Interconnection
- Zonal Reliability
- JTIQ
- American Electric Power
- Sunflower Electric
- Southwestern Power Administration
- Formula Rates
- Transmission Cost Allocation
- Revenue Credits
- RRR File
- Attachment J

## 8. Items That May Need Follow-Up

### Immediate/Ongoing Monitoring:
1. **AEP Cost Recovery Status**: Track the 12-month recovery period for $414,465 (commenced March 1, 2019) - should be complete; verify final filing was made
2. **Sunflower Cost Recovery Status**: Monitor 12-month recovery period for $718,359 (commenced January 1, 2024) - should complete January 1, 2025
3. **Joint Informational Filings**: Ensure timely filing with FERC upon completion of recovery periods for both AEP and Sunflower

### Documentation Requirements:
4. **RRR File Updates**: Verify that canceled project costs are properly reflected and updated to $0 upon full recovery
5. **Property Disposition Tracking**: Monitor any sales or dispositions of properties included in ATRR during or after recovery periods; ensure credits are properly applied

### Southwestern Power Administration:
6. **Capacity Ratio Verification**: Confirm current capacity utilization vs. 872,000 kW total capacity for NITS ATRR calculation
7. **Formula Rate Posting**: Verify notifications are being sent through proper exploder list when NITS ATRR calculations are revised
8. **Website Link Verification**: Confirm current URL for exploder list access (April 2017 reference may be outdated)

### Policy/Procedural Clarifications Needed:
9. **Western-UGP Lump Sum Requirement**: Understand rationale for restricting Western-UGP to lump sum payments only for Sponsored Upgrades
10. **ILTCR Term Selection**: Clarify criteria or guidelines for determining specific ILTCR terms within the 10-20 year range
11. **Interest Calculation Methodology**: Document how interest is calculated on canceled project costs during recovery period

### Coordination Items:
12. **Multi-Party

---

# Chunk 6 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary
This document is Attachment L from SPP's (Southwest Power Pool) Tariff, specifically addressing the treatment and distribution of transmission service revenues. It establishes detailed procedures for how transmission revenues are allocated among transmission owners across different zones, covering both Network Integration Transmission Service (NITS) and Point-to-Point (PTP) transmission service. The attachment includes provisions for single-owner zones, multi-owner zones, grandfathered agreements, and special considerations for creditable upgrades under Attachment Z2.

## 2. Key Topics
- **Revenue Distribution for Network Integration Transmission Service (NITS)**
  - Single-owner zone revenue allocation procedures
  - Multi-owner zone revenue distribution formulas
  - Owner-Specific Zonal Annual Revenue Requirement (OZRR) calculations
  
- **Grandfathered Agreements Treatment**
  - Revenue collection rights under pre-existing agreements
  - Adjustments to OZRR for sellers and purchasers under grandfathered agreements
  
- **Point-to-Point Transmission Service Revenue Distribution**
  - 50/50 split methodology between OZRR and MW-mile impacts
  - Creditable Upgrades revenue priority (Attachment Z2)
  
- **Network Load Outside Transmission System**
  - Special provisions under Section 31.4 for designated network loads
  - Load Ratio Share calculations
  
- **Zone-Specific Provisions**
  - Special treatment for Zone 1 (American Electric Power zone)
  - Special treatment for Zone 19 (pre-October 1, 2015 designations)

## 3. Decisions or Actions
- **Revenue Distribution Mechanisms Established:**
  - Schedule 9 revenues distributed to transmission owners where network load is located
  - OZRR adjustments required for grandfathered agreement sellers and purchasers
  - Hypothetical NITS payments calculated for transmission owners not taking NITS
  
- **Payment Requirements:**
  - Positive amounts: Transmission Owner pays Transmission Provider
  - Negative amounts: Transmission Provider pays Transmission Owner
  
- **Dispute Resolution Process:**
  - Parties must attempt to reach agreement on grandfathered agreement treatment
  - Either party may invoke tariff dispute resolution procedures
  - FERC determination may be sought if agreement cannot be reached

## 4. Important Dates
- **October 1, 2015**: Cutoff date for Network Load designations outside the Transmission System in Zone 19 that receive special revenue distribution treatment

## 5. Organizations and People Mentioned
### Organizations:
- **SPP (Southwest Power Pool)** - Transmission Provider
- **FERC (Federal Energy Regulatory Commission)** - Regulatory authority for dispute determinations
- **American Electric Power** - Specifically mentioned in relation to Zone 1
- **Transmission Owners** (various, unnamed)
- **Transmission Customers** (various, unnamed)
- **Network Customers** (various, unnamed)
- **Upgrade Sponsors** - Entities receiving credits for Creditable Upgrades

### People:
- No individual names mentioned

## 6. Links or References
### Internal Tariff References:
- **Schedules**: 7, 8, 9, 11
- **Tariff Sections**: 31.4, 34.1(2), 34.4, 39
- **Attachments**: H, L, S, Z2

### Concepts Referenced:
- Base Plan Zonal Annual Transmission Revenue Requirements
- Region-wide Annual Transmission Revenue Requirement
- Load Ratio Shares
- MW-mile impacts (procedures in Attachment S)
- Creditable Upgrades

## 7. Suggested Tags
- Revenue Distribution
- Transmission Service
- NITS (Network Integration Transmission Service)
- Point-to-Point Transmission
- Grandfathered Agreements
- OZRR (Owner-Specific Zonal Annual Revenue Requirement)
- Multi-Owner Zones
- Load Ratio Share
- Attachment L
- SPP Tariff
- FERC Compliance
- Zone 1
- Zone 19
- Creditable Upgrades
- MW-mile methodology

## 8. Items That May Need Follow-Up
1. **Zone 1 Special Treatment**: Verify current status of transmission owners in Zone 1 beyond American Electric Power and confirm OZRR establishments

2. **Zone 19 Pre-2015 Designations**: Identify all Network Customers with load designated prior to October 1, 2015, to ensure proper revenue distribution

3. **Grandfathered Agreement Inventory**: Compile complete list of grandfathered agreements and verify:
   - Which are between transmission owners in the same zone
   - Revenue amounts and OZRR adjustments being properly applied
   - Any unresolved disputes requiring FERC determination

4. **Creditable Upgrades (Attachment Z2)**: Cross-reference with Attachment Z2 to ensure revenue credit methodology is consistent and properly implemented

5. **Dispute Resolution Cases**: Track any invoked dispute resolution procedures related to grandfathered agreement treatment in multi-owner zones

6. **OZRR Calculations**: Verify all transmission owners have properly filed and updated their OZRRs as shown in Attachment H

7. **Network Load Designations Outside System**: Identify all instances under Section 31.4 and confirm proper Load Ratio Share denominator treatment

8. **MW-mile Impact Calculations**: Ensure Attachment S procedures are being consistently applied for Point-to-Point revenue distribution

9. **Native Load Customer Elections**: Track which transmission owners have elected not to take NITS for Native Load Customers to ensure proper hypothetical NITS payment calculations

---

# Chunk 7 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document is chunk 7 of 27 from SPP (Southwest Power Pool) tariff comments dated August 14, 2025 (document ID: RR696). The content focuses on detailed revenue distribution mechanisms for transmission services, loss compensation procedures, and the transmission planning process. It outlines how various revenues collected under different schedules are distributed among transmission owners, how transmission losses are calculated and allocated, and provides an overview of SPP's comprehensive Transmission Expansion Plan (STEP) process. The content is highly technical and prescriptive, defining the financial and operational framework for SPP's transmission system.

## 2. Key Topics

- **Revenue Distribution Mechanisms**
  - Distribution of revenues from Region-wide Charges for Base Plan Upgrades, Balanced Portfolios, and Interregional Projects
  - Point-to-Point revenue distribution under Zonal ATRR (Annual Transmission Revenue Requirements) reallocation
  - Revenue distribution for Creditable Upgrades and JTIQ (Joint Targeted Interconnection Queue) Upgrades

- **JTIQ ATRR Balance Calculations**
  - Monthly charging/crediting mechanisms between Resident Load and Transmission Owners
  - Net revenue requirement calculations for JTIQ Upgrades

- **Loss Compensation Procedures**
  - Real power loss responsibilities for Network Integration and Point-to-Point Transmission Services
  - Injection Loss Factor (ILF) and Delivery Loss Factor (DLF) methodologies
  - Loss energy settlement in the Integrated Marketplace

- **Transmission Planning Process**
  - SPP Transmission Expansion Plan (STEP) components and development
  - Multiple sources of transmission upgrades (10 different processes identified)
  - Stakeholder review and approval processes

## 3. Decisions or Actions

- **Required Actions:**
  - Transmission Provider must distribute revenues proportionately according to specified formulas
  - Network Customers are responsible for real power losses in zones where Network Load is located
  - Transmission Provider must maintain and post schedule of real power loss factors
  - JTIQ ATRR Balance must be calculated monthly and set forth in RRR File on SPP website
  - Transmission Provider must post draft project lists on SPP website for stakeholder review

- **Approval Processes:**
  - Draft project lists subject to written stakeholder comments
  - Review required with stakeholder working groups and Regional State Committee
  - Final recommended list of upgrades prepared considering stakeholder input

## 4. Important Dates

- **Monthly/Recurring:**
  - Monthly calculation: one-twelfth of JTIQ ATRR Balance charged or credited
  - Hourly metered Network Load coincident with Zone monthly peak load hour

- **Annual:**
  - Annual SPP Transmission Expansion Plan report

- **Document Date:**
  - August 14, 2025 (SPP Comments date - RR696)

*Note: No specific future deadlines are mentioned in this chunk*

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)** - Transmission Provider
- **Transmission Owners** - Entities owning Base Plan Upgrades and facilities
- **Network Customers** - Service recipients under Network Integration
- **Transmission Customers** - Service recipients under Point-to-Point service
- **Upgrade Sponsors** - Entities sponsoring Creditable Upgrades
- **Interregional Planning Region** - Partner regions for interregional projects
- **Western-UGP** - Federal Power entity with Statutory Load Obligations
- **Regional State Committee** - Stakeholder review body
- **Stakeholder Working Groups** - Review and comment participants

**People:**
- No specific individuals mentioned in this chunk

## 6. Links or References

**Internal Tariff References:**
- Attachment J (Section IV.A) - Zonal ATRR reallocation
- Attachment L (Section II.A, II.C, III.A, III.F)
- Attachment AU - Revenue allocation
- Attachment Z2 (Section II.D, III.C.2) - Creditable Upgrades
- Attachment O (Addendum 1, Section V.7) - Transmission planning coordination
- Attachment AE - Energy and Operating Reserve Markets settlement
- Attachment AQ - Delivery point facility changes
- Attachment AX - Process requests
- Attachment V - Generator Interconnection
- Attachment AV (Appendix 2) - JTIQ Formula Rate template
- Attachment Y - Competitive Upgrades definition
- Attachment Z1 - Transmission service request evaluation
- Attachment M (Appendix 1) - Loss factors
- Schedule 7, 8, 9, 11 - Various service schedules
- Section 39.3(e)(ii) - Federal Power-Western-UGP provisions

**External References:**
- SPP website (for RRR File and draft project list postings)
- Figure 1 (illustrating planning processes within SPP)

## 7. Suggested Tags

- Revenue Distribution
- Transmission Planning
- JTIQ (Joint Targeted Interconnection Queue)
- Loss Compensation
- ATRR (Annual Transmission Revenue Requirements)
- Point-to-Point Service
- Network Integration Service
- Base Plan Upgrades
- Balanced Portfolios
- Interregional Projects
- SPP Transmission Expansion Plan (STEP)
- Tariff Attachments
- Stakeholder Process
- Creditable Upgrades
- Zone-based Allocation
- Load Ratio Share
- Integrated Marketplace
- Loss Factors (ILF/DLF)

## 8. Items That May Need Follow-Up

**Calculation and Posting Requirements:**
- Verification that JTIQ ATRR Balance calculations are posted monthly to RRR File on SPP website
- Confirmation that loss factor schedules (ILF and DLF) in Appendix 1 to Attachment M are current and maintained
- Ensure draft project lists are being posted on SPP website as required

**Stakeholder Engagement:**
- Track written comment submission periods for draft project lists
- Monitor stakeholder working group and Regional State Committee review meetings
- Verify stakeholder input is appropriately considered in final recommended upgrade lists

**Revenue Distribution Verification:**
- Audit that revenue distributions under Schedule 11 are properly calculated and allocated
- Confirm proportionate distributions align with specified formulas for Base Plan Upgrades, Balanced Portfolios, and Interregional Projects
- Verify JTIQ Generator Charges are properly applied under approved JTIQ Generator Interconnection Agreements

**Interregional Coordination:**
- Monitor approved Interregional Projects and associated revenue distributions
- Track coordination agreements under Addendum 1 to Attachment O
- Verify compensation to other transmission providers and Interregional Planning Regions

**Compliance Concerns:**
- Ensure all 11 types of transmission projects are properly included in annual STEP report
- Verify each project has proper endorsement/approval through correct process
- Confirm identification of Competitive Upgrades causing reliability violations on adjacent systems

**Data Integrity:**
- Validate hourly metered Network Load data for loss calculations
- Verify Zone DLF applications for Federal Power-Western-UGP deliveries (Zone 19)
- Cross-check multiple tariff attachment references for consistency

---

# Chunk 8 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary

This document section (chunk 8 of 27) from SPP's regulatory filing dated August 14, 2025, contains detailed transmission planning procedures and service timing requirements. The content primarily focuses on the disclosure processes for transmission upgrades, approval/endorsement procedures involving the Markets and Operations Policy Committee and SPP Board of Directors, and specific timing requirements for various transmission service requests. The document outlines governance structures for the SPP Transmission Expansion Plan (STEP), including quarterly updates, removal procedures, and status reporting requirements.

## 2. Key Topics

- **Disclosure Requirements**: Planning information, study results, and upgrade recommendations must be posted on SPP website with stakeholder access
- **Approval Process Hierarchy**: Multi-level approval process involving Markets and Operations Policy Committee recommendations and SPP Board of Directors final approval
- **Transmission Expansion Plan Types**: 
  - ITP Upgrades
  - Balanced Portfolios
  - High Priority Upgrades
  - 20-Year Assessment Upgrades
  - Sponsored Upgrades
  - Generator Retirement Upgrades
  - JTIQ Upgrades
  - Interregional Projects
- **Plan Updates and Modifications**: Quarterly posting requirements and out-of-cycle adjustments
- **Transmission Service Timing**: Detailed requirements for various service request types including Next-Hour Market requests
- **Adjacent System Impacts**: Procedures for evaluating Competitive Upgrades' effects on neighboring transmission systems

## 3. Decisions or Actions

- **Minimum 10-day notice** required before SPP Board of Directors action on project lists
- **Quarterly reporting** required to Markets and Operations Policy Committee, Regional State Committee, and SPP Board of Directors on upgrade status
- **Quarterly modifications** to SPP Transmission Expansion Plan must be posted on website
- **Annual presentation** of SPP Transmission Expansion Plan to Board of Directors required
- **Reimbursement obligation** for Transmission Owners when upgrades are removed from approved plans
- **5-minute window** for simultaneous transmission service requests; lottery system determines priority
- **3-request limit** for non-firm hourly transmission on DC ties (09:55-10:05 CPT)
- SPP Board may modify approved upgrade lists throughout the year with proper posting and notice

## 4. Important Dates

- **23:00 previous day**: Deadline for first hour of day requests
- **15:00 day prior**: Non-firm schedules acceptance deadline (with conditions)
- **09:55:00 - 10:05:00 CPT**: Critical window for DC tie transmission requests (3-request limit)
- **10-day minimum**: Notice period before Board action on projects
- **Quarterly**: Status updates and plan modification postings required
- **Annual**: Full Transmission Expansion Plan presentation to Board
- **Sundays and NERC Holidays**: Excluded from certain timing calculations

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)** - Transmission Provider
- **Markets and Operations Policy Committee** - Makes recommendations on upgrades
- **SPP Board of Directors** - Final approval authority
- **Regional State Committee** - Reviews modifications
- **Transmission Owners** - Entities with transmission facilities
- **Transmission Customers** - Service requestors
- **NERC** - North American Electric Reliability Corporation
- **Commission** (FERC implied) - Regulatory filing authority

### Roles/Groups:
- Stakeholder working groups
- Transmission Provider staff

## 6. Links or References

### Tariff Sections Referenced:
- **Attachment O** - Section II, IV.7, V, VII, VIII
- **Attachment J** - Section VIII (cost reimbursement)
- **Attachment Z1** - Transmission service approval provisions
- **Attachment V** - Generator Interconnection Service provisions
- **Attachment AB** - Generator Retirement Upgrade provisions
- **Attachment P** - Transmission Service Timing Requirements
- **Attachment T** - Rate determinations
- **Sections 13.2 and 14.2** - SPP OATT capacity allocation principles
- **Section 15.3** - Service agreement filing requirements

### Other References:
- SPP Membership Agreement
- CEII (Critical Energy Infrastructure Information) requirements
- SPP OASIS (Open Access Same-Time Information System)
- NERC TLR (Transmission Loading Relief)

## 7. Suggested Tags

- Transmission Planning
- Regulatory Compliance
- SPP Governance
- Upgrade Approval Process
- Stakeholder Engagement
- CEII Confidentiality
- Transmission Service Timing
- Non-Firm Transmission
- Board Approval Requirements
- Quarterly Reporting
- Competitive Upgrades
- Generator Interconnection
- NERC Standards
- Cost Reimbursement
- Interregional Coordination

## 8. Items That May Need Follow-Up

1. **Confidentiality Protocols**: Verify password protection systems for CEII-sensitive planning information on SPP website are adequate and compliant
2. **Board Deviation Explanations**: Track instances where Board approves upgrades different from Committee recommendations and review explanations
3. **Quarterly Compliance**: Monitor adherence to quarterly posting requirements for plan modifications and status updates
4. **10-Day Notice Verification**: Ensure all Board action items receive proper 10-day advance notice to stakeholders
5. **Reimbursement Claims**: Track any Transmission Owner reimbursement requests for removed upgrades per Section VIII of Attachment J
6. **Adjacent System Coordination**: Clarify cost responsibility protocols for reliability violations on adjacent systems (document states SPP will not pay unless otherwise agreed)
7. **Lottery System Implementation**: Verify non-discriminatory operation of lottery system for simultaneous transmission requests
8. **DC Tie Request Monitoring**: Monitor compliance with 3-request limit during 09:55-10:05 CPT window; define "affiliated Transmission Customers"
9. **Out-of-Cycle Adjustments**: Document rationale for any between-annual-approval modifications to ensure they meet "system reliability" or "new business opportunities" criteria
10. **Stakeholder Comment Process**: Verify electronic link for written comments on Transmission Expansion Plan is functional and comments are being processed
11. **Balanced Portfolio Requirement**: Clarify criteria for when Balanced Portfolio is/isn't required since "SPP is not required to have a Balanced Portfolio each year"

---

# Chunk 9 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary
This document is chunk 9 of 27 from SPP (Southwest Power Pool) tariff comments dated August 14, 2025 (RR696). The content details rate sheets and service structures for Point-To-Point Transmission Service across multiple transmission service providers within the SPP region, specifically focusing on the American Electric Power - West (AEPW) rate zone and City Utilities of Springfield, Missouri. It establishes service increments, pricing structures for both firm and non-firm transmission services, revenue crediting mechanisms, and special discount provisions for ERCOT-related transactions.

## 2. Key Topics

- **Service Increments and Windows**: Five standardized service periods (Fixed Hourly, Fixed Daily, Extended Weekly, Extended Monthly, Extended Yearly)
- **Point-To-Point Transmission Service Rates**: Detailed pricing structures for the AEPW rate zone
- **Balanced Portfolio Reallocation Adjustment**: Methodology for rate adjustments based on Zonal Annual Transmission Revenue Requirements
- **Revenue Crediting**: Adjustments for Schedule 7 and 8 revenues and Attachment AU allocations
- **Formula Rate References**: Multiple transmission owner-specific formula rates (AEP, AEP-West Transco, AECC, TROK)
- **ERCOT Discount Provisions**: 45.27% discount for specific ERCOT Regional Transmission Service scenarios
- **Time Convention**: All services processed in Central Prevailing Time using 24-hour clock convention

## 3. Decisions or Actions

- **Standardized Service Offerings**: SPP offers only specific service increment and window combinations as listed
- **Rate Structure Implementation**: Rates set forth in Revenue Requirements and Rates File (RRR File) posted on SPP website
- **ERCOT Discount Application**: 45.27% reduction in zonal rates under Schedules 7 and 8 for qualifying Load Serving Entities importing Planned or Unplanned Resources into ERCOT
- **On-Peak/Off-Peak Definitions**:
  - Daily: On-Peak = yearly rate ÷ 260 days; Off-Peak = yearly rate ÷ 365 days
  - Hourly: On-Peak = HE 0700-2200 excluding Sundays/holidays; Off-Peak = all other hours
  - Holidays defined per NERC standards

## 4. Important Dates

- **Document Date**: August 14, 2025 (RR696 SPP Comments 20250814)
- **Service Windows**:
  - Fixed Daily: 00:00 to 24:00 same calendar day
  - Extended Weekly: >1 week to <4 weeks
  - Extended Monthly: >1 month to <12 months
  - Extended Yearly: >1 year
- **On-Peak Hours**: HE 0700 to HE 2200, Central Time
- **Holidays Referenced**: New Year's Day, Memorial Day, Independence Day, Labor Day, Thanksgiving Day, Christmas Day

## 5. Organizations and People Mentioned

**Organizations:**
- Southwest Power Pool (SPP)
- American Electric Power - West (AEPW)
- American Electric Power (AEP)
- East Texas Electric Cooperative, Inc.
- Deep East Electric Cooperative, Inc. (collectively "Texas Electric Cooperatives")
- Oklahoma Municipal Power Authority (OMPA)
- AEP West Transmission Companies (AEP-West Transco)
- Coffeyville Municipal Light and Power (CMLP)
- Arkansas Electric Cooperative Corporation (AECC)
- Transource Oklahoma (TROK)
- City Utilities of Springfield, Missouri
- The Empire District Electric Company
- AEP Texas Central Company (TCC)
- AEP Texas North Company (TNC)
- Public Service Company of Oklahoma
- Southwestern Electric Power Company
- Electric Reliability Council of Texas (ERCOT)
- North American Energy Standards Board (NAESB)
- North American Electric Reliability Corporation (NERC)
- Federal Energy Regulatory Commission (Commission/FERC)

**People Mentioned:**
None specifically identified

## 6. Links or References

**Tariff Attachments Referenced:**
- Attachment R-1: NAESB WEQ-001 Business Practice Standards incorporation
- Attachment X: Central Prevailing Time definition
- Attachment T: Rate Sheets for Point-To-Point Transmission Service
- Attachment J, Section IV.A: Balanced Portfolio Reallocation
- Attachment AU: Revenue distribution and allocation
- Attachment H, Addendum 4: AEP Formula Rate
- Attachment H, Addendum 12: AEP-West Transco Formula Rate
- Attachment H, Addendum 38: AECC Formula Rate
- Attachment H, Addendum 48: TROK Formula Rate
- Attachment H, Addendum 17: City Utilities of Springfield Formula Rate

**External References:**
- NAESB Wholesale Electric Quadrant (WEQ-001) Business Practice Standards
- SPP Tariff Section 34.1(2)
- Revenue Requirements and Rates File (RRR File) on SPP website
- AEP Operating Companies' Tariff Part IV (ERCOT Regional Transmission Service)
- SPP Tariff Schedules 7 and 8

## 7. Suggested Tags

- Point-To-Point Transmission Service
- SPP Tariff
- Rate Schedules
- AEPW Rate Zone
- Formula Rates
- ERCOT Discount
- Firm Transmission Service
- Non-Firm Transmission Service
- Revenue Requirements
- NAESB Standards
- Balanced Portfolio
- Central Prevailing Time
- On-Peak/Off-Peak Rates
- Transmission Pricing
- AEP
- City Utilities Springfield
- Service Increments

## 8. Items That May Need Follow-Up

1. **RRR File Verification**: Confirm current rates posted on SPP website match tariff provisions for all transmission owners listed
2. **ERCOT Discount Eligibility**: Clarify qualification criteria and documentation requirements for Load Serving Entities claiming the 45.27% discount
3. **Formula Rate Updates**: Track any pending changes to referenced formula rates in Attachment H (Addendums 4, 12, 17, 38, 48)
4. **NAESB Standards Compliance**: Verify current version of WEQ-001 incorporated in Attachment R-1 is up to date
5. **Empire District Rates**: Document appears to cut off mid-section on Empire District Electric Company rate sheet—obtain complete information
6. **Holiday Definition Changes**: Monitor NERC for any updates to holiday definitions that would affect On-Peak/Off-Peak determinations
7. **Balanced Portfolio Reallocation**: Track implementation and any disputes regarding reallocation adjustments under Attachment J
8. **Schedule 7 and 8 Revenue Crediting**: Verify proper application of revenue adjustments across all rate zones
9. **Service Increment Limitations**: Confirm no requests for additional service increment/window combinations beyond the five listed
10. **Commission Approval Status**: Verify all transmission owner rates referenced have current FERC approval

---

# Chunk 10 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary

This document contains detailed tariff language for Point-To-Point (PTP) transmission service rate structures within the SPP (Southwest Power Pool) system. It covers multiple transmission zones including Empire District Electric Company, Evergy Kansas Central, Inc., and Evergy Metro, Inc. The content specifies rate calculation methodologies, formula rate references, revenue crediting mechanisms, and pricing structures for both firm and non-firm transmission services. All rates are documented in the Revenue Requirements and Rates File (RRR File) posted on the SPP website, with specific annual update schedules and effective dates.

## 2. Key Topics

- **Point-To-Point Transmission Service Rates**: Detailed rate structures for firm and non-firm transmission services across multiple delivery timeframes (yearly, monthly, weekly, daily, hourly)
- **Formula Rate References**: Multiple formula rates referenced in Attachment H with various addendums (3, 10, 15, 16, 18, 43, 44)
- **Balanced Portfolio Reallocation Adjustments**: Rate adjustments based on Zonal Annual Transmission Revenue Requirement reallocations per Section IV.A of Attachment J
- **Revenue Crediting**: Adjustments for Schedule 7 and 8 revenues and Attachment AU allocations per Section 34.1(2)
- **Rate Zone Structures**: Separate rate sheets for Empire District, Evergy Kansas Central, and Evergy Metro zones
- **Zonal ATRR (Annual Transmission Revenue Requirement)**: Existing Zonal ATRR calculations and postings

## 3. Decisions or Actions

- Rates are posted on the SPP website in the RRR File with zone-specific tabs
- Transmission Customers must compensate Transmission Providers according to specified rate schedules
- Rate adjustments incorporate Balanced Portfolio reallocations and revenue credits
- Weekly delivery caps apply to daily reservations (based on highest MW capacity during the week)
- Daily delivery caps apply to hourly reservations (based on highest MW/kW capacity during the day)

## 4. Important Dates

- **October 15**: Evergy Kansas Central, Inc. Formula Rate (Addendum 3) Existing Zonal ATRR posted annually
- **September 1**: Prairie Wind Formula Rate (Addendum 15) Existing Zonal ATRR posted annually
- **October 1**: South Central MCN Formula Rate (Addendum 43), Kansas Power Pool Formula Rate (Addendum 16), and NEET Southwest Formula Rate (Addendum 44) Existing Zonal ATRR posted annually
- **January 1**: Effective date for all posted rates (following year after posting)

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)** - Transmission Provider, website host
- **The Empire District Electric Company** - Transmission zone operator
- **Evergy Kansas Central, Inc.** - Transmission zone operator (formerly Evergy Kansas South, Inc.)
- **Evergy Metro, Inc. (EMe)** - Transmission zone operator
- **Prairie Wind Transmission LLC** - Rate formula entity
- **South Central MCN LLC** - Rate formula entity
- **Kansas Power Pool** - Rate formula entity
- **NextEra Energy Transmission Southwest, LLC (NEET Southwest)** - Rate formula entity
- **City of Independence, Missouri (INDP)** - Transmission Owner with approved rates in Evergy Metro zone
- **Commission** - Regulatory approval authority (likely FERC)

### People:
None specifically mentioned

## 6. Links or References

### Internal Document References:
- **Attachment T** - Point-To-Point rate attachment
- **Attachment H** - Formula rate attachment with multiple addendums:
  - Addendum 3: Evergy Kansas Central, Inc. Formula Rate
  - Addendum 10, Parts 1 and 2: EMe formula rate
  - Addendum 15: Prairie Wind Formula Rate
  - Addendum 16: Kansas Power Pool Formula Rate
  - Addendum 18: Empire District Electric Company formula rate
  - Addendum 43: South Central MCN Formula Rate
  - Addendum 44: NEET Southwest Formula Rate
- **Attachment J, Section IV.A** - Balanced Portfolio reallocation provisions
- **Attachment AU** - Revenue distribution and allocation provisions
- **Section 34.1(2) of Tariff** - Revenue crediting implementation
- **Attachment H, Section I, Table 1** - Existing Zonal ATRR references (Lines 14, 14a, 14b, 14c, 14d, 14e, Column 3)

### External References:
- **RRR File (Revenue Requirements and Rates File)** - Posted on SPP website with zone-specific tabs:
  - "Empire PTP Rate Att T" tab
  - "Evergy Kansas Central, Inc. PTP Rate Att T" tab
  - "EMe PTP Rate Att T" tab
- **SPP website** - Primary repository for rate information

### Rate Schedules Referenced:
- Schedule 7 and 8 revenues

## 7. Suggested Tags

- Point-To-Point Transmission
- Transmission Rates
- SPP Tariff
- Formula Rates
- Revenue Requirements
- Evergy Kansas Central
- Evergy Metro
- Empire District Electric
- Firm Transmission Service
- Non-Firm Transmission Service
- Zonal ATRR
- Balanced Portfolio
- Revenue Crediting
- Reserved Capacity
- Rate Schedules
- Transmission Service Agreements

## 8. Items That May Need Follow-Up

1. **Annual Rate Postings**: Verify timely posting of Existing Zonal ATRRs by specified deadlines (September 1, October 1, October 15) for effectiveness January 1
2. **RRR File Updates**: Confirm all zone-specific tabs are current and accessible on SPP website
3. **Formula Rate Compliance**: Ensure all referenced formula rates (Addendums 3, 10, 15, 16, 18, 43, 44) are properly calculated and documented
4. **Revenue Crediting Calculations**: Verify Schedule 7 and 8 revenue adjustments and Attachment AU allocations are properly applied
5. **Balanced Portfolio Adjustments**: Confirm reallocation adjustments per Attachment J, Section IV.A are correctly reflected in rates
6. **Multi-Entity Coordination**: Track coordination among multiple transmission owners in Evergy Kansas Central zone (Evergy, Prairie Wind, Kansas Power Pool, South Central MCN, NEET Southwest)
7. **Rate Zone Consolidation**: Note merger/consolidation reference (Evergy Kansas South, Inc. and Evergy Kansas Central, Inc.) - verify current zone structure
8. **INDP Fixed Rate**: Confirm $2,442.048 rate for City of Independence, Missouri remains current and Commission-approved
9. **Peak/Off-Peak Definitions**: Verify peak hour definitions (appears to be 16 hours for peak, 24 hours for off-peak in hourly calculations)
10. **Weekly/Daily Caps**: Ensure billing systems correctly apply demand charge caps for shorter-duration reservations

---

# Chunk 11 Analysis

# REGULATORY ANALYSIS REPORT
## Source: RR696 SPP Comments 20250814.docx.txt - Chunk 11 of 27

---

## 1. Executive Summary

This document section contains detailed transmission service rate schedules and tariff structures for multiple transmission providers within the Southwest Power Pool (SPP) network. The content specifies Point-to-Point (PTP) transmission service rates for both Firm and Non-Firm service across different delivery timeframes (yearly, monthly, weekly, daily, and hourly). The document covers rate structures for Evergy Missouri West, Inc., Grand River Dam Authority, and Kansas City Board of Public Utilities, including provisions for balanced portfolio reallocation adjustments and revenue crediting mechanisms.

---

## 2. Key Topics

- **Point-to-Point Transmission Service Rates**: Detailed rate structures for Firm and Non-Firm service
- **Reserved Capacity Pricing**: Rates calculated per MW or kW of reserved capacity across various delivery periods
- **Formula Rate Applications**: References to specific formula rates in Attachment H with various Addendums
- **Revenue Requirements and Rates File (RRR File)**: Primary repository for effective rates posted on SPP website
- **Balanced Portfolio Reallocation**: Adjustments to zonal annual transmission revenue requirements
- **Revenue Crediting Mechanisms**: Adjustments for Schedule 7 and 8 revenues and Attachment AU allocations
- **On-Peak vs. Off-Peak Pricing**: Differential pricing structures based on usage timing
- **Rate Caps**: Weekly and daily charge limitations to prevent excessive billing

---

## 3. Decisions or Actions

**No explicit decisions or actions are identified in this content.** This section appears to be regulatory tariff language establishing rate structures rather than meeting minutes or action items.

**Regulatory Requirements Established:**
- Transmission customers must compensate providers according to specified formula rates
- Rates must be posted in RRR File on SPP website
- Demand charge caps must be applied to prevent overcharging for shorter-term reservations
- Revenue crediting adjustments must be implemented per Section 34.1(2) of the Tariff

---

## 4. Important Dates

**No specific dates are mentioned in this content.**

The document references time periods for rate calculations:
- Yearly delivery rates (divided by 12 for monthly, 52 for weekly, 260 for daily on-peak, 365 for daily off-peak, 4,160 for hourly on-peak, 8,760 for hourly off-peak)
- These are formula divisors, not calendar dates

---

## 5. Organizations and People Mentioned

**Organizations:**
- **Southwest Power Pool (SPP)** - Regional transmission organization
- **Evergy Missouri West, Inc.** - Transmission owner/provider
- **Transource Missouri, LLC** - Transmission owner in Evergy Missouri West rate zone
- **Grand River Dam Authority (GRDA)** - Transmission provider
- **Kansas City Board of Public Utilities (BPU)** - Transmission provider
- **Federal Energy Regulatory Commission (FERC)** - Implied through "Commission approved rate(s)" reference

**People:**
No individuals are mentioned in this content.

---

## 6. Links or References

**Tariff Attachments Referenced:**
- **Attachment T** - Point-to-Point Transmission Service rates
- **Attachment H** - Formula rates with multiple addendums:
  - Addendum 10, Parts 1 and 2 (EMe formula rate)
  - Addendum 11, Parts 1 and 2 (Evergy Missouri West formula rate)
  - Addendum 13 (Grand River Dam Authority formula rate)
  - Addendum 21 (Transource Missouri, LLC rate formula and protocols)
  - Addendum 46 (Kansas City Board of Public Utilities formula rate)
- **Attachment J, Section IV.A** - Balanced Portfolio Reallocation provisions
- **Attachment AU** - Revenue distribution and allocation
- **Section 34.1(2)** - Revenue crediting implementation procedures

**RRR File Tabs Referenced:**
- "EMW PTP Rate Att T" (Evergy Missouri West)
- "GRDA PTP Rate Att T" (Grand River Dam Authority)
- "BPU PTP Rate Att T" (Kansas City Board of Public Utilities)

**External Resources:**
- SPP website (for posted RRR Files)

---

## 7. Suggested Tags

- Transmission Rates
- Point-to-Point Service
- SPP Tariff
- Firm Transmission Service
- Non-Firm Transmission Service
- Formula Rates
- Revenue Requirements
- Evergy Missouri West
- Grand River Dam Authority
- Kansas City BPU
- Transource Missouri
- Reserved Capacity
- Rate Schedules
- FERC Tariff
- EMe Formula
- Attachment T
- RRR File
- On-Peak Rates
- Off-Peak Rates

---

## 8. Items That May Need Follow-Up

1. **Formula Rate Updates**: Verify that all referenced formula rates in Attachment H Addendums (10, 11, 13, 21, 46) are current and properly implemented

2. **RRR File Accessibility**: Confirm that all referenced RRR File tabs are accessible on the SPP website and contain current effective rates

3. **Revenue Crediting Implementation**: Verify proper application of Schedule 7 and 8 revenue adjustments and Attachment AU allocations per Section 34.1(2)

4. **Balanced Portfolio Reallocation**: Confirm that reallocation adjustments from Section IV.A of Attachment J are being correctly applied to Point-to-Point rates

5. **Rate Cap Calculations**: Ensure billing systems properly implement demand charge caps for weekly and daily reservations

6. **Transource Missouri Integration**: Verify complete integration of Transource Missouri, LLC rates within the Evergy Missouri West zone

7. **Unit Consistency**: Note that Grand River Dam Authority uses kW/kWh while others use MW - confirm this is intentional and properly handled in billing systems

8. **INDP Component**: The document references "INDP yearly delivery rates" without defining the acronym - clarification may be needed for stakeholders

9. **Commission Approval Status**: Verify FERC approval status for all transmission owners' rates, particularly Transource Missouri, LLC

10. **Cross-Reference Verification**: Ensure all tariff attachment references are accurate and point to current, effective provisions

---

# Chunk 12 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document (chunk 12 of 27) from RR696 SPP Comments dated August 14, 2025, contains detailed tariff rate schedules for Point-To-Point (PTP) Transmission Services across multiple utility zones within the Southwest Power Pool (SPP) region. The content specifies rate structures for both Firm and Non-Firm transmission services, including various delivery timeframes (yearly, monthly, weekly, daily, and hourly), and references formula rates contained in various Attachment H Addenda. The document covers rate schedules for Kansas City Kansas Board of Public Utilities, Lincoln Electric System, Midwest Energy Inc., and Nebraska Public Power District zones.

## 2. Key Topics

- **Point-To-Point Transmission Service Rate Structures** - Comprehensive rate schedules for multiple delivery periods
- **Firm vs. Non-Firm Transmission Services** - Distinct pricing structures for guaranteed and non-guaranteed capacity reservations
- **Formula Rate Calculations** - References to specific Attachment H Addenda for rate determination
- **Revenue Requirements and Rates File (RRR File)** - Central repository for effective rates posted on SPP website
- **Balanced Portfolio Reallocation Adjustments** - Adjustments reflecting zonal revenue requirement reallocations per Attachment J
- **Revenue Crediting Mechanisms** - Adjustments for Schedule 7 and 8 revenues and Attachment AU allocations
- **On-Peak vs. Off-Peak Pricing** - Time-differentiated rates with specific definitions
- **Demand Charge Caps** - Maximum charges based on weekly/daily capacity reservations
- **Multi-Zone Rate Consolidation** - NPPD zone incorporating NPPD, Tri-State, and CNPPID rates

## 3. Decisions or Actions

No specific decisions or required actions are explicitly stated in this document. This appears to be a tariff schedule reference document establishing rate structures and calculation methodologies.

## 4. Important Dates

- **December 15** (annually) - NPPD formula calculation results posted (effective January 1)
- **January 1** - NPPD formula rates become effective
- **June 15** (annually) - Tri-State formula calculation results posted (effective July 1)
- **July 1** - Tri-State formula rates become effective
- **On-Peak Hours Definition** - HE 0700 through HE 2200 (Central Time Zone)
- **NERC Holidays** - New Year's Day, Memorial Day, Independence Day, Labor Day, Thanksgiving Day, Christmas Day

## 5. Organizations and People Mentioned

### Organizations:
- **Kansas City, Kansas Board of Public Utilities**
- **Lincoln Electric System (LES)**
- **Midwest Energy, Inc.**
- **Nebraska Public Power District (NPPD)**
- **The Central Nebraska Public Power and Irrigation District (CNPPID)**
- **Tri-State**
- **Southwest Power Pool (SPP)**
- **NERC (North American Electric Reliability Corporation)**

### People:
None mentioned

## 6. Links or References

### Internal Document References:
- **Attachment H, Addendum 46** - Kansas City BPU formula rate
- **Attachment H, Addendum 6** - Lincoln Electric System formula rate
- **Attachment H, Addendum 14** - Midwest Energy, Inc. formula rate
- **Attachment H, Addendum 7** - NPPD Formula Rate
- **Attachment H, Addendum 36** - Tri-State Formula Rate
- **Attachment J, Section IV.A** - Balanced Portfolio Reallocation methodology
- **Attachment T** - Point-To-Point Transmission Service rates
- **Attachment AU** - Revenue distribution and allocation
- **Section 34.1(2)** - Revenue crediting implementation
- **Schedule 7 and 8** - Revenue sources for crediting

### External References:
- **Revenue Requirements and Rates File (RRR File)** - Posted on SPP website
- **SPP Tariff** - Master tariff document
- Specific tabs mentioned:
  - "LES PTP Rate Att T" tab
  - "Midwest PTP Rate Att T" tab
  - "NPPD PTP Rate Att T" tab

## 7. Suggested Tags

- Point-To-Point Transmission
- Transmission Rates
- SPP Tariff
- Formula Rates
- Revenue Requirements
- NPPD
- Lincoln Electric System
- Midwest Energy
- Kansas City BPU
- Firm Transmission Service
- Non-Firm Transmission Service
- Reserved Capacity
- On-Peak Pricing
- Off-Peak Pricing
- Zonal Rates
- CNPPID
- Tri-State
- Attachment H
- RRR File

## 8. Items That May Need Follow-Up

1. **Unit Inconsistencies** - Verify whether rate units should be consistently in MW or kW (document shows both for different utilities)
   - Lincoln Electric System references "kilowatts" in some sections
   - Midwest Energy uses "kW" while others use "MW"

2. **Typographical Error** - Non-Firm PTP section for Lincoln Electric System states "rate per MWh of Reserved Capacity per week" for Off-Peak hourly delivery (likely should be "per hour")

3. **CNPPID Rate Values** - Fixed dollar amounts listed ($128.961/MW annual, $10.747/MW monthly, $2.480/MW weekly) may need periodic verification for currency

4. **Formula Rate Updates** - Confirm all referenced Addenda (6, 7, 14, 36, 46) are current and reflect latest approved formula rates

5. **Website Posting Compliance** - Verify timely posting of formula calculation results per specified deadlines (December 15 for NPPD, June 15 for Tri-State)

6. **Revenue Crediting Implementation** - Ensure Schedule 7 and 8 revenue adjustments and Attachment AU allocations are properly reflected in published rates

7. **Incomplete Section** - Document ends mid-sentence ("On-Peak: Shall be the rate for Reserved") - need complete section 4 for NPPD Firm PTP Daily delivery rates

8. **Cross-Reference Verification** - Validate that all attachment references correctly correspond to current tariff structure

---

# Chunk 13 Analysis

# Regulatory Document Analysis Report

## 1. Executive Summary

This document contains detailed tariff rate schedules for Point-to-Point Transmission Services across multiple utility zones within the SPP (Southwest Power Pool) system. The content primarily focuses on rate calculation methodologies for both Firm and Non-Firm transmission services across various delivery periods (yearly, monthly, weekly, daily, and hourly) for CNPPID, Oklahoma Gas and Electric Company (OG&E), and Omaha Public Power District (OPPD). The rates are calculated using formula-based templates referenced in Attachment H of the SPP Tariff and include adjustments for Balanced Portfolio Reallocation and revenue crediting.

## 2. Key Topics

- **Point-to-Point Transmission Service Rates**: Detailed rate structures for Firm and Non-Firm services
- **Rate Calculation Methodologies**: Formula-based approaches specific to each transmission provider
- **On-Peak/Off-Peak Definitions**: HE 0700-2200 Central Time on weekdays (excluding NERC holidays)
- **Zonal Annual Transmission Revenue Requirements (Zonal ATRR)**: Cost allocation framework
- **Balanced Portfolio Reallocation Adjustments**: Rate adjustments per Attachment J
- **Revenue Crediting Mechanisms**: Schedule 7 and 8 revenues, Attachment AU allocations
- **Reserved Capacity Charges**: Multi-tiered pricing based on service duration
- **Rate Zone Differentials**: NPPD, CNPPID, Tri-State, OG&E, AECC, PEC, NEET Southwest, Oklahoma Municipal Power Authority, OPPD

## 3. Decisions or Actions

- Rate formulas to be applied as specified in various Attachment H Addendums
- Service in opposite direction of original schedule requires separate charge payment
- Total demand charges capped at higher-tier rate multiplied by highest Reserved Capacity during the period
- Revenue Requirements and Rates File (RRR File) to be posted on SPP website
- Capacity designations at Point(s) of Receipt inclusive of losses
- Implementation of adjustments through established formula protocols

## 4. Important Dates

- **September 1** (annually): OG&E Existing Zonal ATRR to be posted on SPP website
- **January 1** (following year): OG&E rates become effective
- **July 20** (annually): OPPD Formula Rate results to be posted on SPP website
- **August 1**: OPPD rates become effective
- **NERC Holidays**: New Year's Day, Memorial Day, Independence Day, Labor Day, Thanksgiving Day, Christmas Day

## 5. Organizations and People Mentioned

### Organizations:
- **NPPD** (Nebraska Public Power District)
- **CNPPID** (Central Nebraska Public Power and Irrigation District)
- **Tri-State**
- **Oklahoma Gas and Electric Company (OG&E)**
- **SPP** (Southwest Power Pool)
- **AECC** (Arkansas Electric Cooperative Corporation)
- **PEC** (People's Electric Cooperative)
- **NEET Southwest** (NextEra Energy Transmission Southwest, LLC)
- **Oklahoma Municipal Power Authority**
- **OPPD** (Omaha Public Power District)
- **NERC** (North American Electric Reliability Corporation)

### People:
None specifically mentioned

## 6. Links or References

- **Attachment H**: Main tariff attachment containing formula rate templates
  - Addendum 2-A: OG&E Formula Rate
  - Addendum 2-B: OG&E Formula Rate Implementation Protocols
  - Addendum 7: NPPD Formula Rate Template
  - Addendum 8: OPPD Formula Rate Template
  - Addendum 38: AECC Formula Rate and protocols
  - Addendum 44: NEET Southwest Formula Rate and protocols
  - Addendum 51: PEC Formula Rate and protocols
- **Attachment T**: Point-to-Point rate schedules
- **Attachment J, Section IV.A**: Balanced Portfolio Reallocation procedures
- **Attachment AU**: Revenue distribution and allocation
- **Section 34.1(2)**: Schedule 7 and 8 revenue adjustments
- **RRR File** (Revenue Requirements and Rates File): Posted on SPP website
- **SPP Tariff**: Overall governing document

## 7. Suggested Tags

- Transmission Rates
- Point-to-Point Service
- Formula Rates
- SPP Tariff
- Firm Transmission Service
- Non-Firm Transmission Service
- FERC Tariff
- Reserved Capacity
- Zonal ATRR
- Revenue Requirements
- On-Peak/Off-Peak
- Rate Schedules
- Utility Rates
- Electric Transmission
- Regulatory Compliance

## 8. Items That May Need Follow-Up

1. **Rate Updates**: Monitor SPP website for annual postings by September 1 (OG&E) and July 20 (OPPD)
2. **Formula Rate Protocols**: Verify implementation procedures in referenced Addendums align with current practices
3. **Revenue Crediting**: Confirm proper application of Schedule 7 and 8 revenue adjustments
4. **Balanced Portfolio Reallocation**: Track any changes to reallocation methodology under Attachment J
5. **NERC Holiday Definitions**: Verify current NERC holiday list hasn't changed
6. **Cross-Reference Verification**: Ensure all referenced line items in formula templates (e.g., "line 14 of Page 1") are accurate
7. **Rate Caps**: Confirm proper application of demand charge caps across different service periods
8. **Loss Calculations**: Clarify methodology for losses included in capacity designations at Point(s) of Receipt
9. **Multiple Entity Coordination**: Ensure rate coordination among OG&E zone participants (AECC, PEC, NEET Southwest, Oklahoma Municipal Power Authority)
10. **Tariff Consistency**: Verify that all rate calculation divisions (12 months, 52 weeks, 260/365 days, 4160/8760 hours) are consistently applied across all zones

---

# Chunk 14 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary
This document chunk contains detailed rate schedules and transmission service pricing structures for multiple power transmission providers within the SPP (Southwest Power Pool) system. It establishes point-to-point transmission service rates for three entities: OPPD (Omaha Public Power District), Southwestern Power Administration, and Southwestern Public Service Company. The content specifies firm and non-firm transmission service rates calculated through formula-based templates, including various delivery timeframes (yearly, monthly, weekly, daily, and hourly) with differentiated on-peak and off-peak pricing structures.

## 2. Key Topics
- **Point-to-Point Transmission Service Rates**: Comprehensive rate structures for firm and non-firm transmission services
- **Formula-Based Rate Templates**: References to multiple addenda in Attachment H for rate calculations
- **Revenue Requirements and Rates File (RRR File)**: Central repository for rate information posted on SPP website
- **Revenue Crediting Adjustments**: Schedule 7 and 8 revenue adjustments and Attachment AU distributions
- **Balanced Portfolio Reallocation**: Adjustments to rates based on Zonal Annual Transmission Revenue Requirements
- **On-Peak/Off-Peak Distinctions**: Time-based rate differentiation for daily and hourly services
- **Reserved Capacity Compensation**: Multiple calculation methodologies based on service duration and peak demand

## 3. Decisions or Actions
- **Rate Publication**: Results of formula calculations to be posted on SPP website and SPS OASIS website
- **Rate Effectiveness**: Rates posted by October 1 become effective January 1 of the following year
- **Peak Demand Billing**: For certain customers directly connected to Southwestern's system, billing based on greatest of: (1) current month peak demand, (2) highest of previous 11 months, or (3) contracted capacity
- **Weekly Demand Charge Caps**: Total demand charges in any week cannot exceed weekly rate multiplied by highest Reserved Capacity
- **Daily Demand Charge Caps**: Total demand charges in any day for hourly delivery cannot exceed daily rate multiplied by highest Reserved Capacity

## 4. Important Dates
- **October 1**: Deadline for posting formula calculation results on websites
- **January 1**: Effective date for new rates (following year after October 1 posting)
- **NERC Holiday Schedule**: Rate differentiation applies to New Year's Day, Memorial Day, Independence Day, Labor Day, Thanksgiving Day, and Christmas Day
- **On-Peak Hours**: HE 0700 through HE 2200 (excluding weekends and NERC holidays)
- **On-Peak Days**: Monday through Friday (excluding NERC holidays)

## 5. Organizations and People Mentioned
**Organizations:**
- SPP (Southwest Power Pool)
- OPPD (Omaha Public Power District)
- Southwestern Power Administration
- South Central MCN LLC
- Missouri Joint Municipal Electric Utility Commission (MEUC)
- People's Electric Cooperative (PEC)
- Southwestern Public Service Company
- Xcel Energy Operating Companies
- Lea County Electric Cooperative, Inc. (LCEC)
- NERC (North American Electric Reliability Corporation)

**No individuals mentioned**

## 6. Links or References
- **Attachment T**: Main tariff attachment governing point-to-point transmission service
- **Attachment H**: Contains multiple addenda with formula rates:
  - Addendum 8 (OPPD Formula Rate)
  - Addendum 43 (South Central MCN Formula Rate)
  - Addendum 50 (MEUC Formula Rate)
  - Addendum 51 (PEC Formula Rate)
  - Addendum 52 (LCEC Formula Rate)
  - Attachment O - SPS of Xcel Energy OATT
- **Attachment AU**: Revenue distribution and allocation methodology
- **Attachment J, Section IV.A**: Balanced Portfolio Reallocation provisions
- **Section 34.1(2)**: Tariff section governing Schedule 7 and 8 revenue adjustments
- **Revenue Requirements and Rates File (RRR File)**: Posted on SPP website with specific tabs:
  - "SPA PTP Rate Att T" tab
  - "SPS PTP Rate Att T" tab
- **SPP Website**: Primary location for rate file posting
- **SPS OASIS Website**: Secondary accessible location for rate posting

## 7. Suggested Tags
- Transmission_Rates
- Point_to_Point_Service
- Formula_Based_Rates
- OPPD
- Southwestern_Power_Administration
- SPS
- Revenue_Requirements
- Firm_Transmission_Service
- Non-Firm_Transmission_Service
- Reserved_Capacity
- On-Peak_Off-Peak_Pricing
- RRR_File
- SPP_Tariff
- Rate_Schedules
- Attachment_H
- Attachment_T

## 8. Items That May Need Follow-Up
1. **Rate Formula Verification**: Confirm all referenced addenda (8, 43, 50, 51, 52) in Attachment H are current and accessible
2. **RRR File Posting Compliance**: Verify timely posting by October 1 deadline on both SPP website and SPS OASIS website
3. **Revenue Credit Calculations**: Ensure proper implementation of Schedule 7 and 8 revenue adjustments per Section 34.1(2)
4. **Balanced Portfolio Reallocation**: Monitor application of reallocations from Zonal Annual Transmission Revenue Requirements
5. **Peak Demand Tracking**: For Southwestern customers, ensure proper 11-month historical peak demand tracking system
6. **Formula Rate Updates**: Coordinate updates across multiple entities (South Central MCN, MEUC, PEC, LCEC) when base rates change
7. **NERC Holiday Calendar Alignment**: Confirm holiday definitions remain consistent with current NERC standards
8. **Secondary Transmission Service Limits**: Verify enforcement of capacity limits for secondary service customers
9. **Cross-Reference Integrity**: Validate that all attachment and section references are accurate following any tariff revisions
10. **Rate Calculation Discrepancies**: Review if text cut-off at end of document ("...revenues and revenu") indicates incomplete content requiring completion

---

# Chunk 15 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document is chunk 15 of SPP (Southwest Power Pool) comments regarding tariff rate structures for Point-to-Point Transmission Service across multiple rate zones. The content focuses on detailed pricing methodologies, formula rate references, and service terms for both Firm and Non-Firm transmission services. Key zones covered include Southwestern Public Service Company (SPS), Sunflower Electric Power Corporation, and Upper Missouri Zone (UMZ). The document specifies rate calculations, time-of-use definitions (On-Peak/Off-Peak), and revenue crediting mechanisms across various transmission service durations (yearly, monthly, weekly, daily, and hourly).

## 2. Key Topics

- **Point-to-Point Transmission Service Rates**: Detailed rate structures for Firm and Non-Firm services across multiple rate zones
- **Formula Rate References**: Multiple Attachment H addendums referenced for rate calculations
- **Time-of-Use Pricing**: Definitions and applications of On-Peak (HE 0700-2200) and Off-Peak hours
- **Rate Zone Structures**: SPS Zone, Sunflower Electric, and Upper Missouri Zone rate methodologies
- **Revenue Requirements and Rates (RRR) File**: Central repository for effective rates posted on SPP website
- **Balanced Portfolio Reallocation Adjustments**: Mechanisms for adjusting Point-to-Point rates
- **Revenue Crediting**: Schedule 7 and 8 revenue adjustments and Attachment AU allocations
- **LCEC Formula Rate**: Integration with Southwestern Public Service Company rates
- **Lamar Tie Line**: Special discounted rate (50%) for service across this tie line between PSCo and SPS zones

## 3. Decisions or Actions

- Transmission Customers must compensate Transmission Providers monthly for Reserved Capacity
- Service in opposite direction of original schedule requires separate payment
- Rate caps implemented: weekly charges cannot exceed specified weekly rates; daily charges cannot exceed specified daily rates
- Capacity designations at Point(s) of Receipt are inclusive of losses
- All rates must be set forth in the RRR File posted on SPP website
- Special discounted rate (one-half applicable rate) applies for Lamar Tie Line crossings

## 4. Important Dates

- **Document Date**: August 14, 2025 (from filename RR696 SPP Comments 20250814)
- **NERC Holidays Referenced**: New Year's Day, Memorial Day, Independence Day, Labor Day, Thanksgiving Day, Christmas Day
- **Peak Hours**: HE 0700-2200, Central Time Zone (excluding Sundays and holidays)

## 5. Organizations and People Mentioned

**Organizations:**
- Southwest Power Pool (SPP)
- Southwestern Public Service Company (SPS)
- Xcel Energy
- LCEC
- Public Service Company of Colorado (PSCo)
- Sunflower Electric Power Corporation (SECC)
- ITC Great Plains, LLC
- Prairie Wind Transmission, LLC
- Basin Electric Power Cooperative
- Heartland Consumers Power District
- Missouri River Energy Services (MRES)
- East River Electric Power Cooperative, Inc.
- Corn Belt Power Cooperative
- NorthWestern Energy Public Service Corporation (NWPS)
- Northwest Iowa Power Cooperative (NIPCO)
- Harlan Municipal Utilities (HMU)
- Western Area Power Administration, Upper Great Plains Region (Western-UGP)
- Central Electric Power Cooperative, Inc.
- Mountrail-Williams Electric Cooperative
- Mor-Gran-Sou Electric Cooperative, Inc.
- Roughrider Electric Cooperative, Inc.
- L and O Power Cooperative (LOPC)
- MRES Members: Moorhead Public Service, Orange City Municipal Utilities, City of Pierre (SD), City of Sioux Center (IA), Watertown Municipal Utility Department, Denison Municipal Utilities, Vermillion Light & Power
- NERC (North American Electric Reliability Corporation)
- FERC (implied - Commission)

**People:** None specifically mentioned

## 6. Links or References

**Tariff Attachments Referenced:**
- Attachment AU (revenue allocation)
- Attachment H, Addendum 5 (SPS formula rate)
- Attachment H, Addendum 9 (ITC Great Plains formula rate)
- Attachment H, Addendum 15 (Prairie Wind Transmission formula rate)
- Attachment H, Addendum 20 (Sunflower Electric formula rate)
- Attachment H, Addendums 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 37, 40, 41, 42, 45, 47, and 49 (UMZ zone formula rates)
- Attachment O - SPS of the Xcel Energy OATT
- Attachment T (rate sheets)
- Attachment J, Section IV.A (Balanced Portfolio Reallocation)
- Section 34.1(2) of the Tariff

**Files Referenced:**
- Revenue Requirements and Rates File (RRR File) - posted on SPP website
- Specific tabs: "SECC PTP Rate Att T", "UMZ PTP Rate Att T"
- Schedule 7 and 8 (revenues)

## 7. Suggested Tags

`Point-to-Point Transmission`, `SPP`, `Rate Structure`, `Formula Rates`, `Firm Transmission Service`, `Non-Firm Transmission Service`, `SPS Zone`, `Upper Missouri Zone`, `Sunflower Electric`, `OATT`, `Revenue Requirements`, `Time-of-Use Rates`, `Peak/Off-Peak`, `Transmission Tariff`, `RRR File`, `Balanced Portfolio`, `Revenue Crediting`, `Lamar Tie Line`, `Reserved Capacity`, `Transmission Pricing`

## 8. Items That May Need Follow-Up

1. **RRR File Verification**: Confirm all referenced rates are properly posted and current on SPP website
2. **Formula Rate Updates**: Verify all Attachment H addendums (particularly 22-49 for UMZ) are current and Commission-approved
3. **Lamar Tie Line Discount**: Confirm 50% discount rate is still applicable and properly documented
4. **LCEC Formula Rate**: Complete description appears truncated; full methodology needs verification
5. **UMZ Participant List**: Verify completeness of transmission owner list and their respective addendum numbers
6. **Schedule 7 & 8 Revenue Crediting**: Ensure proper implementation across all rate zones
7. **Attachment AU Implementation**: Verify revenue distribution and allocation mechanisms are functioning as intended
8. **Peak Hour Definition Consistency**: Confirm NERC holiday definitions are current and consistently applied across all zones
9. **Loss Inclusion**: Verify methodology for including losses at Points of Receipt is clearly documented
10. **Cross-Zone Service**: Clarify treatment of services spanning multiple rate zones
11. **Weekly/Daily Rate Caps**: Ensure billing systems properly implement not-to-exceed provisions
12. **Opposite Direction Service**: Confirm separate billing procedures are established and documented

---

# Chunk 16 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document chunk is from SPP (Southwest Power Pool) tariff comments, specifically focusing on transmission service rate structures and integrated marketplace provisions. It details point-to-point transmission service rates for two rate zones: the UMZ (Upper Missouri Zone) and WFEC (Western Farmers Electric Cooperative) zone. The content also covers substantial revisions to Attachment AE (Integrated Marketplace) provisions, including must-offer requirements, market participant obligations, and Day-Ahead Market execution procedures.

## 2. Key Topics

- **Point-to-Point Transmission Service Rates**: Calculation methodologies for firm and non-firm transmission service across different time periods (yearly, monthly, weekly, daily, hourly)
- **UMZ Rate Zone**: Formula rates incorporating multiple transmission owners (Basin Electric, Heartland, MRES, East River, Corn Belt, NWPS, NIPCO, HMU, Western-UGP, Central Power, Mountrail-Williams, Mor-Gran-Sou, Roughrider, and LOPC)
- **WFEC Rate Zone**: Rates for WFEC and People's Electric Cooperative (PEC)
- **Revenue Crediting**: Balanced Portfolio Reallocation Adjustment and Schedule 7 & 8 revenue adjustments
- **Integrated Marketplace Operations**: Market participant requirements, must-offer obligations, and Day-Ahead Market execution
- **Meter Agent Requirements**: Data submission and registration requirements
- **SCUC Algorithm**: Security-Constrained Unit Commitment procedures for market clearing
- **Capacity Management**: Emergency capacity limits and shortage/surplus procedures

## 3. Decisions or Actions

- **Rate Calculation Requirements**: Transmission customers must compensate providers based on specified formula rates and ATRR (Annual Transmission Revenue Requirements)
- **Must-Offer Compliance**: Market participants must offer all available resources or maintain net resource capacity ≥90% of load to avoid penalties
- **Meter Agent Agreement**: Any entity performing Meter Agent functions must execute the agreement specified in Attachment AM
- **Data Submission**: Market participants (or designated Meter Agents) must submit actual or estimated resource output and load consumption data per Market Protocols
- **Market Clearing Procedures**: SCUC algorithm will curtail non-firm transactions and incorporate emergency capacity when facing shortages/surpluses

## 4. Important Dates

- **Operating Day**: Referenced throughout for data submission and market execution timelines
- **Monthly/Weekly/Daily/Hourly timeframes**: Various rate calculation periods defined
- **730 hours per month**: Standard used for hourly delivery rate calculations
- No specific calendar dates are mentioned in this chunk

## 5. Organizations and People Mentioned

### Organizations - UMZ Rate Zone:
- Basin Electric
- Heartland
- MRES (Missouri River Energy Services)
- MRES Members
- East River
- Corn Belt
- NWPS (Northwestern Public Service)
- NIPCO
- HMU
- Western-UGP
- Central Power
- Mountrail-Williams
- Mor-Gran-Sou
- Roughrider
- LOPC

### Organizations - WFEC Rate Zone:
- Western Farmers Electric Cooperative (WFEC)
- People's Electric Cooperative (PEC)

### Other Entities:
- SPP (Southwest Power Pool) - Transmission Provider
- Market Participants (generic)
- Market Monitor
- Meter Agents
- Asset Owners

**No individual people are mentioned.**

## 6. Links or References

### Internal Document References:
- **Attachment T**: Point-to-Point Transmission Service rates
- **Attachment H, Addendum 39**: WFEC Formula Rate and protocols
- **Attachment H, Addendum 51**: PEC Formula Rate and protocols
- **Attachment J, Section IV.A**: Balanced Portfolio Reallocation
- **Attachment AU**: Revenue distribution and allocation
- **Attachment AE**: Integrated Marketplace provisions
- **Attachment AF, Section 3.9**: Penalty determinations
- **Attachment AM**: Meter Agent Agreement
- **Section 34.1(2)**: Schedule 7 & 8 revenue adjustments
- **Section 2.2(2)**: Market registration procedures
- **Section 4.1(10)(a), (b), (c)**: Resource commitment status descriptions

### External Files:
- **RRR File (Revenue Requirements and Rates File)**: Posted on SPP website, contains actual rate schedules
- **"WFEC PTP Rate Att T" tab**: Specific worksheet in RRR File
- **Market Protocols**: Timeline specifications for data submission

## 7. Suggested Tags

- Transmission Rates
- Point-to-Point Service
- Formula Rates
- SPP Tariff
- Integrated Marketplace
- Day-Ahead Market
- Must-Offer Requirement
- SCUC Algorithm
- Revenue Requirements
- Rate Zones
- Market Participant Obligations
- Meter Agent
- Capacity Management
- FERC Compliance
- Wholesale Power Markets
- Transmission Service Agreements

## 8. Items That May Need Follow-Up

1. **Revenue Requirements Verification**: Confirm all 15 entities in UMZ have current, Commission-approved formula rates
2. **RRR File Updates**: Verify the Revenue Requirements and Rates File on SPP website reflects current rates and adjustments
3. **Penalty Assessment Process**: Review Section 3.9 of Attachment AF to understand full penalty structure for must-offer violations
4. **90% Threshold Compliance**: Monitor market participant compliance with the 90% net resource capacity requirement
5. **Meter Agent Agreement Status**: Ensure all designated Meter Agents have executed Attachment AM agreements
6. **Emergency Capacity Procedures**: Clarify thresholds and triggers for incorporating emergency capacity limits
7. **Multi-Day Reliability Assessment**: Understand how resources committed in this assessment integrate with Day-Ahead Market
8. **Self-Charging MSR Treatment**: Review special handling procedures for Multi-Configuration Resources (MCRs) and their regulation service eligibility
9. **Non-Firm Transaction Curtailment**: Establish priority procedures for curtailing non-firm imports vs. exports during capacity situations
10. **Balanced Portfolio Reallocation**: Verify implementation of adjustments from Attachment J Section IV.A across all rate zones

---

# Chunk 17 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document (chunk 17 of 27) contains detailed regulatory language from SPP (Southwest Power Pool) regarding Day-Ahead Market operations and Reliability Unit Commitment processes. The content focuses on procedures for resource commitment and decommitment, manual interventions by the Transmission Provider when algorithmic solutions are insufficient, and compensation mechanisms for resources committed to address reliability issues. Key themes include maintaining transmission system security, handling local reliability issues versus system-wide constraints, non-discriminatory resource selection, and cost allocation methodologies (regional vs. local).

## 2. Key Topics

- **Day-Ahead Market SCUC (Security Constrained Unit Commitment) and SCED (Security Constrained Economic Dispatch) processes**
- **Manual resource commitment and decommitment procedures** when algorithms cannot directly address security constraints
- **Local Reliability Issues vs. system-wide Transmission System constraints** and their different treatment
- **Non-discriminatory resource selection** verified by Market Monitor
- **Operating Reserve requirements and co-optimization**
- **Virtual Energy Offers/Bids and Import/Export Interchange Transactions**
- **Capacity adequacy analysis** for upcoming Operating Day
- **Emergency capacity limits** and reliability-only resources
- **Multi-Configuration Resources (MCRs)** and their limitations during transitions
- **Cost minimization principles** in commitment decisions
- **Compensation and cost recovery mechanisms** (regional vs. local allocation)

## 3. Decisions or Actions

**Manual Commitment Authority:**
- Transmission Provider may manually commit/decommit resources when security constraints cannot be addressed algorithmically
- Must be done in non-discriminatory manner verified by Market Monitor (Section 6.1.2.1)
- Selected to minimize commitment costs while maintaining security constraints

**Priority Actions for Capacity Shortages:**
1. Curtail non-firm fixed Export Interchange Transaction Bids
2. Incorporate emergency capacity limits
3. Commit reliability-only resources
4. De-commit charging resources from Day-Ahead Market
5. De-commit self-committed charging resources

**Priority Actions for Capacity Surplus:**
1. Curtail non-firm fixed Import Interchange Transaction Offers
2. Incorporate emergency minimum capacity limits
3. Commit reliability resources capable of charging
4. De-commit non-self-committed resources
5. De-commit self-committed resources

**Operating Guides Development:**
- Transmission Provider, local transmission operators, and Resource owners will develop operating guides for manual commitments addressing known and recurring Local Reliability Issues

## 4. Important Dates

- **Operating Day** - repeatedly referenced as the time horizon for commitments and capacity analysis
- **30 minutes** - MCR Transition State Time threshold; MCRs exceeding this during transitions are not eligible to clear Operating Reserve

## 5. Organizations and People Mentioned

**Organizations:**
- **Transmission Provider** - primary authority for market operations and resource commitments
- **Market Monitor** - verification entity for non-discriminatory practices
- **Local transmission operator** - requests manual commitments for Local Reliability Issues
- **Resource owners** - participants in developing operating guides
- **Market Participants** - notified when units are manually committed
- **Reliability Coordinator** - authority role of Transmission Provider

**No individual people are mentioned by name**

## 6. Links or References

**Internal Cross-References (Attachment AE Sections):**
- Section 3.3.1 - SCED algorithm details
- Section 4.1(10)(b) - Market commitment status
- Section 4.1(10)(c) - Reliability-only resource designation
- Section 6.1.2.1 - Market Monitor verification process
- Section 8.3.2 - Virtual Reserve Limits (VRLs) in SCED
- Section 8.5.9 - Day-Ahead Market compensation for committed resources
- Section 8.5.10 - Regional cost recovery
- Section 8.6.5 - Day-Ahead RUC compensation
- Section 8.6.7(A) - Regional cost collection
- Section 8.6.44 - Local cost recovery/collection

**Document Reference:**
- Source: RR696 SPP Comments 20250814.docx.txt

## 7. Suggested Tags

- Day-Ahead Market
- SCUC (Security Constrained Unit Commitment)
- SCED (Security Constrained Economic Dispatch)
- Reliability Unit Commitment
- Manual Commitment
- Local Reliability Issues
- Transmission Security Constraints
- Operating Reserves
- Resource Commitment
- Cost Allocation
- Market Monitor
- Non-Discriminatory Selection
- Emergency Capacity
- MCR (Multi-Configuration Resources)
- Southwest Power Pool
- Reliability Coordinator
- Capacity Adequacy
- Regional vs Local Cost Recovery

## 8. Items That May Need Follow-Up

1. **Market Monitor Verification Process** - Section 6.1.2.1 referenced multiple times but not detailed in this chunk; need full process documentation

2. **Operating Guides Development Timeline** - No timeline specified for when Transmission Provider, local operators, and Resource owners must complete operating guides

3. **VRL (Virtual Reserve Limit) Implementation** - Referenced in Section 8.3.2 but specifics of "appropriately priced VRL" not defined in this chunk

4. **Definition Clarifications Needed:**
   - Distinction between "Local Reliability Issue" and "Local Emergency Condition"
   - "Instantaneous Load Capacity requirement" bounds (upper/lower)
   - Specific criteria for "reliability only use" resources

5. **Compensation Mechanism Details** - Multiple references to Sections 8.5.9, 8.6.5, 8.5.10, 8.6.7(A), and 8.6.44 but calculation methodologies not included in this chunk

6. **Day-Ahead Market SCUC Re-run Procedures** - "Time permitting" condition for re-running after manual commitments lacks specific time thresholds

7. **Shadow Price Calculation Methodology** - Referenced for Operating Reserve MCPs but not detailed

8. **Marginal Loss Sensitivity Factors** - Mentioned as included in SCED but approximation methodology not explained

9. **Coordination Protocols** - Specific communication procedures between Transmission Provider and local transmission operators not detailed

10. **Document Continuity** - This is chunk 17 of 27; remaining sections may contain critical context, definitions, or implementation details

---

# Chunk 18 Analysis

# Regulatory Meeting/Page Analysis Report

## 1. Executive Summary

This document contains detailed regulatory tariff language governing SPP's (Southwest Power Pool) Intra-Day Reliability Unit Commitment (RUC) execution process and the Delivery Point Assessment Process (Attachment AQ). The content primarily focuses on operational procedures for committing generation resources during the operating day, handling local reliability issues, and establishing protocols for delivery point facility changes. The document establishes cost allocation methodologies, Market Monitor verification requirements, and coordination procedures between transmission providers and local transmission operators.

## 2. Key Topics

- **Intra-Day Reliability Unit Commitment (RUC) Execution**: Detailed SCUC (Security Constrained Unit Commitment) algorithm operations for committing resources to meet load forecasts and reserve requirements
- **Resource Commitment Hierarchy**: Priority order for addressing capacity shortages and surpluses
- **Manual Commitment Procedures**: Protocols for handling reliability issues that cannot be addressed algorithmically
- **Local Reliability Issues**: Special procedures for local transmission operator actions during emergencies
- **Market Monitor Verification**: Non-discriminatory resource selection verification processes
- **Cost Recovery Mechanisms**: Regional vs. local cost allocation for different commitment types
- **Delivery Point Assessment Process (Attachment AQ)**: Procedures for changes to delivery point facilities, upgrades, retirements, and new connections
- **Load Connection Study (LCS)**: Requirements and procedures for evaluating delivery point modifications

## 3. Decisions or Actions

### Procedural Requirements:
- SCUC algorithm must minimize commitment costs while maintaining transmission system security constraints
- Market Monitor must verify non-discriminatory resource selection for manual commitments (Section 6.1.2.1)
- Local transmission operators must notify Transmission Provider of instructions given to resources during Local Emergency Conditions
- Transmission Provider and transmission operators must coordinate to ensure subsequent instructions are provided by Transmission Provider
- Operating guides must be developed for manual commitments addressing known and recurring Local Reliability Issues
- Transmission Customers must submit written requests for delivery point changes to Transmission Provider and Host Transmission Owner

### Commitment Actions (Priority Order for Capacity Shortage):
1. Curtail non-firm fixed Export Interchange Transaction Bids
2. Incorporate emergency capacity limits and/or commit reliability-only resources
3. De-commit charging Resources from Day-Ahead Market
4. De-commit self-committed charging Resources

### Commitment Actions (Priority Order for Capacity Surplus):
1. Curtail non-firm fixed Import Interchange Transaction Offers
2. Incorporate minimum emergency capacity limits and/or commit MSR charging resources
3. De-commit Resources committed by Transmission Provider (not self-committed)
4. De-commit self-committed Resources

## 4. Important Dates

- **Ten (10) Business Days**: Host Transmission Owner response deadline for delivery point change requests
- No other specific dates mentioned in this content chunk

## 5. Organizations and People Mentioned

### Organizations:
- **Transmission Provider** (SPP)
- **Host Transmission Owner**
- **Market Monitor**
- **Transmission Customer**
- **Local transmission operators**
- **Resource owners**

### People:
- No specific individuals mentioned

## 6. Links or References

### Internal Cross-References:
- Section 8.6.44 of Attachment AE (local cost recovery)
- Section 6.1.1 (inputs for Intra-Day RUC)
- Section 4.1(10)(c) of Attachment AE (reliability-only resource designation)
- Section 4.1(10)(b) of Attachment AE (market commitment status)
- Section 6.1.2.1 of Attachment AE (Market Monitor verification process)
- Section 8.6.5 of Attachment AE (resource compensation)
- Section 8.6.7(A) of Attachment AE (regional cost recovery)
- Section 20 of Network Operating Agreement
- Section 8 of Point to Point Transmission Service Agreement
- Section 3.2 of Attachment AQ (DPNS)
- Addendum 1 (Sample Request for Change in Local Delivery Facilities)

### Referenced Agreements:
- **Network Operating Agreement**
- **Point to Point Transmission Service Agreement**
- **Load Connection Study (LCS) Agreement**

## 7. Suggested Tags

- Intra-Day RUC
- Unit Commitment
- SCUC Algorithm
- Resource Commitment
- Local Reliability Issues
- Market Monitor
- Manual Commitment
- Cost Allocation
- Emergency Procedures
- Delivery Point Assessment
- Attachment AE
- Attachment AQ
- Load Connection Study
- Transmission Planning
- Operating Reserves
- Capacity Adequacy
- Non-discriminatory Selection
- Host Transmission Owner

## 8. Items That May Need Follow-Up

### Clarifications Needed:
1. **Section 6.1.2.1 Reference**: The Market Monitor verification process is referenced multiple times but not detailed in this chunk - need to review that section
2. **Section 8.6.44 Details**: Local cost recovery methodology referenced but not fully described - requires review
3. **Operating Guide Development**: Timeline and specific requirements for developing operating guides for manual commitments addressing recurring Local Reliability Issues
4. **Affiliation Rules**: Definition and criteria for determining Resource affiliation with local transmission operator (mentioned in discriminatory selection provisions)

### Process Questions:
5. **LCS Timeline**: While Host Transmission Owner has 10 business days to respond, no timeline specified for actual study completion
6. **Study Cost Estimation**: No guidelines provided for what constitutes "estimated study cost" for the advance deposit determination
7. **Exemption Criteria**: Three types of delivery point changes exempt from Attachment AQ process - may need clarification on how "corresponding change to load" is defined
8. **Advance Deposit Amount**: $25,000 threshold mentioned but no basis or inflation adjustment mechanism provided

### Coordination Issues:
9. **Emergency Communication Protocols**: Specific communication procedures between local transmission operator and Transmission Provider during time-critical Local Emergency Conditions
10. **Logging Requirements**: Specific format and retention requirements for logged instructions not detailed
11. **DPNS Coordination**: When Delivery Point Network Study is required vs. when Host Transmission Owner handles independently

### Compliance Monitoring:
12. **Market Monitor Verification Standards**: Standards for determining discriminatory vs. non-discriminatory resource selection need review
13. **Cost Recovery Disputes**: No dispute resolution process mentioned for regional vs. local cost allocation disagreements

---

# Chunk 19 Analysis

# Regulatory Analysis Report
**Source: RR696 SPP Comments 20250814.docx.txt - chunk 19 of 27**

---

## 1. Executive Summary

This document contains detailed regulatory procedures for transmission system modifications, specifically focusing on two attachment sections (AQ and AX) of what appears to be SPP's (Southwest Power Pool) tariff. The content establishes processes for requesting and evaluating changes to local delivery facilities and provisional load increases. It defines timeframes, responsibilities, and cost allocation between Transmission Customers, Host Transmission Owners, and Transmission Providers for conducting necessary studies (Load Connection Studies and Delivery Point Network Studies) and implementing facility changes.

---

## 2. Key Topics

- **Load Connection Study (LCS) Process**: Procedures for studying new or modified delivery points, including timelines (60 days for completion) and deposit requirements
- **Transmission System Study & Preliminary Assessment**: 10 business day assessment period for delivery point configuration changes
- **Delivery Point Network Study (DPNS)**: Analysis of significant transmission system impacts with 60-day completion requirement
- **Study Agreement Requirements**: Mandatory execution within 30 calendar days, with deposits of actual estimated cost or $10,000 (whichever is less)
- **Integrated Transmission Planning Assessment**: Evaluation of requests with identified Network Upgrades
- **Cost Reimbursement Procedures**: Interest-bearing accounts and refund processes per 18 C.F.R. § 35.19a(a)(2)
- **Provisional Load Process (Attachment AX)**: Procedures for handling increased load without sufficient Designated Resources
- **Study Request Modifications**: Flexibility for revising planned facilities during study processes

---

## 3. Decisions or Actions

**Required Actions:**
- Transmission Customers must execute LCS/DPNS Agreements within 30 calendar days of receipt or request is deemed withdrawn
- Host Transmission Owner must complete LCS and issue Load Connection Report within 60 calendar days
- Transmission Provider must complete preliminary assessment within 10 business days (extendable to 20 business days)
- Transmission Provider must deliver DPNS Agreement within 5 business days if significant impact found
- SPP must post monthly (by 20th day) all Requests for Change that received preliminary assessment
- Transmission Customers must reimburse unpaid study costs exceeding deposits
- Providers must refund excess deposits with interest

**Withdrawal Conditions:**
- Automatic withdrawal if executed agreement not returned within 30 days
- Voluntary withdrawal allowed at any time via written notice

---

## 4. Important Dates

- **30 Calendar Days**: Deadline for returning executed study agreements with deposits
- **10 Business Days**: Initial timeline for preliminary assessment completion
- **20 Business Days**: Extended deadline for preliminary assessments with non-standard elements
- **5 Business Days**: Delivery of DPNS Agreement after preliminary assessment showing significant impact
- **60 Calendar Days**: Completion deadline for both LCS and DPNS reports
- **20th Day of Each Month**: SPP posting deadline for prior month's preliminary assessments

---

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)**: Transmission Provider, responsible for system studies and assessments
- **Host Transmission Owner**: Entity owning the transmission system portion requiring connection/modification
- **Transmission Customer**: Entity requesting delivery point changes or load increases

**Roles Referenced:**
- Transmission Provider
- Host Transmission Owner
- Transmission Customer
- Representative of Transmission Customer (signature authority)

---

## 6. Links or References

**Regulatory References:**
- **18 C.F.R. § 35.19a(a)(2)**: Federal regulation regarding interest calculation on deposits
- **Attachment AQ**: Delivery Point Assessment Process
- **Attachment AX**: Provisional Load Process
- **Addendum 1 to Attachment AQ**: Sample Request for Change in Local Delivery Facilities
- **SPP Business Practices**: Standardized project timelines
- **Section 20 of Network Operating Agreement**: Specifies submission requirements
- **Section 8 of Point-to-Point Transmission Service Agreement**: Alternative submission requirements
- **SPP OASIS**: Location for PLPS agreement availability
- **SPP Website**: Posting location for study requests and reports

---

## 7. Suggested Tags

- Transmission Planning
- Delivery Point Modifications
- Network Studies
- DPNS (Delivery Point Network Study)
- LCS (Load Connection Study)
- SPP Tariff
- Attachment AQ
- Attachment AX
- Provisional Load Process
- Network Upgrades
- Integrated Transmission Planning
- Study Agreements
- Cost Allocation
- Transmission Service
- Regulatory Compliance
- FERC Regulations

---

## 8. Items That May Need Follow-Up

1. **Incomplete Document**: Content cuts off mid-sentence in Attachment AX ("...commit the Transmission Customer to pay the Transmission P")—need complete text

2. **Monthly Posting Compliance**: Verify SPP is meeting the 20th-day monthly posting requirement for preliminary assessments

3. **Study Timeline Extensions**: Track instances where mutual agreements extend standard 30/60-day timelines to ensure not being used to circumvent regulatory deadlines

4. **Interest Calculation Verification**: Confirm proper application of 18 C.F.R. § 35.19a(a)(2) for deposit refunds with interest

5. **Deposit Amount Adequacy**: Monitor whether $10,000 minimum deposit remains appropriate or if actual study costs frequently exceed this threshold

6. **Integrated Planning Assessment Capacity**: Determine if "soonest available" assessment process creates bottlenecks for Network Upgrade evaluations

7. **Scope Definition Clarity**: The "elements beyond scope of Attachment AQ process" provision allowing 20-day extensions needs clearer definition to prevent disputes

8. **Idev Modeling Requirements**: Addendum 1 references "Idev modeling file(s)"—verify this requirement is clearly defined elsewhere and customers understand expectations

9. **Coordination Between Processes**: Clarify relationship between Attachment AQ (delivery point changes) and Attachment AX (provisional load) when both may apply

10. **Posting of DPNS Reports**: Section 3.5 conditions for posting need clarification—verify notification and update procedures are working effectively

---

# Chunk 20 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary
This document chunk contains detailed procedural requirements for the SPP (Southwest Power Pool) Provisional Load Process, focusing on delivery point modifications, study requirements, and non-conforming load protocols. It outlines the responsibilities of Transmission Customers, Host Transmission Owners, and Transmission Providers in conducting Load Connection Studies (LCS) and Provisional Load Process Studies (PLPS), including timelines, cost allocation, and technical specifications. The document also includes Market Protocol requirements for Non-Conforming Load forecasting and must-offer obligations.

## 2. Key Topics
- **Load Connection Studies (LCS)**: Process for assessing feasibility of modifying or establishing delivery points
- **Provisional Load Process Studies (PLPS)**: Assessment of impacts on transmission system due to delivery point changes
- **Cost Allocation**: Customer responsibility for study costs with deposit requirements
- **Study Timelines**: Specific timeframes for study completion and reporting
- **Delivery Point Transfers**: Process for transferring delivery points when resources are insufficient
- **Non-Conforming Load**: Forecasting requirements for load not following normal predictable patterns
- **Energy Storage Resources (ESR)**: Charging capabilities treated as Non-Conforming Load
- **Must-Offer Requirements**: Market participant obligations for Day-Ahead Market, RUC, and RTBM

## 3. Decisions or Actions
- **Deposit Requirements**: Host Transmission Owner may require advance deposit equal to estimated study cost or $25,000, whichever is less
- **Study Withdrawal**: If executed LCS agreement not returned within 30 calendar days, study request deemed withdrawn
- **Cost Reimbursement**: Transmission Customer must reimburse actual study costs exceeding deposits
- **Initial Assessment**: Transmission Provider must perform initial assessment upon receiving Provisional Load Process request
- **Report Posting**: PLPS reports posted on SPP website once Network Upgrade identified and customer provides notification
- **Forecasting Submissions**: Market Participants must submit hourly load forecasts for Non-Conforming Load before Day-Ahead RUC process

## 4. Important Dates
- **10 Business Days**: Host Transmission Owner response time to study request
- **30 Calendar Days**: Deadline for returning executed LCS agreement with deposit
- **90 Calendar Days**: Timeline for completing LCS and issuing Load Connection Report (from receipt of executed agreement, deposit, and data)
- **90 Calendar Days**: Timeline for Transmission Provider to send PLPS study report (from agreement on study assumptions)
- **One Year**: Validity period for PLPS results after issuance of study report
- **30 Minutes**: Deadline before Operating Hour for submitting Non-Conforming Load forecasts
- **15 Minutes**: Rolling basis for submitting Non-Conforming Load forecasts
- **2 Hours**: Encouraged forecast horizon for each 15-minute interval for Non-Conforming Load

## 5. Organizations and People Mentioned
### Organizations:
- **SPP (Southwest Power Pool)**: Transmission Provider
- **Host Transmission Owner**: Entity conducting LCS
- **Transmission Customer**: Entity requesting delivery point modifications
- **Market Participants**: Entities with registered loads and resources

### Roles Referenced:
- Asset Owner
- Representative of Transmission Customer

## 6. Links or References
- **18 C.F.R. § 35.19a(a)(2)**: Interest calculation reference
- **Attachment AX of Tariff**: Contains Provisional Load Process
- **Addendum 1 to Attachment AX**: Sample Request for Provisional Load Process
- **Addendum 2 and Addendum 3 of Attachment AX**: Provisional Load Process Agreements
- **Section 6.2.2**: Non-Conforming Load description
- **Section 2**: Provisional Load Process Study description
- **Section 4.2.1.1**: Must-offer obligation details
- **Section 6.3, 8.2, 8.3**: Referenced but not detailed in this chunk
- **Market Protocols Glossary**: Referenced for definitions

## 7. Suggested Tags
- Provisional Load Process
- Load Connection Study
- Transmission Service
- Delivery Point Modification
- Network Upgrades
- Study Requirements
- Cost Allocation
- Non-Conforming Load
- Energy Storage Resources
- Day-Ahead Market
- Load Forecasting
- Must-Offer Requirements
- SPP Tariff
- Transmission Planning
- RUC (Reliability Unit Commitment)
- RTBM (Real-Time Balancing Market)

## 8. Items That May Need Follow-Up
1. **Missing Study Agreement Details**: Specific terms of LCS agreement not fully detailed
2. **Study Cost Estimates**: Methodology for estimating study costs not specified
3. **Significant Impact Definition**: Criteria for determining "significant impact on the Transmission System" not clearly defined
4. **Restudy Process**: Section 2.3 references modifications but detailed restudy procedures may need clarification
5. **Section 2.4 Missing**: Document jumps from Section 2.3 to Section 2.5
6. **Engineering Agreements**: Section 3.0 references written agreements but templates not provided
7. **Incomplete Must-Offer Section**: Section 4.2.1.1 appears to be cut off mid-sentence
8. **ESR Registration**: Process for registering ESRs as MSR not detailed
9. **Dispute Resolution**: No mention of dispute resolution process for study disagreements
10. **Communications Configuration**: Meter communications requirements mentioned but not detailed
11. **"At Risk" Reference**: Document contains "at risk" notation without context
12. **Multiple "Must" References**: Document contains numerous standalone "must" references that may indicate formatting issues or missing content

---

# Chunk 21 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary
This document is chunk 21 of 27 from SPP (Southwest Power Pool) Comments dated August 14, 2025, regarding regulatory requirements RR696. The content details complex market participation rules, focusing on must-offer obligations for Market Participants, Day-Ahead (DA) Market execution procedures, and capacity calculation methodologies. It establishes comprehensive requirements for load-serving entities, resource commitment protocols, and the treatment of bilateral contracts, firm power purchases/sales, and various resource types including Multi-Configuration Resources (MCRs) and Market Storage Resources (MSRs).

## 2. Key Topics

- **Must-Offer Obligations**: Detailed requirements for Market Participants to offer available resources to meet load and operating reserve obligations
- **Capacity Calculations**: Methods for calculating net resource capacity, including treatment of:
  - Reported Load calculations
  - Operating Reserve obligations
  - Firm power purchases and sales
  - Bilateral contracts
  - Jointly Owned Units (JOUs)
- **Compliance Thresholds**: 90% net resource capacity requirement for must-offer compliance
- **Day-Ahead Market (DA) Execution**: SCUC (Security Constrained Unit Commitment) and SCED (Security Constrained Economic Dispatch) algorithms
- **GFA Carve Out Requirements**: Specific offering requirements for resources used as GFA Carve Out sources
- **Emergency Procedures**: Capacity shortage and surplus management protocols
- **Local Reliability Issues**: Procedures for addressing transmission system constraints and local emergency conditions
- **Market Monitor Role**: Verification and monitoring of Market Participant compliance

## 3. Decisions or Actions

### Mandatory Actions:
- Market Participants must offer all available resources with Commitment Status of Market, Self, or Reliability
- Supporting documentation for firm power purchases/sales must be provided to Market Monitor upon request
- Market Participants have the option to input firm power purchase/sale information into Market Monitor website
- Resources used for GFA Carve Out must be offered with sufficient capacity to cover GFA Carve Out Schedule

### Compliance Procedures:
- Market Monitor will monitor hourly load, Operating Reserve obligation, offered Resources, and net Resource capacity
- Non-compliance results in penalties as described in Section 4.2.1.1.1
- SPP may manually commit/decommit Resources to address transmission system security constraints

### Priority Order Actions (Capacity Shortage):
1. Curtail non-firm fixed Export Interchange Transaction Bids
2. Incorporate emergency capacity limits and commit Reliability Resources

### Priority Order Actions (Capacity Surplus):
1. Curtail non-firm fixed Import Interchange Transaction Offers
2. Incorporate emergency minimum limits and commit available MSRs for charging

## 4. Important Dates

- **Operating Day**: Referenced throughout as the measurement period for compliance
- **Day-Ahead Market**: Clears for each hour of the upcoming Operating Day
- **Document Date**: August 14, 2025 (RR696 SPP Comments 20250814)

*Note: No specific future deadlines or milestone dates are mentioned in this chunk.*

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)**: Primary regulatory authority and market operator
- **Market Monitor**: Oversight and verification entity
- **Market Participants**: Load-serving entities and resource owners
- **Asset Owners**: Entities owning generation and load assets
- **Local Transmission Operators**: Regional transmission system operators

### Roles (No specific individuals named):
- Reliability Coordinator (SPP function)
- Resource owners
- Buyers and sellers under bilateral contracts

## 6. Links or References

### Internal Cross-References:
- Section 6.2.8: Bilateral contract load registration
- Section 4.1.3(4): Operating Reserve obligation calculations
- Section 4.2.1.1: Must-offer obligation requirements
- Section 4.2.1.1.1: Penalty assessment procedures
- Section 4.2.2.5.4: JOU Individual Resource Option
- Section 6.1.14: Combined Interest Resource modeling
- Section 6.1.7.1: MCR registration options
- Section 4.5.9.12: Resource compensation
- Section 4.5.9.13: Regional cost recovery
- Section 4.5.8.12: Local reliability resource compensation
- Section 4.5.9.10(1): Local cost recovery
- Section 6.1.2.1 of Attachment AE to the Tariff: Market Monitor verification process

### Referenced Documents:
- **Attachment AE to the Tariff**: Contains Market Monitor processes and procedures
- **Source Document**: RR696 SPP Comments 20250814.docx.txt

## 7. Suggested Tags

- Must-Offer-Obligation
- Day-Ahead-Market
- Market-Participation
- Capacity-Requirements
- Operating-Reserves
- SCUC-Algorithm
- SCED-Algorithm
- Market-Monitor
- Compliance-Requirements
- Firm-Power-Transactions
- Bilateral-Contracts
- Resource-Commitment
- Emergency-Procedures
- Local-Reliability
- GFA-Carve-Out
- Market-Storage-Resources
- Multi-Configuration-Resources
- Transmission-Constraints
- SPP-Tariff
- RR696

## 8. Items That May Need Follow-Up

### Clarification Needed:
1. **Penalty Structure**: Section 4.2.1.1.1 referenced for penalty assessment but not detailed in this chunk - requires review of complete penalty framework
2. **Market Monitor Website Details**: Specifications for the optional firm power purchase/sale information input system
3. **Counterparty Dispute Resolution**: Process when one party disputes a firm purchase/sale to Market Monitor - no detailed procedure provided
4. **Self-Charging MSR Definition**: How "Self-Charging MW" is calculated and verified during maximum Reported Load hour

### Compliance Monitoring:
5. **90% Threshold Justification**: Rationale for the 90% net resource capacity compliance threshold (versus 100%)
6. **Hourly vs. Daily Compliance**: Reconciliation between hourly compliance assessment and daily Operating Reserve obligations
7. **Non-Discriminatory Manual Commitment Verification**: Detailed Market Monitor verification process per Section 6.1.2.1

### Operational Concerns:
8. **Emergency Limit Duration**: No time limits specified for use of Maximum/Minimum Emergency Capacity Operating Limits
9. **MCR Transition Hour Restrictions**: Impact of regulation ineligibility during configuration transitions on market efficiency
10. **Local vs. Regional Cost Allocation**: Criteria distinguishing local (Section 4.5.9.10(1)) versus regional (Section 4.5.9.13) cost recovery

### Documentation Requirements:
11. **Supporting Documentation Standards**: Specific requirements for verifying firm power purchases/sales documentation
12. **GFA Carve Out Source Verification**: Monitoring and verification procedures for sufficient capacity coverage
13. **Jointly Owned Unit Accounting**: Treatment when shares haven't been registered as separate Resources

### Coordination Issues:
14. **Multi-Day Reliability Assessment Integration**: How Resources committed in this process flow into DA Market SCUC
15. **Local Transmission Operator Authority**: Clear delineation of when local operators can request SPP action versus direct SPP action
16. **Incomplete Sentence**: Document ends mid-sentence ("Resource owners will develop op...") - requires complete text review

---

# Chunk 22 Analysis

# REGULATORY ANALYSIS REPORT
**Source:** RR696 SPP Comments 20250814.docx.txt - chunk 22 of 27

---

## 1. Executive Summary

This document section details Southwest Power Pool's (SPP) Day-Ahead Market operations, Reliability Unit Commitment (RUC) execution procedures, and Intra-Day RUC processes. The content extensively describes the Security Constrained Unit Commitment (SCUC) and Security Constrained Economic Dispatch (SCED) algorithms used for resource commitment and energy dispatch. Key focus areas include manual commitment procedures for local reliability issues, compensation mechanisms, and the handling of Multi-Configuration Resources (MCRs) with transition times greater than 30 minutes. The document establishes hierarchical procedures for addressing capacity shortages and surpluses while maintaining transmission system security.

---

## 2. Key Topics

- **Day-Ahead Market SCUC/SCED Execution**
  - Resource commitment optimization to meet demand, virtual energy bids, and operating reserve requirements
  - Marginal loss sensitivity factors for energy dispatch optimization
  - Co-optimization logic for energy and operating reserve market clearing prices

- **Manual Commitment Procedures**
  - Process for manual commitments by SPP or at local transmission operator request
  - Local Reliability Issues requiring out-of-merit commitments/decommitments
  - Development of operating guides for known and recurring reliability issues

- **Day-Ahead RUC Execution**
  - Capacity adequacy analysis using SCUC algorithm
  - Commitment decisions based on Start-Up, No-Load, and incremental cost at minimum output
  - Resource commit status categories: Market, Self, and Reliability

- **Multi-Configuration Resources (MCRs)**
  - MCRs with transition times >30 minutes ineligible for Contingency Reserve during configuration transitions
  - MCRs ineligible for regulation selection during transitions

- **Capacity Shortage/Surplus Management**
  - Priority order for addressing shortages: curtail non-firm exports, use emergency limits, commit reliability resources, de-commit charging resources
  - Priority order for addressing surplus: curtail non-firm imports, use emergency limits, commit charging reliability resources, de-commit market/self-committed resources

- **Violation Relaxation Limits (VRLs)**
  - Applied in SCED when constraint enforcement results in infeasible solutions

- **Compensation and Cost Recovery**
  - Regional vs. local cost allocation depending on commitment circumstances
  - References to Sections 4.5.9.8, 4.5.9.10, and 4.5.9.12

---

## 3. Decisions or Actions

- **SPP shall re-run Day-Ahead SCUC algorithm** after manual commitments (time permitting) if not included in initial run

- **SPP must notify Market Participants** when units are manually committed

- **SPP must apply VRLs in SCED** when constraint enforcement creates infeasible solutions below appropriately priced VRL

- **SPP, local transmission operators, and Resource owners shall develop operating guides** for manual commitments addressing known and recurring Local Reliability Issues

- **Market Monitor to review manual commitments** through process in Section 6.1.2.1 of Attachment AE to ensure non-discriminatory selection

- **Day-Ahead RUC and Intra-Day RUC Operators will determine** which advisory options (schedule curtailments, reliability resources, emergency limits) should be acted upon and when

---

## 4. Important Dates

- **Operating Day** - Referenced throughout as the timeframe for market execution (specific dates not provided in this section)
- No specific calendar dates or deadlines mentioned in this chunk

---

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)** - Primary market operator and reliability coordinator
- **Market Participants** - Resource owners and market entities
- **Local transmission operators** - Entities requesting manual commitments for local reliability issues
- **SPP Operators** - Day-Ahead RUC and Intra-Day RUC operators
- **Market Monitor** - Oversight entity for non-discriminatory commitment selection
- **Resource owners** - Entities owning generation/storage resources

### People:
- No specific individuals mentioned

---

## 6. Links or References

### Internal Document References:
- **Section 3.1.1** - Resource operating constraints and transmission constraints
- **Section 4.1.3.3** - Violation Relaxation Limits (VRLs) in SCED
- **Section 4.3.2.2** - Day-Ahead RUC Execution
- **Section 4.4.1.3** - Intra-Day RUC Execution
- **Section 4.5.9.8** - Compensation for RUC committed resources
- **Section 4.5.9.10** - Cost recovery/allocation mechanisms (regional vs. local)
- **Section 4.5.9.10(1)** - Local cost collection
- **Section 4.5.9.12** - Compensation for Day-Ahead Market manual commitments
- **Section 6.1.2.1 of Attachment AE to the Tariff** - Market Monitor process for reviewing manual commitments
- **Section 6.1.7.1** - MCR registration option regarding configuration transitions

### External References:
- None explicitly mentioned

---

## 7. Suggested Tags

- Day-Ahead Market
- Reliability Unit Commitment (RUC)
- SCUC (Security Constrained Unit Commitment)
- SCED (Security Constrained Economic Dispatch)
- Manual Commitments
- Local Reliability Issues
- Multi-Configuration Resources (MCR)
- Operating Reserves
- Capacity Adequacy
- Market Clearing Prices
- Violation Relaxation Limits
- Cost Allocation
- Transmission Constraints
- Resource Commitment
- SPP Integrated Marketplace
- Emergency Operations
- Intra-Day Operations

---

## 8. Items That May Need Follow-Up

### Clarification Needed:
1. **Operating guide development timeline** - No deadline specified for SPP, local transmission operators, and Resource owners to develop operating guides for manual commitments

2. **Definition of "time permitting"** - Criteria for when SPP will/won't re-run SCUC after manual commitments needs clarification

3. **MCR transition time threshold** - Rationale for 30-minute threshold for Contingency Reserve eligibility during configuration transitions

4. **Local vs. Regional cost recovery criteria** - Need clearer delineation between when costs are recovered locally (Section 4.5.9.10(1)) versus regionally (Section 4.5.9.10)

### Potential Issues:
5. **Market Monitor oversight process** - Reference to Section 6.1.2.1 for non-discriminatory selection review but no details on timing, criteria, or remedies

6. **Advisory nature of RUC results** - Operator discretion in acting on RUC recommendations could create inconsistencies; procedures for decision-making not fully specified

7. **Incomplete capacity surplus procedure** - Text ends mid-sentence: "incorporate capacity down to Resources' Minimum Emergency Capacity Operating" - requires completion

8. **Coordination with local transmission operators** - Process for local transmission operator requests for manual commitments could benefit from more specific procedural details

### Cross-Reference Verification:
9. **Section 4.5.9.8, 4.5.9.10, 4.5.9.12 consistency** - Verify compensation mechanisms are consistent across different commitment scenarios

10. **Attachment AE Section 6.1.2.1** - Confirm Market Monitor process adequately addresses manual commitment oversight

11. **Section 6.1.7.1 MCR registration** - Verify consistency of MCR treatment across all market processes (Day-Ahead, RUC, Real-Time)

---

# Chunk 23 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document chunk contains detailed operational and planning criteria from SPP (Southwest Power Pool) regulatory documents. It primarily covers three main areas: (1) resource commitment procedures during reliability and capacity events, including manual commitments and Local Reliability Issues; (2) operational requirements for Non-Conforming Load registration, Emergency Operating Plans, and ICCP connectivity; and (3) transmission planning criteria definitions including Transmission Material Modifications and Qualified Changes. The content establishes protocols for coordinating actions between SPP, local transmission operators, and Market Monitors to maintain system reliability while ensuring non-discriminatory practices and appropriate compensation for resources.

## 2. Key Topics

- **Resource Commitment Management**: Procedures for committing/de-committing resources during capacity surplus, transmission constraints, and reliability issues
- **Local Reliability Issues**: Protocols for out-of-merit commitment, decommitment, or dispatch instructions by SPP or local transmission operators
- **Market Monitor Oversight**: Non-discriminatory selection verification process per Section 6.1.2.1 of Attachment AE
- **Compensation Recovery**: Regional vs. local collection of costs under Section 4.5.9.8 and 4.5.9.10
- **Non-Conforming Load Registration**: Requirements for loads 50 MW or greater
- **Emergency Operating Plans (EOPs)**: Operator-controlled load shedding and critical natural gas load prioritization
- **ICCP Connectivity Requirements**: Dual-node configuration and 240-second reconnection standards for TOPs and GOPs
- **Transmission Planning Criteria**: Definitions of Transmission Material Modification and Qualified Changes
- **System Reliability Standards**: NERC compliance and SPP regional planning requirements

## 3. Decisions or Actions

- **Resource De-commitment Priority**: During excess capacity, SCUC will: (1) operate within emergency limits, (2) commit reliability resources capable of charging, (3) de-commit DA Market resources, (4) de-commit self-committed resources post-Day-Ahead RUC
- **Manual Commitment Selection**: Must be non-discriminatory and minimize commitment costs while maintaining security constraints
- **Local Emergency Response**: Local transmission operators may issue direct instructions during Local Emergency Conditions when time doesn't permit SPP coordination
- **Affiliated Resource Restriction**: Resources selected discriminatorily that are affiliated will not receive compensation under Section 4.5.9.8
- **Operating Guide Development**: SPP, local transmission operators, and resource owners must develop operating guides for manual commitments for recurring Local Reliability Issues
- **Load Shedding Rotation**: Regular rotation of shed load between different areas during extended periods
- **Critical Load Prioritization**: Natural gas loads protected from manual and automatic load shedding
- **ICCP Configuration Requirements**: All TOPs must connect to both primary and backup SPP sites concurrently

## 4. Important Dates

- **ICCP Reconnection Timeframe**: 240 seconds for alternate ICCP node reconnection after failure
- **Permanent Change Duration**: Typically greater than 12 months for Qualified Changes and Transmission Material Modifications
- No specific calendar dates mentioned in this content chunk

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)**: Primary regulatory and market operator
- **Market Monitor**: Oversight entity verifying non-discriminatory practices
- **NERC (North American Electric Reliability Corporation)**: Standards authority
- **Local Transmission Operators**: Entity-level reliability operators
- **TOPs (Transmission Operators)**: NERC-registered entities
- **GOPs (Generator Operators)**: NERC-registered entities
- **SPP BA (Balancing Authority) Area**: Operational territory
- **SPP RC (Reliability Coordinator) Area**: Reliability coordination territory
- **Transmission Owners**: Host entities for delivery points

### People:
- No specific individuals mentioned

## 6. Links or References

### Internal SPP Document References:
- **Section 4.5.9.8**: Compensation provisions for committed resources
- **Section 4.5.9.10**: Regional/local cost recovery collection procedures
- **Section 6.1.2.1 of Attachment AE**: Market Monitor verification process
- **Attachment O**: Transmission Planning Process in OATT
- **Attachment V**: Generation Interconnection procedures
- **Attachment AB**: Retirement assessment process
- **Attachment AQ**: Delivery point establishment procedures

### NERC Standards:
- **FAC-002-041**: Mandatory reliability standard for qualified changes
- **NERC Glossary of Terms**: Standard definitions
- **NERC Reliability Standards**: General BES requirements

### Other References:
- **SPP OATT (Open Access Transmission Tariff)**: Governing tariff document
- **RDS (Telemetering and Control System Status)**: Outage scheduling information
- **ICCP (Inter-Control Center Communications Protocol)**: Communication standard

## 7. Suggested Tags

- Resource_Commitment
- Reliability_Management
- Local_Reliability_Issues
- Market_Monitoring
- Non-Discriminatory_Practices
- Compensation_Recovery
- ICCP_Connectivity
- Emergency_Operating_Plans
- Load_Shedding
- Transmission_Planning
- NERC_Compliance
- Day-Ahead_Market
- SCUC_Algorithm
- Reserve_Zones
- Non-Conforming_Load
- Transmission_Material_Modification
- Qualified_Changes
- BES_Facilities
- GOP_TOP_Requirements
- Critical_Infrastructure

## 8. Items That May Need Follow-Up

1. **Operating Guide Development Status**: Verify completion status of operating guides for manual commitments addressing recurring Local Reliability Issues between SPP, local transmission operators, and resource owners

2. **ICCP Compliance Verification**: Confirm all TOPs and qualifying GOPs (>1500 MW or 15+ resources) have implemented dual-node ICCP configurations with 240-second reconnection capability

3. **Non-Conforming Load Registration**: Ensure all loads ≥50 MW have been properly identified and registered with appropriate PNode or APNode designations

4. **Market Monitor Process Implementation**: Verify Section 6.1.2.1 verification processes are functioning for manual commitment selections and affiliated resource determinations

5. **EOP Critical Load Prioritization**: Review Emergency Operating Plans to confirm critical natural gas load prioritization procedures are documented and implemented

6. **Third-Party ICCP Contracts**: Audit third-party ICCP service contracts to ensure 240-second reconnection requirements are contractually guaranteed

7. **Transmission Material Modification Threshold**: Clarify specific percentage/magnitude thresholds for the incomplete definition at document end (appears cut off at "im...")

8. **Cost Recovery Allocation Disputes**: Monitor any disputes between regional vs. local cost allocation for manually committed resources under different reliability scenarios

9. **Local Emergency Condition Documentation**: Ensure proper logging and notification procedures are followed when local transmission operators issue direct instructions

10. **Affiliated Resource Determinations**: Track Market Monitor decisions on discriminatory resource selection and affiliated resource compensation denials for potential appeals or pattern identification

---

# Chunk 24 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document chunk (24 of 27) from SPP's RR696 Comments contains detailed operational procedures and business practices related to generator interconnection studies, network upgrades, and delivery point management. The content primarily focuses on three areas: (1) non-jurisdictional facility system studies and responsibilities, (2) HILLGA (Higher Injection Level Generator Addition) network study procedures and modeling requirements, and (3) Business Practice 7850 regarding delivery point additions, modifications, and retirements under Attachment AQ and AX processes. The document establishes clear procedural frameworks for coordinating studies between SPP, Transmission Owners, and interconnection customers, with emphasis on affected system analysis and upgrade requirements.

## 2. Key Topics

- **Non-Jurisdictional Generator Interconnection**: Procedures for generator interconnection customers not subject to OATT, including study requirements and Transmission Owner responsibilities
- **HILLGA Network Studies**: Detailed methodology for Higher Injection Level Generator Addition requests, including queue positioning and model development
- **Short-Circuit Fault Current Analysis**: Calculation procedures consistent with SPP ITP Manual requirements
- **Network Upgrade Requirements**: Conditions and responsibilities for completing upgrades on Transmission and Distribution Systems
- **Delivery Point Management (BP 7850)**: Processes for evaluating Delivery Point Additions, Modifications, and Retirements
- **Attachment AQ and AX Processes**: Planning processes for assessing delivery point impacts and necessary upgrades
- **Model Development**: Base and Change Model requirements for HILL and HILLGA studies
- **Affected System Studies**: Coordination procedures when external systems are impacted

## 3. Decisions or Actions

- **Transmission Owner Responsibilities**: Must conduct required studies when notified of potential system impacts; must notify SPP of impacts and provide system impact studies
- **SPP Study Determinations**: SPP will determine what additional studies are required to coordinate impacts, potentially including Definitive Interconnection System Impact Studies
- **Study Agreement Requirements**: Transmission Owner/distribution provider has option to either enter into study agreements themselves or require interconnection customer to do so
- **Network Upgrade Completion**: All Network Upgrades must be completed prior to Generating Facility operation unless other mitigations are approved by SPP
- **HILLGA Queue Processing**: Initial Queue Position determines whether HILLGA Requests are processed serially (if Electrically-Equivalent) or in parallel (if not Electrically-Equivalent)
- **NITS Agreement Updates**: Transmission Customer responsible for notifying SPP to update NITS Agreement after Attachment AQ review
- **Request Aggregation**: Multiple Delivery Point requests in relative proximity may be aggregated into single study analysis

## 4. Important Dates

- No specific dates are mentioned in this content chunk
- References to timing include:
  - "Prior to operation of the Generating Facility" (for Network Upgrade completion)
  - Study timelines mentioned but not specified
  - "Prior queued" and "subsequent to publishing" references for ITP models

## 5. Organizations and People Mentioned

**Organizations:**
- SPP (Southwest Power Pool)
- Transmission Owners
- Distribution Providers
- Associated Electric Cooperatives, Inc.
- California Independent System Operator Corporation
- Electric Reliability Council of Texas (ERCOT)
- Midcontinent Independent System Operator, Inc. (MISO)
- Peak
- Public Service Company of Colorado
- Saskatchewan Power Corporation
- Southwestern Power Administration
- Tennessee Valley Authority

**Roles/Parties (no specific individuals named):**
- Transmission Customers
- Interconnection Customers
- Non-jurisdictional generator interconnection customers

## 6. Links or References

**Referenced Documents/Systems:**
- SPP Open Access Transmission Tariff (OATT)
- Generator Interconnection Procedures (Attachment V)
- SPP Business Practices (specifically BP 7250, BP 7850, BP 7060)
- Attachment AQ (Delivery Point planning process)
- Attachment AX (Delivery Point additions with planned generation)
- Attachment BB (Section 4.1.1, Section 8.4.1)
- Seams Agreements
- SPP Disturbance Performance Requirements
- SPP Quarterly Project Tracking Report
- Request Management System
- New Three Stage Interconnection Process
- ITP Manual (Short-Circuit Analysis)
- SPP Model Development Procedure Manual

**Study Types Referenced:**
- Definitive Interconnection System Impact Studies
- Affected System Study Agreements
- Delivery Point Network Study (DPNS)
- Provisional Load Process Study (PLPS)

## 7. Suggested Tags

- Generator_Interconnection
- HILLGA
- Network_Studies
- Business_Practice_7850
- Business_Practice_7250
- Attachment_AQ
- Attachment_AX
- Non-Jurisdictional_Facilities
- Network_Upgrades
- Short_Circuit_Analysis
- Delivery_Points
- Transmission_System
- Affected_System_Studies
- NITS_Agreement
- SPP_OATT
- Queue_Management
- Model_Development
- ITP_Manual

## 8. Items That May Need Follow-Up

1. **Placeholder Content**: Section contains "(Placeholder)" notation indicating incomplete content requiring future development
2. **Financial Responsibility Clarification**: Multiple options given for who bears financial responsibility for studies (Transmission Owner vs. Interconnection Customer) - may need policy clarification
3. **Study Timeline Specifications**: References made to "study timelines" and "study timeframe requirements" but specific timeframes not provided in this chunk
4. **HILLGA Queue Processing Rules**: Electrically-Equivalent determination criteria not fully defined in this section - may be referenced elsewhere
5. **Aggregation Criteria**: "Relative proximity" for request aggregation is not specifically defined - may need clearer guidelines
6. **Model Update Procedures**: Process for incorporating "affected system generation with GIAs" needs coordination with external entities
7. **NITS Agreement Update Process**: Customer notification responsibility mentioned but detailed procedure not specified
8. **Coordination with BP 7060**: Referenced for "standardized project timelines" but details not included in this chunk
9. **Incomplete Sentence**: Text ends mid-sentence regarding Provisional Load Process Study aggregation
10. **Cross-Reference Verification**: Multiple cross-references to Attachment BB sections should be verified for consistency

---

# Chunk 25 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary
This document excerpt (chunk 25 of 27) from SPP's RR696 Comments dated August 14, 2025, contains technical specifications for transmission service processes and resource adequacy requirements. The content primarily addresses: (1) procedures for evaluating delivery point changes through Attachment AQ and AX processes, (2) requirements for demand response programs and behind-the-meter generation under Business Practice 8100, (3) load forecasting procedures for Integrated Transmission Planning, and (4) revenue requirement tables for transmission owners. The document establishes criteria for determining which evaluation process applies based on whether transmission customers have sufficient designated resources to serve increased loads.

## 2. Key Topics

- **Attachment AQ Process**: Evaluation criteria for delivery point additions, modifications, and retirements when transmission customers have sufficient existing designated resources
- **Attachment AX Process**: Evaluation criteria for delivery point changes when transmission customers lack sufficient designated resources
- **Resource Adequacy (Business Practice 8100)**: Requirements for demand response programs and behind-the-meter generation (<10 MW)
- **Demand Response Program Classifications**: Differentiation between dispatchable/controllable and non-dispatchable/non-controllable programs
- **Integrated Transmission Planning (ITP)**: Load forecast requirements and persistent operational needs assessment
- **Revenue Requirements**: Allocation tables for through and out transactions across SPP transmission owners
- **Network Upgrade Aggregation**: Transmission Provider's ability to aggregate multiple study requests for comprehensive system analysis

## 3. Decisions or Actions

- Transmission Provider must propose aggregated study approaches to all parties and evaluate feedback before making aggregation decisions
- Non-controllable and non-dispatchable demand response programs may only be considered in LRE's forecasted Peak Demand
- Each LRE must report projected MW level of Peak Demand reduction as an informational line item in the Workbook
- Peak Demand forecasts must maintain 50-50 probability (50% chance of being too high, 50% chance of being too low)
- Seasonal demand reduction determination requires historical hourly demand data and may be augmented by system surveys
- SPP may propose additional operational needs to ESWG and TWG for review and endorsement

## 4. Important Dates

- **August 14, 2025**: Date of SPP Comments document (RR696)
- No other specific deadlines or dates mentioned in this excerpt

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)**: Transmission Provider
- **ESWG**: Engineering and System Working Group
- **TWG**: Transmission Working Group
- **LRE (Load Responsible Entity)**: Multiple references
- **Market Participants**: General reference

### Transmission Owners (Table 1 & 2):
- AEP West Transmission Companies (AEP Oklahoma Transmission Company, Inc. and AEP Southwestern Transmission Company, Inc.)
- American Electric Power (Public Service Company of Oklahoma and Southwestern Electric Power Company)
- Arkansas Electric Cooperative Corporation-1 and -7
- City Utilities of Springfield
- Corn Belt Power Cooperative
- Empire District Electric Company
- Evergy Kansas Central, Inc., Evergy Kansas South, Inc., Evergy Metro, Inc., Evergy Missouri West, Inc.
- Grand River Dam Authority
- Kansas City Board of Public Utilities
- Lincoln Electric System
- Midwest Energy, Inc.
- Missouri Joint Municipal Electric Utility Commission
- Nebraska Public Power District
- Oklahoma Gas and Electric
- Omaha Public Power District
- Southwestern Power Administration
- Southwestern Public Service Company
- Sunflower Electric Power Corporation
- Tri-State G&T Association
- Western Farmers Electric Cooperative
- Western-UGP

### People:
None specifically mentioned

## 6. Links or References

### Referenced Documents/Processes:
- **Attachment AQ**: Process for delivery point changes with sufficient resources
- **Attachment AX**: Process for delivery point additions without sufficient resources
- **Attachment AA**: Resource Adequacy Requirement and Winter Season Obligation
- **Business Practice 8100**: Resource Adequacy requirements for Demand Response Programs and Behind-The-Meter Generation
- **ITP Manual**: Integrated Transmission Planning Manual (sections 2.1.3 and 4.4)
- **Model Development Procedure Manual**: Load forecast submission process
- **RRR File**: Revenue Requirements file (referenced in both tables)
- **Schedule 1 Point-to-Point (PTP) Revenue Credit**: Referenced in Table 2

### External References:
- Section II.3 (referenced for American Electric Power)
- Workbook (for reporting Peak Demand reduction)

## 7. Suggested Tags

- Transmission Planning
- Delivery Points
- Resource Adequacy
- Demand Response
- Behind-the-Meter Generation
- Attachment AQ
- Attachment AX
- Load Forecasting
- Network Upgrades
- Revenue Requirements
- SPP Tariff
- Business Practice 8100
- ITP Manual
- Load Responsible Entity
- Peak Demand
- Transmission Service
- ESWG
- TWG
- Point-to-Point Service

## 8. Items That May Need Follow-Up

1. **Aggregated Study Approach**: Clarification needed on specific criteria the Transmission Provider uses to determine when aggregation is "appropriate" and how party feedback is weighted in the decision-making process

2. **50-50 Forecast Methodology**: Verification of how LREs validate that their Peak Demand forecasts maintain the required 50% probability threshold after incorporating non-controllable demand response programs

3. **Historical Data Requirements**: Specific timeframe for "sufficient" historical hourly demand data needed to establish demand reduction associated with demand response programs

4. **Revenue Requirements File**: The actual RRR File referenced in Tables 1 and 2 needs to be located and reviewed for complete revenue requirement figures

5. **Transfer of Delivery Points**: Clarification on the distinction between transfers that require evaluation (Attachment AX) versus those that don't (Attachment AQ)

6. **Behind-the-Meter Generation Threshold**: Justification for the 10 MW threshold distinguishing treatment of behind-the-meter generation

7. **Additional Operational Needs**: Process and timeline for SPP's proposals to ESWG and TWG regarding operational issues not meeting standard criteria thresholds

8. **Non-SPP Delivery Points**: Evaluation process for delivery points "not physically interconnected with the SPP Transmission System" requires further clarification regarding interface transmission service status

9. **Local Delivery Facilities**: Definition and scope of what constitutes "Local Delivery Facilities" versus other transmission facilities

10. **Schedule 1 PTP Revenue Credits**: Understanding why some transmission owners show "N/A" while others show "$0" in Table 2

---

# Chunk 26 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary
This document appears to be chunk 26 of 27 from SPP (Southwest Power Pool) comments on Revision Request 696, dated August 14, 2025. The content consists primarily of detailed financial allocation tables showing Annual Transmission Revenue Requirements (ATRR) across multiple zones and transmission entities within the SPP region. The tables outline zonal ATRRs, regional ATRRs, and various reallocation mechanisms including Base Plan, Balanced Portfolio, and payments to Upgrade Sponsors.

## 2. Key Topics
- **Annual Transmission Revenue Requirements (ATRR)** allocation and reallocation methodology
- **Zonal ATRR** assignments across 19+ zones within SPP territory
- **Base Plan vs. Balanced Portfolio** revenue requirement structures
- **Region-wide ATRR** calculations and components
- **Interregional Planning** cost allocations (SPP and Other regions)
- **Upgrade Sponsor** payment mechanisms
- **JTIQ ATRR Balance** (Joint Transmission Integration Queue)
- **Network Integration Transmission Service (NITS)** costs
- **Historical transition** (before/after June 19, 2010)

## 3. Decisions or Actions
- Specific ATRR amounts allocated to certain entities:
  - East Texas Electric Cooperative, Inc.: $14,567,983
  - Deep East Texas Electric Cooperative, Inc.: $2,576,698
  - Oklahoma Municipal Power Authority (Zone 1e): $768,624
  - Coffeyville Municipal Light and Power: $391,790
  - City of Independence, Missouri: $7,043,930
  - Oklahoma Municipal Power Authority (Zone 7b): $368,501
  - Southwestern Power Administration (Non-Federal): $15,533,800
  - Central Nebraska Public Power and Irrigation District: $327,891
- Majority of detailed figures referenced as "See Att. H tab, posted RRR File"
- Multiple zones "Reserved for Future Use" (Zones 1c, 11b, 15)

## 4. Important Dates
- **June 19, 2010** - Critical transition date for Base Plan Zonal ATRR calculations (appears as a column distinction in Table 3 and row distinctions in Tables 4 and 5)
- **August 14, 2025** - Document date (from filename: RR696 SPP Comments 20250814)

## 5. Organizations and People Mentioned

**Transmission Owners/Operators (19 Primary Zones):**
- American Electric Power - West (with multiple sub-zones)
- Kansas City Board of Public Utilities
- City Utilities of Springfield, Missouri
- Empire District Electric Company
- Grand River Dam Authority
- Evergy (Metro, Missouri West, Kansas Central/South)
- Oklahoma Gas and Electric
- Midwest Energy, Inc.
- Southwestern Power Administration
- Southwestern Public Service Company
- Sunflower Electric Power Corporation
- Western Farmers Electric Cooperative
- Lincoln Electric System
- Nebraska Public Power District
- Omaha Public Power District
- Upper Missouri Zone (multiple members)

**Sub-Zone Entities:**
- Public Service Company of Oklahoma
- Southwestern Electric Power Company
- East Texas Electric Cooperative, Inc.
- Deep East Texas Electric Cooperative, Inc.
- Oklahoma Municipal Power Authority
- AEP Oklahoma Transmission Company, Inc
- AEP Southwestern Transmission Company, Inc
- Coffeyville Municipal Light and Power
- Arkansas Electric Cooperative Corporation
- Transource Oklahoma, LLC / Transource Missouri, LLC
- City of Independence, Missouri
- People's Electric Cooperative
- NextEra Energy Transmission Southwest, LLC
- South Central MCN LLC
- Missouri Joint Municipal Electric Utility Commission
- Lea County Electric Cooperative, Inc.
- ITC Great Plains, LLC
- Prairie Wind Transmission, LLC
- Kansas Power Pool
- Central Nebraska Public Power and Irrigation District
- Tri-State G&T Association
- Basin Electric Power Cooperative
- Heartland Consumers Power District
- Missouri River Energy Services (with 8 municipal sub-members)
- East River Electric Power Cooperative, Inc.
- Corn Belt Power Cooperative
- NorthWestern Energy Public Service Corporation
- Northwest Iowa Power Cooperative
- Harlan Municipal Utilities
- Central Power Electric Cooperative
- Mountrail-Williams Electric Cooperative
- Mor-Gran-Sou Electric Cooperative, Inc.
- Roughrider Electric Cooperative, Inc.
- L and O Power Cooperative

## 6. Links or References
- **Attachment H tab, posted RRR File** - Referenced extensively throughout all tables for detailed ATRR values
- **Section II.2** - Referenced for AEP West sub-zone structure
- **RR696** (Revision Request 696) - The subject document
- **Column (6), Section I, Table 1** - Referenced in Tables 4 and 5 for reallocation calculations

## 7. Suggested Tags
- ATRR
- Transmission Cost Allocation
- SPP
- Southwest Power Pool
- Revision Request 696
- Zonal Revenue Requirements
- Base Plan
- Balanced Portfolio
- Upgrade Sponsors
- Interregional Planning
- NITS
- Tariff Amendment
- Regional Transmission Organization
- Cost Recovery

## 8. Items That May Need Follow-Up

1. **Missing Detailed Values**: Most ATRR amounts reference "See Att. H tab, posted RRR File" - requires access to Attachment H for complete financial picture

2. **Reserved Zones**: Zones 1c, 11b, and 15 are marked "Reserved for Future Use" - may indicate planned expansion or reorganization

3. **June 19, 2010 Transition**: The significance of this date and methodology changes should be clarified for complete understanding

4. **JTIQ ATRR Balance**: Table 5 includes this item (line 9) - requires explanation of Joint Transmission Integration Queue balance treatment

5. **Interregional Cost Allocation**: Tables 4 and 5 reference "Other Interregional Planning Region ATRR" and "Other transmission provider ATRR" - specific regions/providers not identified

6. **Context for RR696**: Being chunk 26 of 27, review of earlier chunks needed to understand the full scope of the revision request and SPP's position

7. **Effective Dates**: While document is dated 2025, implementation timing for these allocations is not specified

8. **NextEra Energy Transmission Southwest, LLC**: Appears in both Zones 7e and 14e with references to both columns (4) and (5), suggesting special treatment

---

# Chunk 27 Analysis

# Regulatory Content Analysis Report
**Source: RR696 SPP Comments 20250814.docx.txt - chunk 27 of 27**

---

## 1. Executive Summary

This document chunk contains technical regulatory tables from what appears to be a Southwest Power Pool (SPP) tariff or operational document. The content includes: (1) a comprehensive listing of transmission zones and owners with their associated credits, (2) detailed transmission service request timelines and requirements for various service types (Long-Term Firm, Short-Term Firm, Non-Firm), and (3) a glossary of technical acronyms used in SPP operations. This appears to be reference material defining operational procedures, jurisdictional boundaries, and standardized terms for transmission service administration.

---

## 2. Key Topics

- **Transmission Zone Structure**: 19 primary zones covering multiple states (Oklahoma, Texas, Kansas, Missouri, Nebraska, South Dakota, Iowa, North Dakota) with numerous sub-zones
- **ATRR Credits**: Zonal Annual Transmission Revenue Requirement credits (mostly N/A or $0)
- **Schedule 11 Credits**: Limited to specific entities, mostly $0 where applicable
- **Transmission Service Types**: 
  - Long-Term Firm (1 year or more)
  - Short-Term Firm (daily to monthly)
  - Non-Firm (hourly to monthly)
  - Next Hour Market
- **Service Request Timelines**: Detailed scheduling windows ranging from 20 minutes to 120 days depending on service type
- **Energy Scheduling Changes**: Standardized cutoff times (typically 12:00 day prior for firm, 15:00 day prior for non-firm)
- **Technical Acronyms**: Comprehensive list including NERC, FERC, GIA, OATT, NRIS, ERIS, and operational terms

---

## 3. Decisions or Actions

**No explicit decisions or action items are present in this chunk.** The content is entirely reference material consisting of:
- Established zone designations and credit allocations
- Standardized operational procedures already in effect
- Defined terminology for ongoing use

This appears to be the final reference section of a larger regulatory document.

---

## 4. Important Dates

### Operational Timing Requirements (Standardized):

**Long-Term Firm Service:**
- Request window: 90 days prior to service start
- Response time: 10 days from application
- Customer response: 3 days

**Short-Term Firm Service:**
- Monthly: 8-31 days prior request window
- Weekly: 2-8 days prior request window
- Daily: 10:00 day prior to 3 days prior
- Response time: 24 hours
- Study periods: 30-60 days

**Non-Firm Service:**
- Monthly: 3 days to 60 days prior
- Daily: 10:00 day prior to 2 days prior
- Hourly: 30 minutes to 10:00 day prior
- Next Hour Market: 20 minutes prior

**Universal Energy Scheduling Deadlines:**
- Firm service changes: 12:00 day prior
- Non-firm service changes: 15:00 day prior
- All services: 20 minutes prior to start of schedule

**Note:** No specific calendar dates are mentioned; all timing is relative to service start dates.

---

## 5. Organizations and People Mentioned

### **Transmission Owners/Organizations (by Zone):**

**Zone 1 - American Electric Power-West:**
- Public Service Company of Oklahoma
- Southwestern Electric Power Company
- East Texas Electric Cooperative, Inc.
- Deep East Texas Electric Cooperative, Inc.
- Oklahoma Municipal Power Authority
- AEP Oklahoma Transmission Company, Inc.
- AEP Southwestern Transmission Company, Inc.
- Coffeyville Municipal Light and Power (CMLP)
- Arkansas Electric Cooperative Corporation (AECC)
- Transource Oklahoma, LLC

**Other Major Entities:**
- Kansas City Board of Public Utilities (Zone 2)
- City Utilities of Springfield, Missouri (Zone 3)
- Empire District Electric Company (Zone 4)
- Grand River Dam Authority (Zone 5)
- Evergy Metro, Inc. (Zone 6)
- Oklahoma Gas and Electric (Zone 7)
- Midwest Energy, Inc. (Zone 8)
- Evergy Missouri West, Inc. (Zone 9)
- Southwestern Power Administration (Zone 10)
- Southwestern Public Service Company (Zone 11)
- Sunflower Electric Power Corporation (Zone 12)
- Western Farmers Electric Cooperative (Zone 13)
- Evergy Kansas Central/South (Zone 14)
- Lincoln Electric System (Zone 16)
- Nebraska Public Power District (Zone 17)
- Omaha Public Power District (Zone 18)

**Zone 19 - Upper Missouri Zone:**
- Western-UGP
- Basin Electric Power Cooperative
- Heartland Consumers Power District
- Missouri River Energy Services
- East River Electric Power Cooperative
- Corn Belt Power Cooperative
- NorthWestern Energy Public Service Corporation
- Multiple municipal utilities and cooperatives

**Supporting Organizations:**
- ITC Great Plains, LLC
- Prairie Wind Transmission, LLC
- NextEra Energy Transmission Southwest, LLC
- Transource Missouri, LLC
- South Central MCN LLC
- Tri-State G&T Association

**Regulatory Bodies (from acronyms):**
- Federal Energy Regulatory Commission (FERC)
- North American Electric Reliability Corporation (NERC)
- Southwest Power Pool (SPP)

**No individual people are mentioned by name.**

---

## 6. Links or References

### **Internal Document References:**
- Section II.3 (regarding AEP Public Service Company structure)
- Section II of Attachment Z1 (open season specifications)
- Sections 19.4 and 32.4 (schedule specifications)
- Section 30.2.2 (expedited designation process)
- Generator Interconnection Procedures (GIP)
- Open Access Transmission Tariff (OATT)
- Integrated Transmission Planning (ITP)

### **External Standards Referenced:**
- NERC Transmission System Planning Performance Requirement (TPL)
- Power System Simulator for Engineering (PSS/E) - industry standard software

### **Regulatory Framework:**
- Schedule 11 (credit structure)
- Attachment Z1 (transmission service procedures)

**No web URLs or external hyperlinks are present in this content.**

---

## 7. Suggested Tags

**Primary Tags:**
- SPP_Tariff
- Transmission_Zones
- OATT
- Service_Request_Procedures
- Southwest_Power_Pool

**Operational Tags:**
- Long_Term_Firm_Service
- Short_Term_Firm_Service
- Non_Firm_Service
- Energy_Scheduling
- ATRR_Credits
- Schedule_11

**Geographic Tags:**
- Oklahoma
- Kansas
- Missouri
- Nebraska
- Texas
- Iowa
- South_Dakota
- North_Dakota

**Technical Tags:**
- Generator_Interconnection
- Transmission_Service
- Network_Resource_Interconnection
- Energy_Resource_Interconnection
- Variable_Energy_Resource

**Organizational Tags:**
- AEP
- Evergy
- SWPA
- Basin_Electric
- AECC

**Regulatory Tags:**
- FERC_Tariff
- NERC_Standards
- Transmission_Rights
- Utility_Regulation

---

## 8. Items That May Need Follow-Up

### **Incomplete Information:**
1. **Reserved Zones**: Multiple zones marked "Reserved for Future Use" (1c, 1b [Zone 11], Zone 15) - may require monitoring for future assignments
2. **Empty Tables**: Tables 11-46 are referenced but contain no content in this chunk - these may need to be cross-referenced with other document sections

### **Clarifications Needed:**
3. **"N/A" Credits**: The vast majority of transmission owners show "N/A" for ATRR and Schedule 11 credits - clarification on what determines applicability may be needed
4. **Section II.3 Reference**: Zone 1a references "See Section II.3" - this cross-reference should be verified for completeness
5. **Footnote References**: Tables include footnote markers (1/, 2/, 3/, 4/, 5/, 7/, 8/, 9/) but the actual footnotes are not visible