# Final Combined Report

# Executive Summary

This analysis covers the complete SPP Model Development Procedure Manual (HILL Edits version), a comprehensive technical document establishing data requirements and procedures for transmission system modeling across the Southwest Power Pool region. The manual defines responsibilities for Transmission Owners, Generator Owners, Balancing Authorities, and other NERC-registered entities to submit steady-state, dynamic, short circuit, and geomagnetic disturbance modeling data. Version 9.0 (2025) applies to the 2026 Series MDAG Model Build and emphasizes data quality assurance, stakeholder coordination, and compliance with NERC MOD-032-1 standards. The document provides detailed technical specifications for PSS®E software modeling, seasonal load forecasting methodologies (including 50/50 probability forecasts), renewable energy resource representation (FYAE methodology), and equipment modeling standards for voltages 60kV and above.

---

# Key Topics

## Model Development Framework
- **MDAG (Model Development Advisory Group)** processes for creating base transmission system models
- **Annual model development cycle** with near-term (Years 1-5) and longer-term (Years 6-10) planning horizons
- **Six seasonal models**: Summer On-Peak, Winter On-Peak, Spring On-Peak, Fall On-Peak, Spring Light Load, Summer Shoulder Off-Peak
- **Compliance alignment** with NERC MOD-032-1 and SPP OATT requirements

## Data Submission Requirements
- **MOD (Model On Demand) database** and **Engineering Data Submission Tool (EDST)** for data management
- **PSS®E software platform** as standard modeling tool (version 34+ for node-breaker modeling)
- **Data Owner vs. Data Submitter** roles with delegation via Letter of Notice
- **Steady-state, dynamic, and short circuit** data submission protocols
- **Tie line coordination** and substation node-breaker modeling for EHV facilities

## Technical Modeling Standards
- **Transformer specifications**: ULTC/NLTC requirements, vector groups, tap positions, voltage regulation (minimum 0.0125 p.u. band)
- **Generator modeling**: PMAX/PMIN/QMAX/QMIN limits, MOD-025-2 compliance, station service representation
- **Renewable energy**: Figure 2 equivalent representation mandatory; FYAE methodology for wind/solar dispatch
- **Phase Shifting Transformers (PSTs)**: Operational MW limits, phase angle ranges, two-winding representation
- **Equipment scope**: BES facilities and equipment 60kV and above subject to SPP OATT

## Load Forecasting & Resource Modeling
- **50/50 load forecast methodology** (50% probability of exceeding forecast, non-coincident to regional peak)
- **Demand Side Management (DSM)** treatment: exclude controllable, include non-controllable
- **Distributed Energy Resources (DER)** and **Energy Storage Resources (ESR)** separate from load
- **Battery resource modeling**: Different approaches for on-peak, off-peak, and light load models
- **Point of Interconnection (POI)** injection limits for shared interconnection points

## Quality Assurance & Compliance
- **DocuCode automated validation** and **ACCC summary reviews**
- **13 identified causes of model non-convergence** with resolution strategies
- **Exception vs. Overridden status** for data quality issues
- **GMD/GIC modeling** with USGS earth conductivity models and TPL-007-3 compliance
- **SSAE compliance** for Reactive Matrix (MW-Mile) calculations

---

# Decisions or Actions

## Mandatory Requirements

### Data Submission
- All Data Owners **shall submit** modeling data for existing and future equipment annually
- Data **must be submitted** via SPP MOD Web Portal in PSS®E compatible format
- Node-breaker modeling information **shall be submitted** for all EHV substations within SPP footprint
- Substation names **must include** "SPP_" prefix unique to Eastern Interconnection
- All transmission elements comprising flowgates **must be included** in submitted data

### Modeling Standards
- Wind and solar facilities **must use** Figure 2 equivalent representation (not Figure 1 detailed)
- Generator PMAX **shall be modeled** based on gross seasonal maximum capability
- Station Service and Auxiliary loads **shall be represented** in normal plant configuration
- Emergency ratings **must never be less than** normal ratings
- Minimum voltage band limit difference **must not be less than** 0.025 p.u. for switched shunt devices (0.0125 p.u. absolute minimum)
- Transformer tap positions **must be specified** as discrete values (use "99" for untapped windings)

### Data Quality
- All CNTB errors **shall be corrected** (with documented exceptions)
- Transmission lines and transformers 69 kV and above **shall not have overloads** above 100% of RATE1 in base cases (10-year cases excepted)
- Islanded buses **shall not be modeled**
- Actual interchange **must be within** 25 MW of specified desired interchange value
- Unacceptable model data **shall be addressed** in each model pass and **corrected prior to** MDAG approval

### Coordination & Approval
- Data Owners **must designate** Data Submitters with written notification (Letter of Notice or contractual agreement)
- Data Owners' submitted data **shall not modify** another Data Owner's data without explicit consent
- Bilateral transactions **must be coordinated** with all parties prior to submission
- Generator owners **must submit** retirement notification to SPP no less than one year from expected retirement date (per OATT Attachment AB, Section 2)

### Renewable Energy & Batteries
- Individual renewable plants **must have** data points meeting or exceeding 25% of initial seasonal system load hours; otherwise state averages used
- Energy storage dispatch **must not exceed** rated output sustainable for minimum one (1) hour
- Solar modeled at **zero MW for light load** cases regardless of transmission service amount

## Prohibited Practices
- Do **not use** voltage band limit differences less than 0.0125 p.u. for ULTC transformers
- Do **not use** MATLAB/SIMULINK user models (licensing restrictions)
- Do **not create** pseudo-tie modeling with fictitious topology
- Do **not include** purely conjectural/speculative facilities
- Do **not use** fictitious generators for load netting
- Do **not delete and re-add** equipment; use modifications instead
- Do **not convert** resistances to per-unit Ohms; retain actual Ohmic quantities
- Do **not enter all loads** into GMD Loads sheet—only EHV/HV exceptions with ground paths

## Recommended Actions
- Data Owners **should coordinate** submissions that may impact another Data Owner's system
- Data Submitters **should submit** late data presentations to MDAG regarding impacts
- Voltage regulation schedules **should not exceed** 1.10 p.u. or below 0.90 p.u.
- Remote regulation **should be avoided** for buses more than one bus away from regulating device
- Best practice **requires synchronizing** short circuit databases across software platforms (CAPE, ASPEN, PSS®E)

---

# Important Dates

## Seasonal Definitions (Table 1)
- **Spring/Light Load**: April 1 – May 31 (Cutoff: May 1)
- **Summer/Summer Shoulder**: June 1 – September 30 (Cutoff: August 1)
- **Fall**: October 1 – November 30 (Cutoff: November 1)
- **Winter**: December 1 – March 31 (Cutoff: February 1 of following year)
- **Example**: 2017 Winter: 12/1/2017 – 3/31/2018 (yyyy = 2017, yyyy+1 = 2018)

## Key Process Dates
- **October 1st**: SPP makes available initial FYAE dispatch values for renewable resources
- **One week before initial update data due**: Deadline for distributing Area Summary Reports
- **One year notice**: Generator retirement notification requirement to SPP (OATT Attachment AB)
- **Within one year of retirement**: Comment required on changeset if retirement date within one year of model build start

## Operational Timeframes
- **20 seconds**: Minimum undisturbed operation simulation time for dynamic models
- **18 months**: Maximum timeframe for converting user-written models to acceptable models after notification
- **Light

---

# Partial Chunk Reports

# Chunk 1 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document is the SPP (Southwest Power Pool) Model Development Procedure Manual, which establishes comprehensive modeling data requirements and reporting procedures for transmission planning. The manual defines responsibilities for various entities within the SPP region to submit steady-state, dynamic, short circuit, and geomagnetic disturbance modeling data. It outlines requirements for creating base transmission system models used for reliability planning, compliance assessments, and various SPP planning processes. The document is designed to ensure consistent data collection from multiple stakeholders including Transmission Owners, Generator Owners, Balancing Authorities, and other NERC-registered entities to support Near-term and Long-term Transmission Planning Horizon analysis.

## 2. Key Topics

- **Model Development Requirements**: Procedures for steady-state, dynamic, and short circuit data submission
- **Data Owner and Submitter Responsibilities**: Clear delineation of who must submit what data
- **Scope of Applicability**: Equipment coverage including BES facilities and equipment 60kV and above
- **MDAG (Model Development Advisory Group)**: Group responsible for SPP Transmission System model development
- **Base Case Development**: Creation of transmission system models representing anticipated conditions
- **Data Quality Assurance**: MDAG model quality assurance procedures
- **Coordination Requirements**: Tie line coordination, substation modeling, and inter-entity data coordination
- **Compliance Framework**: Alignment with NERC MOD-032-1 standard and SPP OATT requirements
- **GMD/GIC Modeling**: Geomagnetic disturbance modeling data requirements
- **Load Forecasting**: On-peak/off-peak models and 50/50 load forecast methodology

## 3. Decisions or Actions

- **Mandatory Data Submission**: Data Owners must submit modeling data for existing and future equipment
- **Data Submitter Designation**: Data Owners may delegate submission responsibilities with written notification to SPP
- **Letter of Notice Requirement**: Contractual agreement or Letter of Notice required when designating a Data Submitter
- **Model Contact List**: Must be completed to reflect Data Owner and Data Submitter responsibilities
- **Consent Requirement**: Data Owners' submitted data shall not modify another Data Owner's data without explicit consent
- **Coordination Encouraged**: Data Owners should coordinate submissions that may impact another Data Owner's system
- **Quality Assurance**: MDAG model quality assurance procedures must be followed
- **Annual Submission**: Transmission system data submitted annually to SPP Planning Coordinator

## 4. Important Dates

- **Annual Models**: Referenced as "Typical Annual Models" but specific dates not provided in this chunk
- **First Data Request**: Schedule for model development sent with first data request
- No specific deadline dates are mentioned in this excerpt (likely contained in subsequent sections or separate documentation on www.spp.org)

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)** - Regional Transmission Organization, Planning Coordinator, Balancing Authority, Transmission Service Provider
- **MDAG (Model Development Advisory Group)** - Responsible for model development
- **MMWG (Markets and Model Working Group)** - Referenced for deliverables
- **NERC (North American Electric Reliability Corporation)** - Regulatory standard-setting body
- **ERO (Electric Reliability Organization)** - Referenced for Interconnection-wide modeling

### Entity Types (not specific companies):
- Planning Coordinators
- Transmission Planners
- Transmission Owners
- Generator Owners
- Balancing Authorities
- Transmission Operators (TOPs)
- Reliability Coordinator (RC)
- Distribution Providers
- Resource Planners
- Network Customers
- Transmission Customers
- Native Load Customers

### Roles:
- **Regional Coordinators** - Position referenced but not detailed in this chunk
- **MMWG Coordinator(s)** - Position referenced but not detailed in this chunk

## 6. Links or References

### External References:
- **www.spp.org** - SPP corporate website for latest modeling requirements, schedules, and MDAG model lists
- **SPP OATT (Open Access Transmission Tariff)** - Governing document for transmission service
- **NERC MOD-032-1** - Data for Power System Modeling and Analysis Reliability Standard

### Internal Document References:
- Appendix I: Master Tie Line File Data Fields
- Appendix II: Utilized Impedance Correction Tables
- Appendix III: Designating MOD-032-1 Data Submittal Assignment
- Appendix IV: SPP Model On Demand (MOD) Matrix
- Appendix V: GMD/GIC Data Collection Template User's Guide
- Appendix VI: 50/50 Load Forecast Example
- Appendix VII: MOD-032-1 Attachment 1
- Appendix VIII: Five-Year Average Enhancement (FYAE) Methodology

### Data Tools Referenced:
- Engineering Data Submission Tool
- Excel Template for Dynamics Data Updates
- Letter of Notice (in appendix)

## 7. Suggested Tags

- Transmission Planning
- Model Development
- Data Requirements
- SPP Compliance
- NERC Standards
- MOD-032-1
- Power System Modeling
- Steady-State Analysis
- Dynamic Modeling
- Short Circuit Analysis
- BES (Bulk Electric System)
- OATT Compliance
- Generator Modeling
- Load Forecasting
- Reliability Planning
- GMD/GIC Modeling
- Transmission Owners
- Data Submission
- Regional Coordination
- Quality Assurance

## 8. Items That May Need Follow-Up

1. **Letter of Notice Submission**: Verify all Data Owners who have delegated responsibilities have submitted required Letters of Notice or contractual agreements to SPP

2. **Model Contact List**: Ensure modeling contact list is current and accurately reflects all Data Owner/Data Submitter relationships

3. **Annual Submission Deadlines**: Obtain specific dates for annual data submissions referenced on www.spp.org

4. **MDAG Case Type Set**: Review complete list of required case types/scenarios (referenced but not detailed in this chunk)

5. **Regional Coordinator Assignments**: Identify who serves as Regional Coordinators and their specific responsibilities

6. **MMWG Coordinator Identification**: Determine current MMWG Coordinator(s)

7. **Data Quality Issues**: Monitor "Troubleshooting" procedures for recurring data quality problems

8. **Small Generating Facilities**: Clarify treatment of facilities near the 2MW threshold for exclusion

9. **External Resource Modeling**: Review detailed requirements for modeling resources outside SPP footprint

10. **Substation Node-Breaker Modeling**: Verify compliance with detailed substation modeling requirements (sections 61-63)

11. **Mutual Agreement Verification**: Confirm all Data Owner/Data Submitter designations show mutual written agreement

12. **Equipment Classification**: Ensure all equipment 60kV and above subject to SPP OATT is properly identified and modeled

13. **First-Time Submitters**: Identify any new entities that may need guidance on submission procedures

14. **Website Access**: Verify all applicable Data Owners/Submitters have access to required documentation on www.spp.org

15. **Coordination Protocols**: Establish clear processes for Data Owners to coordinate submissions affecting other Data Owners' systems

---

# Chunk 2 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document is a section from the SPP (Southwest Power Pool) Model Development Procedure Manual that outlines the responsibilities, processes, and requirements for developing transmission system models. It details data submission requirements for network resources, establishes accountability frameworks for participating entities, and defines communication protocols between SPP as Planning Coordinator and member entities. The document emphasizes the importance of timely and accurate data submission, establishes best practices for model-building processes, and outlines confidentiality requirements and model distribution guidelines. It also specifies technical requirements including PSS®E software usage and the MOD Web Portal for data submission.

## 2. Key Topics

- **Data Submission Requirements**: Network Load, firm power purchases/sales, transmission equipment specifications
- **Accountability Framework**: Roles and responsibilities of SPP, MDAG (Model Development Advisory Group), Data Owners, and Data Submitters
- **Model-Building Best Practices**: Timeline adherence, data accuracy, stakeholder participation
- **Communication Protocols**: Two-way communication between SPP, Transmission Planners, and Applicable Entities
- **Technical Standards**: PSS®E and MOD software requirements and data format specifications
- **Model Types**: Annual models including near-term (years 1-5) and longer-term (years 6-10) planning horizons
- **Confidentiality and Proprietorship**: Model access rights and confidentiality agreements
- **MMWG Deliverables**: Requirements for Regional Coordinators including steady-state and dynamics cases

## 3. Decisions or Actions

- **Data Owner Responsibilities**: Establish contact for model data coordination; submit data ahead of deadlines; perform data integrity reviews; participate in MDAG conferences
- **Late Data Submission Protocol**: Data Owners seeking to submit late data must present to MDAG regarding impacts on models and schedule
- **Non-Participation Reporting**: MDAG may report non-participating entities to TWG/MOPC
- **Lessons-Learned Requirement**: SPP staff and MDAG members will prepare lessons-learned and best practice recommendations after each model-building cycle
- **Model Progression Assessment**: Assessment of model-building progression and participation during each model iteration
- **Data Format Compliance**: All data must be submitted via SPP MOD Web Portal in PSS®E compatible format
- **External Model Release**: Base case models may be released to government agencies under FERC Form 715

## 4. Important Dates

- **Annual Model Development Timeline**: Based on calendar year MDAG powerflow models are completed
- **Year One Definition**: Annual + 1 for year-out seasonal models (per NERC Glossary of Terms)
- **Model Types Timeline**:
  - Near-term planning horizon: Case types 1-15 (Years 1-5)
  - Longer-term planning horizon: Case types 16-17 (Years 6-10)
- **Note**: Specific deadlines referenced but not explicitly stated in this excerpt; schedule available at outset of each model-building period

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)** - Planning Coordinator
- **MDAG (Model Development Advisory Group)** - Primary model-building coordination body
- **TWG (Transmission Working Group)**
- **MOPC** (specific role not defined in excerpt)
- **NERC** - Regulatory authority (TPL reliability standards, MOD-032-1)
- **ERAG MMWG (MMWG)** - Multi-regional coordination group
- **Power Technologies Incorporated** - PSS®E software provider
- **FERC** - Federal Energy Regulatory Commission (Form 715)

### Roles Referenced:
- Planning Coordinator
- Transmission Planner(s)
- Data Submitter
- Data Owner
- Applicable Entities
- Network Load registrants
- Market Participants
- Regional Coordinators
- MMWG Coordinator(s)

## 6. Links or References

### Websites:
- **spp.org** - SPP corporate website
- **www.spp.org** - Schedule and MDAG models location

### Email Contacts:
- **SPPEngineeringModeling@spp.org** - General modeling questions and data submission

### Systems/Portals:
- **SPP Models On Demand (MOD) Web Portal** - Data submission platform
- **GlobalScape** - SPP MDAG File Sharing Site (preferred submission method)
- **Request Management System** - For SPP Map/Model requests

### Referenced Documents/Standards:
- **NERC MOD-032-1 Requirement R3** - Data request and clarification requirements
- **NERC TPL reliability standards** - Model development framework
- **NERC Glossary of Terms** - Year One definition
- **SPP OATT (Open Access Transmission Tariff)** - Network Load requirements
- **FERC Form 715** - External system model release requirements
- **SPP Confidentiality Agreement** - Required for public model access
- **SPP Maps & Models FAQ** - Resource for questions
- **Profile Submission form** - For non-PSS®E users

### Request Templates:
- Request Template: Submit Information
- Request Type: Submission
- Subtype 1: Map/Model Order
- Subtype 2: Map Order

## 7. Suggested Tags

- Model Development
- Transmission Planning
- Data Submission Requirements
- MDAG
- SPP Planning Coordinator
- PSS®E Software
- NERC Compliance
- MOD-032-1
- Network Resources
- Power Flow Models
- Dynamics Models
- Short Circuit Models
- Data Accountability
- Confidentiality Requirements
- MMWG Coordination
- Transmission System Modeling
- Regulatory Compliance
- Best Practices
- Stakeholder Participation

## 8. Items That May Need Follow-Up

1. **Schedule Clarification**: Obtain specific deadlines and milestones from the jointly developed schedule referenced but not detailed in this excerpt

2. **Software Version Requirements**: Confirm current MOD and PSS®E versions specified by SPP for compatibility

3. **Non-Participating Entity Reporting**: Clarify process and consequences when MDAG reports entities to TWG/MOPC

4. **Lessons-Learned Reports**: Review previous lessons-learned assessments to identify recurring issues or improvement trends

5. **Technical Concerns Process**: Understand detailed workflow for MOD-032-1 Requirement R3 when additional data or clarification is requested

6. **Late Submission Impact**: Establish clear criteria for when late submissions require MDAG presentation versus standard acceptance

7. **Annual Training Details**: Verify timing and content of annual training regarding version changes and data format updates

8. **Profile Submission Form**: Obtain current Profile Submission form for non-PSS®E users

9. **Confidentiality Agreement**: Review current SPP Confidentiality Agreement requirements for public model access

10. **MMWG Deliverable Specifications**: Clarify complete requirements for Regional Coordinators, including specific format requirements for contingency files and data dictionaries

11. **External System Equivalencing**: Review disclaimer requirements for equivalenced external models released to government agencies

12. **Case Title Format Standards**: Confirm case title formatting conventions (e.g., *04SP, *04FA) for all model types

13. **Data Integrity Review Process**: Establish standardized procedures for performing data integrity reviews during each model-building pass

14. **Multi-Owner Coordination**: Develop protocols for data submissions that impact multiple Data Owners' systems

---

# Chunk 3 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document is a section from the SPP (Southwest Power Pool) Model Development Procedure Manual that outlines requirements and procedures for steady-state power system modeling. It details data submission requirements through the Model On Demand (MOD) database and Engineering Data Submission Tool (EDST), load forecasting methodologies requiring 50/50 probability forecasts, and seasonal model development processes. The document establishes standardized procedures for Data Submitters to maintain current transmission system models used for reliability analysis and planning studies in accordance with OATT (Open Access Transmission Tariff) and Planning Criteria requirements.

## 2. Key Topics

- **Model Development Coordination**: MMWG Coordinator responsibilities for posting steady-state and dynamics cases to ERAG Web Site
- **Data Management Systems**: MOD (Model On Demand) database with three components - Base Case, Projects, and Profiles
- **Engineering Data Submission Tool (EDST)**: Contains both informational and modeling data including:
  - Transactions (firm and non-firm reservations)
  - Generator data
  - SPP Modeling Assignments
  - Load Details
  - Bus Details
  - Interregional Ties
  - Outages
- **Load Forecasting Requirements**: 
  - 50/50 load forecast methodology (50% probability of exceeding forecast)
  - Non-coincident to SPP regional peak
  - Treatment of Demand Side Management (DSM)
  - Distributed Energy Resources (DER) and Energy Storage Resources (ESR) modeling
- **Seasonal Models**: Six models developed - Summer On-Peak, Winter On-Peak, Spring On-Peak, Fall On-Peak, Spring Light Load, and Summer Shoulder Off-Peak
- **Compliance Requirements**: Adherence to MDAG procedures and schedules

## 3. Decisions or Actions

- **Data Submitter Responsibilities**:
  - Keep MOD data current for each pass during MDAG model build
  - Keep EDST informational and modeling data current
  - Coordinate transactions and interregional ties before submission to SPP
  - Annotate and model known outages with appropriate effective dates
  - Submit load forecasts based on 50/50 methodology
  - Model non-scalable loads appropriately in PSS®E
  - Include loads completing Attachment AQ process by load submittal deadline
  - Assign appropriate type and status to load projects in MOD

- **MMWG Coordinator Actions**:
  - Post steady-state cases to ERAG Web Site
  - Post dynamics case input data and documentation
  - Post conversion files and complete databases

- **Load Modeling Requirements**:
  - Do NOT reduce load forecasts for controllable DSM
  - Do reduce load forecasts for non-controllable DSM
  - Model DER and ESR separately from load quantities
  - Submit pseudo-tied load forecasts to both SPP and embedded entity

- **SPP May Reject**: MOD projects or PSS®E idevs attempting to modify delivery points not studied through Attachment AQ or applicable SPP process

## 4. Important Dates

- **Table 1 Reference**: Season Date Range and Cutoff Dates mentioned but specific dates not fully detailed in this excerpt
- **Example provided**: 2017 Winter: 12/1/2017 – 3/31/2018 (yyyy = 2017, yyyy+1 = 2018)
- **Load Submittal Deadline**: Referenced but specific date not provided in this excerpt (tied to MDAG model build schedule)

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP** (Southwest Power Pool) - Primary organization
- **MDAG** (Model Development Advisory Group)
- **MMWG** (Multi-regional Modeling Working Group)
- **ERAG** (Eastern Reliability Assessment Group)
- **Data Submitters** - Member organizations submitting data
- **Data Owners** - Entities owning transmission/load assets
- **Municipal utilities** - Referenced as load owners

**Roles/Positions:**
- MMWG Coordinator(s)
- Model builders

**Contact Information Referenced:**
- MDAG Contact List location: SPP's GlobalScape under Modeling (CEII, RSD) → SPP Modeling Contacts → 3. Final Modeling Contacts

## 6. Links or References

**Websites:**
- **spp.org** - Main SPP website for documents and SPP Glossary
- **SPP.org** - MDAG documents location
- **ERAG Web Site** - For posting cases

**Internal Document References:**
- SPP Model Development Procedure Manual_HILL Edits.docx
- MDAG Model Development Procedure Manual
- MDAG Power flow, Short Circuit, and Dynamic model schedule and list
- Data Submittal Forms (separate document)
- MDAG Procedure for late or no data submittal (FUTURE)
- Appendix VIII - For transaction information and 50/50 load forecast derivation example
- Attachment AQ of the OATT - Delivery point facilities changes

**Document Locations:**
- Model Development Advisory Group documents section on SPP website
- GlobalScape: Modeling (CEII, RSD) → SPP Modeling Contacts
- SPP Glossary on SPP website

**Technical References:**
- PSS®E (Power System Simulator for Engineering) - modeling software
- DYRE format - Dynamics input data format
- IDEV format - Contingency events format
- RAWD case file format
- CONL file format
- FLECS code - For user defined models
- IPLAN or PYTHON programs

## 7. Suggested Tags

- Model Development
- Power System Planning
- Load Forecasting
- Steady-State Modeling
- Data Submission
- MDAG
- MMWG
- MOD Database
- EDST
- 50/50 Forecast
- Demand Side Management
- Distributed Energy Resources
- Energy Storage Resources
- Seasonal Models
- OATT Compliance
- Transmission Planning
- PSS®E
- Reliability Analysis
- Planning Criteria
- Attachment AQ

## 8. Items That May Need Follow-Up

1. **MDAG Procedure for late or no data submittal** - Marked as (FUTURE), indicating incomplete procedure requiring development

2. **Specific Season Cutoff Dates** - Table 1 referenced but complete cutoff dates for all seasons not fully detailed in this excerpt

3. **Complete 50/50 Load Forecast Derivation** - Referenced in Section 12 Appendix VIII but not included in this chunk

4. **Data Submittal Forms** - Separate document posted with every model set - need to verify current version

5. **Municipal utility load modeling** - Text cuts off mid-sentence regarding identification requirements

6. **Summer Shoulder Off-Peak percentage clarification** - Stated as "typically 70% - 80%" but lacks definitive specification

7. **Special studies load forecast requirements** - Mentioned (e.g., 90/10 forecast) but procedures not detailed

8. **Pseudo-tied load coordination** - Process for coordinating forecasts between SPP and embedded entities may need clarification

9. **Service agreement finalization timeline** - "In the process of finalization" defined but specific timeline expectations not established

10. **Non-scalable load worksheet updates** - Process and frequency for updating EDST non-scalable Load worksheet needs verification

---

# Chunk 4 Analysis

# Regulatory Meeting/Document Analysis Report

## 1. Executive Summary

This document is a procedural manual section from SPP (Southwest Power Pool) detailing model development procedures for power system analysis. It provides comprehensive technical guidance on data preparation, submission, and coordination requirements for SPP member systems. The content focuses on steady-state power flow modeling standards, including load mapping, area summary reports, tie-line coordination, line and transformer data specifications, and bus data requirements. The procedures emphasize consistency, coordination among members, and compliance with NERC (North American Electric Reliability Corporation) standards.

## 2. Key Topics

- **Load Mapping**: Guidelines for maintaining load identifiers in the EDST (Energy Data Submission Tool)
- **Area Summary Report**: Initial step in the update process; must be distributed one week before initial data submission
- **Area Slack Bus Selection**: Requirements for designating and maintaining area slack buses for system loss adjustment
- **Tie-Line Coordination**: Procedures for coordinating transmission line data between SPP members and external entities
- **Line and Transformer Data**: Specifications for impedance parameters, ratings, and circuit information on 100 MVA base
- **Seasonal Ratings**: Requirements for normal (Rate 1) and emergency (Rate 2) ratings for all transmission equipment
- **Bus Data Standards**: Naming conventions, voltage codes, and consistency requirements across models
- **Generator Modeling**: Requirements for modeling gross output with explicit station service loads
- **NERC Flowgate Modeling**: Mandatory inclusion of flowgates in submitted data
- **MOD Project Management**: Use of project files for tracking changes and additions

## 3. Decisions or Actions

- **Required Actions**:
  - Area Summary Reports must be distributed to all appropriate systems at least one week before initial update data is due
  - Each Data Submitter shall submit normal and emergency seasonal line ratings for each transmission line branch
  - Each Data Submitter shall submit normal and emergency ratings for each transformer branch
  - All NERC flowgates must be included in data submitted to MMWG
  - Renewable resources should be avoided as area slack buses unless no other resources exist (requires MDAG approval if used)
  - Entity's area slack machine shall be modeled within the entity's model area
  - Generators shall model gross output and explicitly model Station Service/Auxiliary load
  
- **Coordination Requirements**:
  - Purchases and sales values must be coordinated with parties involved prior to data preparation
  - Tie-line data must be coordinated with neighboring systems
  - Circuit mileages should be coordinated on all jointly owned lines

## 4. Important Dates

- **One week before initial update data due**: Deadline for distributing Area Summary Reports to appropriate systems
- **Note**: Specific calendar dates are not mentioned; timing is relative to data submission deadlines

## 5. Organizations and People Mentioned

**Organizations**:
- **SPP (Southwest Power Pool)**: Primary organization; SPP Office receives data submissions
- **MDAG**: Approval authority for renewable resource use as area slack
- **MMWG (Multi-regional Modeling Working Group)**: Coordinates PC tie line list and flowgate data
- **NERC**: Standards organization for flowgates and reliability
- **ERAG MMWG**: Standards body for bus naming conventions
- **Regional MMWG Coordinators**: Approve Master Tie Line Database entries

**People**: 
- No specific individuals named; document references "the person that prepared the report" (to be entered on forms)

## 6. Links or References

**Referenced Documents/Systems**:
- EDST (Energy Data Submission Tool) - Load Mapping worksheet
- Area Summary Report/Sheet
- MOD Project files
- MMWG PC tie line list
- Master Tie Line Database
- SPP Planning Criteria Section 7.1
- OATT (Open Access Transmission Tariff)
- ERAG MMWG Standards
- SPP tie line reports

**Technical Standards**:
- 100 MVA base for impedance parameters
- Minimum allowable reactance: 0.00011 P.U. on 100 MVA base
- Rate 1 (normal, continuous) and Rate 2 (emergency) rating fields required

## 7. Suggested Tags

- Power System Modeling
- SPP Procedures
- Data Submission Requirements
- Steady-State Analysis
- Transmission Planning
- Load Flow Modeling
- NERC Compliance
- Tie-Line Coordination
- Generator Modeling
- Seasonal Ratings
- Area Interchange
- Bus Data Standards
- Flowgate Modeling
- MOD Projects
- MMWG
- Regulatory Compliance

## 8. Items That May Need Follow-Up

1. **Renewable Resource Approval Process**: When renewable resources must be used as area slack buses, what is the specific MDAG approval process and timeline?

2. **Area Slack Bus Changes**: What constitutes a "specific reason" to justify changing an area slack bus year-to-year?

3. **Missing Slack Machine Protocol**: What specific procedures should be followed when a model area has no slack machine designated or in-service?

4. **Tie Line Ownership Disputes**: How are conflicts resolved when majority ownership of ties is disputed between entities?

5. **Rating Field Consistency**: While Rate 1 and Rate 2 are mandatory, clarification needed on when Rate 3 should be used and what it represents

6. **Compliance Monitoring**: How is compliance with these procedures monitored and what are consequences for non-compliance?

7. **Update Frequency**: How often are these procedures themselves updated, and what is the change management process?

8. **Invalid Line Lengths**: What is the remediation process when invalid line lengths result in inaccurate revenue allocations?

9. **Voltage Code Standardization**: The document states voltage codes are "recommended, but not required" - should this be made mandatory for consistency?

10. **Generator Offline Status**: Need clarification on reporting requirements when generators transition between online and offline status during model periods

---

# Chunk 5 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document section (chunk 5 of 20) from the SPP Model Development Procedure Manual details technical specifications for modeling reactive power devices, shunt devices, and generators in power system simulations. It provides comprehensive guidance on representing capacitors, reactors, SVCs, and various switchable devices in load flow software, with specific emphasis on accurate seasonal modeling and operational constraints. The content also addresses generator data requirements, including capability limits, impedance modeling, and procedures for handling mothballed or retired generation units.

## 2. Key Topics

- **Reactive Power Device Modeling**: Seasonal variations in reactive requirements and proper representation of capacitors, reactors, and SVCs
- **Shunt Device Classification**: Four categories (Fixed, Switched-Locked, Switched-Discrete, Switched-Continuous)
- **Load Flow Software Configuration**: Control modes (0-6), voltage band limits, and convergence considerations
- **Generator Data Requirements**: PMAX, PMIN, QMAX, QMIN, MVA limits, and ZSOURCE impedance calculations
- **Energy Storage Modeling**: Requirements for pumped hydro, battery, and flywheel systems
- **Generator Retirement Process**: Procedures for mothballed, future retired, and decommissioned units
- **Transmission-Level Device Representation**: Explicit modeling requirements for devices at 60 kV or greater

## 3. Decisions or Actions

- **Mandatory Modeling Standards**:
  - Voltage band limit difference must not be less than 0.025 pu for switched shunt devices
  - Switched shunts shall not be connected to generator buses or through zero-impedance branches
  - All shunt reactive devices at transmission-level buses (≥60 kV) must be modeled explicitly
  - Generator capabilities must align with MOD-025-2 and SPP Planning Criteria 7.1.1
  - Energy storage dispatch must not exceed rated output sustainable for minimum one (1) hour
  
- **Data Submission Requirements**:
  - Data Owners/Submitters must ensure proper shunt device IDs and control modes
  - Generator PMAX, PMIN, QMIN, and MVA limits provided through SPP MOD generation profile submission
  - Retirement dates must be updated in Engineering Data Submission Tool (EDST)

## 4. Important Dates

- **One-Year Notice Requirement**: Generator owners must submit retirement notification to SPP no less than one year from expected retirement date (per OATT Attachment AB, Section 2)
- **Retirement Reference Timing**: Comment required on changeset if retirement date is within one year of current model build start

## 5. Organizations and People Mentioned

**Organizations:**
- SPP (Southwest Power Pool)
- System Operators/Control Centers
- Data Owners
- Data Submitters
- Generator Owners (GO)
- Transmission Provider
- Integrated Marketplace

**Roles Referenced:**
- Switchman (field operations)
- Protection System personnel

## 6. Links or References

**Referenced Standards and Documents:**
- MOD-025-2 (generator capability verification)
- SPP Planning Criteria 7.1.1
- OATT Attachment AB (Generator Retirement Process)
- XSOURCE Table (impedance calculations)
- Engineering Data Submission Tool (EDST)
- Generator Data worksheet
- PSS®E load flow software documentation

**Software:**
- PSS®E load flow software

## 7. Suggested Tags

- Power System Modeling
- Reactive Power Management
- Shunt Device Modeling
- Generator Data Requirements
- Load Flow Analysis
- Voltage Control
- SPP Model Development
- Generator Retirement
- Energy Storage
- Transmission Planning
- MOD-025-2
- OATT Attachment AB
- PSS®E Software
- Impedance Modeling
- Dynamic Simulation

## 8. Items That May Need Follow-Up

1. **Verification of Voltage Band Limits**: Ensure all switched shunt devices in existing models comply with the minimum 0.025 pu limit difference requirement

2. **Generator Retirement Tracking**: Confirm all generators with planned retirement dates within one year have proper Attachment AB study references in EDST

3. **Shunt Device Control Mode Validation**: Review current models to ensure control modes accurately reflect actual operational capabilities (not just software capabilities)

4. **Energy Storage One-Hour Rule**: Verify all energy storage devices are dispatched at levels sustainable for minimum one hour

5. **Line Shunt Modeling Consistency**: Determine whether line shunts are modeled as part of BRANCH data or with intermediate buses/zero-impedance branches

6. **ZSOURCE Data Accuracy**: Validate that Machine MVA Base and impedance data match between steady-state and dynamic models

7. **Mothballed Unit Status**: Confirm proper in-service status (=0) for all non-operational but potentially returnable units

8. **Decommissioned Unit Removal**: Identify units not registered in Integrated Marketplace for removal from models

9. **Tertiary Reactor Modeling**: Verify tertiary reactors are properly modeled on low voltage bus when tertiary not explicitly modeled

10. **Seasonal Device Consistency**: Cross-check that capacitors, reactors, and SVCs reflect actual seasonal operation across all seasonal models

---

# Chunk 6 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary
This document section (chunk 6 of 20) from the SPP Model Development Procedure Manual details technical requirements for modeling generator parameters and station service loads in power system planning models. The content focuses on setting maximum generation capacity (PMAX) values and properly representing auxiliary loads at generating facilities, with specific emphasis on compliance with SPP Planning Criteria and NERC MOD-025-2 standards.

## 2. Key Topics
- **Generator PMAX Modeling**: Requirements for modeling gross seasonal maximum capability
- **Station Service and Auxiliary Load Representation**: Three acceptable modeling configurations for auxiliary loads
- **Load Modeling Standards**: Requirements for non-scalable annotation and aggregation methods
- **Compliance Framework**: Integration with SPP Planning Criteria 7.1 and MOD-025-2
- **Load Identification Protocols**: Specific naming conventions using "Sn" for aggregated loads

## 3. Decisions or Actions
- Generator PMAX **shall** be modeled based on gross seasonal maximum capability
- Station Service and Auxiliary loads **shall** be represented in normal plant configuration
- Loads **shall** be modeled explicitly on appropriate bus based on voltage
- Loads **shall** be annotated as non-scalable
- Aggregated loads **shall** use "Sn" designation in Load ID13
- Total aggregated load quantity **shall** properly reflect total real and reactive loading

## 4. Important Dates
- **Within a year of expected retirement date** - mentioned in context of modeling considerations (text appears cut off from previous section)

## 5. Organizations and People Mentioned
- **SPP (Southwest Power Pool)** - Organization issuing the procedure manual
- **HILL** - Editor who made revisions to the document (per filename)
- No specific individuals named in this section

## 6. Links or References
- **SPP Planning Criteria 7.1** - Testing and reporting procedures
- **MOD-025-2** - NERC standard for generator capability verification
- **Figure VII-1** - Auxiliary load connected to generating unit bus
- **Figure VII-2** - Auxiliary load with separate transformation
- **Figure VII-3** - Auxiliary load on high-side bus of station service transformer
- **Figure VII-4a** - Aggregated generating plant Station Service loads
- **Load ID13** - Load identification field/parameter

## 7. Suggested Tags
- Generator Modeling
- PMAX Modeling
- Station Service Load
- Auxiliary Load
- MOD-025-2
- SPP Planning Criteria
- Power System Modeling
- Load Representation
- Non-Scalable Load
- Generator Retirement
- NERC Compliance
- Model Development

## 8. Items That May Need Follow-Up
1. **Incomplete Context**: Opening sentence references retirement dates but appears cut off from previous content - may need full context review
2. **Company-Specific Procedures**: Document allows "company-specific procedure" as alternative to MOD-025-2 - may need clarification on approval process for such procedures
3. **Load Variability Handling**: Document acknowledges considerable variation in auxiliary loads based on dispatch/operating conditions but doesn't specify tolerance ranges or update frequencies
4. **Aggregation Criteria**: No specific guidance on when aggregation is appropriate versus non-aggregated modeling - may need decision criteria
5. **Figure References**: Multiple figures referenced (VII-1 through VII-4a) - ensure these are properly included and cross-referenced in complete document
6. **Seasonal Variation**: PMAX defined as "seasonal" but no guidance on how many seasons or specific seasonal values required
7. **Reactive Loading**: Mentioned requirement for "real and reactive loading" but no specific power factor or reactive power calculation methodology provided

---

# Chunk 7 Analysis

# REGULATORY CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document is a procedural manual section (chunk 7 of 20) from SPP's Model Development Procedure Manual detailing technical requirements for modeling various generation resources and loads in transmission planning models. The content focuses on standardized methodologies for representing conventional generation, renewable resources (wind/solar), battery storage, distributed energy resources (DER), and energy storage resources (ESR). Key procedures include economic dispatch modeling using publicly available EIA data, renewable resource output calculations using Five-Year Average Enhancement (FYAE) methodology, and protocols for handling generation shortfalls. The manual establishes clear responsibilities for Planning Coordinators (PC), Data Submitters, and the Model Development and Advisory Group (MDAG).

## 2. Key Topics

- **Station Service and Auxiliary Load Modeling**: Detailed specifications for aggregated, combined, and discrete load representations with specific labeling conventions ("Sn," "Fn," "Vn")
- **Conventional Generation Economic Dispatch**: Use of SPP Common Economic Data Set based on EIA/DOE publicly available information
- **Renewable Resource Modeling**: FYAE calculation methodology for wind/solar dispatch; solar modeled at zero MW for light load cases
- **Battery Resource Modeling**: Different modeling approaches for spring light load off-peak, on-peak, and summer shoulder off-peak models
- **Point of Interconnection (POI) Injection Limits**: Procedures for resources sharing common POI with MW injection limits less than total capacity
- **DER and ESR Modeling**: Criteria for modeling as generators versus load records, including BES-scale and non-BES-scale resources
- **SATOA (Storage As Transmission Only Asset)**: Identification through ITP DPP process; modeled offline
- **Shortfall Guidance**: Procedures for addressing insufficient generation including future GI queue resources and exploratory generation

## 3. Decisions or Actions

- **Annual Pre-Build Activities**: PC must obtain latest EIA cost/performance data and compare to SPP Common Economic Data Set; coordinate with MDAG for variations exceeding ±10%
- **Initial Data Population**: PC populates SPP Economic Data Worksheet using EDST, MOD, and SPP Common Economic Data Set
- **Data Submitter Review**: Individual generating units reviewed and can be modified by Data Submitters after PC provides initial worksheet
- **Dispute Resolution**: When affected parties disagree on renewable or battery dispatch amounts, they should coordinate updates; unresolved cases escalated to MDAG
- **POI Dispatch Adjustments**: Generation must be reduced by season in prescribed orders (different for Summer Peak, Winter/Spring/Fall Peak, Spring Light Load, and Summer Shoulder)
- **Validation Responsibility**: Affected parties responsible for validating renewable resource and battery dispatch updates

## 4. Important Dates

- **October 1st**: SPP makes available initial FYAE dispatch values for renewable resources
- **Post-October 1st Submissions**: New renewable facilities submitted after this date dispatched with replacement data
- **Annual Cycle**: Model development build occurs annually with pre-build EIA data review activities
- **Light Load Hours**: Typically between midnight and 4am (context for solar modeling at zero MW)

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)**: Primary organization developing models
- **MDAG (Model Development and Advisory Group)**: Decision-making body for disputes and data variations
- **EIA (Energy Information Administration)**: Source of publicly available cost/performance data
- **US Department of Energy (DOE)**: Parent organization of EIA
- **PC (Planning Coordinator)**: Responsible for data collection and initial worksheets
- **GO (Generator Owner)**: Submits BES-scale ESR data
- **Data Submitters**: Review and modify generating unit data; submit DER/ESR information
- **Affected Parties**: Validate and provide dispatch updates
- **TO (Transmission Owner)**: Provides Resource Plans for Exploratory Generation
- **FERC Order 2222 DER Aggregators**: Submit designated network resources

### People:
- **HILL**: Referenced in source filename as editor (SPP Model Development Procedure Manual_HILL Edits.docx.txt)

## 6. Links or References

### Internal References:
- **Section 14: APPENDIX VIII** - Five-Year Average Enhancement (FYAE) Methodology
- **Table 2 and Table 3** - MDAG Economic Dispatch White Paper
- **Attachment V, subsection 8.9** - Interconnection Facility Study stage criteria
- **Section 10 Appendix 4** - MOD Type/Status Matrix
- **Attachment 1 of MOD-032-1** - DER and ESR modeling data requirements
- **Figure VII-4, VII-4b, VII-4c** - Examples of generating plant Auxiliary load representations

### External Documents:
- **EDST** (Economic Data Submission Tool)
- **MOD** (Model on Demand or Modeling database)
- **SPP Common Economic Data Set**
- **SPP Economic Data Worksheet**
- **ITP DPP process** (Integrated Transmission Planning - Detailed Project Proposal)
- **RTO OATT** (Regional Transmission Organization Open Access Transmission Tariff)
- **PSS®E** - Power system simulation software

## 7. Suggested Tags

`transmission-planning` `model-development` `generation-modeling` `renewable-energy` `battery-storage` `economic-dispatch` `load-modeling` `SPP` `MDAG` `distributed-energy-resources` `energy-storage` `wind-generation` `solar-generation` `FYAE` `EIA-data` `auxiliary-load` `station-service` `POI-limits` `shortfall-procedures` `exploratory-generation` `BES` `SATOA` `procedure-manual` `data-submission` `NERC-MOD-032`

## 8. Items That May Need Follow-Up

### Process Clarifications:
1. **±10% Variation Threshold**: Criteria for when MDAG coordination is required needs monitoring; what happens with variations between 0-10%?
2. **Dispute Resolution Timeline**: No specified timeframe for affected parties to coordinate before escalating to MDAG
3. **Replacement Data Methodology**: Referenced but full methodology detail deferred to Appendix VIII

### Technical Specifications:
4. **Solar Zero MW Modeling**: Light load cases model solar at zero MW "regardless of facility's long-term firm transmission service amount" - potential impact on rights holders needs validation
5. **Battery Pmin/Pmax Tolerance**: Referenced for dispatch updates but specific tolerance values not provided in this section
6. **Non-BES-scale DER In-Service Modeling**: Requires "MDAG concurrence" but criteria for concurrence not specified

### Data Responsibilities:
7. **Future GI Queue Resources**: Only allowed in Long-Term Planning Horizon at Interconnection Facility Study stage minimum - tracking mechanism for stage progression unclear
8. **Exploratory Generation Siting**: Requirement to minimize impact on neighboring systems "exercise diligence" is subjective - may need more specific criteria
9. **Dynamic Load Model Recommendations**: CMLDxxDGU2 model recommended but not required - tracking of which Data Submitters comply unclear

### Coordination Needs:
10. **Reciprocal Non-Firm Transactions**: Multiple parties required to add coordinated records - verification process for consistency not specified
11. **POI Injection Limit Tracking**: SPP staff updates with "unique identifier (likely the Surplus unit GI Queue #)" - "likely" suggests uncertainty in standardization
12. **SATOA Modeling**: Dependent on ITP DPP process and NTC grant - integration between processes needs verification

### Documentation Gaps:
13. **External Resource Modeling Section**: Cuts off mid-sentence ("when modeling externa") - continuation needed
14. **Load ID Field Footnote 14**: Referenced but footnote content not included in this chunk

---

# Chunk 8 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary
This document section outlines SPP's (Southwest Power Pool) model development procedures, focusing on power system modeling standards and data management requirements. It covers technical requirements for modeling external resources, network representation, generator data submission, and periodic model updates. The content emphasizes data accuracy, SSAE compliance requirements, and specific technical specifications for representing renewable energy resources in planning models. Key focus areas include proper bus numbering, area assignments, voltage regulation, and equivalent representations for wind and solar facilities.

## 2. Key Topics

- **External Resource Modeling**: Procedures for members acquiring resources outside their Model Area, including bus numbering, area/zone assignments, and coordination requirements
- **SSAE Compliance**: Owner data and line-mileage data requirements for Reactive Matrix (MW-Mile) calculations
- **Model Validation Process**: Initial run reviews, area interchange verification, tie line metering, and network accuracy checks
- **Generator Modeling Standards**: Requirements for MW/MVAR ratings, generator base values, fuel type identification, and reactive output limits
- **Renewable Energy Representation**: Specific equivalent representation requirements for wind and solar farms (Figure 2 mandatory for planning models)
- **Model Update Procedures**: MDAG updates, system impact studies, and methods for submitting changes through MOD or IDEV files
- **Software Platform**: Use of PTI PSS®E (Power System Simulator for Engineers) for model creation and maintenance

## 3. Decisions or Actions

- **Mandatory**: All planned projects, including reactive resources (capacitor banks), must be included in models per MOD Type/Status Matrix (Section 10 Appendix 4)
- **Mandatory**: Wind and solar facilities must use equivalent representation per Figure 2 (not detailed representation from Figure 1)
- **Requirement**: Load supplying entities must validate load power-factors with most current system snapshots for MDAG case types
- **Action Required**: Purely conjectural facilities should not be included; delayed/cancelled facilities must be removed
- **Procedure**: Generator Owners must coordinate with host Transmission Owners to obtain valid SPP bus numbers
- **Standard**: Emergency ratings must never be less than normal ratings
- **Requirement**: Updated equivalent representations must be submitted to Transmission Planner before submitting to Planning Coordinator for any equipment or topology changes

## 4. Important Dates

- **Seasonal Updates**: Load power-factor validation required for summer peak, winter peak, and light load periods
- **Seasonal Adjustments**: Generator ratings should be adjusted seasonally considering scheduled outages
- **Annual Process**: After annual update process completion, periodic model updates may be necessary

*Note: No specific calendar dates are mentioned in this section*

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)** - Planning Coordinator
- **MMWG (Model Manager Working Group)** - Maintains procedure manual
- **MDAG (Model Development and Analysis Group)** - Develops seasonal models
- **Power Technologies, Incorporated (PTI)** - Software provider
- **WECC (Western Electricity Coordinating Council)** - Referenced for best practice guides
- **OASIS** - Reservation system referenced

### Roles/Entities:
- Members
- Host Control Area
- Generation Owners/Data Submitters
- Transmission Owners
- Transmission Planner
- Planning Coordinator
- Load Supplying Entities
- Eligible Customers

## 6. Links or References

### Referenced Documents:
- MMWG Procedure Manual (contains Zone Range, System Codes, DC Lines information)
- MOD Type/Status Matrix (Section 10 Appendix 4)
- Section 6-A (guidelines for transmission line/transformer impedance data)
- SPP Planning Criteria (reactive output limits definitions)
- WECC Wind Power Plant Power Flow Modeling Guide
- WECC PV Plant Power Flow Modeling Guide

### Software/Systems:
- MOD (Model on Demand system)
- PSS®E (Power System Simulator for Engineers)
- EDST (SPP Generation tab)
- SPP file sharing site

### Standards:
- SSAE (Statement on Standards for Attestation Engagement)

## 7. Suggested Tags

`#PowerSystemModeling` `#SPP` `#PSSE` `#GeneratorModeling` `#RenewableEnergy` `#WindFarms` `#SolarFarms` `#TransmissionPlanning` `#MDAG` `#MOD` `#DataCompliance` `#SSAE` `#ModelDevelopment` `#VoltageRegulation` `#NetworkModeling` `#EquivalentRepresentation` `#PlanningModels` `#SystemImpactStudies`

## 8. Items That May Need Follow-Up

1. **Data Accuracy Verification**: Ensure all members maintain current owner data and line-mileage data in MOD for SSAE compliance
2. **Renewable Resource Compliance**: Verify that all wind and solar facilities are using Figure 2 equivalent representation (not Figure 1 detailed representation)
3. **Transformer Test Reports**: Confirm all transformer data reflects manufacturer test report information for renewable resources
4. **Power Factor Validation**: Track completion of load power-factor validation against system snapshots for all MDAG case types
5. **Cancelled/Delayed Projects**: Review and remove any previously planned facilities that have been cancelled or delayed
6. **Generator Model Updates**: Verify generator workbook includes both saturated and unsaturated impedance values for each machine
7. **Fuel Type Identification**: Ensure wind farms and other fuel types are properly identified in appropriate columns
8. **IDEV File Submissions**: Monitor that companies submit only one IDEV file per modeling pass and include MOD Projects for topology changes
9. **Voltage Bandwidth Standards**: Check that minimum voltage bandwidth meets 4% requirement for switched shunts
10. **Emergency Rating Verification**: Audit that no emergency ratings are less than normal ratings across all circuit elements

---

# Chunk 9 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document chunk is from the SPP (Southwest Power Pool) Model Development Procedure Manual and focuses on detailed technical requirements for steady-state power system modeling using PSS®E software. The content provides comprehensive guidelines for data formatting, error screening protocols, and modeling requirements for generators, transformers, and other electrical equipment. The manual is based in Little Rock, Arkansas, and establishes standards for the Eastern Interconnection power grid modeling. Key emphasis is placed on data quality control, equipment representation consistency, and adherence to ERAG MMWG (presumably Eastern Reliability Assessment Group Multi-regional Modeling Working Group) model building requirements.

## 2. Key Topics

- **PTI-PSS®E Data Format Standards**: Free format data structure with comma-separated fields
- **Steady-State Solution Requirements**: Area interchange control with "Tie Line and Loads" option
- **Data Error Screening Protocols**: Six specific quality control checks including interchange matching, CNTB errors, switched shunt corrections, and overload restrictions
- **Generator Modeling Standards**: Requirements for synchronous condensers, SVCs, and step-up transformers
- **Renewable Energy Facilities**: Multiple technology type representation (Type 3, Type 4 wind turbines, solar PV, battery storage)
- **Transformer Modeling**: Detailed specifications for two-winding and three-winding transformers, including impedance, tap ratios, and winding configurations
- **Network Component Standards**: Bus voltage nomenclature, zero impedance branches, and islanded bus prohibitions
- **XSOURCE Table Requirements**: Dynamic model data matching specifications

## 3. Decisions or Actions

- **Mandatory**: All CNTB errors shall be corrected (with documented exceptions)
- **Mandatory**: Transmission lines and transformers 69 kV and above shall not have overloads above 100% of RATE1 in base cases (10-year cases excepted)
- **Mandatory**: Renewable generator facilities with multiple technology types shall use Figure 2 representation in planning models
- **Prohibited**: Islanded buses shall not be modeled
- **Prohibited**: Fictitious generators should not be used for load netting
- **Prohibited**: Users cannot delete equipment and re-add with new data; modifications must be used instead
- **Required**: Eight-character unique bus names within Eastern Interconnection
- **Required**: Minimum and maximum tap position limits based on transformer test reports or manufacturer nameplate data

## 4. Important Dates

- **No specific dates mentioned** in this content chunk
- Reference to "10 year cases" for overload exceptions (timeframe context, not specific date)

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)** - Primary organization
- **PTI** - PSS®E software developer
- **ERAG MMWG** - Eastern Reliability Assessment Group Multi-regional Modeling Working Group (implied)
- **Eastern Interconnection** - Geographic/operational scope

**Location:**
- Little Rock, Arkansas (SPP location)

**People:**
- **HILL** - Editor mentioned in source filename (SPP Model Development Procedure Manual_HILL Edits.docx.txt)

**Countries:**
- United States
- Canada

## 6. Links or References

**Software/Manuals:**
- PSS®E Program Operation Manual Volume I, Chapter 4: Section 1.1
- PSS®E dynamic library models

**Data Specifications:**
- RATE1 (equipment rating parameter)
- THRSHZ (zero impedance threshold in PSS®E)
- RMIN and RMAX (tap position limits)
- XSOURCE value table

**Figures Referenced:**
- Figure 1 (guidance for renewable resource representations)
- Figure 2 (mandatory representation for planning models) - noted as located in "Initial Run Review Section"

## 7. Suggested Tags

- Power System Modeling
- PSS®E Software
- Steady-State Analysis
- Data Quality Control
- Generator Modeling
- Transformer Specifications
- Renewable Energy Integration
- Grid Planning
- Eastern Interconnection
- SPP Standards
- Model Development Procedures
- Error Screening
- Voltage Control
- Network Equivalencing
- Transmission Planning

## 8. Items That May Need Follow-Up

1. **Missing Visual References**: Figures 1 and 2 are referenced but not included in this chunk; need to verify these are accessible in the complete document

2. **XSOURCE Table Incomplete**: The XSOURCE table is mentioned with a heading but the actual values/data are not shown in this excerpt

3. **Exception Documentation Process**: CNTB error exceptions "will be documented" but the documentation process/location is not specified

4. **ERAG MMWG Definition**: This acronym is used but not explicitly defined; confirmation of full organization name needed

5. **Software Version Compatibility**: No PSS®E version number specified; may need clarification on which software versions these procedures apply to

6. **Renewable Energy Model Updates**: The document mentions "2nd generation (or later) generic renewable models" - need to track if newer generation models require procedure updates

7. **Tap Position Data Sources**: Requirements state transformer test reports or manufacturer nameplate data are needed - clarification on data validation/storage process may be needed

8. **Connection Code Standards**: References to connection codes "<10" and ">10" without full explanation of the coding system

9. **System MVA Base Confirmation**: 100 MVA is stated as system base but no reference to when/if this might change

10. **Load Calculation Zone Separation**: Recommendation for separate zones for nonnative loads needs operational implementation guidance

---

# Chunk 10 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary

This document chunk is from the SPP (Southwest Power Pool) Model Development Procedure Manual, specifically focusing on technical specifications for modeling electrical power system components in planning models. It provides detailed requirements for transformer modeling (including tap changers, phase shifting transformers, and generator step-up transformers), generator specifications, static VAR systems, DC transmission systems, and troubleshooting guidance for model convergence issues. The content is highly technical and prescriptive, establishing standards for data owners and submitters to ensure consistent and accurate power system modeling using PSS®E software.

## 2. Key Topics

- **Transformer Tap Changer Specifications**: ULTC (Under-load tap changers) and NLTC (No-load tap changers) requirements, including control modes, tap positions, and voltage regulation parameters
- **Voltage Regulation Requirements**: Regulated bus specifications, voltage band limits (VMAX, VMIN), and minimum limit differences (0.0125 p.u. minimum, 0.025 p.u. recommended)
- **Phase Shifting Transformers (PSTs)**: Operational requirements, MW flow limits, phase shift angle ranges, and modeling specifications
- **Generator Step-Up Transformers (GSUs)**: Implicit vs. explicit modeling requirements, impedance specifications, and cross-compound unit considerations
- **Generator Modeling Parameters**: MW and MVAR limits (PMIN, PMAX, QMIN, QMAX) and seasonal capability representations
- **Static VAR Systems**: Reactive power limits, voltage set points, and switched shunt equipment modeling
- **DC Transmission Systems**: Detailed behavioral modeling requirements
- **Model Convergence Issues**: 13 identified causes of non-convergence and solution strategies
- **Flowgate Modeling**: Requirements for transmission element representation

## 3. Decisions or Actions

**Required Actions for Data Owners/Submitters:**
- Specify transformer tap positions as discrete values (use "99" for untapped windings)
- Provide vector group and connection code data matching topological configurations
- Submit manufacturer tested capability and operational limits for PSTs to SPP planning staff
- Model PSTs as two-winding transformers at the same nominal voltage level
- Provide GSU data (resistance, reactance, tap settings) when modeled implicitly
- Coordinate multiple regulating devices controlling single bus voltage
- Include all transmission elements comprising flowgates in submitted data
- Ensure actual interchange within 25 MW of specified desired interchange value

**Prohibited Practices:**
- Do not use voltage band limit differences less than 0.0125 p.u. for ULTC transformers
- Avoid remote regulation of buses more than one bus away from regulating device
- Avoid voltage regulation schedules exceeding 1.10 p.u. or below 0.90 p.u.
- Do not use a value of "1" as a tap position (PSS®E limitation)

## 4. Important Dates

- **June 1 – September 30**: Referenced as Summer Peak Season example for PST operational MW flow analysis

*Note: No specific compliance deadlines or meeting dates are mentioned in this technical specifications section.*

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)**: Primary organization issuing these requirements; SPP planning staff responsible for developing corrective actions
- **PC (Planning Coordinator)**: Authority to request additional modeling information
- **TP (Transmission Planner)**: Authority to request additional modeling information
- **Regional Reliability Organization**: Entity that may require explicit GSU modeling
- **Data Owners**: Entities responsible for providing transformer and equipment data
- **Data Submitters**: Entities submitting modeling data to SPP
- **Transmission Owner**: Entity that may determine need for explicit GSU modeling

**People:**
- **HILL**: Referenced in source filename as editor/reviewer

## 6. Links or References

**Software:**
- **PSS®E**: Power system simulation software referenced throughout for modeling requirements and limitations

**Technical Standards Referenced:**
- Vector group notation (e.g., "Dyn11")
- Clock notation for transformer phase displacement
- Approved MM (Model Management procedures)

**Related Documents (Implicit):**
- Impedance tables for planning models
- Transformer core type specifications (shell type or core type)

## 7. Suggested Tags

- Power System Modeling
- SPP Model Development
- Transformer Specifications
- ULTC (Under-Load Tap Changers)
- Phase Shifting Transformers
- Generator Step-Up Transformers
- PSS®E Software
- Voltage Regulation
- Model Convergence
- Static VAR Systems
- DC Transmission
- Flowgate Modeling
- Planning Procedures
- Technical Standards
- Data Submission Requirements

## 8. Items That May Need Follow-Up

**Technical Clarifications Needed:**
1. Specific definition and reference for "approved MM" (Mentioned in cause #13 of non-convergence)
2. Clarification on coordination thresholds: "offsetting MVAR output changes greater than 500 MVAR" - basis for this specific value
3. Definition of "small generators" threshold (example given as 10 MVA, but needs confirmation if this is the standard cutoff)

**Implementation Questions:**
4. Process for submitting manufacturer tested capability data for PSTs to SPP planning staff
5. Procedure for resolving conflicts when multiple data owners have regulating devices at the same bus
6. Template or format requirements for impedance correction adjustment tables for PSTs

**Compliance Monitoring:**
7. How compliance with these specifications is verified by SPP
8. Process for handling existing models that don't meet new standards (grandfather provisions?)
9. Review cycle for seasonal capability updates (PMIN/PMAX adjustments)

**Cross-Reference Requirements:**
10. Need to verify consistency between this manual and dynamics modeling requirements for generators
11. Coordination with transmission service agreements regarding PST firm service levels
12. Integration with flowgate monitoring and constraint management procedures

**Potential Contradictions or Gaps:**
13. Clarification needed on when GSUs "may" vs. "shall" be modeled explicitly
14. More specific guidance on "lumping" small generators into equivalents while maintaining accuracy

---

# Chunk 11 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document is a technical section from the SPP (Southwest Power Pool) Model Development Procedure Manual, specifically focusing on power flow modeling standards, data quality requirements, and transaction management protocols. The content provides detailed guidance on troubleshooting common modeling issues, managing phase-shifting transformers, balancing generation and load through model areas, and establishing requirements for transaction data submission. The document emphasizes the importance of proper data conventions, coordination between data owners, and adherence to specific technical standards to ensure accurate power flow modeling across the interconnected electrical network.

## 2. Key Topics

- **Data Quality Issues**: Guidelines for identifying and resolving common modeling errors including zero/low reactance branches, duplicate bus names, and inconsistent transformer representations
- **Phase Shifting Transformer Conventions**: Detailed technical specifications for PSS®E software compatibility, including sign conventions and bus naming requirements
- **Model Area Balancing**: Comprehensive explanation of balancing generation and load within model areas, including swing generator requirements and slack machine designation
- **Pseudo-Tie Modeling**: Differentiation between intra-SPP and inter-SPP pseudo-ties, with restrictions on fictitious topology
- **Transaction Data Requirements**: Detailed protocols for bilateral transaction submissions through MDAG EDST system
- **Data Precision Standards**: Requirements for MW precision in inter-area (0.01MW) versus external area (whole MW) transactions
- **Troubleshooting Procedures**: Systematic approaches for resolving voltage regulation issues, missing tie lines, and high R/X ratios

## 3. Decisions or Actions

### Required Actions for Data Owners:
1. **Submit all transactions data via MDAG EDST system**
2. **Coordinate bilateral transactions** with all parties prior to submission
3. **Submit only their portion** of bilateral transactions (source or sink)
4. **Review and update transactions data** according to model building schedule
5. **Ensure proper polarity**: positive for source transactions, negative for sink transactions
6. **Complete all required EDST data fields** for each transaction portion
7. **Round external area transactions** to nearest whole MW
8. **Limit inter-area transaction precision** to two decimal places (0.01MW)
9. **Justify inter-SPP pseudo-tied loads** with proper documentation
10. **Notify Regional Coordinator** for zero voltage regulation issues
11. **Notify AEP** if phase shifter data does not conform to specified convention

### Prohibited Actions:
- Creating pseudo-tie modeling representations incorporating **fictitious topology**
- Referring to "generation area" or "load area" (improper terminology)

## 4. Important Dates

- **Transaction Start date** (required field - specific dates not mentioned in excerpt)
- **Transaction Stop date** (required field - specific dates not mentioned in excerpt)
- References to **model building schedule** (specific dates not provided in this section)

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)** - Primary organization/Balancing Authority
- **AEP (American Electric Power)** - Processes MMWG models using PSS®E
- **MISO** - Referenced as example non-SPP member for bilateral transactions
- **PTI (Power Technologies Inc.)** - Developer of PSS®E software
- **MMWG (Multi-regional Modeling Working Group)**
- **ERO (Electric Reliability Organization)** or its designee
- **OASIS (Open Access Same-Time Information System)**
- **MDAG (Model Development and Analysis Group)**

### Roles Referenced:
- Regional Coordinator
- Data Owners
- SPP Market Participants
- SPP staff
- Planning Coordinator (PC)
- Balancing Authorities

## 6. Links or References

### Software/Systems:
- **PTI PSS®E** steady-state program
- **MDAG EDST** (Electronic Data Submittal Tool)
- **OASIS** system for scheduling

### Referenced Documents:
- Page 3 of Appendix (for phase shifter sign convention)
- Figure 1 (Example of interconnected model areas)
- Figure 2 (Four types of inter-SPP pseudo-ties)
- Figure 3 (Example of Inter-area transfer)
- Figure 4 (Example of Intra-area transfer)

### Technical Standards:
- Minimum reactance = 0.0001 per unit
- Minimum MW tolerance for phase-shifting-under load transformers

## 7. Suggested Tags

- Power Flow Modeling
- Model Development
- Data Quality
- Phase Shifting Transformers
- Transaction Management
- Balancing Authority
- Model Areas
- Pseudo-Ties
- Data Submission Requirements
- SPP Procedures
- PSS®E Software
- MDAG
- Bilateral Transactions
- Load Balancing
- Generation Dispatch
- Interchange Scheduling
- Technical Standards
- Data Coordination
- Troubleshooting

## 8. Items That May Need Follow-Up

### Technical Clarifications Needed:
1. **Specific model building schedule dates** - document references schedule but doesn't provide specific deadlines
2. **Incomplete sentence** at end of excerpt regarding "EDST information reserved for SPP staff usage"
3. **Definition of minimum MW tolerance** for phase-shifting-under load transformers (referenced but not specified)
4. **Complete list of required EDST data fields** - excerpt appears to be cut off

### Process Clarifications:
1. **Procedure for justifying inter-SPP pseudo-tied loads** - criteria and documentation requirements not fully detailed
2. **Coordination process with non-SPP members** - specific protocols not fully explained
3. **Regional Coordinator notification process** for voltage regulation issues
4. **AEP notification procedure** for non-conforming phase shifter data

### Potential Issues:
1. **High R/X ratios causing non-convergence** - guidance to "delete line or reduce ratio" may need more specific criteria
2. **Pseudo-tie usage** - potential for misuse to avoid proper accounting needs monitoring
3. **Data precision requirements** - potential for rounding errors in external area transactions
4. **Duplicate bus names** - systematic prevention measures may be needed

### Coordination Requirements:
1. **Bilateral transaction coordination** between multiple parties - may need tracking mechanism
2. **Consistency between interconnected companies** at different voltage levels for delta-wye transformers
3. **SPP staff responsibilities** for non-SPP member transaction portions - workload and timeline implications

---

# Chunk 12 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document chunk is from the SPP (Southwest Power Pool) Model Development Procedure Manual and covers technical modeling requirements for electrical system data. The content focuses on transaction modeling, substation node-breaker modeling, model quality assurance processes, and dynamic data requirements. It establishes procedures for how SPP members must submit and maintain electrical system data, including firm transactions, detailed substation configurations, and quality control measures. The manual emphasizes the importance of accurate data submission for system planning, ATC calculations, and compliance with FERC requirements regarding roll-over rights.

## 2. Key Topics

- **Transaction Modeling Requirements**: Procedures for modeling transactions between control areas, including external resources and load obligations
- **Firm Transaction Definitions**: Requirements for modeling long-term firm transactions, including FERC roll-over rights considerations
- **Substation Node-Breaker Modeling**: Detailed requirements for EHV (Extra High Voltage) substation modeling using PSS®E version 34+
- **Naming Conventions**: Specific formats for substation numbering and naming (SPP_ prefix requirement)
- **Model Quality Assurance**: MDAG's role in data validation through DocuCode and ACCC summary reviews
- **Data Submitter Responsibilities**: Obligations for timely and accurate data submission
- **Exception and Override Procedures**: Process for handling non-compliant or unacceptable model data
- **Dynamic Data Requirements**: Introduction to dynamic modeling requirements for SPP resources

## 3. Decisions or Actions

- Data Submitters **shall submit** node-breaker modeling information for all EHV substations within SPP footprint
- Substation names **must** include "SPP_" prefix and be unique to the Eastern Interconnection
- Unacceptable model data **shall be addressed** in each model pass and **shall be corrected** prior to MDAG approval
- Fault current interrupting devices **shall be modeled** in substation switching device data
- Data Owners **are expected** to ensure data correctness before submitting to SPP
- SPP Staff and MDAG **may override** unacceptable model data when Data Owners/Submitters are non-responsive
- Data Owner/Data Submitter updates **should be submitted** during the next data submission period per MDAG schedule

## 4. Important Dates

No specific dates or deadlines are mentioned in this content chunk. References are made to:
- "Next data submission period" (timing based on latest MDAG model building schedule)
- "SPP quarterly MOPC reporting process" (general quarterly cycle)
- Long-term firm transactions with future extension considerations

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)** - Primary organization
- **MDAG (Model Development Advisory Group)** - Approval and oversight body
- **MOPC** - Quarterly reporting recipient
- **FERC** - Federal regulatory authority (referenced for roll-over rights ruling)
- **Energy Information Agency (EIA)** - Data coordination reference
- **Eastern Interconnection** - Regional coordination context

### Roles Referenced:
- Data Owners
- Data Submitters
- System Representatives
- SPP Staff
- Generation Owners
- Load Modeling Entities

### Example References:
- STATION A, TECUMSEH_HILL (example substation names)
- WERE-TECUMSEH-HILL (example naming convention)

## 6. Links or References

### Software/Technical Standards:
- **PSS®E** (Power System Simulator for Engineering) - Version 34 and higher
- **EDST** (transaction data system)
- **DocuCode** - Automated quality assurance routine
- **ACCC (AC Contingency Calculation)** - Model validation tool
- **EMS model** - Energy Management System
- **EIA-411 Data** - Energy Information Agency reporting

### Referenced Documents:
- Appendix VIII (transaction worksheet)
- Planning Criteria
- SPP quarterly MOPC reporting process
- Latest MDAG model building schedule
- "This manual" (self-referential to SPP Model Development Procedure Manual)

## 7. Suggested Tags

- Model Development
- Transaction Modeling
- Node-Breaker Modeling
- Substation Data
- Quality Assurance
- MDAG
- Data Submission Requirements
- PSS®E
- FERC Compliance
- Firm Transactions
- EHV Substations
- Eastern Interconnection
- Switching Devices
- DocuCode
- AC Contingency Analysis
- Data Validation
- SPP Procedures
- Power System Modeling

## 8. Items That May Need Follow-Up

1. **Data Submission Compliance**: Tracking which Data Owners/Submitters are meeting the node-breaker modeling requirements for EHV substations
2. **Non-Responsive Data Owners**: Monitoring entities that require MDAG/SPP Staff overrides due to non-response on unacceptable data
3. **Exception Tracking**: Maintaining a comprehensive list of all MDAG "Exceptions" granted for legitimate deviations from standard requirements
4. **Override Documentation**: Ensuring all overridden data is properly annotated in DocuCode summaries with justification
5. **PSS®E Version Compliance**: Verifying all Data Submitters are using PSS®E version 34 or higher for node-breaker modeling
6. **Quarterly MOPC Reporting**: Following up on data corrections reported through the quarterly process
7. **Transaction Confirmation**: Confirming firm transactions at both source and sink ends, especially outside Pool boundaries
8. **Dynamic Model Completion**: Section 4 introduction suggests additional requirements to be detailed
9. **EIA-411 Data Consistency**: Ensuring submitted SPP data aligns with official EIA reporting
10. **Contingency Analysis Follow-up**: Tracking modeling errors identified through ACCC and ensuring corrections in next submission period

---

# Chunk 13 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document section outlines SPP's (Southwest Power Pool) comprehensive procedures and technical requirements for dynamic modeling of the Eastern Interconnection power system. It establishes detailed standards for submitting dynamic model data in PSS®E format, including specifications for generator modeling, data submittal requirements, and initialization procedures. The content emphasizes the importance of accurate, detailed dynamic representations for reliability studies and compliance with ERAG MMWG (Eastern Interconnection Reliability Assessment Group Multiregional Modeling Working Group) requirements. Key focus areas include generator modeling standards, exceptions for non-detailed modeling, user-defined model requirements, and step-by-step procedures for case initialization and validation.

## 2. Key Topics

- **MDAG Dynamic Model Requirements**: Format specifications (PSS®E DYRE and RAWD formats) for Eastern Interconnection modeling
- **Generator Modeling Standards**: Detailed requirements for synchronous generators and condensers (minimum two direct axis circuits and one quadrature axis circuit)
- **Exceptions for Non-Detailed Modeling**: Criteria for units ≤50 MVA and special circumstances
- **Dynamic Model Components**: Requirements for excitation systems, turbine-governors, power system stabilizers, and reactive compensation
- **Alternative Generation Technologies**: Modeling requirements for wind, solar, HVDC, SVC, STATCOM, and FACTS devices
- **Load Modeling**: Dynamic behavior representation requirements (≥10 MW non-scalable loads)
- **User-Defined Models**: Documentation and source code requirements (FLECS, C, or FORTRAN only)
- **Unit Aggregation Rules**: Netting (≤20 MVA) and lumping (≤50 MVA units, max 300 MVA lumped) permissions
- **Relay Protection Models**: Requirements for devices with ≤10 second operation times
- **Case Initialization Procedures**: Detailed 17-step process for validating dynamic cases

## 3. Decisions or Actions

- Dynamic model data must be submitted in PSS®E DYRE and RAWD formats
- MATLAB/SIMULINK user models are **not permitted** due to licensing restrictions
- All exceptions to modeling standards require MMWG approval and documentation in SDDB
- Per unit data must be provided on generator nameplate MVA rating
- MINS (Miscellaneous Other) values must use unique eight-digit numbering system (first 6 digits = bus number, last 2 = unique identifier)
- Non-scalable loads ≥10 MW require dynamic load model representation
- Standard loads default to 100% constant current (MW) and 100% constant admittance (Mvar)
- User-defined models require comprehensive written documentation including block diagrams, parameters, and state variables

## 4. Important Dates

- **Units older than 1970**: Eligible for non-detailed modeling if detailed data unavailable
- **Quarter-cycle and half-cycle time steps**: Specified for model solving (no specific dates provided)
- No specific submission deadlines mentioned in this chunk (referenced as available on www.spp.org)

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)**: RTO responsible for reliability studies
- **ERAG MMWG (Eastern Interconnection Reliability Assessment Group - Multiregional Modeling Working Group)**: Sets dynamic modeling requirements
- **MDAG (Model Development Action Group)**: Responsible for dynamic model updates
- **Siemens PTI**: PSS®E software provider
- **PC (Planning Coordinator)**
- **TP (Transmission Planner)**

### People:
- None specifically mentioned

## 6. Links or References

- **www.spp.org**: SPP corporate website for dynamic data submission schedules and model lists
- **PSS®E Program Operation Manual**: Referenced for technical guidance
- **SDDB (System Dynamic Data Base)**: Repository for exception documentation
- **PSS®E software formats**: DYRE, RAWD formats
- **Programming languages**: FLECS, C, FORTRAN (acceptable); MATLAB/SIMULINK (not permitted)

## 7. Suggested Tags

`Dynamic Modeling`, `PSS®E`, `MDAG`, `MMWG`, `Generator Modeling`, `Eastern Interconnection`, `SPP`, `ERAG`, `Reliability Studies`, `Power System Simulation`, `DYRE Format`, `RAWD Format`, `Synchronous Generators`, `User-Defined Models`, `Load Modeling`, `Relay Protection`, `Model Validation`, `HVDC`, `Wind Modeling`, `Solar/PV Modeling`, `FACTS Devices`, `Data Submittal Requirements`

## 8. Items That May Need Follow-Up

1. **Verification of current PSS®E revision requirements** - Document references "current PSS®E revision" without specifying version number
2. **MMWG exception approval process** - No detailed procedure provided for requesting/documenting exceptions
3. **Specific submission deadlines** - Referenced as available on website but not included in document
4. **SDDB access and documentation procedures** - How entities submit exception documentation to SDDB
5. **User-defined model approval process** - Criteria for determining when standard models "cannot adequately approximate" performance
6. **Typical detailed data sources** - Where to obtain typical data when manufacturer data unavailable
7. **Relay model availability timeline** - "When available" is ambiguous for mandatory submission
8. **CONEC, CONET, and COMPILE file specifications** - Referenced in procedure but not detailed
9. **SYSANG model requirements** - Mentioned as "highly desirable" but criteria unclear
10. **Cross-compound unit modeling conventions** - Reference to IEEEG1 conventions needs clarification
11. **Verification of 10-second relay protection threshold** - Basis for this specific time threshold
12. **Validation of quarter-cycle/half-cycle time step requirements** - Technical justification not provided

---

# Chunk 14 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document section details SPP's (Southwest Power Pool) technical procedures for dynamic model development, validation, and short circuit data requirements. It outlines comprehensive testing protocols for power system simulation, including exciter and governor model validation, data submission requirements for both PSS®E and non-PSS®E users, and dynamic model acceptability criteria aligned with NERC standards. The section emphasizes rigorous initialization checks, 20-second no-disturbance simulations, and specific procedures for handling user-written models and offline wind units.

## 2. Key Topics

- **Dynamic Model Initialization and Testing Procedures**
  - Six-step compilation and execution process using CLOAD4
  - Initial conditions checking and validation protocols
  - 20-second undisturbed operation simulation requirements

- **Model Validation Requirements**
  - Exciter model response validation (ESTR/ERUN)
  - Governor model response validation (GSTR/GRUN)
  - Offline wind unit testing at 100% Pmax

- **Dynamic Data Submission Formats**
  - PSS®E dyre file format requirements
  - Flat text file compatibility standards
  - Version compatibility with current SPP-specified PSS®E version

- **Model Acceptability Standards**
  - NERC List of Unacceptable Models compliance
  - User-written model conditions and restrictions
  - MDAG supplemental unacceptable model list

- **Short Circuit Data Requirements**
  - MOD (Model On Demand) database integration
  - Engineering Data Submission Tool (EDST) usage
  - Sequence data requirements (zero, positive, negative)

## 3. Decisions or Actions

- **Mandatory Testing Protocol**: All regional data submittals must undergo satisfactory initialization and 20-second no-disturbance simulation checks

- **Offline Wind Unit Handling**: Wind units switched in at 100% Pmax for initialization in 5-year summer peak cases with compensatory ramping of existing online wind

- **Data Correction Responsibility**: Data submitters remain responsible for corrections through MOD or new dyre entries for subsequent model builds

- **User-Written Model Requirements**: Only allowed under five specific conditions including 18-month conversion commitment

- **Load Modeling Standards**: Voltage dependency must be represented as ZIP model (constant impedance, current, and power mixture)

- **Third-Party Data Sharing**: Requires execution of SPP confidentiality/non-disclosure agreement

## 4. Important Dates

- **20 seconds**: Minimum undisturbed operation simulation time required

- **20 seconds**: Required equilibrium time for steam or combustion turbine governors (hydro units may require longer)

- **18 months**: Maximum timeframe for converting user-written models to acceptable models after notification

- **5-year summer peak case**: Reference case for offline wind initialization

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)** - Planning Coordinator (PC)
- **NERC (North American Electric Reliability Corporation)**
- **MMWG (Multi-regional Modeling Working Group)**
- **MDAG (Model Development Action Group)**
- **Siemens PTI** - PSS®E software provider
- **Regional Coordinators**
- **Transmission Planner**

### Roles Referenced:
- Data Owner
- Data Submitter
- Generator/Dynamic Device Owner
- MMWG Coordinator
- Responsible Entity

## 6. Links or References

- **NERC Website Path**: Event Analysis, Reliability Assessment and Performance Analysis → Modeling Assessments → Resources → Dynamic Modeling Recommendations

- **Referenced Documents**:
  - "Guidelines for SPP MOD-032 Dynamic Models document"
  - MOD Procedure Manual
  - Section III.H of this manual (noted as "yet to be written")
  - SDDB (System Dynamic Data Base) data screening checks

- **Software References**:
  - Siemens PTI PSS®E software (various versions)
  - GlobalScape (data submission platform)

- **File Formats**:
  - .dyr (dynamics data format)
  - .lib or .dll (compilation/linking format)
  - .pdf or .docx (documentation format)

## 7. Suggested Tags

- Dynamic Modeling
- PSS®E Software
- Model Validation
- NERC Compliance
- Power System Simulation
- Exciter Models
- Governor Models
- Wind Generation
- Short Circuit Analysis
- Model On Demand (MOD)
- Data Submission Requirements
- Initialization Testing
- User-Written Models
- Dynamic Data Validation
- Load Flow Analysis
- MMWG
- MDAG
- Sequence Data

## 8. Items That May Need Follow-Up

1. **Incomplete Documentation**: Section III.H referenced as "yet to be written" - needs completion for no-disturbance simulation check procedures

2. **PSS®E Version Specification**: Current PSS®E version required by SPP is not specified in this section - needs clarification

3. **User-Written Model Tracking**: 18-month conversion timeline requires monitoring system for user-written models awaiting conversion

4. **Wind Unit Initialization Issues**: Process for handling initialization problems appears iterative with PC providing "proposed corrections" - may need clearer escalation procedures

5. **Typical Data Documentation**: Guidelines suggest documentation for models with typical data but enforcement mechanisms unclear

6. **Third-Party Confidentiality Agreements**: Process and template for SPP confidentiality/non-disclosure agreements not detailed

7. **SDDB Data Screening Checks**: Specific screening test criteria not detailed in this section - requires reference to complete documentation

8. **Excel Template Details**: Mentioned for dynamics data updates but template specifications not provided

9. **Load Modeling Parameters**: ZIP model parameters to be "provided by Regions" but coordination mechanism unclear

10. **Short Circuit Model Approval Process**: PC verification procedures mentioned but detailed approval workflow not specified

---

# Chunk 15 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document section (chunk 15 of 20) from the SPP Model Development Procedure Manual describes technical procedures for short circuit model development, mutual impedance modeling, and data management processes. It covers the validation and testing requirements for sequence data, the development of three types of short circuit models (Base MDAG, Classical assumptions, and Maximum Fault), and establishes standardized definitions for model building terminology. The section concludes with detailed appendix specifications for Master Tie Line File data fields across various equipment types.

## 2. Key Topics

- **Short Circuit Model Validation**: Procedures for checking and testing models for errors, including fault analysis requirements (three-phase, single-line-to-ground, and double-line-to-ground)
- **Mutual Impedance Modeling**: Guidelines for identifying and calculating mutual coupling between parallel transmission lines affecting zero-sequence current during ground faults
- **Short Circuit Model Development**: Three annual model versions built from MDAG Powerflow models with specific construction steps
- **Data Synchronization**: Requirements for coordinating short circuit databases across different software platforms (CAPE, ASPEN, PSS®E)
- **Transformer Requirements**: All transformers must have Vector Group and corresponding Connection Code in PSS®E 33+ format
- **Standardized Definitions**: Comprehensive terminology for model building including Peak Demand, Interchange, Equivalencing, and Shortfall
- **Master Tie Line File Specifications**: Detailed data field requirements for Branch, Two/Three Winding Transformers, and DC Tie equipment

## 3. Decisions or Actions

- **PC Responsibility**: Planning Coordinator (PC) shall check models for errors and validate usability
- **Error Reporting**: Any sequence data errors shall be brought to Data Submitter's attention
- **Retired Generators**: GSUs are kept in service if interrupting device exists on low side for accurate short circuit results
- **Mutual Impedance Submission**: Data shall be submitted by attaching to applicable MOD project
- **Model Exclusions**: Member submitted sequence via IDEV file applied to a model will NOT be included in next published model (Pass N or Final)
- **Pre-Presentation Analysis**: SPP staff will conduct preliminary analysis of three phase balanced and unbalanced faults before presenting to MDAG
- **Synchronization Requirement**: Best practice requires synchronizing all short circuit databases across different software platforms

## 4. Important Dates

- **Annual Development Cycle**: Short Circuit models are developed annually using MDAG Powerflow models subset
- **Seasonal Definitions**: Seasonal Line Ratings must include at least four seasons per year
- **Annual Calculation**: Seasonal ratings calculated annually, if not more frequently
- No specific calendar dates or deadlines mentioned in this section

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)** - Planning Coordinator
- **MDAG (Model Development Advisory Group)** - Receives model presentations
- **SERC** - Provides Short Circuit model data
- **SERC's Short Circuit Database Working Group (SCDWG)** - Builds SERC Short Circuit models
- **PC (Planning Coordinator)** - Performs validation and testing

### Software/Tools:
- **PSS®E** - Siemens PTI's Power System Simulator for Engineering
- **PSS®E MOD** - Web-based model management application
- **CAPE, ASPEN** - Alternative short circuit modeling software platforms
- **EDST (Engineering Data Submission Tool)** - Web-based application for data submission
- **PSS®MOD File Builder** - Siemens stand-alone tool for capturing model changes

### Roles Referenced:
- Data Owner
- Data Submitter
- Transmission Provider
- Balancing Authority

## 6. Links or References

### External Documents/Standards:
- **PSS®E Program Operation Manual** - Referenced for Classical assumptions methodology
- **SPP Model Development Procedure Manual** - Self-referential for Data Owner/Submitter responsibilities
- **Generation Interconnection process** - Referenced for Exploratory Generation definition

### Data Models Referenced:
- MDAG steady-state base model
- SERC Short Circuit model
- Master Tie Line File specifications

### File Formats:
- RAW files (PSS®E raw data)
- SEQ files (sequence data)
- IDEV files (applied changes that aren't carried forward)

## 7. Suggested Tags

- Short Circuit Modeling
- PSS®E
- Model Validation
- Mutual Impedance
- Sequence Data
- MDAG
- Fault Analysis
- Model Development
- Data Management
- Transformer Modeling
- Tie Line Data
- Planning Coordinator
- SPP Procedures
- Classical Assumptions
- Generation Step-Up Transformers (GSU)
- Zero-Sequence Current
- Model Synchronization
- SERC
- Maximum Fault Case

## 8. Items That May Need Follow-Up

### Technical Clarifications Needed:
1. **IDEV File Exclusion Policy**: Clarify impact on members who rely on IDEV files for interim model updates and establish alternative submission workflows
2. **Mutual Impedance Calculation Standards**: Establish specific methodology or tolerance levels for "substantial distance" parallel routing requiring mutual impedance modeling
3. **Primary Database Designation**: Verify which database (CAPE, ASPEN, PSS®E) serves as primary source for each company's footprint

### Process Improvements:
4. **Model Transition Protocol**: Document procedure for ensuring sequence data continuity between model sets given IDEV exclusion policy
5. **Error Resolution Timeline**: Establish timeframes for Data Submitters to respond to sequence data errors identified by PC
6. **First Tier Company Definition**: Clarify which companies constitute "first tier" for SERC data extraction purposes

### Data Quality Issues:
7. **Vector Group Compliance**: Verify all transformers have been updated to PSS®E 33+ format with Vector Group and Connection Code
8. **GSU Status Verification**: Audit retired generator GSUs to ensure proper in-service/out-of-service status based on interrupting device presence
9. **Seasonal Rating Updates**: Confirm all entities are calculating seasonal ratings at required frequency

### Coordination Requirements:
10. **Cross-Platform Synchronization**: Establish periodic verification schedule for database synchronization across software platforms
11. **MOD Project Submission Deadlines**: Define submission cutoff dates for mutual impedance data to ensure inclusion in next model cycle
12. **SCDWG Coordination**: Formalize data exchange timeline with SERC's Short Circuit Database Working Group

---

# Chunk 16 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document chunk is from the SPP (Southwest Power Pool) Model Development Procedure Manual, specifically covering technical data field specifications and administrative procedures. The content primarily consists of:
- Technical data field listings for two-terminal DC tie configurations
- Appendices covering impedance correction tables, MOD-032-1 data submittal assignments
- Detailed GMD/GIC (Geomagnetic Disturbance/Geomagnetically-Induced Current) data collection requirements
- A formal letter template for designating data submission responsibilities between Data Owners and Data Submitters

This is a technical procedures manual section rather than meeting minutes, establishing standardized processes for power system modeling data collection and submission.

## 2. Key Topics

- **PSS®E Data Format Compatibility**: All data formats must align with PSS®E (Power System Simulator for Engineering) input requirements
- **MOD-032-1 NERC Reliability Standard Compliance**: Data submission requirements and assignment procedures
- **GMD/GIC Modeling Data Requirements**: Comprehensive specifications for geomagnetic disturbance analysis
- **Substation Data Collection**: Geographic and electrical grounding information requirements
- **Transformer Modeling Specifications**: Detailed technical parameters including K-factor, core types, winding resistance
- **Data Owner vs. Data Submitter Responsibilities**: Clear delineation that accuracy remains with Data Owner even when submission is delegated

## 3. Decisions or Actions

- **Data Format Standardization**: Mandated use of PSS®E-compatible formats
- **Date Format Requirement**: In-service and out-of-service dates must be expressed as mm/dd/yyyy
- **Delegation Process Established**: Formal mechanism for Data Owners to designate Data Submitters via written notice
- **Earth Model Assignment**: USGS-based one-dimensional earth conductivity models to be applied based on geographic location
- **Transformer Data Conversion Rule**: Three-phase combined resistance data must be divided by three for per-phase submission
- **Temperature Standardization**: DC resistance measurements adjusted to 75°C

## 4. Important Dates

- **Date Format Standard**: mm/dd/yyyy required for all in-service and out-of-service dates
- **No specific calendar dates mentioned** in this chunk; the Letter of Notice template includes blank date fields to be completed upon execution

## 5. Organizations and People Mentioned

### Organizations:
- **Southwest Power Pool, Inc. (SPP)** - Planning Coordinator
- **NERC** (North American Electric Reliability Corporation) - Standards authority
- **MDAG** (Model Development Advisory Group) - Model development entity
- **United States Geological Survey (USGS)** - Earth conductivity model source
- **Siemens/PTI** - Software provider

### Email Contact:
- SPPEngineeringModeling@spp.org (for designation revocations)

### Roles Referenced:
- Data Owner
- Data Submitter
- Planning Coordinator

## 6. Links or References

### Standards and Regulations:
- **NERC Reliability Standard MOD-032-1** (and specifically R2 requirement and Attachment 1)

### Software:
- **PSS®E** (Power System Simulator for Engineering)

### Technical Models:
- **USGS standard earth conductivity models**
- **SPP MDAG steady-state models**
- **SPP GMD Model Set**

### Internal References:
- Section 8: Appendix II - Utilized Impedance Correction Tables
- Section 9: Appendix III - Designating MOD-032-1 Data Submittal Assignment
- Section 10: Appendix IV - SPP Model On Demand (MOD) Matrix
- Section 11: Appendix V - GMD/GIC Data Collection Template User's Guide
- "1D Earth Model Reference" sheet
- "Busses" sheet
- "Substations" sheet
- "Transformers" sheet

## 7. Suggested Tags

- Power System Modeling
- NERC Compliance
- MOD-032-1
- GMD/GIC Analysis
- Geomagnetic Disturbance
- Data Submission Procedures
- PSS®E
- Transformer Modeling
- Substation Data
- SPP Procedures
- Reliability Standards
- Grid Modeling
- DC Tie Data
- K-Factor
- Winding Resistance
- Earth Conductivity Models

## 8. Items That May Need Follow-Up

### Technical Clarifications Needed:
1. **K-factor Assumption Table**: The document references "the following table" for K-factor values but the table appears to be cut off in this chunk
2. **Connection Code Review**: Suggested review of vector group and winding order for proper CC submittal indicates potential data quality issues
3. **Unknown Core Configurations**: When core type is unknown, software makes assumptions - may need validation process
4. **Earth Model Tool**: References a tool on "1D Earth Model Reference" sheet - verification of tool availability and accuracy

### Administrative Follow-Up:
5. **Delegation Agreements**: Monitor and track active Data Owner/Data Submitter delegation agreements
6. **Revocation Process**: Establish tracking system for written revocations sent to SPPEngineeringModeling@spp.org
7. **Compliance Responsibility**: Ensure Data Owners understand that delegation doesn't shift compliance obligations

### Data Quality Concerns:
8. **Estimated vs. Actual Data**: Document states "estimated values should only be used when data are unavailable" - need audit process
9. **Grounding Resistance Values**: Special handling of "-1" for ungrounded substations requires validation
10. **Transformer Resistance Division**: Three-phase to per-phase conversion - potential source of errors requiring quality control
11. **Temperature Adjustment**: 75°C adjustment requirement may need standardized calculation guidance

### Procedural Updates:
12. **Model Development Schedule**: References "then-effective SPP MOD-032 Model Development Procedure Manual" suggesting version control needs
13. **SPP Modeling Data Requests**: Schedule coordination between multiple procedural documents

---

# Chunk 17 Analysis

# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document section is a technical manual excerpt detailing data collection requirements for Geomagnetically Induced Current (GIC) analysis modeling in the SPP (Southwest Power Pool) Model Development And Governance (MDAG) process. The content provides comprehensive technical specifications for modeling transformers, shunts, transmission branches, and loads in DC network analysis for Geomagnetic Disturbance (GMD) events. The manual establishes standardized data submission requirements, measurement protocols (primarily DC resistance at specific temperatures), and modeling conventions to ensure accurate GIC flow analysis during GMD events, in compliance with TPL-007-3 reliability standards.

## 2. Key Topics

- **GIC Blocking Device Specifications**: Status and DC resistance requirements for blocking devices on transformer windings
- **Transformer Modeling in DC Networks**: Vector group representation vs. T-model representation; special handling of symmetric phase shifting transformers
- **Shunt Device Data Collection**: Line reactors and fixed shunts modeling approaches; distinction between explicit bus modeling and branch incorporation
- **Transmission Line Branch Characteristics**: DC resistance requirements at 50°C; AC vs. DC resistance considerations for bundled conductors
- **GMD-Induced Electric Field**: Real and imaginary field components per TPL-007-3 reference (8V/km standard)
- **Temperature Standardization**: DC resistance measurements adjusted to 75°C for equipment; 50°C for transmission lines
- **Load Modeling Exceptions**: Rare EHV/HV level loads offering ground paths for GIC
- **Per-Unit vs. Actual Ohmic Values**: Consistent requirement to retain actual Ohmic quantities rather than per-unit conversions

## 3. Decisions or Actions

**Explicit Requirements:**
- Data Submitters must avoid entering "1" in Transformer Model in DC Network field when vector groups are defined
- All transmission line conductor DC resistances shall be entered at 50°C
- Do not convert resistances to per-unit Ohms per phase; retain actual Ohmic quantities
- AC resistances at temperatures greater than 50°C must be corrected to 50°C before use
- Leave electric field values blank (not zero) to apply uniform electric field automatically
- Do not enter all loads into Loads sheet—only exceptions at EHV/HV levels with ground paths

**Recommended Actions:**
- Confirm how line shunts are being modeled (explicit vs. incorporated into branch)
- Use measured values from specification sheets or test reports when available
- For conservative GMD studies, use smaller DC resistance values (hence 50°C standard)

## 4. Important Dates

- No specific dates mentioned in this excerpt

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)**: Primary organization for the model
- **MDAG (Model Development and Governance)**: Group managing model data collection

**People:**
- **HILL**: Referenced in source filename as editor

**Software/Standards:**
- **PSS®E**: Load flow software with GIC analysis module
- **TPL-007-3**: NERC reliability standard for GMD events (reference geoelectric field of 8V/km)

## 6. Links or References

**Standards Referenced:**
- TPL-007-3 (reference geoelectric field of 8V/km for benchmark GMD events)

**Technical Documents Referenced:**
- Shunt specification sheets
- Transformer test reports
- Ground grid designs
- Step-down transformer specification sheets

**Model Components:**
- Vector groups (YNa with Connection Codes 9 or 19)
- MW symmetrical/asymmetrical PAR control modes

## 7. Suggested Tags

- GIC Analysis
- Geomagnetic Disturbance (GMD)
- SPP MDAG Model
- DC Network Modeling
- Transformer Modeling
- TPL-007-3
- Transmission Line Resistance
- Power System Reliability
- Blocking Devices
- Shunt Modeling
- Load Flow Analysis
- PSS®E Software
- Electric Field Modeling
- Ground Path Analysis
- Vector Group Configuration

## 8. Items That May Need Follow-Up

**Technical Clarifications Needed:**
1. **PSS®E Software Ambiguity**: Outstanding software ambiguity for symmetric phase shifting transformers mentioned but not detailed
2. **Future Field Elimination**: "Transformer Model in DC Network" field may be eliminated in future revisions—timeline unclear
3. **Future Blocking Device Modeling**: Expected future software versions to support actual DC resistance vs. current infinite resistance assumption

**Data Quality Concerns:**
1. **Inconsistent Line Reactor Modeling**: Practice varies among model builders (explicit vs. incorporated); requires confirmation process
2. **AC vs. DC Resistance**: Non-linear temperature variations may cause significant differences, especially for bundled conductors above 50°C
3. **Missing Measurement Guidance**: What to do when measured values from specification sheets/test reports are unavailable

**Procedural Questions:**
1. How to handle transmission lines where temperature-adjusted resistance data is unavailable?
2. What validation process exists for confirming shunt modeling method choices?
3. How are exceptions for buried/undersea transmission cables formally documented?
4. What is the threshold for determining "rare" EHV/HV loads that should be included?

**Potential Compliance Issues:**
1. Risk of zeros being entered in electric field values when blanks are required
2. Potential confusion between per-unit and actual Ohmic values across different submitters
3. Temperature correction requirements may be overlooked for AC resistances above 50°C

---

# Chunk 18 Analysis

# Regulatory Meeting/Page Content Analysis Report

## 1. Executive Summary

This document is chunk 18 of 20 from the SPP Model Development Procedure Manual (HILL Edits version). It contains detailed technical appendices covering renewable energy resource modeling methodologies, load forecasting examples, NERC MOD-032-1 compliance requirements, and the Five-Year Average Enhancement (FYAE) methodology for variable energy resources. The document also includes a comprehensive version control table showing the manual's evolution from 2018 to 2025, with version 9.0 being the current edition applicable to the 2026 Series MDAG Model Build. Key content focuses on data-driven approaches to modeling wind and solar generation, load forecasting techniques, and compliance with transmission planning requirements.

## 2. Key Topics

- **Load Forecasting Methodology**: 50/50 load forecast example using historical demand data and compound annual growth rate (CAGR) calculations
- **Five-Year Average Enhancement (FYAE) Methodology**: Comprehensive process for modeling variable energy resources (wind and solar)
- **Renewable Plant Modeling**: Data collection, conversion to per-unit values, statistical evaluation using seasonal mean values
- **NERC MOD-032-1 Compliance**: Data requirements for transmission system modeling
- **Data Quality Assurance**: Procedures for identifying and handling erroneous renewable generation data
- **Seasonal Modeling Definitions**: Date ranges for Spring, Summer, Fall, Winter, and shoulder periods
- **Generator State Modeling**: Treatment of online, offline, and decommissioned generation
- **Dynamic Model Parameters**: Required parameters for various generator types including synchronous and renewable resources

## 3. Decisions or Actions

- **Data Threshold Established**: Individual renewable plants must have data points meeting or exceeding 25% of initial seasonal system load hours; otherwise, state averages are used as replacement data
- **Linear Regression Application**: Example shows +0.9667 MW/year trend equating to 6.73% CAGR for load growth
- **Erroneous Data Exclusion**: Data points where Pgen > Pmax should be reviewed and excluded if Pmax is correct
- **State Average Replacement**: When insufficient data exists, state averages by fuel type (wind/solar) should be used
- **Solar Replacement Data**: Process for solar farm replacement data is still under development by MDAG
- **Version Updates**: Manual updated to version 9.0 for 2026 Series MDAG Model Build, including updated MOD Matrix to include BP 7400 process

## 4. Important Dates

### Seasonal Date Ranges:
- **Spring/Light Load**: April 1 – May 31 (Cutoff: May 1)
- **Summer/Summer Shoulder**: June 1 – September 30 (Cutoff: August 1)
- **Fall**: October 1 – November 30 (Cutoff: November 1)
- **Winter**: December 1 – March 31 (Cutoff: February 1 of following year)

### Version History Milestones:
- **June 21, 2018**: Initial format update
- **2025 v9.0**: Current version for 2026 Series MDAG Model Build
- **Historical Updates**: Annual major versions from 2020-2025 (v4.0 through v9.0)

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)**: Primary organization
- **MDAG (Model Development Advisory Group)**: Responsible for manual maintenance and process development
- **NERC (North American Electric Reliability Corporation)**: Regulatory authority (MOD-032-1 standard)
- **Planning Coordinator (PC)**
- **Transmission Owner (TO)**
- **Transmission Planner (TP)**
- **EDST**: Entity referenced for submission processes

### People:
- **HILL**: Referenced in document title as editor
- **SPP Engineering Modeling**: Author of all version updates (2018-2025)

## 6. Links or References

- **MOD-032-1 – Attachment 1**: NERC standard for data requirements for transmission system modeling
- **Table 1 of the Model Development Procedure Manual**: Referenced for seasonal date range definitions
- **Planning Criteria for Material Modifications**: Referenced in 2023 v7.0 update
- **RMS version**: Referenced for transmission map/model requests
- **BP 7400 process**: Added to MOD Matrix in version 9.0
- **TPL-001**: Outage review reference (added in 2021 v5.0)
- **Attachment AJ**: Referenced for seasonal ratings updates

## 7. Suggested Tags

- Model Development
- Renewable Energy Modeling
- Wind Generation
- Solar Generation
- Load Forecasting
- NERC Compliance
- MOD-032-1
- FYAE Methodology
- Transmission Planning
- Data Quality Assurance
- MDAG
- SPP Engineering
- Variable Energy Resources
- Power System Modeling
- Seasonal Analysis
- Generator Modeling
- Dynamic Modeling

## 8. Items That May Need Follow-Up

1. **Solar Replacement Data Development**: Document explicitly states that the process for solar farm replacement data is "still under development with the Model Development Advisory Group (MDAG) and may be added here in the future"

2. **25% Data Threshold Validation**: The 25% threshold for renewable plant data points requires monitoring to ensure it provides adequate confidence levels for typical output determination

3. **State Average Calculation Verification**: Need to ensure 10 typical seasonal output values per state (5 wind, 5 solar) are being properly calculated and maintained

4. **Erroneous Data Review Process**: Ongoing need to review renewable plants where Pgen > Pmax and verify Power Generator Maximum Capability values

5. **BP 7400 Process Integration**: Recently added to MOD Matrix in v9.0; implementation and compliance should be monitored

6. **Annual Version Updates**: Next update (v10.0) would be expected for 2027 Series MDAG Model Build

7. **Outlier System Load Hours**: Document recommends reviewing daily peaks and minimums during the FYAE process; formalized procedures may be needed

8. **Mothballed Generation Clarification**: Added in 2023 v7.0; may need ongoing refinement

9. **Battery Modeling and Seasonal Dispatching**: Added in 2022 v6.0; relatively recent addition that may require ongoing refinement

10. **Generator Retirement Language**: Updated in 2024 v8.1 for EDST submissions; ensure consistent application across stakeholders

---

# Chunk 19 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary

This document segment is from the SPP (Southwest Power Pool) Model Development Procedure Manual and contains critical operational tables defining data validation procedures, dynamic model update protocols, and project classification systems. The content establishes standardized procedures for managing transmission system model data quality, handling various types of system modifications, and categorizing projects based on approval status and regulatory requirements. The tables provide comprehensive guidance for data submitters on acceptable data standards, correction methods, and project documentation requirements.

## 2. Key Topics

- **Model Data Quality Control**: Table 9 establishes comprehensive criteria for identifying and resolving unacceptable model data, including branch overloads, voltage violations, and transformer issues
- **Dynamic Model Updates**: Table 10 provides detailed procedures for modifying, adding, deleting, and replacing dynamics models in power system simulations
- **Project Classification System**: Table 11 defines multiple project types including SPP-approved transmission upgrades, planned transmission changes, Attachment AQ modifications, and generation interconnections
- **Data Validation Standards**: Distinction between "Exception" and "Overridden" status for various model data issues
- **Regulatory Compliance**: Requirements for NTC (Notice to Construct), PID, UID numbers, and compliance with SPP OATT (Open Access Transmission Tariff) Attachments O, V, and AQ

## 3. Decisions or Actions

- **Mandatory Resolutions**: All unacceptable model data must be either resolved or formally designated as "Exception" or "Overridden"
- **RMS Ticket Requirement**: Data Submitters must submit RMS tickets for Planned Transmission System Changes using the TO Project Evaluation Process Request Form
- **Immediate Commitment**: "Modeling Correction" projects are immediately committed to MOD base case upon review
- **Exclusion Policy**: Speculative projects will not be reviewed by SPP or included in model sets
- **Approval Requirements**: Generation Interconnection projects must have executed IA or IGIA and not be suspended for inclusion

## 4. Important Dates

- **In Service/Out of Service Dates**: Required for new generating units (specific dates not provided in this excerpt)
- No specific calendar dates mentioned; references are procedural timeframes

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)**: Primary regulatory authority
- **MMWG (Market & Modeling Working Group)**: Review body for system models
- **Data Submitters**: Entities responsible for providing model data
- **Transmission Owners (TO)**: Entities submitting project evaluations
- **Transmission Customers**: Entities requesting transmission services

### Specific Examples Referenced:
- BEPC (example organization)
- WFEC (Westar/WestPlains Energy)
- NextEra (generation company)

## 6. Links or References

### Internal References:
- SPP OATT (Open Access Transmission Tariff)
  - Attachment V (generation interconnection processes)
  - Attachment O (planning processes)
  - Attachment AQ (load modification procedures)
- SPP.org website: Engineering > Modeling > Related Documents
- TO Project Evaluation Process Request Form
- Generator Interconnection Procedure (GIP)

### Document Types Referenced:
- NTC (Notice to Construct)
- PID (Project Identification)
- UID (Unit Identification)
- DPA/DPNS numbers
- Interconnection Agreement (IA)
- Interim Generator Interconnection Agreement (IGIA)

## 7. Suggested Tags

`power-system-modeling` `transmission-planning` `data-validation` `SPP` `regulatory-compliance` `generation-interconnection` `transmission-upgrades` `model-development` `OATT` `project-classification` `dynamics-modeling` `voltage-control` `base-case-development` `MMWG` `network-topology` `quality-control` `attachment-AQ` `NTC-requirements`

## 8. Items That May Need Follow-Up

### Clarification Needed:
1. **Exception vs. Overridden Distinction**: What are the specific criteria and implications for designating data issues as "Exception" versus "Overridden"?
2. **Voltage Criteria Standards**: What are the specific MMWG voltage criteria referenced for System Intact Alteration projects?
3. **Acknowledgement Process**: What is the specific timeline and process for SPP to acknowledge "Planned Transmission System Change" projects?

### Process Questions:
4. **Speculative Project Handling**: What happens to speculative projects if they later gain budgetary approval?
5. **RMS Ticket Response Time**: What is the expected SPP response timeframe for RMS ticket submissions?
6. **Model Set Application**: Clear definition needed for which model sets (MDAG, ITP, TS, GI, Special Study) apply to each project type

### Documentation Requirements:
7. **Naming Convention Compliance**: Verification process for proper project/individual naming conventions with area/owner/zone numbers
8. **Suspended GI Projects**: Specific procedures for handling generation interconnection projects that become suspended after initial approval
9. **Emergency Changes**: Fast-track procedures for transmission changes resulting from equipment failures

### Coordination Items:
10. **TO Project Evaluation Form**: Availability and accessibility of the form on SPP.org website should be verified
11. **Balanced Portfolio Process**: Additional documentation needed on how this process integrates with transmission upgrades
12. **High Priority Study Process**: Further clarification on criteria for high priority transmission changes

---

# Chunk 20 Analysis

# Regulatory Content Analysis Report

## 1. Executive Summary

This document appears to be the final section (chunk 20 of 20) of the SPP (Southwest Power Pool) Model Development Procedure Manual with edits by HILL. The content consists exclusively of technical reference tables (Tables 12-20) providing standardized data specifications for power system modeling. The tables cover earth conductivity models, transformer core designs, load forecasting examples, and comprehensive data requirements for steady-state, dynamic, and short-circuit power system studies.

## 2. Key Topics

- **Geomagnetic Modeling**: USGS earth conductivity models mapped to Siemens/PTI software codes for various North American regions
- **Transformer Technical Specifications**: Core design types and K-factor calculations based on voltage levels
- **Load Forecasting Methodology**: Historical load analysis and median-based forecasting examples
- **Power System Modeling Data Requirements**: Comprehensive specifications for:
  - Steady-state analysis (bus, generator, transmission, transformer, reactive compensation data)
  - Dynamic modeling (excitation systems, governors, stabilizers, renewable energy systems)
  - Short-circuit analysis (sequence impedance data)
- **Seasonal Load Analysis**: Methodologies for peak and light load conditions across seasons
- **Renewable Energy Integration**: Wind farm capacity factor data by season and state

## 3. Decisions or Actions

No explicit decisions or action items are identified in this content. This section serves as a technical reference appendix providing standardized tables and data specifications that support the procedures described in earlier sections of the manual.

## 4. Important Dates

**Historical Data Period**: 2012-2020 (Table 15 - Feeder A historical demand)

**Forecast Period**: 2021-2030 (Table 16 - Feeder A forecasted demand)

Note: These dates appear in example tables and may not represent actual planning timelines.

## 5. Organizations and People Mentioned

### Organizations:
- **SPP** (Southwest Power Pool) - Implied owner/publisher of the manual
- **USGS** (United States Geological Survey) - Earth conductivity model source
- **Siemens/PTI** - Software vendor (power systems analysis software)

### Geographic Regions Referenced:
- Canadian Provinces: British Columbia (BC), Alberta (AB), Saskatchewan (SK), Manitoba (MB), Ontario (ON), Quebec (QC)
- U.S. States: Kansas, Missouri, Oklahoma, Florida, North Dakota, Michigan, South Carolina, Georgia
- Geographic Features: Adirondack Mountains, Appalachian Plateaus, Rocky Mountains, Columbia Plateau, Colorado Plateau, etc.

### Functional Entities (by NERC registration):
- **BA** (Balancing Authority)
- **GO** (Generator Owner)
- **LSE** (Load Serving Entity)
- **TO** (Transmission Owner)
- **TSP** (Transmission Service Provider)
- **RP** (Resource Planner - for future planned resources)
- **Planning Coordinator**
- **Transmission Planner**

### Editor:
- **HILL** - Individual or organization responsible for edits to this version

## 6. Links or References

### Software Systems:
- Siemens/PTI software platform (for power system modeling)

### Technical Standards/Models:
- USGS Earth Conductivity Models
- NERC functional entity definitions (implied)

### Related Documentation (Implied):
- Earlier sections of the SPP Model Development Procedure Manual (chunks 1-19)
- NERC reliability standards for model data requirements

**Note**: No URLs or explicit document references are provided in this section.

## 7. Suggested Tags

- `SPP`
- `Model Development`
- `Power System Modeling`
- `Earth Conductivity`
- `Transformer Specifications`
- `Load Forecasting`
- `Steady-State Analysis`
- `Dynamic Modeling`
- `Short-Circuit Analysis`
- `USGS`
- `Siemens-PTI`
- `NERC`
- `Transmission Planning`
- `Generator Data`
- `Wind Farm Modeling`
- `Renewable Energy`
- `Technical Reference`
- `Procedure Manual`
- `Data Requirements`
- `Seasonal Load Analysis`

## 8. Items That May Need Follow-Up

### Technical Clarifications Needed:

1. **Table 12 Inconsistencies**:
   - "MID-ATL" shows as equivalent to "PT-1" but PT-1 is separately defined as "Piedmont"
   - "SD" and "SHIELD" appear to have mapping issues (PB-1 listed as equivalent, but PB-1 is Pacific Border)
   - "PRAIRIES" spelling discrepancy (table shows "PRARIES" in software code column)
   - These may be errors requiring correction

2. **Florida Model (FL-1)**: Listed as having "none" for software code - clarify if this is intentional or requires addition

3. **Table 17 Completeness**: 
   - Verify if this represents the complete data requirements or if additional parameters exist in other sections
   - Confirm requirements for "user-written models" submission process

4. **Seasonal Definitions (Table 18)**:
   - "Fall" category appears to be missing specific exclusion criteria
   - Clarify if this is a formatting issue or intentional

5. **Example Data Context**:
   - Tables 15-16 (Feeder A), Table 19 (Wind Farms 1-3), and Table 20 (state averages) use placeholder data
   - Confirm whether these should be replaced with actual system data or remain as examples

6. **Cross-Reference Verification**:
   - Verify that all entities mentioned in Table 17 data requirements align with earlier procedural sections
   - Confirm that all NERC functional entity abbreviations are used consistently throughout the complete manual

7. **Version Control**:
   - Determine if "HILL Edits" represent the final approved version or if additional review is pending
   - Establish whether this is subject to formal approval process

### Recommendations:
- Conduct technical review of Table 12 mappings for accuracy
- Validate all example tables are clearly marked as examples vs. actual requirements
- Ensure complete manual (all 20 chunks) undergoes final consistency check before publication