# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document outlines the High Impact Large Load (HILL) Assessment process implementation at Southwest Power Pool, Inc. (SPP). The HILL process, which became effective January 15, 2026, establishes procedures for studying large load requests through either Attachment AQ or Attachment AX processes. The document was last revised June 12, 2026, and describes submission requirements, study timelines (90 calendar days), and how two revision requests (RR696 and RR724) impact existing processes. Key updates include new load modeling data requirements, changes to zonal planning criteria, and a 5-year minimum requirement for Designated Resources.

## 2. Key Topics

- **HILL Classification**: Definition and determination criteria based on load size, type, and interconnection voltage per OATT Part I Definitions
- **Two Study Pathways**: 
  - Attachment AQ (for customers with sufficient Designated Resources)
  - Attachment AX (for customers without sufficient Designated Resources)
- **HILL Delivery Point Study (HDPS)**: 90-day study process including steady-state, transient stability dynamics, short circuit ratio, and SCRCCT screening
- **Study Requirements**: Detailed submission requirements for both AQ and AX processes
- **Network Upgrades**: Cost allocation differences between processes (Base Plan funding vs. Directly Assigned)
- **Electromagnetic Transient (EMT) Analysis**: Additional analysis required if SCRCCT fails
- **Provisional Service Agreement**: Transitional mechanism for AX process

## 3. Decisions or Actions

### Completed Actions:
- HILL process (RR696) became effective 1/15/2026
- RR720 became effective 7/1/2026, giving Transmission Customers with Designated Resources headroom the choice to submit in AQ or AX

### Required Actions:
- Transmission Customers must submit fully completed DPA Request Form or Provisional Load Process Request Form to loadstudies@spp.org
- Customers must execute HDPS Agreement within 30 calendar days (AX process)
- SPP must coordinate scoping call within 10 days of receiving all required data
- SPP must complete HDPS within 90 calendar days
- Host TO must perform Load Connection Study within 90 calendar days
- TC must notify SPP of intent to add new load within one year of posting HDPS results
- Transmission Customers required to provide additional load modeling data (per RR724)

### Process Changes (RR724):
- Project selection criteria will replace existing least-cost solution method
- Zonal Planning Criteria now addressed by Zonal Reliability Upgrades
- Minimum 5-year requirement implemented for Designated Resources

## 4. Important Dates

- **January 15, 2026**: HILL process (RR696) became effective
- **June 12, 2026**: Document last revised
- **July 1, 2026**: RR720 effective date (customer choice provision)
- **90 calendar days**: Study completion timeline from valid request
- **30 calendar days**: Deadline for TC to submit executed HDPS Agreement and deposit (AX process)
- **10 days**: Timeframe for coordinating scoping call after receiving required data
- **One year**: Validity period for HDPS results after study completion
- **One year**: Deadline for TC to notify SPP of intent to add new load after HDPS results posting
- **5 years**: Minimum requirement for Designated Resources to cover load requests

## 5. Organizations and People Mentioned

### Organizations:
- **Southwest Power Pool, Inc. (SPP)** - Primary regulatory organization
- **Transmission Customer (TC)** - Entity requesting load service
- **Host Transmission Owner (TO)** - Responsible for Load Connection Study and upgrades
- **OATT (Open Access Transmission Tariff)** - Governing regulatory framework

### Contact/Submission Information:
- **Email**: loadstudies@spp.org

### Referenced Entities:
- Aggregate Transmission Service Study (ATSS)
- Network Integrated Transmission Service Agreement (NITSA)
- Generator Outlet Facility (GOF)

## 6. Links or References

### External References:
- SPP Tariff Attachment AQ
- SPP Tariff Attachment AX
- SPP Studies page on OASIS
- Business Practice 7850 (Delivery Point Additions, Modifications, and Retirements Procedures)
- Additional HILL Characteristics Form (located in Business Practice 7850)
- Load Study (AX and AQ) FAQs, Guidelines and Request Forms

### Referenced Documents:
- DPA Request Form (Addendum 1 to Attachment AQ)
- Provisional Load Process Request Form
- HDPS Agreement
- Open Access Transmission Tariff Business Practices

### Technical Requirements:
- IDEV files
- DYR files
- Load Modeling Data [CMLD and/or PERC1 (preferred)]
- PSCAD model (recommended for EMT analysis)

### Revision Requests:
- **RR696**: Established HILL process
- **RR720**: Customer choice provision
- **RR724**: Impacts to existing processes

## 7. Suggested Tags

- High Impact Large Load (HILL)
- HILL Assessment
- SPP
- Attachment AQ
- Attachment AX
- HDPS (HILL Delivery Point Study)
- Transmission Planning
- Load Studies
- Network Upgrades
- Designated Resources
- OATT
- RR696
- RR724
- RR720
- Business Practice 7850
- Provisional Service Agreement
- NITSA
- Electromagnetic Transient Analysis
- SCRCCT
- Power System Studies
- Transmission Customer
- Load Modeling

## 8. Items That May Need Follow-Up

### Immediate Follow-Up Needed:
1. **EMT Analysis Timeline**: Document states EMT analysis is required "outside of the 90-day study timeline" if SCRCCT fails - need clarification on expected timeline and resource requirements
2. **PSCAD Model Submission**: While "recommended," unclear if this becomes mandatory when SCRCCT screening indicates potential failure

### Process Clarification Required:
3. **Project Selection Criteria**: RR724 mentions implementation of new criteria to replace least-cost solution method - details not provided in this document
4. **Cost Allocation Transition**: Process for moving Network Upgrade costs from "Directly Assigned" to "Base Plan funding" when resource is granted firm service needs detailed procedures
5. **Affected System Studies**: Document mentions these are "evaluated for impact and studied if needed" but doesn't specify criteria for determining when study is needed

### Documentation Gaps:
6. **Deposit Amounts**: No mention of required deposit amounts for HDPS studies
7. **Scoping Call Outcomes**: No documented process for what happens if parties cannot agree during scoping call
8. **Study Agreement Templates**: References to "fully executed HDPS Agreement" but no details on terms or standard language
9. **Five-Year Designated Resources Requirement**: Implementation details and verification process not specified

### Compliance Monitoring:
10. **One-Year Validity Enforcement**: Need process for tracking and managing studies approaching one-year expiration
11. **RR724 Implementation Status**: Document describes future changes but unclear if fully implemented as of June 12, 2026 revision date
12. **Zonal Reliability Upgrades**: New approach mentioned but process details not included

### Stakeholder Communication:
13. **FAQ Document**: Referenced but need to verify it addresses all procedural questions
14. **Training Requirements**: No mention of training for Transmission Customers on new requirements under RR724