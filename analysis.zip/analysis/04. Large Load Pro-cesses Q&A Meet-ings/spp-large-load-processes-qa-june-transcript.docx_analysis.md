# Final Combined Report

# COMPREHENSIVE REGULATORY MEETING ANALYSIS REPORT
## SPP Large Load Processes Q&A Session - June 4, 2026

---

## 1. EXECUTIVE SUMMARY

This report analyzes a 78-minute SPP (Southwest Power Pool) Large Load Processes Q&A session held on June 4, 2026, led by Nolan Fertig with participation from SPP staff across multiple departments (APUAX, TS, Helga, SVP markets). The session addressed critical questions regarding large load interconnections—particularly focused on data center loads—using the AQ (Attachment AQ) and AX processes.

**Key Focus Areas:**
- **HILL vs. CHILL Service**: Firm service (HILL) versus conditional firm service (CHILL) for large loads, including 7-year term limitations and non-renewability provisions
- **HILLGA Process**: High Impact Large Load Generation Agreement requirements, including proximity rules, generation accreditation, and study timelines
- **Study Coordination**: Handling discrepancies between transmission owner studies and SPP studies, pre-existing violations, and integration with ITP (Integrated Transmission Planning)
- **RR724 Implementation**: New tariff improvements addressing zonal planning upgrades, MW mile criteria, and enforceable TO study deadlines

**Format Note**: The meeting relies on pre-submitted questions via RMS (Request Management System) rather than ad-hoc inquiries, with only 4 questions received since the April 2026 meeting.

---

## 2. KEY TOPICS

### A. Service Types and Requirements

**HILL Service (Firm Service)**
- Permanent firm transmission service for large loads
- Requires either local generation via HILLGA or firm transmission service procurement
- No term limitations once established

**CHILL Service (Conditional Firm Service)**
- Maximum 7-year term, non-renewable
- Can be transmission-limited or generation-limited
- Change of ownership does not reset timeline
- Multiple CHILL services at single interconnection point require distinct metering
- Generation must be available for market dispatch to qualify

**Mixed Configurations**
- Loads can combine HILL and CHILL service (e.g., 300 MW firm + 200 MW conditional for 500 MW data center)
- Common bus vs. local area configurations have different permanence implications

### B. HILLGA (High Impact Large Load Generation Agreement)

**Proximity Requirements**
- **Common Bus**: Generation directly connected to same bus as load (no additional firm transmission service required if non-jurisdictional)
- **Two-Bus Rule**: Generation up to two substations away (all voltage levels within single substation count as one bus per Attachment BB, Section 313)
- Generation accreditation varies by type (e.g., 20% for wind requires 500 MW to support 100 MW load)

**Study Process**
- 90-day study timeline under Attachment BB
- Separate from ICS (Interconnection Customer Service) studies
- Subject to JTIQ screening (though designed for zero grid impact)
- Direct assignment upgrade costs apply (not Grid C charges)

**Term Limits**
- Local area HILLGA: 5-year term
- Common bus non-jurisdictional HILLGA: Permanent (potential conflict with 7-year CHILL maximum needs clarification)

### C. Study Coordination and Processes

**Study Timeline Requirements**
- 60 days standard for TO studies (90 days for "hills")
- Approximately 90-day study period for SPP load studies
- 45 days for transmission customer onboarding
- Two-week window for reactive setting adjustments

**Model Precedence**
- SPP study models take precedence over TO models when issuing NDCs (Network Delivery Commitments)
- Developers can request ITPBR models through RMS with NDA but cannot access actual AQ models

**Pre-existing Violations**
- Load studies address only new violations, not pre-existing base case violations
- Pre-existing violations handled through ITP/CPP (Consolidated Planning Process)
- SPP considers TO/CEO feedback on pre-existing violations but won't issue NTCs for them

### D. RR724 Tariff Improvements

- Zonal planning upgrade criteria and authority
- MW mile criteria implementation
- Enforceable TO study deadlines (60/90 days) with FERC escalation mechanism
- Shift from least-cost solution to ATC/CLR/CVR value-based project selection

### E. AQ vs. AX Processes

**AQ Process**
- For loads with existing designated resources
- Specific modeling approaches for hill service requests

**AX Process**
- "Bring your own generation" pathway
- Can submit even with generation shortfall if bringing sufficient generation to cover deficiency plus new load
- Allows planned resources rather than existing

### F. Regulatory and Credit Generation

**RERA (Retail Electric Regulatory Authority)**
- SPP can study load without RERA approval
- Approval must occur before load connection (per Attachment BA, Section 1)
- Potential for approval process to extend beyond 90-day study period

**Credit Generation**
- Mapping credit generation to specific loads
- Distance limitations for credit generation from load
- Business case considerations for generation location

### G. BESS/ESRLA Integration

- ESRLA (Energy Storage Resource Interconnection Assessment) studies continue under GI group
- NERC facility requirement
- ESRLA clusters 1-6 nearing completion
- LCS (Local Coordination Studies) may be required by some TOs after ESRLA completion

---

## 3. DECISIONS OR ACTIONS

### Established Clarifications

1. **Study Model Hierarchy**: SPP study models take precedence over TO models for NDC issuance
2. **Violation Handling**: Load studies only address new violations; pre-existing violations handled through ITP/CPP
3. **TO Upgrade Path**: TOs can submit projects through sponsored upgrade processes or TOPE if they identify necessary upgrades not in SPP studies
4. **Reactive Settings**: Two-week window established for members to provide adjustments during annual model building
5. **Project Selection**: Implementation of CLR/CVR value-based criteria replacing solely least-cost solutions (RR 724)
6. **ESRLA Continuation**: Studies continue with GI group as NERC requirement
7. **CHILL Service Non-Renewal**: Confirmed 7-year maximum term with no renewal option; ownership changes don't reset timeline
8. **Metering Requirements**: Distinct metering required for each CHILL service at same interconnection point
9. **AX with Deficiency**: Submissions allowed if bringing sufficient generation to cover existing deficiency plus new load

### Action Items Identified

1. **July 2nd Meeting Topics**:
   - CHILLS framework timeline and Attachment P relationship
   - Common bus HILLGA and CHILL term interaction clarification
   - Multiple deferred technical questions with specific examples

2. **RMS Submissions Required**:
   - Multiple CHILL metering question (Robel Arega)
   - HILLGA wind generation variability scenario (Rafael Torres)
   - Common bus/firm service interaction example (Rafael Torres)
   - Incomplete credit generation mapping question (Robel Arega)

3. **Follow-up Research**:
   - Generation servicing CHILL loads with future generators
   - CHILL extension language correction
   - JTIQ impact on zero-impact HILLGA configurations

4. **Process Improvements**:
   - Encourage more RMS question submissions (only 4 received since April)
   - Monitor TO compliance with new 60/90-day study deadlines
   - Track implementation of zonal planning upgrade authority

---

## 4. IMPORTANT DATES

### Meeting Schedule
- **This Meeting**: June 4, 2026, 7:26 PM
- **Next Meeting**: July 2, 2026
- **Previous Meeting**: April 2026

### Process Timelines
- **60 days**: Standard TO study completion deadline
- **90 days**: TO study completion for "hills"; general SPP load study period
- **45 days**: Transmission customer onboarding process
- **Two weeks**: Reactive setting adjustment window (annual)

### Service Terms
- **5 years**: Local area HILLGA maximum term
- **7 years**: Maximum CHILL service term (all types)
- **Permanent**: Common bus non-jurisdictional HILLGA (potential conflict with 7-year CHILL limit)

### Study Status
- **ESRLA 1-6**: Nearing completion (referenced as

---

# Partial Chunk Reports

# Chunk 1 Analysis

# Regulatory Meeting Analysis Report

## 1. Executive Summary

This document is a transcript from SPP's (Southwest Power Pool) Large Load Processes Q&A session held on June 4, 2026. The 78-minute session was led by Nolan Fertig and included SPP staff from APUAX, TS, Helga, and SVP markets departments. The meeting addressed four pre-submitted questions regarding the AQ (Attachment AQ) and AX process for large load interconnections, focusing on study coordination between SPP and transmission owners, timelines, and how pre-existing violations are handled. The format relies on questions submitted via RMS (Request Management System) between meetings rather than ad-hoc inquiries.

## 2. Key Topics

- **Study Result Discrepancies**: How to handle cases where host transmission owner (TO) studies and SPP studies produce different results
- **Study Timeline Requirements**: Deadlines for transmission owners to complete load connection studies (60 days standard, 90 days for "hills")
- **Pre-existing Violations**: Treatment of base case violations versus new violations caused by proposed loads
- **ITP (Integrated Transmission Planning) Integration**: How already-identified SPP ITP upgrades affect load interconnection timelines
- **RR724 (Revision Request 724)**: New tariff improvements addressing zonal planning upgrades, MW mile criteria, and TO study deadlines
- **Chills Process**: Questions about timelines and attachment P references
- **Credit Generation**: Mapping credit generation to loads and distance limitations

## 3. Decisions or Actions

**Established Clarifications:**
- SPP study models take precedence over TO models when issuing NDCs (Network Delivery Commitments)
- Load studies only address new violations, not pre-existing base case violations
- Pre-existing violations are handled through ITP/CPP (Consolidated Planning Process)
- TOs can submit projects through sponsored upgrade processes or TOPE if they identify necessary upgrades not in SPP studies

**Action Items:**
- Question about Chills framework timeline and Attachment P relationship to be addressed at next meeting (July 2nd meeting)
- Members encouraged to submit scenario-based questions via RMS for upcoming meetings
- Incomplete question about credit generation mapping to be addressed

## 4. Important Dates

- **Meeting Date**: June 4, 2026, 7:26 PM
- **Next Meeting**: July 2, 2026 (referenced)
- **Study Deadlines**: 
  - 60 days from scoping call for standard TO studies
  - 90 days for "hills" studies
- **Previous Meeting**: April 2026 (referenced)

## 5. Organizations and People Mentioned

**Organizations:**
- SPP (Southwest Power Pool)
- FERC (Federal Energy Regulatory Commission)
- Plus Power (questioner's organization)

**People:**
- **Nolan Fertig** - SPP Staff, meeting facilitator
- **Allison** - SPP Staff contributor
- **Dalton Cyr** - Meeting participant
- **Robel Arega** - Plus Power representative, asked multiple questions
- **Beverly Laios** - Participant (brief interjection)
- **Alexander, James** - Listed participant
- **Martin** - Referenced participant

**Departments/Teams:**
- APUAX staff
- TS staff
- Helga staff
- SVP staff for markets

## 6. Links or References

**Tariff/Policy Documents:**
- **RR724** (Revision Request 724) - Attachment AQ improvements
- **Business Practice 7850** - Covers zonal planning upgrades and MW mile criteria
- **Business Practice 7400** - Delayed mitigations and NDC procedures
- **Attachment AQ and AX** - Load study processes
- **Attachment P** - Referenced in Chills process question
- **Section 3.1** - Post transmission owners' responsibilities

**Processes:**
- RMS (Request Management System) - Question submission portal
- ITP (Integrated Transmission Planning)
- CPP (Consolidated Planning Process)
- TOPE process - TO project submission
- Sponsored upgrade processes
- NDCs (Network Delivery Commitments)

## 7. Suggested Tags

- Large Load Interconnection
- Attachment AQ/AX
- SPP Studies
- Transmission Owner Studies
- RR724
- Study Timelines
- Network Delivery Commitments
- ITP Integration
- Zonal Planning Criteria
- Pre-existing Violations
- Chills Process
- Credit Generation
- Q&A Session
- Study Model Discrepancies

## 8. Items That May Need Follow-Up

**Immediate Follow-Up Required:**
1. **Chills Framework Timeline Question** (Robel Arega) - Deferred to July 2nd meeting
   - Needs clarification on which Attachment P timeline governs Chills process
   - Whether Chills adds additional timeline requirements beyond Attachment P

2. **Credit Generation Mapping** (Robel Arega) - Question incomplete/cut off
   - How to confirm credit generation is mapped to specific load
   - Distance limitations for credit generation from load
   - Special considerations when "hill becomes a chi" (transcript cut off)

**Process Improvements to Monitor:**
1. Effectiveness of RMS question submission process (only 4 questions received since April)
2. TO compliance with new 60/90-day study deadlines under RR724
3. Implementation of zonal planning upgrade authority in AQ/AX studies

**Potential Escalation Issues:**
1. TO study delays - now have FERC enforcement mechanism via tariff deadlines
2. Study result discrepancies requiring coordination meetings between SPP and TOs
3. Delayed ITP project mitigations affecting load interconnection timelines

**Unclear/Ambiguous Items:**
1. Exact process for escalating TO study delays to SPP and potentially FERC
2. How "different models" between TO and SPP are reconciled in practice
3. Relationship between load studies and broader ITP project timelines

---

# Chunk 2 Analysis

# Regulatory Meeting Analysis Report

## 1. Executive Summary

This document is a transcript from an SPP (Southwest Power Pool) Q&A session focused on large load interconnection processes, specifically discussing the HILLGA (High Impact Load Large Generation Agreement), CHILLS (Capacity and High Impact Large Load Service), and related study procedures. The meeting covers technical requirements for load interconnection, including proximity requirements, credit generation linkages, study timelines, regulatory approvals, and the differences between various service attachment processes (AQ vs. AX). Staff addressed multiple stakeholder questions about location requirements, pre-existing violations, BESS (Battery Energy Storage System) charging studies, and model availability.

## 2. Key Topics

- **HILLGA Process Requirements**: Two-bus proximity requirement for generation credit
- **CHILLS Service**: No specific location requirement, only accreditation requirement; can obtain through queue (transmission limited) or AX process
- **Credit Generation Distance**: Discussion of how far credit generation can be from load
- **Pre-existing Violations**: How SPP handles existing system issues in load studies (no NTCs issued but still considered)
- **Regulatory Approval (RERA)**: Timing requirements for retail electric regulatory authority approval
- **Study Timeline**: Approximately 90-day study period
- **Project Selection Criteria**: Shift from least-cost solution to ATC/CLR/CVR value-based selection
- **Reactive Setting Adjustments**: New two-week window for members to provide adjustments
- **BESS/ESRLA Process**: Continuation of ESRLA studies by GI group
- **Model Availability**: Questions about AQ model access for developers
- **AQ vs AX Processes**: Differences between existing designated resources (AQ) and planned resources (AX)

## 3. Decisions or Actions

- **Reactive Settings Process**: SPP now allows members a two-week period to provide reactive setting adjustments when building annual models
- **Pre-existing Violations**: SPP will consider TO/CEO feedback on pre-existing violations but won't issue NTCs for them
- **Project Selection**: Implementation of CLR/CVR value-based criteria instead of solely least-cost solutions (RR 724 change)
- **ESRLA Continuation**: ESRLA studies will continue to be performed by GI group as NERC facility requirement
- **RERA Approval Timing**: SPP can study load without RERA approval, but approval must occur before load connection

## 4. Important Dates

- **Study Period**: Approximately 90 days for load study process
- **Transmission Customer Onboarding**: About 45 days to become SPP transmission customer
- **Reactive Settings Window**: Two-week period provided annually for member input
- **ESRLA Clusters**: ESRLA 1-6 studies nearing completion (referenced as "coming to a close soon")
- **Attachment AQ Focus Group**: Occurred approximately 2 years prior to this meeting

## 5. Organizations and People Mentioned

**SPP Staff** (multiple unnamed representatives)

**Participants/Questioners:**
- **Beverly Laios**
- **Robel Arega** (multiple questions)
- **Cyr, Dalton** (questions about pre-existing violations)
- **Joey/Joe Foltz** (BESS charging studies question)
- **DITSCH, LOREN J** (Lauren Deech) - OPPD (Omaha Public Power District)
- **Speaker 1/Renee** (SPS - questions about voltage requirements)
- **Kevin** (acknowledged for contribution)

**Organizations:**
- SPP (Southwest Power Pool)
- OPPD (Omaha Public Power District)
- SPS
- Various TOs (Transmission Owners)
- TCs (Transmission Customers)
- NERC

## 6. Links or References

**Regulatory/Process References:**
- **Attachment BA** (Section 1 - RERA approval requirements)
- **Attachment AQ** (focus group and process)
- **RR 724** (regulatory change regarding project selection criteria)
- **NHTSA** (Network Transmission Service Agreement)
- **ITP** (Integrated Transmission Planning)
- **ESRLA Process** (Energy Storage Resource Interconnection Assessment)
- **GIA** (Generator Interconnection Agreement)
- **DICIS/ICS** (interconnection cluster studies)

**Study Types:**
- HILLGA process
- CHILLS service
- AQ (Attachment AQ) process
- AX (Attachment AX) process
- LCS (Local Coordination Studies)

**Technical Criteria:**
- ATC (Available Transfer Capability)
- CLR/CVR (project selection criteria)
- NTCs (Network Transmission Commitments)

## 7. Suggested Tags

`SPP` `Large-Load-Interconnection` `HILLGA` `CHILLS` `Transmission-Planning` `Load-Studies` `BESS` `ESRLA` `Attachment-AQ` `Attachment-AX` `Regulatory-Approval` `RERA` `Network-Service` `Credit-Generation` `Study-Process` `Transmission-Customer` `Pre-existing-Violations` `RR-724` `Project-Selection` `Reactive-Settings` `Two-Bus-Requirement` `90-Day-Study` `GIA` `ITP` `NERC-Requirements`

## 8. Items That May Need Follow-Up

1. **Model Access for Developers**: Robel Arega's question about whether AQ models are available to developers (not transmission customers) was not fully answered in this excerpt

2. **Credit Generation Distance Clarification**: While discussed, the specific business case considerations for credit generation location relative to load may need further documentation

3. **Pre-existing Violations Protocol**: Process for TOs to provide feedback on pre-existing violations that may be exacerbated by new loads needs clarification

4. **RERA Approval Timeline**: The potential for approval processes extending beyond 90-day study period may create planning uncertainties that need addressing

5. **LCS Study Responsibility**: Clarification needed on which TOs require LCS studies after ESRLA completion and standardization of this requirement

6. **Joe Foltz's Full Question**: Technical issues prevented complete discussion of BESS charging study questions

7. **One-Line Diagram**: SPP staff promised to provide a one-line diagram example in chat to illustrate two-bus rule - should be documented

8. **AQ vs AX Process Details**: Robel Arega's question about differences was being answered when transcript ended - complete explanation needed

9. **Attachment BA Section 1 Language**: Discussion revealed potential confusion about RERA approval requirements - may need clearer tariff language

10. **Transmission Customer Onboarding Process**: 45-day onboarding process mentioned but not detailed - may need separate documentation for new participants

---

# Chunk 3 Analysis

# Regulatory Meeting Analysis Report

## 1. Executive Summary

This transcript covers a technical Q&A session regarding SPP's large load processes, focusing on service types for major load additions (particularly data centers). The discussion centers on the differences between firm ("Hill") and conditional firm ("Chill") service, HILLGA (Hill Generation Agreement) requirements, and various pathways for obtaining transmission service. Key technical issues include metering requirements, generation accreditation, service term limits, and the interaction between different service types. Several questions were deferred for follow-up at the next meeting due to complexity.

## 2. Key Topics

- **Chill vs. Hill Service Designations**: Transmission-limited chill service vs. generation-limited chill service; mixed Hill/Chill service configurations
- **HILLGA Requirements**: Common bus vs. local area configurations; service term limits; generation accreditation (e.g., 20% for wind requiring 500 MW to support 100 MW load)
- **AQ and AX Processes**: Pathways to obtain transmission service; model access through RMS platform; generation deficiency requirements
- **Metering Requirements**: Distinct metering points needed for multiple chill services at single interconnection point
- **Service Term Limits**: 5-year term for local area HILLGA; 7-year maximum for all Chill service types; permanent service for common bus non-jurisdictional HILLGA
- **Generation Shortfall**: Requirements for bringing additional generation when submitting AX requests while in deficiency

## 3. Decisions or Actions

**Actions Identified:**
- Submit question about multiple chill requests at single location and TC generation determination (Robel Arega to submit via RMS)
- Submit specific example regarding HILLGA wind generation variability and market purchases during low-wind periods (Rafael Torres to submit)
- Follow up on common bus HILLGA and Chill service interaction regarding 7-year term limits (Rafael Torres question for clarification)
- Markets team to provide input on metering requirements for multiple chills at single point

**Clarifications Provided:**
- Model access: Developers can request ITPBR models through RMS with NDA; cannot access actual AQ models
- AX submissions allowed even with generation shortfall if bringing sufficient generation to cover deficiency plus new load
- Distinct metering required for each chill service at same interconnection point

## 4. Important Dates

- **5-year term**: Local area HILLGA service limit
- **7-year term**: Maximum term for all Chill service types (regardless of type 1, type 2, etc.)
- **Next meeting**: Multiple questions deferred for discussion and examples to be worked through

## 5. Organizations and People Mentioned

**People:**
- **Robel Arega**: Asked questions about chill/hill designations, metering, and BYOG vs. HILLGA
- **Seth Mayfield**: SPP Markets representative; clarified metering and 7-year chill service term
- **Speaker 1 (Renee)**: Asked about AX submission with generation shortfall
- **Rafael Torres** (NextEra): Asked detailed questions about HILLGA generation variability and service terms
- **Nolan**: Referenced earlier in conversation regarding generator location requirements
- **SPP Staff**: Multiple staff members responded to questions

**Organizations:**
- **SPP (Southwest Power Pool)**: Host organization
- **NextEra**: Rafael Torres's organization

## 6. Links or References

**Systems/Platforms:**
- **RMS (Resource Management System)**: Platform for requesting models and submitting questions
- **ITPBR models**: Available through RMS with NDA
- **AQ models**: Not available to developers

**Processes Referenced:**
- AQ process (service with designated resources)
- AX process (bring your own generation)
- GI process (generator interconnection)
- ICS and CPP (referenced as end goals for HILLGA on-ramp)

**Documentation:**
- Deck from previous meeting with HILLGA examples
- SPP Tariff provisions regarding service types and terms

## 7. Suggested Tags

- Large Load Interconnection
- Data Centers
- Chill Service
- Hill Service
- HILLGA
- Generation Accreditation
- AQ Process
- AX Process
- Transmission Service
- Metering Requirements
- Service Term Limits
- Resource Adequacy
- SPP Tariff
- Renewable Integration
- Wind Generation

## 8. Items That May Need Follow-Up

**High Priority:**
1. **Multiple Chill Metering Question**: How TC determines generation qualification for multiple chill requests at same location; how metering requirements work with multiple services
2. **HILLGA Variable Generation Example**: Rafael Torres's scenario about wind generation variability (500 MW wind supporting 100 MW load) and whether market purchases allowed during low-wind periods
3. **Common Bus HILLGA and Chill Term Interaction**: Clarification needed on whether common bus HILLGA configuration (shown as "permanent") conflicts with 7-year chill maximum term; impact on load service requirements

**Medium Priority:**
4. **Planned Outage RR for HILLGA**: Referenced revision request for handling planned maintenance of HILLGA supporting generation
5. **Two-Bus Substation Requirement**: Further clarification on alternatives to HILLGA for meeting generation requirements
6. **Mixed Hill/Chill Service**: How 300 MW firm + 200 MW chill would work in practice for 500 MW data center example

**Process Items:**
7. Questions should be submitted via RMS with subject "Large Load Q&A Questions" for proper routing
8. Need NDA in place for accessing ITPBR models through RMS
9. Next meeting scheduled to address deferred technical questions with specific examples

---

# Chunk 4 Analysis

# Regulatory Meeting Analysis Report

## 1. Executive Summary

This document captures a portion of an SPP (Southwest Power Pool) technical Q&A session focused on large load processes, specifically discussing the HILL (High Impact Large Load), CHILL (Conditional High Impact Large Load), and HILLGA (High Impact Large Load Generation Agreement) processes. The discussion centers on clarifying service requirements, interconnection procedures, transmission service obligations, and the distinctions between various load and generation configurations. Key concerns include the permanence of common bus configurations, the seven-year limit on CHILL service, substation bus counting rules, and study requirements for different service types.

## 2. Key Topics

- **Common Bus Configuration**: Discussion about whether loads served by common bus generators need to obtain firm transmission service
- **CHILL Service Limitations**: Seven-year maximum term for CHILL service and non-renewability provisions
- **HILLGA Process**: Generation agreements for serving high impact loads, including study requirements and permanent vs. temporary status
- **Substation Bus Counting**: Clarification that all voltage levels within a single substation count as one bus for the "two substations away" rule
- **Firm Service Requirements**: When and how loads must obtain firm transmission service
- **Study Processes**: Distinction between HILLGA studies (90-day, Attachment BB) and ICS (Interconnection Customer Service) studies (CPP, Attachment AY)
- **Grid Charges**: JTIQ and Grid C charges applicability to HILLGA/CHILLGA generation assets
- **AQ vs. AX Modeling**: Different modeling approaches for hill service requests

## 3. Decisions or Actions

- **Follow-up Required**: Rafael Torres to submit a specific example scenario for SPP staff to address at the next meeting regarding common bus/firm service questions
- **Queue Limitation**: Meeting organizers decided to stop taking new questions and handle remaining raised hands only, directing additional questions to RMS (presumably Resource Management System) for next meeting preparation
- **Clarification Provided**: SPP staff will provide written RMS responses to complex questions that couldn't be fully resolved during the call
- **No Renewal Policy Confirmed**: CHILL service cannot be renewed after seven years; it's a one-time, seven-year term
- **Ownership Transfer Rule**: Change of load ownership does not reset the CHILL service timeline

## 4. Important Dates

- **Seven-Year Maximum**: CHILL service has a maximum seven-year term
- **90-Day Study Period**: HILLGA studies operate on a 90-day timeline (per Attachment BB)
- **Future Year Modeling**: Discussion of five-year and seven-year status designations for generation
- No specific calendar dates were mentioned in this excerpt

## 5. Organizations and People Mentioned

**Organizations:**
- SPP (Southwest Power Pool)
- AES Clean Energy
- OPPD (Omaha Public Power District)
- Guzman (company represented by Alberto)

**People:**
- **Rafael Torres** - Multiple questions about common bus configurations and firm service requirements
- **Seth Mayfield** - Provided clarifications on common bus and local area distinctions
- **Michael Hutson** (AES Clean Energy) - Questions about bus counting rules
- **Jason Spirit** - Provided single-line diagram in chat
- **Alberto ONaghten** (Guzman) - Questions about HILLGA submission timing
- **Adam Schieffer** (OPPD) - Questions about JTIQ and Grid C charges
- **Renee** (Speaker 1) - Questions about CHILL service expiration and renewal
- **Robel Arega** - Questions about AQ vs. AX modeling differences
- **Nolan** - SPP staff member providing answers
- **Don** - Mentioned PALS (price adaptive load) concept

## 6. Links or References

**Tariff References:**
- **Attachment BB, Section 313, Bullet Point 5, Sub-bullet A** - Defines "two substations away" rule for bus counting
- **Attachment BB** - Contains HILLGA 90-day study process
- **Attachment AY** - Contains CPP (Capacity Planning Process) procedures

**Process References:**
- RMS (Resource Management System) - For submitting questions
- ICS (Interconnection Customer Service) - Separate from HILLGA process
- CPP (Capacity Planning Process) - Where hills and chills are incorporated
- JTIQ screening - Applied to HILLGA
- PALS (Price Adaptive Load Service) - Mentioned as alternative business model

## 7. Suggested Tags

- HILL (High Impact Large Load)
- CHILL (Conditional High Impact Large Load)
- HILLGA (High Impact Large Load Generation Agreement)
- CHILLGA
- Common Bus Configuration
- Firm Transmission Service
- Interconnection Service
- Grid Charges
- SPP Tariff
- Substation Bus Rules
- Load Interconnection
- Generation Interconnection
- Seven-Year Service Limit
- AQ Process
- AX Process
- Attachment BB
- Attachment AY

## 8. Items That May Need Follow-Up

1. **Rafael Torres' Common Bus Scenario** - Needs formal example submission and SPP response regarding whether a load served by a common bus generator permanently avoids firm service requirements, especially if the HILL load must obtain transmission service by year seven

2. **Double Resource Procurement Concern** - Clarification needed on whether loads with common bus generation still need to procure additional firm resources and transmission service when the seven-year CHILL term expires

3. **AQ vs. AX Modeling Question** - Robel Arega's question about modeling differences between AQ and AX was cut off at the end of the transcript

4. **Grid C Charges Clarification** - Adam Schieffer's question about Grid C charges applicability may need additional written follow-up, as he indicated he needed to "think about that a second"

5. **CHILL Service After Ownership Change** - While answered verbally, formal documentation of the policy that ownership changes don't reset CHILL service timelines may be beneficial

6. **HILLGA Submission Timing with Hill Requests** - Alberto's question about submitting HILLGA years after initial hill request may benefit from documented procedures and limitations

7. **Direct Assignment Upgrade Costs** - HILLGA being subject to direct assignment upgrade costs (rather than Grid C charges) should be confirmed in writing

8. **CPP Incorporation Process** - How hills and chills are specifically incorporated into the CPP study process needs clearer documentation

---

# Chunk 5 Analysis

# Regulatory Meeting Analysis Report

## 1. Executive Summary
This is the final segment (chunk 5 of 5) of an SPP (Southwest Power Pool) Q&A session focused on Large Load Processes. The discussion primarily addresses technical questions regarding CHILL (Customer-Hosted Interconnected Load) service, HILLGA (High-Impact Load Generation Aggregation), and their relationship to the AX (Aggregate Study) process and JTIQ (Joint Transmission Interconnection Queue) provisions. Multiple stakeholders raised questions about how future generation interconnects with load service, transmission owner participation requirements, and grid impact assessments.

## 2. Key Topics
- **CHILL Service Requirements**: How generation serves CHILL loads, particularly regarding future vs. existing generation without firm service
- **AX Process**: Clarification on how CHILL determinations are made through the Aggregate Study process
- **Generation Availability**: Requirements for generation to be available for market dispatch to qualify for CHILL service
- **Transmission Owner Participation**: Whether all TOs/utilities are required to participate in HIL/HILLGA structures
- **JTIQ Provisions**: Relationship between HILLGA and Joint Transmission Interconnection Queue evaluations
- **Grid Impact Assessment**: Zero-impact requirements for HILLGA configurations (behind-the-meter or two buses away)
- **Curtailment**: How curtailment applies when future generators are serving CHILL loads

## 3. Decisions or Actions
- **SPP Staff to Follow-Up**: Staff member needs to "noodle on" the question regarding which generators will service CHILL if they are future generators
- **Correction Issued**: SPP Staff corrected their earlier response about extending CHILL service, stating they "read it the opposite"
- **Participant Action**: Stakeholders directed to review Attachment BB Section 364 for JTIQ provisions related to HILLGA
- **Question Submission Process**: Participants instructed to send questions to RMS labeled as "large load, Q&A" for the next meeting

## 4. Important Dates
- No specific dates mentioned in this segment
- Reference to "next meeting" where examples will be run through based on submitted questions

## 5. Organizations and People Mentioned
**People:**
- **Robel Arega**: Participant asking multiple questions about CHILL service and generation requirements
- **Humberto Branco**: Participant questioning HILLGA's relationship to JTIQ
- **Nolan Fertig**: Person who stopped transcription
- **Renee**: Earlier participant whose question about extending chills was referenced at the end

**Organizations:**
- **SPP (Southwest Power Pool)**: Meeting organizer and regulatory authority
- **TOs/TCs (Transmission Owners/Transmission Customers)**: Referenced regarding participation requirements
- **RMS**: Contact point for submitting questions

## 6. Links or References
- **Attachment BB Section 364**: Contains JTIQ provisions and how they relate to HILLGA
- **AX Process**: Aggregate Study process for determining CHILL service
- **Market Dispatch Requirements**: Generation must be available for dispatch to qualify for CHILL service

## 7. Suggested Tags
- Large Load Process
- CHILL Service
- HILLGA
- AX Process
- JTIQ
- Transmission Planning
- Generation Interconnection
- SPP Regulatory
- Behind-the-Meter
- Curtailment
- Firm Service
- Grid Impact

## 8. Items That May Need Follow-Up

**High Priority:**
1. **Generation Servicing CHILL Loads**: SPP staff needs to provide clarification on how future generators (without firm service) will service CHILL loads and how curtailment applies
2. **CHILL Extension Correction**: SPP staff indicated they misread language about extending CHILL service - corrected information needs to be communicated
3. **JTIQ Impact on HILLGA**: Clarification needed on why HILLGA would be subject to JTIQ evaluation if it's designed to have zero grid impact

**Medium Priority:**
4. **TO Participation Survey**: Determine which Transmission Owners intend to participate in HIL/HILLGA structures
5. **Future vs. Existing Generation**: Clear definition needed distinguishing "future generation" from "existing generation without firm service"
6. **Path 1 vs. Path 2 Requirements**: More detailed explanation of the two HILLGA configuration paths and their respective impact assessments

**Administrative:**
7. **Example Scenarios**: Staff committed to running through examples at the next meeting based on submitted questions
8. **Question Collection**: Ongoing process for collecting and addressing questions via RMS with "large load, Q&A" label