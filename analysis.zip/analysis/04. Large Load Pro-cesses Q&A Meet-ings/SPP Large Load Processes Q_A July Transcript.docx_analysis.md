# Final Combined Report

# COMPREHENSIVE REGULATORY MEETING ANALYSIS REPORT
## SPP Large Load Processes Q&A Session - July 2026

---

## 1. EXECUTIVE SUMMARY

This document analyzes the complete transcript from a Southwest Power Pool (SPP) Large Load Processes Q&A session held on July 2, 2026. The meeting provided comprehensive guidance on new large load interconnection processes, particularly focusing on three service pathways: HILL (High Impact Load Level), HILLGA (HILL with Generator Attachment), and the newly effective cHILL (curtailable HILL) service option.

**Primary Focus Areas:**
- Integration of battery energy storage systems (BESS) with large loads (particularly data centers)
- Transmission service requirements and study processes
- The new cHILL service option (effective July 1, 2026, under RR 720)
- Distinctions between different service pathways (AX, AQ, BC processes)
- Resource adequacy requirements and accreditation calculations
- Behind-the-meter generation considerations

**Key Takeaway:** SPP is implementing structured pathways for large load interconnection while balancing grid reliability, transmission adequacy, and renewable energy integration. The processes require careful navigation of transmission service requirements, resource adequacy obligations, and one-for-one matching principles for load-generation pairs.

---

## 2. KEY TOPICS

### A. Service Pathway Options

**HILL Service (High Impact Load Level)**
- Requires one-to-one matching with generation resources
- Can use firm transmission service amount (not necessarily accredited amount)
- Loads can only be served by paired generators, not the transmission grid
- Applications submitted through AX, AQ, or BC attachment processes

**HILLGA Service (HILL with Generator Attachment)**
- Provides Load Limited Reliability Interconnection Service (LLRIS)
- Strict one-for-one pairing requirement between load and generation
- If generator goes offline, load must also shut down or face unreserved use charges
- Seven-year interconnection agreement term
- Does NOT provide firm transmission service

**cHILL Service (Curtailable HILL)**
- New service option effective July 1, 2026 (RR 720)
- Two pathway options with different transmission impact considerations
- Requires validation of Planning Reserve Margin (PRM) before study
- Subject to curtailment during EEA2 (Energy Emergency Alert Level 2) events
- Must meet accredited amount and PRM requirements (per Attachments BA and BC)
- Cannot be retroactively applied to existing HILL requests

### B. Battery Energy Storage Integration

**Charging Requirements:**
- Batteries cannot net charging requirements against load demand
- Must obtain either:
  - Firm SPP transmission service (network or point-to-point), OR
  - Register as market storage resources
- Example: 1000 MW total capacity = 900 MW load + 100 MW battery (not 1000 MW load with 100 MW battery offset)

**Behind-the-Meter Battery Considerations:**
- Separate accounting required from data center load
- May require firm service for battery systems
- Non-jurisdictional generation (NJG) serving storage must undergo load connection studies
- Subject to NERC FAC 002-4 standards
- Battery-related transmission service requirements under development

**Study Requirements:**
- Must be studied in system impact studies
- Business Practice 7250, Section 5 covers ESRLA (Energy Storage Resource Load Analysis)
- Business Practice 7250, Section 6.3 covers non-jurisdictional generation requirements
- Potential for batteries to be identified as mitigation solutions during stability studies

### C. Transmission Service and Resource Adequacy

**Firm Service Requirements:**
- Non-HILL loads under AX process require firm service through ATSS before connection
- Distinction between firm transmission service and resource adequacy obligations
- Network customer resource designation requires (Section 29.2, Section 8):
  - Ownership confirmation
  - Non-interruption commitments
  
**Resource Adequacy Distinctions:**
- One-for-one transmission service requirements ≠ Planning Reserve Margin obligations
- Load Responsible Entities (LREs) must independently meet RA requirements
- No protective language exists in HILL/HILLGA/cHILL processes for LRE protection
- Different requirements for different service types:
  - **cHILL**: Must use accredited amount
  - **HILL**: Can use firm transmission service amount

**Accreditation Requirements:**
- Examples provided:
  - 100 MW load + 500 MW wind at 20% accreditation = adequate
  - 100 MW load + 110 MW gas at 90% accreditation = adequate
- Wind accreditation referenced as approximately 35-40% ELCC (Effective Load Carrying Capability)

### D. Study Processes and Methodologies

**Limited Operation Studies:**
- Identify transmission limitations and cap cHILL service accordingly
- Use modeling years: 1, 2, 5, and 10
- Scenarios: summer/winter peak and off-peak
- Detailed methodology available in March Load Q&A presentation appendix

**Load Connection Studies:**
- Required for behind-the-meter generation serving storage resources
- NJG (non-jurisdictional generation) process mandatory
- Integration with Interconnection Customer Study (ICS) and CPP processes

**CPP Phase 2 Integration:**
- Policy level review scheduled for MOPC in October
- Will integrate HILL into Cluster Process Project
- Revision Requests to be distributed to working groups after MOPC review
- Questions remain about PIL Map application to HILL requests

### E. Eligible Transmission Customers and DNR Designation

**Eligibility Requirements:**
- Must be eligible transmission customer (new or existing)
- Must be authorized utility in state where load is served
- Can use Designated Network Resources (DNRs) for HILL loads through AQ requests
- Potential pathway to bypass queue backlogs through partnerships

**Process Distinctions:**
- **AX Process**: Leads to PLP (Provisional Load Process) agreements, not NITSA
- **ATSS Process**: Required to firm up generation before load enters actual service agreement
- Generation must complete DISIS and be firmed through ATSS before full connection

---

## 3. DECISIONS OR ACTIONS

### A. Policy Decisions Clarified

1. **No Retroactive cHILL Application**: Previous HILL requests cannot utilize cHILL service; new requests required through AX, AQ, or BC processes

2. **No Load Netting Permitted**: Battery charging cannot be netted against load demands for transmission service purposes

3. **Load Connection Study Requirement**: Behind-the-meter generation serving storage resources must undergo NJG process and system impact studies

4. **New Accredited Generation Allocation**: New accredited generation coming online will NOT backfill previous HILL requests; must be tied to new requests through AX, AQ, or BC

5. **HILLGA Operation Rules**: If generator goes offline under HILLGA, load must also go offline or face unreserved use charges

6. **Service Type Matching Rules**:
   - cHILL requests: Must meet accredited amount
   - HILL requests: Can use firm transmission service amount (one-for-one match)

### B. SPP Staff Commitments

1. **Documentation Development**: Create methodology manuals for cHILL similar to generation-side manuals

2. **Meeting Materials**: Post slides and transcript by Monday following meeting on same registration page

3. **Comparative Analysis**: Provide full comparison between AX service and HILL/HILLGA options at future meeting

4. **Question Management**: Continue accepting questions via RMS for monthly meetings

5. **Process Development**: Ongoing development of battery-related transmission service requirements

### C. Study and Review Actions

1. **MOPC Review**: CPP Phase 2 policy level scheduled for October review

2. **RR Distribution**: Distribute Revision Requests to working groups after MOPC review

3. **Within One Year**: BC request applicants must submit AQ or AX request showing path toward firm service

---

## 4. IMPORTANT DATES

| Date | Event/Deadline | Significance |
|------|---------------|--------------|
| **July 1, 2026** | cHILL service effective date | RR 720 FERC acceptance becomes effective |
| **July 16, 2026** | cHILL MIPO on WebEx | SPP Change User Forum discussion |
| **August 6, 2026** | Next Large Load Q&A meeting | Address additional submitted questions |
| **October 2026** |

---

# Partial Chunk Reports

# Chunk 1 Analysis

# Regulatory Meeting Analysis Report

## 1. Executive Summary

This document is a transcript from an SPP (Southwest Power Pool) Large Load Processes Q&A session held on July 2, 2026. The meeting focused on explaining new large load interconnection processes, particularly regarding HILL (High Impact Load Level), HILLGA (HILL Generator Attachment), and cHILL (curtailable HILL) pathways. SPP staff addressed pre-submitted questions about how battery energy storage systems (BESS) can interconnect with large loads, transmission service requirements, and the newly effective cHILL service option. The session emphasized that only pre-submitted questions would be answered, with additional scenarios to be submitted via RMS for the next monthly meeting.

## 2. Key Topics

- **HILL/HILLGA Pairing**: One-to-one matching of large loads with battery storage generation under Load Limited Interconnection Service (LLRIS)
- **Battery Charging Requirements**: Clarification that batteries cannot net against load and must obtain either firm transmission service or register as market storage resources
- **Behind-the-Meter Generation**: Requirements for non-jurisdictional generation serving storage resources, including load connection studies
- **cHILL Service** (New): Recently approved curtailable service option effective July 1, 2026, allowing loads to be served by the transmission system with limitations
- **Transmission Service Netting**: Prohibition on netting battery charging requirements against load demands
- **HILL Service Limitations**: HILL loads under LLRIS can only be served by their paired HILLGA generators, not the grid

## 3. Decisions or Actions

- **No Retroactive cHILL Application**: Previous HILL requests cannot utilize cHILL service; new requests required through AX, AQ, or BC processes
- **Load Connection Study Requirement**: Behind-the-meter generation serving storage resources must undergo NJG (non-jurisdictional generation) process and be studied in system impact studies
- **No Load Netting Permitted**: For a 1000 MW total capacity, configuration must be 900 MW load + 100 MW battery, not 1000 MW load with 100 MW battery offset
- **Battery Charging Pathways**: Batteries must obtain firm SPP transmission service (network or point-to-point) OR register as market storage resources
- **Question Submission Process**: Additional scenarios and what-if questions must be submitted via RMS for future meetings, not answered on-the-fly

## 4. Important Dates

- **July 1, 2026**: cHILL service effective date (RR 720 FERC acceptance)
- **August 6th**: Next scheduled Q&A meeting for additional submitted questions
- **Seven-year term**: Interconnection agreement duration for cHILL service supported by HILLGA generators

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)**: Meeting host and regulatory authority
- **FERC**: Federal regulatory body that accepted RR 720
- **NERC**: Referenced for FAC 002-4 standard
- **EPA**: Steve Gaw's organization

### People:
- **Nolan** (SPP Staff): Primary presenter
- **Calvin Rosenbaum** (SPP Staff): Addressed HILLGA and behind-the-meter generation questions
- **Steve Gaw** (EPA): Participant asking clarifying questions about ESR charging

## 6. Links or References

### Regulatory Documents:
- **RR 720**: Revision request containing cHILL provisions (FERC accepted, effective July 1, 2026)
- **Attachment AE, Section 2**: Pro forma tariff language on transmission system limitations
- **Section 29.2, Section 4**: Pro forma tariff on transmission service and load netting prohibition
- **Business Practice 7250, Section 6.3**: Covers non-jurisdictional generation requirements
- **Business Practice 7250, Section 5**: Covers ESRLA (energy storage resource load analysis)
- **NERC FAC 002-4**: Standard governing battery studies
- **Attachment AQ**: Process for cHILL connection with adequate generation

### Resources:
- **SPP Storage Facility Process**: Flow chart referenced (link noted as being at bottom of slide)
- **RMS (Request Management System)**: Portal for submitting questions for future meetings

## 7. Suggested Tags

- Large Load Interconnection
- HILL (High Impact Load Level)
- HILLGA (HILL Generator Attachment)
- cHILL (Curtailable HILL)
- LLRIS (Load Limited Interconnection Service)
- Battery Energy Storage Systems (BESS)
- Data Center Interconnection
- Transmission Service
- SPP Processes
- Energy Storage Resources (ESR)
- Non-Jurisdictional Generation
- Load Connection Studies
- Transmission Upgrades
- Market Storage Resources
- RR 720

## 8. Items That May Need Follow-Up

### Unresolved Questions:
1. **Steve Gaw's ESR Charging Question**: Partially deferred to later slides - need to verify if fully addressed regarding charging limitations and relationship to load caps under cHILL service
2. **Behind-the-Meter Battery Scenarios**: Complex scenarios involving 1000 MW data centers with 100 MW BESS may require additional worked examples
3. **cHILL Curtailment Details**: Meeting transcript cuts off mid-discussion of cHILL curtailment provisions during EEA2 events

### Process Clarifications Needed:
4. **Transition Process**: How existing HILL applications can convert to or resubmit for cHILL service
5. **Accreditation Process**: Detailed process for determining "accredited equivalent HILLGA generation"
6. **Study Timeline**: Timeframe for ICS (Interconnection Customer Study), CPP, and other required studies for behind-the-meter generation
7. **Transmission Limited cHILL**: More detailed explanation of how partial service works before upgrades are complete

### Documentation Gaps:
8. **Complete Flow Charts**: Reference to storage facility process flowchart needs to be distributed to participants
9. **Example Scenarios**: Need for more comprehensive worked examples combining BESS, data centers, and various service types
10. **Market Storage Resource Registration**: Detailed process for how batteries register in the market vs. obtaining firm transmission service

### Participant Follow-Up:
11. **Steve Gaw (EPA)**: May need written response on ESR charging scenarios with cHILL service
12. **General Participants**: Encouraged to submit additional scenarios via RMS before August 6th meeting

---

**Note**: This transcript appears to be cut off mid-sentence ("CHILLS can be curtailable jus..."), indicating this is only chunk 1 of 4. Subsequent chunks will likely contain additional Q&A and important clarifications.

---

# Chunk 2 Analysis

# Regulatory Meeting Analysis Report

## 1. Executive Summary

This document contains a transcript from an SPP (Southwest Power Pool) Q&A session focused on Large Load Processes, specifically discussing CHILL (Curtailable High Impact Large Load) service options. The meeting covered transmission service requirements, study processes, and the differences between CHILL service and traditional firm service pathways (AQ/AX requests). Key discussion points included accreditation requirements for generation resources supporting large loads, limited operation studies, integration with the Cluster Process Project (CPP) Phase 2, and the distinction between firm transmission service requirements and resource adequacy obligations.

## 2. Key Topics

- **CHILL Service Options**: Two pathways for curtailable service with different transmission impact considerations
- **Accreditation Examples**: 100 MW load with 500 MW wind (20% accreditation) or 110 MW gas (90% accreditation)
- **AQ and AX Request Integration**: How CHILL service integrates with existing SPP processes
- **Limited Operation Studies**: Studies to identify transmission limitations and cap CHILL service accordingly
- **Study Methodology**: Uses years 1, 2, 5, and 10 models with summer/winter peak and off-peak scenarios
- **Firm Service vs. Resource Adequacy**: Distinction between one-for-one transmission service requirements and Planning Reserve Margin (PRM) obligations
- **Designated Resources**: Requirements per section 29.2 including ownership confirmation and non-interruption commitments
- **CPP Phase 2 Integration**: Future integration of HILL into the Cluster Process Project

## 3. Decisions or Actions

- **Future Documentation**: SPP staff agreed to develop methodology manuals for CHILLS similar to those on the generation side
- **Next Meeting Topics**: 
  - Full comparison between AX service and HILL/HILLGA options
  - Further clarification on differences and risks between connection pathways
- **Policy Review**: MOPC (Markets and Operations Policy Committee) scheduled to review CPP Phase 2 policy level in October
- **RR Distribution**: Revision Requests to be distributed to working groups after MOPC review

## 4. Important Dates

- **October (year not specified)**: MOPC review of CPP Phase 2 policy level
- **Within one year of BC request**: Must submit AQ or AX request showing path towards firm service
- **Previous Presentations**: March Load Q&A session (referenced for study methodology details)

## 5. Organizations and People Mentioned

**Organizations:**
- SPP (Southwest Power Pool)
- Plus Power
- Sunflower
- CPPTF (Cluster Process Project Task Force)
- MOPC (Markets and Operations Policy Committee)

**People:**
- **Nolan** (SPP Staff - Presenter)
- **Jason** (SPP Staff)
- **Robel Arega** (Plus Power)
- **Aditi Rajgopal**
- **Cliff Franklin** (Sunflower)

## 6. Links or References

- **Section 29.2, Section 8**: Network customer resource designation requirements
- **Attachment BC Request**: Chose request with accredited generation
- **AQ and AX Request Forms**: Include CHILL service options at bottom
- **Appendix One**: Network service agreement and NHTSA or point-to-point agreement
- **May/March Load Q&A**: Previous presentation containing study model details (referenced in appendix)
- **ELCC (Effective Load Carrying Capability)**: Referenced for wind accreditation (35-40%)
- **PIL Map**: Mentioned regarding evaluation of HILL requests

## 7. Suggested Tags

- Large Load Processes
- CHILL Service
- SPP Transmission Service
- AQ/AX Requests
- Resource Adequacy
- Accreditation Requirements
- Transmission Studies
- CPP Phase 2
- Firm Service
- Planning Reserve Margin
- Limited Operation Studies
- Network Integration
- Behind-the-Meter Generation
- Load Responsible Entity
- Cluster Process Project

## 8. Items That May Need Follow-Up

1. **Methodology Manual Development**: SPP to create user-accessible documentation for CHILLS study methodologies similar to generation-side manuals
2. **AX vs. HILL/HILLGA Comparison**: Detailed analysis requested for next meeting on differences, risks, and impacts between connection pathways
3. **PIL Map Application**: Clarification needed on whether PIL maps will evaluate HILL requests or only generation requests post-CPP integration
4. **East vs. West PIO Locations**: Status of West PIO location releases (question deferred to CPP team)
5. **CPP Phase 2 Timeline**: Full implementation schedule and integration details pending MOPC October review
6. **LRE Responsibility Clarification**: Relationship between transmission service agreements and resource adequacy obligations for loads with renewable resources
7. **Provisional vs. Firm Service**: Further documentation on NTC issuance and connection timing differences between AX provisional service and CHILL service
8. **ATSS Process**: Connection to Appendix One designation process needs further clarification
9. **Accreditation Percentages**: Current ELCC values for wind (mentioned as ~35-40%) and other resource types

---

# Chunk 3 Analysis

# Regulatory Meeting Analysis Report

## 1. Executive Summary

This is a transcript from an SPP (Southwest Power Pool) Large Load Processes Q&A session held in July, focusing on clarifications regarding HILL (High Impact Load with Load-serving resource), HILLGA (HILL with Generator Agreement), and CHILLS (Curtailable High Impact Load with Load-serving resource) processes. The discussion centered on technical questions about resource adequacy requirements, accredited capacity calculations, load-generation matching requirements, and service limitations under different interconnection scenarios. SPP staff provided detailed responses to stakeholders regarding how these processes work, particularly around Planning Reserve Margin (PRM) requirements, accredited amounts versus nameplate capacity, and options for connecting loads when paired generation has limited operation interconnection service.

## 2. Key Topics

- **Resource Adequacy (RA) Requirements**: Discussion of Load Responsible Entity (LRE) obligations to meet RA requirements and Planning Reserve Margin (PRM) for different load types
- **CHILLS Requirements**: CHILLS requests must meet accredited amount and PRM requirements (validated per Attachment BA and BC)
- **HILLs vs. HILLGA vs. CHILLS**: Different capacity and service requirements for each process type
- **Accredited Amount vs. Nameplate Capacity**: Clarification that accredited amount is used for PRM requirements while firm transmission service amount can be used for transmission service
- **Limited Operation Interconnection Service (LOIS)**: How loads can connect when paired generation has only limited operation capability
- **Load Limited Reliability Interconnection Service (LLRIS)**: Service option through HILLGA where load and generation must match one-for-one
- **Unreserved Use Charges**: Penalties applied when load operates without proper service authorization
- **Non-HILL Loads under AX Process**: Require firm service through ATSS process before connection

## 3. Decisions or Actions

- **SPP Staff Commitments**:
  - Post slides and transcript by Monday of the following week on the same registration page
  - Continue accepting questions for future Q&A sessions
  
- **Clarifications Provided**:
  - CHILLS requests require validation that PRM is met before study (per Attachments BA and BC)
  - LREs must protect themselves regarding RA requirements; no protective language exists in HILL/HILLGA/CHILLS processes
  - For CHILLS: must use accredited amount
  - For HILLs: can use firm transmission service amount (one-for-one match)
  - HILLGA provides LLRIS (load limited service), not firm service
  - If generator goes offline under HILLGA, load must also go offline (or face unreserved use charges)
  - New accredited generation coming online will NOT backfill previous HILL requests; must be tied to new requests through AX, AQ, or BC

## 4. Important Dates

- **July 16**: CHILLs MIPO (SPP Change User Forum) on WebEx
- **August 6**: Next Large Load Q&A meeting
- **Following Monday** (after this meeting): Planned posting of slides and transcript

## 5. Organizations and People Mentioned

**Organizations:**
- SPP (Southwest Power Pool)
- Denovo Energy Solution

**People:**
- **Franklin, Cliff**: Participant asking multiple questions about LRE protection and PRM requirements
- **Ghazizadeh, Milad**: Representative from Denovo Energy Solution asking about accredited amounts vs. nameplate capacity
- **ADITI RAJGOPAL**: Asked questions about HILLGA service and unreserved use charges
- **Jackson Cutsor**: Asked about penalties for generator not serving load
- **Robel Arega**: Asked about accredited generation and how it services CHILLS/HILLs requests
- **Ash Panegal**: Joined late, asked about designating own generator (question cut off)
- **Jason**: SPP staff member who presented Question 5
- **SPP Staff Conference Room**: Multiple SPP staff responding to questions

## 6. Links or References

- **Registration link**: WebEx registration for CHILLs MIPO (mentioned but specific URL not provided in transcript)
- **Attachments Referenced**:
  - Attachment BA
  - Attachment BC
  - Attachment AX
  - Attachment AQ
- **ATSS process**: Referenced for firm service requirements
- **Previous meeting materials**: Available on same registration page as current meeting

## 7. Suggested Tags

- SPP
- HILL Process
- HILLGA Process
- CHILLS Process
- Resource Adequacy
- Planning Reserve Margin
- Accredited Capacity
- Load Interconnection
- Transmission Service
- Generator Interconnection
- LLRIS (Load Limited Reliability Interconnection Service)
- LOIS (Limited Operation Interconnection Service)
- Unreserved Use Charges
- Large Load Processes
- LRE (Load Responsible Entity)

## 8. Items That May Need Follow-Up

1. **Ash Panegal's incomplete question** at the end of the transcript about designating their own generator for a HILL request - answer was cut off

2. **Clarity needed on unreserved use penalty specifics**: While confirmed that loads under HILLGA can technically operate when generator is offline by paying unreserved use charges, the specific penalty amounts and calculation methods were not detailed

3. **Ambiguity around "firm service amount"**: The distinction between nameplate capacity, interconnection limit, and firm service amount could benefit from additional clarification or examples

4. **Process for new accredited generation**: Robel's question about how new accredited generation coming online later in the year would work with HILL requests suggests potential confusion about queue timing that may need further explanation

5. **HILLGA commercial operation timeline**: ADITI's question about when loads can come online after HILLGA study completion may need additional documentation or guidance

6. **LRE self-protection mechanisms**: Franklin's concern about LREs protecting themselves (since there's no protective language in the processes) may warrant development of best practices or guidance documents

7. **Integration between different attachment processes** (AX, AQ, BC, BA) and how they interact could benefit from a comprehensive workflow diagram

8. **Question collection process**: Stakeholders are encouraged to submit questions, but the specific method/email for submission is not mentioned in this transcript excerpt

---

# Chunk 4 Analysis

# Regulatory Meeting Analysis Report

## 1. Executive Summary

This transcript captures the final portion (chunk 4 of 4) of an SPP (Southwest Power Pool) Large Load Processes Q&A session held in July. The discussion focused on technical clarifications regarding High Impact Large Load (HILL) applications, specifically addressing:

- The use of Designated Network Resources (DNRs) for HILL requests
- Requirements for eligible transmission customers
- Behind-the-meter battery considerations
- The transition process from provisional load agreements to firm service
- Differences between AX (load and generation connection) and ATSS (transmission service) processes

The meeting concluded with confirmation of next steps and scheduling for the August 6th follow-up session.

## 2. Key Topics

### Eligible Transmission Customers and DNR Designation
- Discussion of whether HILL requests can partner with generators to bypass queue backlogs
- Clarification that applicants must be eligible transmission customers (new or existing)
- Requirement to be an authorized utility in the state where load is served

### Behind-the-Meter Batteries
- Treatment of batteries used for load smoothing and data center operations
- Requirement for separate accounting from data center load itself
- Potential need for firm service for battery systems
- Development of new battery-related processes underway

### AX Process vs. ATSS Process
- Clarification on load addition procedures
- Distinction between Provisional Load Process (PLP) agreements and Network Integration Transmission Service Agreements (NITSA)
- Requirement for generation to be firmed up through ATSS before load goes into actual service agreement

### Ride-Through Requirements
- Location of documentation (Attachment BA and spp.org)

## 3. Decisions or Actions

### Decisions Made:
- Eligible transmission customers can use designated resources to serve HILL loads through AQ requests
- Behind-the-meter batteries must be accounted for separately from data center loads
- AX process leads to PLP agreements (not NITSA) until generation is firmed through ATSS

### Actions Identified:
- Questions requiring further development to be submitted via RMS (Request Management System) for next meeting
- SPP staff to post materials and transcript on Monday following the meeting
- Battery-related transmission service requirements currently under development

## 4. Important Dates

- **Monday (following meeting)**: Materials and transcript to be posted
- **August 6**: Next Q&A meeting scheduled
- **Independence Day Weekend**: Mentioned as upcoming (indicates meeting occurred late June/early July)

## 5. Organizations and People Mentioned

### Organizations:
- **SPP (Southwest Power Pool)**: Meeting organizer and regulatory body
- **Transmission Owners (TOs)**: Referenced in context of service areas

### People (by speaking role):
- **SPP Staff Conference Room** (likely Nolan - referenced by name): Primary SPP staff representative/moderator
- **Ash Panegal**: Participant asking questions about DNR designation and transmission customer eligibility
- **Zachary P. Andera (Zach)**: Asked questions regarding behind-the-meter batteries
- **Aditi Rajgopal**: Asked questions about transitioning to firm service and AX/ATSS processes
- **Reagan Redd**: Asked about ride-through requirements location

## 6. Links or References

### Documents Referenced:
- **Attachment BA**: Contains ride-through requirements
- **HILL Ride Through Requirements Document**: https://www.spp.org/documents/74272/high%20impact%20large%20load%20ride%20through%20requirements.docx

### Processes/Systems Referenced:
- **ATSS** (Aggregate Transmission Service Study)
- **AQ Request** (Application using designated resources)
- **AX Process** (Load and generation connection process)
- **DNR** (Designated Network Resource)
- **NITSA** (Network Integration Transmission Service Agreement)
- **PLP Agreement** (Provisional Load Process Agreement)
- **RMS** (Request Management System)
- **DISIS** (mentioned in context of generator completion status)

## 7. Suggested Tags

- Large Load Integration
- High Impact Large Load (HILL)
- Transmission Service
- SPP Processes
- Designated Network Resources
- Data Center Loads
- Behind-the-Meter Batteries
- ATSS Process
- Queue Management
- Transmission Customer Eligibility
- Energy Storage Requirements
- Provisional Load Agreements
- Regulatory Compliance

## 8. Items That May Need Follow-Up

### Immediate Follow-Up Required:
1. **Battery Policy Development**: SPP is developing new processes for battery requirements and transmission service - timeline and details needed
2. **Stability Study Outcomes**: Zachary's question about whether batteries could be identified as mitigation solutions during studies needs formal response
3. **Chat Questions**: SPP staff noted some chat questions would need to wait until next meeting - these should be captured

### Clarification Needed:
1. **Queue Bypass Mechanisms**: While clarified that eligible transmission customers can use designated resources, the specifics of avoiding backlog through partnerships may need further documentation
2. **State Authorization Requirements**: Process for becoming an authorized utility in relevant states not fully detailed
3. **Battery Load Netting**: Current inability to net battery loads may change with new policy development

### Process Documentation:
1. **PLP to NITSA Transition**: Step-by-step procedures for transitioning from provisional to firm service agreements
2. **Parallel Study Procedures**: How to properly coordinate AX and ATSS studies when run in parallel
3. **Ride-Through Requirements**: Ensure all participants have access to current documentation

### Meeting Administration:
1. Ensure all submitted RMS questions are compiled for August 6 meeting
2. Post transcript and materials by Monday following meeting
3. Confirm full agenda for August 6 session based on accumulated questions