# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document provides a comprehensive overview of the High Impact Large Load (HILL) Assessment process at Southwest Power Pool (SPP), effective January 15, 2026. The process addresses how large loads are classified, studied, and integrated into the transmission system through two pathways: Attachment AQ (for customers with sufficient Designated Resources) and Attachment AX (for customers without sufficient resources). The process includes a 90-calendar-day study timeline, specific submission requirements, and coordination between Transmission Customers, SPP, and Host Transmission Owners. Key changes were implemented through Revision Requests RR696, RR720, and RR724, with the most recent update dated June 12, 2026.

## 2. Key Topics

- **High Impact Large Load (HILL) Classification**: Definition and criteria based on load size, type, and interconnection voltage per OATT Part I Definitions
- **Two Study Pathways**:
  - Attachment AQ: For customers with sufficient Designated Resources
  - Attachment AX: For customers without sufficient Designated Resources (Provisional Load Process)
- **HILL Delivery Point Study (HDPS)**: 90-calendar-day study process including steady-state, transient stability dynamics, short circuit ratio, and SCRCCT screening
- **Submission Requirements**: Detailed documentation requirements for both AQ and AX processes
- **Network Upgrades**: Cost allocation differences between processes (Base Plan funding vs. Directly Assigned)
- **Study Timeline and Validation**: 10-day scoping call requirement and one-year validity period for study results
- **Resource Requirements**: 5-year minimum requirement for Designated Resources in DPA requests

## 3. Decisions or Actions

**Completed Actions:**
- HILL process (RR696) became effective 1/15/2026
- RR720 implemented effective 7/1/2026, giving Transmission Customers choice to submit in AQ or AX when they have Designated Resources headroom
- Document last revised June 12, 2026

**Required Actions for Transmission Customers:**
- Submit fully completed DPA Request Form or Provisional Load Process Request Form to loadstudies@spp.org
- Provide fully executed HDPS Agreement
- Submit ten-year load forecast with summer, winter, and light loads
- Provide one-line diagrams and associated IDEV files
- Complete "Additional HILL Characteristics Form" (Business Practice 7850)
- Provide Load Modeling Data (CMLD and/or PERC1)
- For AX process: Submit executed agreement and deposit within 30 calendar days
- Notify SPP of intent to add new load within one year of HDPS results posting

**SPP Actions:**
- Coordinate scoping call within 10 days of receiving required data
- Perform HDPS within 90 calendar days
- Generate and send study report to Transmission Customer within 90 calendar days
- Evaluate affected system impact studies during 90-day window

## 4. Important Dates

- **1/15/2026**: HILL process (RR696) became effective
- **6/12/2026**: Document last revised
- **7/1/2026**: RR720 effective date (customer choice provision)
- **10 days**: Timeframe for scoping call after receiving all required data
- **30 calendar days**: Deadline for TC to submit executed HDPS Agreement and deposit (AX process)
- **90 calendar days**: Study completion timeline for HDPS (from valid request and data validation)
- **90 calendar days**: Host TO Load Connection Study timeline
- **One year**: Validity period for HDPS results after study completion
- **One year**: Timeframe for TC to notify SPP of intent to add new load
- **5 years**: Minimum requirement for Designated Resources to cover load requests

## 5. Organizations and People Mentioned

**Organizations:**
- **Southwest Power Pool (SPP)**: Regional transmission organization conducting the studies
- **Transmission Customer (TC)**: Entity requesting load assessment
- **Host Transmission Owner (TO)**: Local transmission owner affected by the load request
- **Affected Systems**: Other systems potentially impacted by the load

**Contact Information:**
- Email: loadstudies@spp.org
- SPP Studies page on OASIS (multiple references for forms and agreements)

**Referenced Entities/Systems:**
- Open Access Transmission Tariff (OATT)
- Aggregate Transmission Service Study (ATSS)
- Network Integrated Transmission Service Agreement (NITSA)

## 6. Links or References

**Forms and Agreements:**
- DPA Request Form (Addendum 1 to Attachment AQ) - Available in SPP Tariff Attachment AQ
- Provisional Load Process Request Form - Available at SPP Studies page on OASIS
- HDPS Agreement - Available on SPP Studies page on OASIS
- Additional HILL Characteristics Form - Business Practice 7850

**Documents Referenced:**
- Open Access Transmission Tariff (OATT) Part I Definitions
- Attachment AQ Section 3.2
- Attachment AX Section 2.2
- Business Practice 7850 (Delivery Point Additions, Modifications, and Retirements Procedures)
- Attachment BA (mentioned for HILL intake)
- Load Study (AX and AQ) FAQs, Guidelines and Request Forms

**Revision Requests:**
- RR696 (HILL process implementation)
- RR720 (Customer choice provision)
- RR724 (Impacts to existing processes)

**Figures:**
- Figure 1 – AQ Process Timeline
- Figure 2 – Provisional Load Process Estimated Timeline

## 7. Suggested Tags

- High Impact Large Load (HILL)
- HILL Assessment
- Transmission Planning
- Load Studies
- SPP Tariff
- Attachment AQ
- Attachment AX
- HDPS (HILL Delivery Point Study)
- Network Upgrades
- Designated Resources
- Provisional Load Process
- Open Access Transmission Tariff (OATT)
- RR696
- RR720
- RR724
- Business Practice 7850
- Transmission Customer
- Load Forecasting
- System Impact Studies
- NITSA
- Regulatory Compliance

## 8. Items That May Need Follow-Up

**Process Clarifications:**
1. **EMT Analysis Timeline**: When SCRCCT screening fails, further Electromagnetic Transient (EMT) analysis is required outside the 90-day timeline - need clarification on extended timeline expectations and coordination
2. **PSCAD Model Submission**: While recommended at time of submission, need clarity on consequences if not provided initially
3. **Cost Transition Mechanism**: When Network Upgrades move from Directly Assigned to Base Plan funding (AX to NITSA conversion), specific financial reconciliation process needs documentation

**Documentation Gaps:**
4. **Deposit Amounts**: No specific deposit amounts mentioned for either AQ or AX processes
5. **Study Agreement Templates**: While locations are provided, specific terms and conditions not detailed
6. **Project Selection Criteria**: RR724 mentions implementation of project selection criteria to replace least-cost solution method, but criteria not detailed in this document

**Coordination Requirements:**
7. **Affected System Studies**: Process for determining which systems need study and coordination protocols needs elaboration
8. **Generator Outlet Facility (GOF) Analysis**: Specific methodology and criteria for GOF analysis in AX process not detailed
9. **Zonal Reliability Upgrades**: How Zonal Planning Criteria will be addressed through Zonal Reliability Upgrades requires further documentation

**Timing and Validity:**
10. **One-Year Validity Extension**: No process mentioned for extending HDPS results beyond one year if circumstances require
11. **Study Queue Management**: How multiple HILL requests are prioritized and managed in queue not addressed
12. **Scoping Call Rescheduling**: What happens if scoping call cannot occur within 10-day window

**Transition and Implementation:**
13. **Legacy Requests**: How requests submitted before 1/15/2026 are handled under new process
14. **RR720 Implementation**: Track implementation of 7/1/2026 customer choice provision and assess usage patterns
15. **5-Year Designated Resource Requirement**: Verification and monitoring process for maintaining 5-year requirement needs definition

**Stakeholder Communication:**
16. **FAQ Updates**: Monitor need for updates to Load Study FAQs based on stakeholder questions
17. **Training Requirements**: Determine if additional training needed for T