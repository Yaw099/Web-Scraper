# REGULATORY MEETING ANALYSIS REPORT

## 1. Executive Summary

This presentation addresses Large Load service policies in the SPP (Southwest Power Pool) region, presented on June 4, 2026. The meeting focuses on answering submitted questions regarding the coordination between SPP and Host Transmission Owner (TO) studies, timeline requirements, and handling of pre-existing system violations. The presentation also provides an overview of various service policies for large loads, including HILL (High Impact Large Load), HILLGA, and newer flexible/intermittent policies (CHILL and PAL) introduced in 2026. Key regulatory reference is made to Business Practice 7850 and Section 31.2d of the SPP Tariff regarding Zonal Planning Upgrades.

## 2. Key Topics

- **Study Coordination Issues**: Reconciliation when Host TO and SPP study results differ
- **Zonal Planning Upgrades (RR724)**: Business Practice 7850 covering Zonal Planning Criteria (ZPC) and upgrade funding mechanisms
- **Study Timeline Requirements**: 60 calendar days for standard loads, 90 days for HILL
- **Pre-existing Violations**: Treatment of existing system issues in load studies
- **Service Policy Types**:
  - HILL/HILLGA (approved August-September, BOD approval)
  - Flexible Intermittent Policies Phase 1 (January 2026) and Phase 2 (April 2026)
  - CHILL (Curtailable HILL)
  - PAL (Price-responsive service)
- **Load Hosting Capacity Tool**: Pending stakeholder approval for ATC data platform
- **Study Models**: Requirements across various timeframes (Years 1-10) for different scenarios

## 3. Decisions or Actions

**Completed Actions:**
- HILL (for Load) - MOPC and BOD approval (August 21 and September 4)
- HILLGA (for Generation) - MOPC and BOD approval (August 21 and September 4)
- Phase 1 Flexible Intermittent Policies implemented (January 2026)
- Phase 2 Flexible Intermittent Policies implemented (April 2026)

**Pending Actions:**
- Load Hosting Capacity Tool awaiting stakeholders' approval
- Resolution of submitted questions regarding study coordination and pre-existing violations

## 4. Important Dates

- **June 4, 2026**: Presentation date
- **August 21**: MOPC approval for HILL and HILLGA policies
- **September 4**: BOD approval for HILL and HILLGA policies
- **January 2026**: Phase 1 Flexible Intermittent Policies implementation
- **April 2026**: Phase 2 Flexible Intermittent Policies implementation
- **Study Timelines**:
  - 60 calendar days: Standard LCS Tariff deadline
  - 90 days: HILL and all new service types study timeline
  - 7-year CHILL status (after study completion)
  - 5-year limited status for Local Area service

## 5. Organizations and People Mentioned

**Organizations:**
- SPP (Southwest Power Pool)
- Host Transmission Owners (TOs)
- MOPC (Markets and Operations Policy Committee)
- BOD (Board of Directors)
- LSEs (Load Serving Entities)

**Customer Types Referenced:**
- Heavy industry
- Mining operations
- Refineries
- Data centers
- Crypto mining
- Battery storage operators
- Transmission Customers

## 6. Links or References

**Regulatory Documents:**
- RR724 (Business Practice 7850: Zonal Planning Upgrades)
- Section 31.2d of the SPP Tariff
- Section 3.1 (LCS Tariff deadline requirements)
- Attachment AQ and Attachment AX processes
- DISIS/CPP processes

**Study References:**
- ITP (Integrated Transmission Planning)
- Transmission System Planning models
- HDPS Studies (referenced but not detailed)

## 7. Suggested Tags

- Large Load
- SPP
- HILL
- HILLGA
- CHILL
- PAL
- Zonal Planning Upgrades
- Transmission Studies
- Load Hosting Capacity
- Interconnection
- RR724
- Business Practice 7850
- Tariff Compliance
- Data Centers
- Flexible Intermittent Load
- Study Timelines
- Base Plan Upgrades
- Curtailable Service

## 8. Items That May Need Follow-Up

1. **Unresolved Questions**:
   - **Question 1**: How to proceed when Host TO and SPP study results don't match (answer not provided in content)
   - **Question 2**: How Transmission Customer should proceed when Host TO study is incomplete and delaying interconnection (partial answer provided)
   - **Question 3**: Treatment of pre-existing violations in load studies (answer not provided in content)
   - **Question 4**: Whether new loads must wait for base case upgrades identified in previous ITP processes (answer not provided in content)

2. **Load Hosting Capacity Tool**: Track stakeholder approval status and implementation timeline

3. **CHILL and PAL Implementation Details**:
   - Monthly/unreserved usage cost structure determination (marked with "?" in table)
   - TBD length of service for PAL
   - Flow-based transmission cost methodology

4. **HDPS Studies**: Recommended studies and supplemental studies stages referenced but not detailed in presentation

5. **Coordination Protocol**: Need for formal process when SPP and Host TO studies conflict

6. **Study Timeline Enforcement**: Monitoring compliance with 60/90-day study completion requirements

7. **Study Models Appendix**: Follow up on specific requirements for Short-Circuit, Stability, and Steady-State studies across different year horizons