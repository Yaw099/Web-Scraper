# REGULATORY MEETING ANALYSIS REPORT

## 1. Executive Summary

This presentation addresses questions about large load interconnection in SPP's service territory, specifically focusing on Highly Interruptible Large Load (HILL), HILL Generation Agreement (HILLGA), and Curtailable HILL Service (CHILLS) pathways. The meeting took place on July 2, 2026, and provided detailed guidance on how large loads (particularly data centers) can connect to the transmission system using various service options. Key topics included battery energy storage systems (BESS) integration with large loads, CHILLS implementation following FERC approval (effective July 1, 2026), designated resource requirements, and the relationship between load service and generation capacity. The presentation clarifies complex interconnection scenarios and provides two primary "CHILL OUT" options for customers seeking curtailable service.

## 2. Key Topics

- **HILL/HILLGA Pairing with Battery Storage**: Clarification on 1:1 matching of HILL load requirements with HILLGA supporting BESS generation accredited capacity
- **Behind-the-Meter (BTM) Battery Requirements**: Registration and service requirements for batteries that condition load but don't inject to the grid
- **CHILLS Implementation**: New curtailable service option approved by FERC, effective July 1, 2026 (RR720)
- **Two CHILL OUT Options**:
  - Option 1: Connect with adequate generation contingent on transmission upgrades (AQ agreement required)
  - Option 2: Require accredited equivalent HILLGA generation for CHILL
- **Designated Resources**: Requirements under Section 29.2(viii) for generation-backed supply arrangements
- **Planning Reserve Margin (PRM)**: Capacity requirements for large loads and resource adequacy obligations
- **Limited Operation Interconnection Service (LOIS)**: Whether loads can connect early when paired generation has only LOIS status
- **Market Storage Resource (MSR)**: Registration requirements for battery charging from the grid
- **Study Requirements**: Multiple models including Short-Circuit, Stability, and Steady-State analyses across years 1-10

## 3. Decisions or Actions

**Decisions Made:**
- CHILLS cannot be retroactively applied to previous HILL requests; new requests must be submitted as new AQ, AX, or BC requests
- All CHILL curtailed during EEA2 (Emergency Energy Alert Level 2)
- BTM batteries must be registered as Market Storage Resources (MSR) or receive firm Transmission Service (AQ or AX)
- No "netting" of load is permitted for battery charging
- AX loads (non-HILL) can only connect once planned generation receives firm service through ATSS process
- HILL loads have additional early connection options: LLRIS (HILLGA) and CHILLS

**Required Actions:**
- BTM batteries subject to Business Practice 7250 Section 6.3 (Non-Jurisdictional Generator) and Section 5 (ESR-LA)
- Network Customers must sign statement confirming resource ownership/purchase commitments
- CHILLS requests with Attachment BC must follow up within one year with corresponding AQ or AX request
- Transmission Service requirements: Resources must be greater than load + losses
- Resource Adequacy requirements: Must adhere to Planning Reserve Margin (Accredited amount)

## 4. Important Dates

- **July 2, 2026**: Date of this Large Load Q&A presentation
- **July 1, 2026**: Effective date of RR720 (CHILLS approval by FERC)
- **July 16, 2026**: CHILLS MIPO Change User Forum (1:30 PM - 4:30 PM CT via Webex)
- **August 21**: MOPC approval for HILL/HILLGA Firm Service Policies (year not specified, likely historical)
- **September 4**: BOD approval for HILL/HILLGA Firm Service Policies (year not specified, likely historical)
- **January 2026**: Phase 1 of Flexible Intermittent Policies (likely early 2026)
- **April 2026**: Phase 2 of Flexible Intermittent Policies
- **90 days**: Standard study timeframe for all service types (AQ, AX, HILLGA, CHILL, PAL)
- **7 years**: CHILL status duration (after study completion), after which must pursue AX/AQ
- **5 years**: Limited status for HILLGA Local Area service, must pursue DISIS/CPP
- **1 year**: Required follow-up timeframe for BC requests to submit corresponding AQ or AX request

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)**: Primary organization conducting the meeting
- **FERC (Federal Energy Regulatory Commission)**: Approved RR720
- **MOPC (Markets and Operations Policy Committee)**: Approval body for policies
- **BOD (Board of Directors)**: Final approval authority for policies
- **LSEs (Load-Serving Entities)**: Referenced as customers with sufficient generation
- **RMS (Request Management System)**: Platform for submitting additional questions

**People:**
- No specific individuals mentioned by name

**Customer Types Referenced:**
- Heavy industry, mining, refineries
- Data centers (with continuous demand and scalable operations)
- Crypto mining operations
- Battery storage operators
- Developers and partnerships

## 6. Links or References

**External Links:**
- **SPP.org**: General SPP website for registration
- **https://spp.org/calendar-list/change-user-forum-net-conference-20260716/**: Registration link for July 16 CHILLS MIPO forum

**Referenced Documents/Processes:**
- **RR720**: FERC-approved revision regarding CHILLS
- **Business Practice 7250 Section 6.3**: Non-Jurisdictional Generator requirements
- **Business Practice 7250 Section 5**: ESR-LA (Energy Storage Resource - Local Area) requirements
- **Attachment AQ**: Service agreement type for LSEs with sufficient generation
- **Attachment AX**: Service agreement type for LSEs acquiring generation
- **Attachment BC**: Request type for CHILLS
- **Attachment AE 2.22.1 (c)**: Referenced for transmission system limitations
- **Section 29.2(viii)**: Designated Resources requirements
- **ATSS (Aggregate Transmission Service Study) Process**: For firm service
- **DISIS/CPP Process**: For generation interconnection
- **ICS (Interconnection Construction Service)**: Screening process for ASGI
- **LLRIS (Large Load Reservation Interconnection Service)**: Service type for HILLGA
- **ITP (Integrated Transmission Planning)**: Study modeling process

## 7. Suggested Tags

- Large Load Interconnection
- HILL (Highly Interruptible Large Load)
- HILLGA (HILL Generation Agreement)
- CHILLS (Curtailable HILL Service)
- Battery Energy Storage Systems (BESS)
- Data Center Interconnection
- SPP Transmission Service
- Behind-the-Meter Battery
- Market Storage Resource (MSR)
- Designated Resources
- Planning Reserve Margin
- Resource Adequacy
- LOIS (Limited Operation Interconnection Service)
- Curtailable Service
- Transmission Upgrades
- EEA2 (Emergency Energy Alert)
- Generation Accreditation
- Network Service
- FERC RR720
- Load Hosting Capacity

## 8. Items That May Need Follow-Up

**Immediate Follow-Up Required:**
1. **CHILLS MIPO Forum Registration** (July 16, 2026): Stakeholders interested in CHILLS implementation details should register at SPP.org
2. **Previous HILL Requests**: Customers with existing HILL requests who want to use CHILLS must submit entirely new AQ, AX, or BC requests
3. **Additional Questions Submission**: Attendees were instructed to submit additional questions via RMS for the next Large Load Q&A call

**Technical Clarifications Needed:**
4. **Load Hosting Capacity Tool**: Marked as "Pending stakeholders' approval" - status and timeline unclear
5. **PAL (Protect Against Load) Service Details**: Length of service listed as "TBD" in the policy comparison table
6. **CHILLS Transmission Cost Structure**: "Monthly/unreserved usage?" marked with question mark, indicating uncertainty

**Policy Implementation Questions:**
7. **Accreditation Calculation Examples**: The example shows 100MW CHILL requiring 