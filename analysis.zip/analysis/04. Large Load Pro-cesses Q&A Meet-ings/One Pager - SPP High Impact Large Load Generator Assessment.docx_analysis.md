# REGULATORY MEETING/PAGE CONTENT ANALYSIS REPORT

## 1. Executive Summary

This document outlines the High Impact Large Load Generator Assessment (HILLGA) process, a new SPP mechanism designed to expedite the approval of supporting generation for large loads while maintaining transmission system reliability. The HILLGA process allows new generation to serve large loads in an interim capacity (up to 5 years) while limiting grid impact, with the option to transition to full generator interconnection through SPP's Consolidated Planning Process (CPP). The process was approved by the Board on 09/03/2025 and filed with FERC on 10/24/2025, with expected FERC acceptance by January 15, 2025. Key timeline: 90 calendar days for System Impact Study completion and 45 business days for interconnection agreement negotiation.

## 2. Key Topics

- **HILLGA Process Implementation**: Parallel study process for large load and supporting generation interconnection
- **Load Limited Resource Interconnection Service (LLRIS)**: Service type specific to HILLGA applications
- **System Impact Study (SIS) Requirements**: 90-day study timeline including steady-state, transient stability, short circuit ratio, and SCRCCT screening
- **Local Interconnection Criteria**: Maximum two substations away from HILL's Local Delivery Facilities
- **Maximum Injection Capability**: Not to exceed associated HILL request MW × higher of (110% + seasonal Planning Reserve Margin) or 125%
- **Nonjurisdictional Generation (NJG) Process**: Coordination requirements for generation not under SPP OATT
- **Transition to Full Interconnection**: Pathway from 5-year limited service to NRIS or ERIS through CPP
- **Electromagnetic Transient (EMT) Analysis**: Required if SCRCCT screening fails; PSCAD model recommended at submission

## 3. Decisions or Actions

**Decisions Made:**
- Board approved HILLGA process on 09/03/2025
- SPP filed final HILLGA proposal on 10/24/2025
- Service term limited to 5 years from Commercial Operation Date

**Actions Required:**
- HILLGA Customer must submit valid request with correct deposit and Point of Interconnection
- HILLGA Customer must provide PSCAD model at submission (recommended)
- SPP must acknowledge HILLGA Request within 5 business days
- SPP has 15 calendar day Review Period; customer has 10 business days to cure deficiencies
- SPP performs HILLGA SIS within 90 calendar days
- Transmission Owner performs Facilities Analysis within same 90 days
- HILLGA Customer must negotiate and execute HILLGIA within 45 business days
- For uninterrupted service beyond 5 years, customer must submit full Interconnection Request in subsequent CPP
- Transmission Owner must notify SPP of interconnection requests ≥5 MW (individual units)
- Transmission Owner must notify SPP of modifications to existing/planned generation if material impact

## 4. Important Dates

- **09/03/2025**: Board Approval (HILLGA available under special contract)
- **10/24/2025**: SPP filed final HILLGA proposal with FERC
- **January 15, 2025**: Expected FERC acceptance date (Note: This appears to be an error in the source document, as it precedes the filing date)
- **11/25/2025**: Document published
- **11/26/2025**: Correction to Submission Requirements

**Process Timelines:**
- **5 business days**: SPP acknowledgment of HILLGA Request
- **15 calendar days**: SPP Review Period
- **10 business days**: Customer cure period for deficiencies
- **90 calendar days**: HILLGA System Impact Study completion (from valid request/data validation)
- **60 calendar days**: Re-Study completion (if required)
- **45 business days**: HILLGIA negotiation and execution
- **5 years maximum**: Service term from Commercial Operation Date

## 5. Organizations and People Mentioned

**Organizations:**
- **SPP (Southwest Power Pool)**: Primary regulatory authority and study coordinator
- **FERC (Federal Energy Regulatory Commission)**: Regulatory approval authority
- **Transmission Owner**: Entity owning transmission facilities
- **Transmission Customer**: Entity requesting transmission service
- **HILLGA Customer**: Applicant for HILLGA process
- **AFS (Affected System) entities**: External systems potentially impacted
- **Distribution providers**: May submit generation requests through Transmission Owner

**Specific References:**
- SPP Board (granted approval)

**Roles/Entities (not named individuals):**
- Load customers
- Generator interconnection customers

## 6. Links or References

**Tariff Attachments:**
- **Attachment BB (Section 3.1.1)**: Submission requirements
- **Attachment AQ**: HILL Request specifications
- **Attachment AX**: HILL Request specifications  
- **Attachment BA**: HILL Request specifications

**Business Practices:**
- **SPP Business Practice 7250 (BP7250)**: 
  - Section 6.3: Non-jurisdictional generator interconnection procedures
  - Section 8: Stability analysis requirements

**Revision Requests:**
- **RR696**: Referenced as impacting existing processes
- **RR720**: In development, impacts existing processes

**Related Processes:**
- **Consolidated Planning Process (CPP)**: Full generator interconnection pathway
- **HILL (High Impact Large Load) registration**: Parallel process
- **HILL-Load Connection Study agreement**: Prerequisite for HILLGA application
- **HILLGIA (HILL Generator Interconnection Agreement)**: Required agreement
- **SPP OATT (Open Access Transmission Tariff)**: Governing tariff

**Service Types:**
- **NRIS (Network Resource Interconnection Service)**: Full interconnection option
- **ERIS (Energy Resource Interconnection Service)**: Alternative interconnection option
- **LLRIS (Load Limited Resource Interconnection Service)**: HILLGA-specific service

## 7. Suggested Tags

- HILLGA
- High Impact Large Load
- Generator Interconnection
- SPP
- System Impact Study
- Load Limited Resource Interconnection Service
- LLRIS
- Transmission Planning
- FERC Filing
- Consolidated Planning Process
- CPP
- Attachment BB
- Business Practice 7250
- Nonjurisdictional Generation
- NJG
- HILL Registration
- Deliverability Area
- Local Interconnection
- Network Resource Interconnection Service
- NRIS
- Energy Resource Interconnection Service
- ERIS
- SCRCCT Screening
- EMT Analysis
- RR696
- RR720
- Affected System Studies

## 8. Items That May Need Follow-Up

**Critical Follow-Up Items:**

1. **Date Discrepancy**: FERC acceptance date of "January 15, 2025" appears before the filing date of "10/24/2025" - needs clarification/correction

2. **FERC Approval Status**: Confirm actual FERC acceptance status and corrected acceptance date

3. **RR696 and RR720 Details**: Obtain full details on these revision requests and their specific impacts on existing processes

4. **EMT Study Timeline**: Clarify timeline extension if SCRCCT screening fails and EMT analysis is required beyond the 90-day window

5. **PSCAD Model Requirements**: Confirm whether PSCAD model submission is truly optional or effectively mandatory given EMT analysis risks

6. **Multiple HILL Support**: Clarification needed on the limitation that HILL Generating Facility may support multiple HILLs with "no more than 5 substations" vs. "no more than two substations" for local interconnection

7. **Affected System Coordination**: Define specific coordination protocols and timeline impacts when AFS entities are involved

8. **Deposit Amounts**: "Correct deposit" mentioned but amounts not specified - need deposit schedule

9. **Non-Jurisdictional 5 MW Threshold**: Confirm applicability of notification requirements for units at exactly 5 MW

10. **Transition Process Details**: Clarify "expedited designation process" for transitioning from HILLGIA to full NRIS/ERIS

11. **Special Contract Terms**: Define terms and conditions for HILLGA availability under "special contract" prior to FERC acceptance

12. **Re-Study Triggers**: Define conditions that would trigger a Re-Study requirement

13. **Service Term Extension**: Clarify gap (if any) between 5-year HILLGIA expiration and full