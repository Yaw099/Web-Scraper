# Final Combined Report

# COMPREHENSIVE REGULATORY MEETING ANALYSIS REPORT
**SPP Large Load Processes Q&A Session - May 7, 2026**

---

## 1. EXECUTIVE SUMMARY

This report analyzes a comprehensive informational session held by Southwest Power Pool (SPP) on May 7, 2026 (2:30-4:00 PM CT), addressing large load connection processes in response to unprecedented load growth from AI facilities, data centers, cryptocurrency mining, and industrial operations. The meeting covered multiple interconnection pathways including High Impact Large Loads (HILLs), High Impact Large Load Generator Assessment (HILGA), Conditional High Impact Large Load Service (CHILLs), and emerging Price Adaptive Load (PALs) concepts.

**Critical Context**: SPP is responding to dramatic increases in load requests requiring new frameworks to balance "speed to power" for developers against grid reliability and market integrity. The session served as educational outreach for both internal and external stakeholders navigating increasingly complex interconnection options.

**Key Tension Points**: The meeting revealed ongoing policy development challenges around battery storage integration, market pricing impacts of curtailable loads, and jurisdictional boundaries between SPP, transmission customers, and developers.

---

## 2. KEY TOPICS

### A. Transmission Service Foundations
- **Fundamental Requirement**: All loads must obtain SPP transmission service (point-to-point, network service, or proposed CHILL service)
- **Eligibility Constraint**: Only SPP transmission customers with state-granted load serving authority can request service
- **Developer Challenge**: Non-utility developers must coordinate through local transmission customers, creating procedural complexity
- **Onboarding Timeline**: ~45 days for transmission customer onboarding; 10 days initial assessment; 60-90 day study periods

### B. High Impact Large Load (HILL) Classification
**Thresholds**:
- 10+ MW for connections ≤69 kV
- 50+ MW for connections >69 kV
- Battery storage explicitly excluded from HILL classification but must register as market resources

**Study Requirements** (90-day timeline):
- Transient stability analysis
- EMT (Electromagnetic Transient) screening
- Short circuit ratio assessment
- Critical clearing time evaluation
- Voltage/frequency ride-through requirements
- Fast ramping impact analysis

**Planning Integration**:
- Models for years 1, 2, 3, 5, and 10 in ITP (Integrated Transmission Planning)
- Zonal planning criteria inclusion begins May 10, 2026
- East region: 69 kV and above; West region: 100 kV and above

### C. Load Connection Pathways

**Attachment AQ** (Firm Service):
- Existing generation resources
- Base plan funding with load ratio sharing for network upgrades
- Standard path for long-term firm service

**Attachment AX** (Provisional Service):
- For planned generation resources
- Provisional Load Agreement process for pre-commercial generation
- 100% direct cost assignment initially, converts to base plan funding once resources are firm
- Notice to Construct (NTC) can be issued during provisional phase

### D. HILGA (High Impact Large Load Generator Assessment)

**Purpose**: Behind-the-meter or load-limited resource interconnection within two buses of load

**Key Features**:
- Five-year term GIA (Generator Interconnection Agreement)
- Load Limited Resource Interconnection Service (LLRIS)
- Cannot inject additional capacity into marketplace
- Designed as "on-ramp" to full SPP interconnection
- Transition path to CPP (Consolidated Planning Process) available before 5-year term expires

**Path One (Behind-the-Meter)**:
- Non-jurisdictional facilities per Business Practice 7250, Section 6.3
- Common bus configurations (case-by-case TO determination required)
- Does not eliminate transmission service requirements

**Two-Bus Criterion**:
- Minimum one electrical bus separation between HILL and HILGA
- Electrical vs. physical distance distinction important
- Visual diagram provided during meeting

**Capacity Calculations**:
- Nameplate basis: Load × 110% + reserve margin (or 125%, whichever higher)
- Accreditation NOT required for HILGA (only for CHILLs)

**Exclusionary Provisions**:
- Cannot have simultaneous DICIS request and HILGA at same Point of Interconnection (POI)
- Projects must choose between DICIS or HILGA pathways
- Can enter CPP after obtaining HILGA GIA

### E. CHILLs (Conditional High Impact Large Load Service)

**Service Characteristics**:
- Curtailable transmission service option
- First to be curtailed in emergencies (before firm loads)
- One-year initial period required before path to firm service demonstration
- Maximum seven-year duration if path to firm service is demonstrated
- Requires adequate generation **accreditation** (not just nameplate capacity)

**Policy Status**:
- Filed with FERC as RR 720
- Requested effective date: July 1, 2026 (pending FERC approval)
- Available on spp.org

**Development Status**:
- Phase 2 under development to address stakeholder concerns:
  - Market pricing impacts
  - Resource run hours
  - Uncovered loads without generation support

**Path to Firm Service**:
- Within one year, must submit Attachment AQ or AX request
- Demonstrates commitment to transition from curtailable to firm service

### F. PALs (Price Adaptive Load Service)

**Concept**: Emerging framework for loads that respond to market price signals (turn on/off based on pricing)

**Status**: Policy in development; approval expected in coming months

**Driver**: Response to stakeholder concerns about CHILLs market impacts and loads without generation coverage

### G. Battery Energy Storage Complexities

**Multiple Unresolved Scenarios**:
1. Battery as HILGA generator without CHILLs service (charging mechanism unclear)
2. Solar + battery combinations under HILGA
3. Battery charging from SPP transmission system under CHILLs service
4. Market Storage Resource requirements vs. load service
5. Co-located generation capacity resource qualification

**Study Process**: ESRLA (Energy Storage Resource Load Assessment) for studying battery charging impacts

**Key Issue**: Tension between generation interconnection requirements and load service needs when batteries serve dual functions

### H. Spot Load Survey Process

**Purpose**: Identify potential future large loads for ITP/CPP planning cycles

**Methodology**:
- Survey-based approach (described as having "no rules" currently)
- "Future 1" (high confidence loads) vs. "Future 2" (all other loads) categorization
- Started in 2025 ITP (25 ITP)
- Larger load amounts in 2026 ITP (26 ITP)
- Annual recurring process

### I. Affected System Studies

**Protocols**:
- Conducted by both SPP and transmission owner depending on location
- Different procedures for different RTOs/ISOs vs. distribution-level connections
- MW value determines study requirements
- Specific thresholds not fully detailed in transcript

---

## 3. DECISIONS OR ACTIONS

### Established Policies

1. **Study Timelines Confirmed**:
   - HILLs: 90-day study period (from information completeness and scoping call)
   - Non-HILL loads: 60-day study period
   - Transmission customer onboarding: ~45 days
   - Initial assessment: 10 days

2. **Cost Allocation Framework**:
   - Attachment AQ network upgrades: Base plan funded with load ratio sharing
   - Attachment AX upgrades: 100% directly assigned initially, converts to base plan funding once resources are firm
   - HILGA: Service-specific cost assignment

3. **Zonal Planning Criteria Integration**: Begins May 10, 2026 in steady state analysis

4. **HILGA Service Parameters**:
   - Five-year maximum GIA term
   - Two-bus minimum separation requirement
   - Nameplate capacity calculation formula established
   - Exclusionary rule with DICIS confirmed

5. **CHILLs Service Requirements**:
   - One-year demonstration period before requiring path to firm service
   - Seven-year maximum duration with demonstrated path
   - Accreditation required (not just nameplate)
   - First-curtailed status in emergencies

### Items Under Development

6. **CPP Phase Two**: HILGA-to-CPP transition procedures being developed through CPPTF (CPP Task Force) and GIAG to avoid service gaps

7. **CH

---

# Partial Chunk Reports

# Chunk 1 Analysis

# REGULATORY MEETING ANALYSIS REPORT

## 1. Executive Summary

This meeting transcript documents an SPP (Southwest Power Pool) informational session held on May 7, 2026, focused on large load connection processes. The session addressed new procedures for handling high-impact large loads (HILLs), driven by unprecedented load growth from AI, data centers, cryptocurrency mining, and industrial facilities. Key topics included transmission service requirements, the High Impact Large Load Generator Assessment (HILGA) study process, and the proposed Conditional High Impact Large Load Service (CHILLs) and Price Adaptive Load (PALs) processes. The meeting served as an educational forum for internal and external stakeholders to understand SPP's evolving framework for managing significant new load connections to the transmission system.

## 2. Key Topics

- **SPP Transmission Service Requirements**: All loads must have SPP transmission service (point-to-point, network service, or proposed CHILL service); only SPP transmission customers with load serving authority can request service
- **High Impact Large Load (HILL) Definition**: 
  - 10+ MW for connections ≤69 kV
  - 50+ MW for connections >69 kV
  - Excludes battery storage
- **Load Connection Pathways**:
  - Attachment AQ (existing generation resources)
  - Attachment AX (planned generation resources with provisional load agreements)
- **HILL Study Requirements**: 90-day studies including transient stability analysis, EMT screening, short circuit ratio, and critical clearing time
- **HILGA Process**: High Impact Large Load Generator Assessment for behind-the-meter or load-limited resource interconnection
- **Cost Allocation**: Base plan funding vs. direct assignment depending on process and voltage level
- **Study Models**: ITP (Integrated Transmission Planning) models for years 1, 2, 3, 5, and 10
- **New Requirements**: Voltage and frequency ride-through requirements for HILLs

## 3. Decisions or Actions

**Established Policies:**
- HILLs require 90-day study periods (vs. 60 days for standard loads)
- Zonal planning criteria will be included in steady state analysis starting May 10th
- Network upgrades from Attachment AQ are base plan funded with load ratio sharing
- Attachment AX upgrades are 100% directly assigned initially, then converted to base plan funding once resources are firm
- Battery storage explicitly excluded from HILL classification but must register in the market

**Study Requirements:**
- Analysis for east region: 69 kV and above; west region: 100 kV and above
- Fast ramping capabilities must be evaluated for reliability impacts
- EMT screening failures trigger supplemental studies beyond the 90-day window

## 4. Important Dates

- **May 7, 2026, 2:30-4:00 PM CT**: Meeting date and time
- **May 10th** (year context: 2026): Start date for including zonal planning criteria in steady state analysis
- **~45 days**: Transmission customer onboarding process duration
- **10 days**: Initial assessment period upon receiving load requests
- **60 days**: Standard study timeline for non-HILL loads
- **90 days**: Study timeline for HILLs (from information completeness and scoping call)
- **Years 1, 2, 3, 5, and 10**: Model years used in ITP analysis

## 5. Organizations and People Mentioned

**People:**
- **Nolan** (primary presenter): Lead on transmission service and load connection processes
- **Calvin Rosenbaum**: Presenter on HILGA (High Impact Large Load Generator Assessment)
- **Jonathan Lubobo**: Attendee with brief comments
- **Andrea Harrison**: Attendee (acknowledgment noted in transcript)

**Organizations:**
- **SPP (Southwest Power Pool)**: Regional transmission organization hosting the meeting
- **SPP transmission customers**: Utilities with load serving authority
- **Host transmission owners**: Involved in scoping calls for load studies

**Implied Stakeholders:**
- State regulatory authorities (referenced regarding serving authority requirements)
- AI companies, data centers, cryptocurrency mining operations, industrial facilities (driving load growth)

## 6. Links or References

**Referenced Processes/Documents:**
- SPP Open Access Tariff (Attachment AQ, Attachment AX)
- ITP/CPP process (Integrated Transmission Planning/Comprehensive Planning Process)
- FAC-002 standards (facilities design requirements)
- Aggregate study process
- CHILLs (Conditional High Impact Large Load Service) material and process documents
- PALs (Price Adaptive Load) material and process documents

**Meeting Materials:**
- Process documentation to be shared via links (mentioned at end of agenda)
- Appendix materials on EMT screening details
- Reference slides for detailed study processes

**Standards Referenced:**
- SPP criteria
- Zonal planning criteria
- Voltage ride-through requirements
- Frequency ride-through requirements

## 7. Suggested Tags

`SPP` `Large-Load` `High-Impact-Large-Load` `HILL` `HILGA` `Transmission-Service` `Load-Interconnection` `Attachment-AQ` `Attachment-AX` `Data-Centers` `AI-Load-Growth` `Cryptocurrency` `Load-Studies` `Transmission-Planning` `ITP` `Network-Upgrades` `Cost-Allocation` `Stability-Analysis` `EMT-Screening` `Regulatory-Process` `CHILLs` `PALs` `Price-Adaptive-Load` `Grid-Reliability` `May-2026`

## 8. Items That May Need Follow-Up

**Process Clarifications Needed:**
- Complete details on CHILLs (Conditional High Impact Large Load Service) and PALs (Price Adaptive Load) processes (agenda items not fully covered in this excerpt)
- Supplemental EMT study process details and timelines when screening fails
- Transmission customer onboarding process specifics (45-day process mentioned but not detailed)
- State-specific requirements for load serving authority
- Complete HILGA presentation (cut off mid-discussion)

**Technical Details:**
- Behind-the-meter connection requirements and jurisdictional boundaries
- Load-limited resource interconnection service details
- Fast ramping analysis methodology for reliability impacts
- Specific voltage ride-through and frequency ride-through thresholds

**Documentation:**
- Links to process documents (promised but not provided in this excerpt)
- Location of "encyclopedia" reference materials mentioned
- Q&A session outcomes (scheduled but not included in this chunk)
- Next meeting agenda formation details

**Policy Considerations:**
- How battery storage registration requirements differ from HILL process
- Provisional load agreement conversion criteria and timing
- Base plan funding allocation formulas (regional vs. zonal percentages)
- Critical clearing time acceptance thresholds

**Stakeholder Engagement:**
- Follow-up for external (non-SPP member) stakeholders seeking to understand processes
- Coordination requirements between transmission customers, SPP, and host transmission owners during scoping calls

---

**Note**: This analysis covers chunk 1 of 6 from the source document. Complete understanding of all topics (particularly CHILLs, PALs, Q&A, and next steps) will require review of subsequent chunks.

---

# Chunk 2 Analysis

# Regulatory Meeting Analysis Report

## 1. Executive Summary

This document is a transcript from an SPP (Southwest Power Pool) meeting focused on Large Load Processes, specifically addressing transmission service options for high-impact large loads. The discussion covers several service types: behind-the-meter generation, Load Limited Interconnection Service (HILGA), Conditional High Impact Large Load Service (CHILLS), and Price Adaptive Load Service (PALS). Key themes include providing expedited pathways to connect large loads while managing grid reliability and market impacts. The meeting includes detailed technical explanations followed by Q&A sessions with stakeholders.

## 2. Key Topics

- **Behind-the-Meter Generation**: Criteria defined in business practice 7250 section 6.3 for non-jurisdictional generators serving local loads
- **HILGA (High Impact Large Load with Generator Attachment)**: 
  - Load limited interconnection service within two buses of the load
  - Five-year term GIA (Generator Interconnection Agreement)
  - Designed as "on-ramp" to full SPP interconnection
  - Cannot inject additional capacity into marketplace
- **CHILLS (Conditional High Impact Large Load Service)**:
  - Curtailable transmission service option
  - First to be curtailed in emergencies (before firm loads)
  - One-year initial period, extendable to seven years with path to firm service
  - Requires adequate generation accreditation (not just nameplate capacity)
  - Phase 2 under development
- **PALS (Price Adaptive Load Service)**: 
  - Emerging concept for loads that turn on/off based on market prices
  - Policy currently in development
  - Response to stakeholder concerns about uncovered CHILLS
- **Transmission Service Requirements**: All loads need transmission service via Attachment AQ (firm) or AX (with generation)

## 3. Decisions or Actions

- **CHILLS Phase 2 is under development** to address stakeholder concerns about market pricing impacts and uncovered loads
- **PALS policy is being developed** and expected for approval in coming months
- **Within one year of CHILLS service**, customers must submit either Attachment AQ or AX request to demonstrate path toward firm service
- **Provisional Load Agreement process** established for AX requests where generation isn't yet commercial
- **Notice to Construct (NTC)** can be issued for upgrades during provisional agreement phase

## 4. Important Dates

- **Five years**: Term of life for HILGA GIA (Generator Interconnection Agreement) after reaching COD
- **One year**: Initial CHILLS service period before requiring demonstration of path to firm service
- **Seven years**: Maximum CHILLS service duration if path to firm service is demonstrated
- **Coming months**: Expected approval timeframe for PALS policy

## 5. Organizations and People Mentioned

**Organizations:**
- SPP (Southwest Power Pool)
- FERC (Federal Energy Regulatory Commission)
- GRDA (Grand River Dam Authority)

**People:**
- Calvin (presenter - discussed HILGA and behind-the-meter)
- Nolan (presenter - discussed CHILLS and PALS)
- Kate (stakeholder with question)
- Joe Fultz, GRDA (asked question about spot loads)
- Ron (asked question via chat about NITS transmission)

## 6. Links or References

- **Business Practice 7250, Section 6.3**: Criteria for behind-the-meter/non-jurisdictional generators
- **RR 720**: Regulatory document filed at FERC containing CHILLS language (available on spp.org)
- **Attachment AQ**: Firm transmission service request process
- **Attachment AX**: Transmission service with generation request process
- **SPP.org**: Website where RR 720 and related documents are available

## 7. Suggested Tags

- Large Load Interconnection
- Transmission Service
- HILGA
- CHILLS
- PALS
- Generator Interconnection
- Resource Adequacy
- SPP Policy
- Behind-the-Meter Generation
- Curtailable Service
- Emergency Procedures
- Market Pricing
- Load Limited Service
- Accreditation Requirements
- PRM (Planning Reserve Margin)

## 8. Items That May Need Follow-Up

1. **CHILLS Phase 2 Development**: Track progress on addressing market pricing impacts, run hours on resources, and stakeholder concerns about uncovered loads
2. **PALS Policy Approval**: Monitor development and approval timeline for Price Adaptive Load Service policy
3. **Ron's Question Resolution**: Confirm whether the answer about provisional load agreements fully addressed the question about requesting NITS transmission through Attachment AX
4. **Joe Fultz's Spot Loads Question**: The transcript cuts off before this question is fully answered - needs completion
5. **Market Impact Analysis**: Follow up on concerns about CHILLS impact to market pricing and resource run hours
6. **Phase 2 Stakeholder Engagement**: Engage stakeholders who desire CHILLS service without generation coverage
7. **Accreditation vs. Nameplate Requirements**: Clarify documentation requirements for demonstrating adequate generation support for CHILLS (accreditation) vs. HILGA (nameplate + PRM)
8. **Transition from Provisional to Firm Service**: Document the specific steps and requirements for transitioning from provisional load agreement to actual service agreement under Attachment AX

---

# Chunk 3 Analysis

# Regulatory Meeting Analysis Report

## 1. Executive Summary

This is a Q&A session from an SPP (Southwest Power Pool) meeting held on May 7, 2026, focusing on Large Load Processes. The discussion covers various interconnection processes including AQ (Attachment AQ), HILGA (High Impact Large Generation), CHILLs (Conditional High Impact Large Loads), and ESRLA (Energy Storage Resource Load Assessment). Key themes include: the spot load survey process for planning, transmission developer requirements, battery energy storage interconnection challenges, and the pending FERC approval for CHILLs service. The meeting clarifies that only SPP transmission customers or local utilities can submit load interconnection requests, creating complexity for developers.

## 2. Key Topics

- **Spot Load Analysis Process**: Survey-based approach for identifying potential future loads (data centers, large loads) for ITP/CPP planning cycles with "Future 1" (high confidence) and "Future 2" (all other loads) categorizations
- **Transmission Developer Requirements**: Process for developers without transmission ownership to submit load interconnection requests via transmission lines
- **Battery Energy Storage (BES) as HILGA**: Challenges of using batteries to serve large loads, including charging requirements and market participation
- **CHILLs Service (Conditional High Impact Large Loads)**: Pending FERC approval with requested July 1st effective date
- **Transmission Customer Eligibility**: Requirements for becoming an SPP transmission customer and role of local utilities
- **HILGA Path 1**: Behind-the-meter interconnection process and its relationship to CPP studies
- **ESRLA Process**: Energy Storage Resource Load Assessment for studying battery charging

## 3. Decisions or Actions

- **No Final Decisions Made** - This was a Q&A/informational session
- **Action Items Implied**:
  - Participants to submit detailed hypothetical questions for future meetings
  - Developers must work with local utilities to submit requests
  - Transmission customers must complete SPP onboarding process (4-5 days)
  - Wait for FERC approval before submitting CHILLs requests

## 4. Important Dates

- **July 1st**: Requested effective date for CHILLs service (pending FERC approval)
- **25 ITP**: Spot load survey started in 2025 ITP cycle
- **26 ITP**: Current planning cycle with larger load amounts being studied
- **Five-year term**: Maximum duration for HILGA on transmission system

## 5. Organizations and People Mentioned

**Organizations:**
- SPP (Southwest Power Pool)
- FERC (Federal Energy Regulatory Commission)
- Jubilee Transmission
- Plus Power
- SAVI

**Named Participants:**
- **Joe Fultz** (questioner)
- **Saad** (Jubilee Transmission - transmission developer)
- **Robel Arega** (Plus Power - battery storage inquiry)
- **Calvin Rosenbaum** (SPP representative - technical responses)
- **Ash Panegal** (questioner - CHILLs and conditional service)
- **Kellen Kinard** (SAVI-DRN/X - HILGA Path 1 questions)
- **Dara** (mentioned as posting information in chat)

## 6. Links or References

- **SPP.org**: Referenced for transmission customer onboarding process information
- **SPP Tariff**: Contains definition of "transmission customer" (capitalized/defined term)
- **Attachment AQ**: Firm transmission service process
- **Attachment AX**: Alternative transmission service process
- **Ride 720**: Related to CHILLs service
- **ICS (Interconnection Study)**: Mentioned in context of affected systems
- **CPP (Comprehensive Planning Process)**: Planning cycle reference

## 7. Suggested Tags

`SPP` `large-load-interconnection` `HILGA` `CHILLs` `transmission-planning` `battery-storage` `ESRLA` `FERC-approval` `AQ-process` `transmission-customer` `data-centers` `spot-loads` `ITP` `CPP` `energy-storage` `load-interconnection` `utility-requirements` `Q&A-session`

## 8. Items That May Need Follow-Up

1. **FERC Approval Status for CHILLs**: Critical path item - need to track approval timeline and actual effective date vs. requested July 1st date

2. **Battery Storage Guidance**: SPP indicated BES as HILGA may not be "most efficient use case" - developers need clearer written guidance on viable battery configurations

3. **Hypothetical Scenario Clarification**: Ash Panegal to submit detailed question about conditional HILGA + HILGAR + BES scenario for future meeting response

4. **Spot Load Survey Formalization**: Process currently has "no rules" - may need standardized criteria and confidence level definitions established

5. **Transmission Developer Process**: Need clearer documentation of the complete pathway for developers without transmission ownership to work with local utilities

6. **Behind-the-Meter HILGA Path 1**: Kellen Kinard's question about CPP study requirements and temporary vs. permanent status was cut off - needs completion

7. **Local Utility Coordination**: No clear process outlined for how developers coordinate with local utilities that are TCs - potential friction point

8. **State Eligibility Requirements**: Referenced but not detailed - developers need state-by-state guidance on load-serving eligibility

9. **ESRLA vs. AQ for Storage**: Confusion exists about when batteries need ESRLA vs. firm transmission service (AQ) - needs clearer decision tree

10. **Annual Survey Timeline**: Confirm spot load survey will continue annually and establish submission deadlines

---

# Chunk 4 Analysis

# Regulatory Meeting Analysis Report
## SPP Large Load Processes Q&A - Chunk 4 of 6

---

## 1. Executive Summary

This segment contains detailed technical discussions from an SPP (Southwest Power Pool) Q&A session focused on HILGA (High Impact Load Generator Agreement) processes, interconnection requirements, and the interaction between HILGA and DICIS (Definitive Interconnection Capital Investment Schedule) processes. Key participants clarified requirements for behind-the-meter generation, transmission service obligations, nameplate capacity calculations, and the transition between different interconnection service types. Critical procedural clarifications were provided regarding exclusionary rules between HILGA and DICIS requests, and the pathway from load-limited resource interconnection service (LLRIS) to longer-term interconnection through the CPP (Consolidated Planning Process).

---

## 2. Key Topics

### HILGA Process Requirements
- **Behind-the-meter configurations** (Path One) including non-jurisdictional facilities and common bus arrangements
- **Transmission service requirements** - loads must obtain transmission service through transmission customer even after HILGA agreement
- **Nameplate capacity calculations** - Load multiplied by 110% plus reserve margin (or 125%, whichever is higher) for HILGA applications
- **Accreditation considerations** - only applies to CHILLS, not HILGA or standard transmission service (AQ/AX)

### DICIS and HILGA Interaction
- **Exclusionary provisions** - cannot have DICIS request and HILGA at same POI (Point of Interconnection) simultaneously per Attachment BB
- **Sequential pathways** - projects must choose between DICIS or HILGA; can enter CPP after obtaining HILGA GIA
- **Service transition** - LLRIS (5-year limited) can transition to CPP for long-term interconnection rights

### Affected System Studies
- Conducted by both SPP and transmission owner (TO) depending on location
- Different protocols for different RTOs/ISOs vs. distribution-level connections
- MW value determines study requirements

---

## 3. Decisions or Actions

### Confirmed Processes
- **HILGA applications use nameplate capacity** calculated as: Load × 110% + reserve margin (or 125%, whichever higher)
- **Accreditation only required for CHILLS**, not HILGA or standard transmission service
- **Projects must withdraw DICIS requests** to pursue HILGA for same generator/location
- **CPP entry allowed after HILGA GIA** - no requirement to wait until 5-year LLRIS expires

### Under Development
- **CPP Phase Two stakeholder process** ongoing to define HILGA-to-CPP transition procedures
- Ensuring no service gaps when transitioning from HILGA GIA to CPP GIA
- Being developed through CPPTF (CPP Task Force) and GIAG

---

## 4. Important Dates

- **5-year service limit** for LLRIS (Load Limited Resource Interconnection Service) under HILGA
- **2024 DICIS request** mentioned as example timeframe
- **Monthly recurring meetings** planned for ongoing Q&A and examples

---

## 5. Organizations and People Mentioned

### Organizations
- **SPP (Southwest Power Pool)** - primary regulatory body
- **MISO** - mentioned as example separate transmission system
- **PJM** - mentioned as example separate transmission system
- **GRDA (Grand River Dam Authority)** - participant organization
- **Invenergy** - participant organization
- **AES Clean Energy** - participant organization
- **SAVI-DRN/X** - participant organization

### Individuals
- **Kellen Kinard** (SAVI-DRN/X) - questioner
- **Calvin Rosenbaum** - SPP technical expert/presenter
- **Juliano Freitas** (Invenergy) - questioner
- **Jason** (Meeting 3A Room 372) - moderator/presenter
- **Michael Hutson** (AES Clean Energy) - questioner
- **Tim Brown** (GRDA) - questioner
- **Nolan** - SPP staff member

---

## 6. Links or References

### Tariff Sections
- **Attachment BB** - HILGA portion of tariff
- **Attachment B** - DICIS processes
- **Appendix One** - referenced for NHTSA service agreements

### Processes Referenced
- **CPP (Consolidated Planning Process)** - ICS/interconnection process
- **CPP Phase One** - currently ongoing
- **CPP Phase Two** - under development for HILGA and transmission service integration
- **CPPTF (CPP Task Force)** - stakeholder development group
- **GIAG** - referenced working group
- **AQ process** - aggregate study process
- **DICIS** - Definitive Interconnection Capital Investment Schedule

### Service Types
- **LLRIS** - Load Limited Resource Interconnection Service
- **ERIS** - Energy Resource Interconnection Service
- **NRIS** - Network Resource Interconnection Service
- **PRM** - Planning Reserve Margin requirements

---

## 7. Suggested Tags

- HILGA
- Large Load Interconnection
- SPP Tariff
- Behind-the-Meter Generation
- Transmission Service
- DICIS Process
- Consolidated Planning Process
- Load Limited Interconnection
- Nameplate Capacity
- Reserve Margins
- Affected System Studies
- Co-located Generation
- Non-jurisdictional Facilities
- Interconnection Service
- CPP Task Force

---

## 8. Items That May Need Follow-Up

### Clarification Needed
1. **Common bus configuration determination** - requires case-by-case TO consultation to confirm whether specific substation configurations qualify as HILGA Path One/behind-the-meter
2. **Affected system study protocols** - MW thresholds that determine whether distribution-level generation requires combined SPP/TO studies vs. other study requirements

### Process Development Tracking
3. **CPP Phase Two timeline** - monitor CPPTF development of HILGA-to-CPP transition procedures to avoid service gaps during 5-year LLRIS period
4. **Monthly Q&A meetings schedule** - establish recurring meeting calendar for ongoing stakeholder education

### Business Process Issues
5. **DICIS/HILGA exclusion implications** - developers with 2024 DICIS requests need guidance on strategic decision-making between continuing DICIS vs. withdrawing for HILGA
6. **Resource adequacy participation** - follow up on co-located generator capacity resource qualification for utilities when generator lacks injection rights
7. **Transmission service coordination** - clarify coordination between HILGA agreements and subsequent transmission service acquisition through transmission customers

### Documentation Needs
8. **Stakeholder guidance documents** - create written materials explaining HILGA nameplate calculations, accreditation requirements, and service type distinctions
9. **DICIS-to-CPP pathway documentation** - flowcharts or process maps showing decision trees and timelines for developers choosing between interconnection pathways

---

**Analysis Confidence Level:** High - Content contains specific technical discussions with clear procedural explanations, though some case-specific determinations require additional TO consultation.

---

# Chunk 5 Analysis

# Regulatory Meeting Analysis Report

## 1. Executive Summary

This transcript excerpt (chunk 5 of 6) captures a technical Q&A session regarding SPP's Large Load Processes, specifically focusing on High Impact Large Load (HILL) and High Impact Large Load Generator Aggregation (HILGA) services. The discussion addresses complex scenarios involving transmission service requirements, load-generation interconnections, battery storage charging mechanisms, and the two-bus criterion. Key participants include Calvin Rosenbaum and various stakeholders (Tim Brown, Ash Panegal, Steve Gaw) asking clarification questions about service options, technical requirements, and emerging use cases involving battery storage paired with renewable generation.

## 2. Key Topics

- **HILGA Study Processes**: Discussion of the 90-day study period and transmission owner (TO) options for stability studies under Business Practice 7250
- **HILGA vs. CHILL Services**: Clarification that HILGA can be a standalone service source without transmission service, but has limitations due to charging constraints
- **Load Limited Radial Integrated Service (LLRIS)**: Service path from HILGA to HILL without requiring CHILL service
- **Two-Bus Criterion**: Requirements for separation between HILL and HILGA (minimum one bus in between); distinction between electrical and physical distance
- **Battery Storage Charging Scenarios**: Multiple use cases discussed:
  - Battery as HILGA generator without CHILL service
  - Solar + battery combinations under HILGA
  - Battery charging from SPP transmission system under CHILL service
- **Conditional HILL (CHILL) Service**: Availability determination process and curtailment implications
- **CPP Process**: HILGA sites treatment in planning processes (still under development)

## 3. Decisions or Actions

- **Visual Aid Posted**: Calvin Rosenbaum posted a diagram to chat showing the two-bus criterion
- **Recommendation to Stakeholders**: Participants encouraged to work directly with transmission owners to clarify metered point configurations versus planning model representations
- **Pending Clarification Needed**: Battery storage charging scenarios under different service types require further bilateral discussion
- **Jurisdictional Boundaries Established**: Determination of firm vs. CHILL vs. HILGA service is outside SPP jurisdiction; agreement between transmission customer and load developer

## 4. Important Dates

- **90-day study period**: Referenced for HILGA study process timeline
- **Meeting timestamp**: Session occurred on 05/07/2026 (based on filename)
- No specific future deadlines mentioned in this excerpt

## 5. Organizations and People Mentioned

**People:**
- **Calvin Rosenbaum** (SPP representative, primary responder)
- **Tim Brown** (questioner, 1:09:06 timestamp)
- **Ash Panegal** (multiple detailed questions)
- **Steve Gaw** (APA - American Public Power Association, joined late)

**Organizations:**
- **SPP** (Southwest Power Pool)
- **APA** (American Public Power Association)
- **Transmission Owners (TOs)** (multiple references)
- **FERC** (referenced regarding CHILL proposal)

**Facilities/Entities:**
- Meeting 3A Room 372 (meeting location identifier)

## 6. Links or References

**Documents/Resources Referenced:**
- **Business Practice 7250**: Contains detailed breakdown of HILGA study situations
- **Two-bus criterion diagram**: Posted to chat during meeting
- **CPP Process** (unclear what CPP stands for - Connected Planning Process?)
- **FERC proposal**: Referenced regarding CHILL service

**No URLs or external links provided in transcript**

## 7. Suggested Tags

- Large Load Processes
- HILL (High Impact Large Load)
- HILGA (High Impact Large Load Generator Aggregation)
- CHILL (Conditional High Impact Large Load)
- LLRIS (Load Limited Radial Integrated Service)
- Transmission Service
- Battery Storage
- Two-Bus Criterion
- Stability Studies
- Business Practice 7250
- Market Storage Resource
- Renewable Integration
- Solar Generation
- Transmission Owner Coordination
- SPP Stakeholder Meeting

## 8. Items That May Need Follow-Up

### High Priority:
1. **Battery Storage Charging Protocols**: Multiple unresolved scenarios regarding how battery storage facilities can charge under different service types (HILGA-only, CHILL, firm transmission)
   - *Stakeholders involved*: Steve Gaw, Calvin Rosenbaum, SPP staff
   - *Status*: Deferred for separate conversation

2. **CPP Process Treatment of HILGA Sites**: How HILGA sites will be handled as "planned sites" in the CPP process
   - *Status*: "Still under development" per meeting discussion

3. **Load Study Methodology for Battery+Solar Combinations**: How to study summation vs. netting of charging load and generation when battery+solar paired with large load
   - *Status*: Question raised but not answered

### Medium Priority:
4. **Two-Bus Criterion Physical vs. Electrical Distance**: Clarification needed when two buses are physically co-located at same substation but electrically separate
   - *Action*: Verify with transmission owner on configuration

5. **CHILL Service Availability Determination**: Process for how transmission customers/load developers learn if CHILL service is available
   - *Status*: Outside SPP jurisdiction; bilateral determination needed

6. **Battery as HILGA Generator Without CHILL**: Feasibility question - how battery charges if only service is HILGA without market participation
   - *Preliminary answer*: Would require market storage resource status

### Administrative:
7. **Business Practice 7250 Review**: Stakeholders may need to review detailed provisions
8. **Visual Diagrams**: Distribution of two-bus criterion diagram to all participants

---

# Chunk 6 Analysis

# REGULATORY MEETING ANALYSIS REPORT

## 1. Executive Summary

This is the final segment (chunk 6 of 6) of an SPP Large Load Processes Q&A session held on May 7, 2026. The discussion focused on clarifying the use cases for HILGER (likely a transmission service designation), particularly regarding AX (service expansion) and AQ processes, network service integration, and resource adequacy requirements. The meeting concluded with procedural information about future meetings and question submission processes. The session emphasized that HILGER addresses "speed to power" rather than long-term firm service solutions.

## 2. Key Topics

- **HILGER Service Applications**: Use cases for HILGER in AX vs. AQ processes
- **Network Service Integration**: How HILGER integrates with Load Responsible Entity (LRE) network service
- **Resource Adequacy**: DNR (Designated Network Resource) requirements and resource adequacy counting
- **Firm Service vs. Speed**: HILGER as interim solution while awaiting firm service through GIA and CPP
- **LLRIS (Large Load Retail Integrated Service)**: Its role as lesser service compared to AQ firm service
- **TSR Requests**: Transmission service requests through ATSS

## 3. Decisions or Actions

- **Next Meeting Scheduled**: June 4th (first Thursday of month pattern established)
- **Question Submission Deadline**: May 21st for inclusion in June 4th meeting
- **Submission Method**: Via SPP RMS (Request Management System) with title "Large Load Q&A"
- **Materials to be Posted**: Transcript, recording, slideshow, and additional materials on high impact arch load page at spp.org
- **Meeting Series**: Scheduled through August (subject to evaluation of usefulness)

## 4. Important Dates

- **May 21, 2026**: Deadline for submitting questions for June meeting
- **June 4, 2026**: Next Q&A meeting
- **July 2026**: Follow-up meeting (implied)
- **August 2026**: Potential final scheduled meeting
- **2028**: Referenced as example timeline for load coming online

## 5. Organizations and People Mentioned

**People:**
- **Steve Gaw**: Participant asking clarification questions
- **Aquila Bamigbade**: Representative from Clover Leaf Infrastructure
- **Calvin Rosenbaum**: Meeting facilitator/moderator
- **Nolan (Fertig)**: Technical expert/presenter (stopped transcription)
- **Jason**: Staff member (posted RMS submission instructions in chat)

**Organizations:**
- **SPP (Southwest Power Pool)**: Host organization
- **Clover Leaf Infrastructure**: Aquila's organization
- **Meeting Room**: "3A Room 372" (physical/virtual location identifier)

## 6. Links or References

- **SPP.org**: High impact arch load page (where materials will be posted)
- **SPP RMS**: Request Management System for question submission
- **CPP**: Referenced process for GIA and NRIS
- **ATSS**: System for TSR requests
- **GIA**: Generator Interconnection Agreement process
- **NRIS**: Network Resource Interconnection Service

## 7. Suggested Tags

- Large Load Processes
- HILGER Service
- Transmission Service
- Resource Adequacy
- SPP Q&A
- Network Integration
- AX Process
- AQ Process
- Firm Service
- DNR Requirements
- LLRIS
- Generator Interconnection

## 8. Items That May Need Follow-Up

1. **Clarification on HILGER Definition**: The acronym/term "HILGER" is used extensively but never fully defined in this chunk
2. **DNR Qualification Process**: How TSR requests through ATSS qualify as DNRs needs further documentation
3. **Resource Adequacy Counting**: Whether HILGER resources can count toward resource adequacy requirements remains partially unresolved
4. **Real-World Examples**: Need stakeholder submission of actual use cases by May 21st
5. **AQ Process Limitations**: The statement that HILGER "doesn't really make sense" for AQ may need additional clarification for stakeholders
6. **Long-term vs. Short-term Solutions**: Clear documentation distinguishing when to use HILGER vs. traditional firm service paths
7. **Meeting Continuation Decision**: Evaluation needed after August to determine if additional sessions are required
8. **Unanswered Questions**: Three participants had hands raised when meeting concluded - their questions remain unaddressed