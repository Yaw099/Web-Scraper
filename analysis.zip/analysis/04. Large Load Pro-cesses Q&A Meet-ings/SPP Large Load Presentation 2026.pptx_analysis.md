# Final Combined Report

# COMPREHENSIVE REGULATORY MEETING ANALYSIS REPORT
## SPP Large Load Presentation 2026

---

## 1. EXECUTIVE SUMMARY

Southwest Power Pool (SPP) has developed a comprehensive framework to address unprecedented large load growth, particularly from AI data centers, cryptocurrency mining, and industrial facilities. The presentation outlines four distinct service pathways:

**Core Services (Approved September 2024):**
- **HILL (High Impact Large Load)** - Traditional transmission service for permanent loads with sufficient generation
- **HILLGA (HILL Generation Assessment)** - Accelerated pathway for behind-the-meter or load-limited generation

**Emerging Services (2026 Implementation):**
- **CHILL (Conditional HILL)** - Temporary curtailable service (Phase 1: January 2026)
- **PAL (Price Adaptive Load)** - Usage-based service protecting market prices (Phase 2: April 2026)

**Key Drivers:**
- AI data centers projected to consume 5-8% of US electricity by 2030, potentially increasing rates 2-7% annually
- AI industry expected to contribute $4 trillion to US GDP by 2030
- Unprecedented demand requiring new 90-day study processes and proactive transmission planning

**Critical Issues:**
- Balancing grid reliability with rapid load growth
- Protecting wholesale market pricing from demand spikes
- Managing limited generation resources and permit-constrained capacity
- Providing flexible products for intermittent/curtailable loads

---

## 2. KEY TOPICS

### A. Load Connection Service Framework

#### HILL (High Impact Large Load) - Base Service
**Definition & Thresholds:**
- ≤69 kV: ≥10 MW
- >69 kV: ≥50 MW
- New commercial/industrial loads at single sites
- **Excludes:** Electric Storage Resources (must register in market)

**Two Pathways:**

1. **Attachment AQ** (Current Process)
   - For LSEs with sufficient existing generation
   - Load willing to wait on transmission upgrades
   - Base Plan Funding (BPF) cost allocation
   - 90-day study timeline for HILL
   - Permanent service status
   - Eligible for Demand Response

2. **Attachment AX** (Provisional Process)
   - For LSEs acquiring future generation
   - 60-90 day Delivery Point Network Study
   - 100% directly assigned upgrade costs
   - Load willing to wait on upgrades
   - Permanent service status

**Cost Allocation (Base Plan Funding):**
- 345 kV: 100% Regional (Load Ratio Share - 12 CP)
- 230 kV: 67% Zonal / 33% Regional
- 69 kV: 100% Zonal

**Typical Customers:**
- Heavy industry
- Mining operations
- Refineries
- Data centers with continuous demand

#### HILLGA (HILL Generation Assessment)

**Path 1: Behind the Meter (Non-Jurisdictional)**
- Previously required full Generator Interconnection (GI) process for >5 MW
- **Now:** 90-day study for zero-injection configurations
- Generation >10 MW must be market registered
- Separate metering required for load and generation
- Load-owned or partnership arrangements
- **Status:** Permanent or can transition to grid injection with DISIS/CPP

**Path 2: Load Limited Resource Interconnection Service (LLRIS) - Attachment BB**
- Generation within 2 substations of each load
- Maximum 5 substations, 2 transmission lines
- Output limited to HILL amounts
- **Formula:** Total generation capacity ≤ HILL load × Max(110% + PRM, 125%)
- **Interim service:** 5 years, then transitions to firm with CPP GRID-C fee
- Directly assigned transmission costs

**Common Bus vs. Local Area:**
- Supporting generation built behind common bus with HILL
- Must maintain electrical proximity requirements

**Study Requirements:**
- $250,000 flat fee (up to 500 MW)
- $500,000 flat fee (>500 MW)
- $20,000 application fee
- $8,000/MW security deposit at application

**Key Limitation:**
- Current inability to take HILLGA outages (future changes anticipated)

#### CHILL (Conditional HILL) - Attachment BC

**Service Characteristics:**
- Curtailable, non-conforming load service
- For large loads willing to accept curtailment without sufficient generation
- **Initial term:** Up to 1 year
- **Long-term:** Up to 7 years (after study completion), then must pursue AX/AQ
- **All CHILL curtailed during EEA2** (Emergency Energy Alert Level 2)
- Not eligible for Demand Response
- Directly assigned transmission costs

**Two CHILL Options:**

1. **Option 1:** Adequate generation but contingent on transmission upgrades
   - Curtailed when system limitations are realized
   
2. **Option 2:** Requires accredited equivalent HILLGA generation
   - Curtailed if generation becomes unavailable

**Stakeholder Concerns:**
- **Market pricing impacts:** More load without generation = higher prices
- **Impact on limited/permit-limited generation resources:** Increased run hours
- **Stakeholder requests:** Some desire allowance for uncovered CHILL

**Status:** Phase 1 implementation January 2026

**Typical Customers:**
- Data centers with scalable operations
- Flexible industrial loads

#### PAL (Price Adaptive Load) - Proposed New Product

**Concept:**
- Only pulls power when excess energy exists on system
- Studied in LOLE without increasing planning reserve margin
- Effectuated through price sensitivity or projected dispatch stack
- Storage not injecting into system may be eligible
- **Purpose:** Protect market prices from demand spikes

**Service Characteristics:**
- Available to any load willing to take curtailable service
- Curtailable for price OR reliability
- Flow-based (usage-based) transmission costs vs. reservation-based
- Not eligible for Demand Response
- Permanent service status

**Typical Customers:**
- Cryptocurrency mining
- Battery storage operations
- Highly flexible, low load factor operations

**Status:** Phase 2 implementation April 2026

**Addresses Stakeholder Needs:**
- Usage-based transmission payment structure
- Permanent curtailable product (vs. temporary CHILL)
- No Designated Resources requirement

---

### B. Large Load Growth Drivers & Market Context

#### AI Data Centers
- **Economic Impact:** $4 trillion US GDP growth by 2030 ($15 trillion globally)
- **Electricity Consumption:** 5-8% of US electricity by 2030
- **Rate Impact:** May drive 2-7% annual electricity rate increases
- **Operational Profile:** Flat, continuous 24/7 operation with low ramping ability
- **US Competitive Position:** 
  - Top 5 US tech firms hold >75% of AI patent share
  - 7 of top 10 AI universities located in US
  - China investing $70 billion by 2025 as competitor

#### Cryptocurrency Mining
- **Load Range:** 5-100+ MW
- **Flexibility:** High demand response appetite
- **Operational Profile:** Can respond rapidly to price signals

#### Manufacturing & Heavy Industry
- **Load Range:** 20-500+ MW
- **Flexibility:** Moderate to low
- **Examples:** Refineries, mining operations

#### Green Hydrogen Production
- **Load Range:** 20-300+ MW
- **Flexibility:** High flexibility potential
- **Growth Driver:** Clean energy transition

#### Battery Energy Storage Systems (BESS)
- **Load Range:** 10-500+ MW
- **Flexibility:** Very high flexibility
- **Unique Status:** Must register as market resource, excluded from HILL definition

#### Other Load Types
- EV charging hubs
- Mining operations (mineral extraction)
- Oil & gas facilities

---

### C. Technical Study Requirements

#### Study Timeline & Process
- **All HILL services:** 90 calendar days standard
- **Preliminary Assessment:** 10 business days
- **Delivery Point Network Study (AX):** 60-90 calendar days
- **SCRCCT screening:** Performed for DISIS and HILLGA
- **Additional EMT/PSCAD:** May be required outside 90-day window

#### Model Years for Analysis
**Steady-State Analysis:**
- ITP Years 1, 2, 3, 5, and 10

**Stability

---

# Partial Chunk Reports

# Chunk 1 Analysis

# REGULATORY MEETING ANALYSIS REPORT
## SPP Large Load Presentation 2026

---

## 1. Executive Summary

This presentation outlines Southwest Power Pool's (SPP) comprehensive approach to managing large load connections, with a particular focus on High Impact Large Loads (HILLs) driven by AI data centers and other industrial growth. SPP has developed new processes and service classifications to address unprecedented demand growth while maintaining grid reliability. The framework includes three main pathways: traditional transmission service (Attachments AQ/AX), High Impact Large Load Generation Assessment (HILLGA) for behind-the-meter and load-limited generation, and Conditional HILL (CHILL) service for curtailable loads. AI-driven loads are projected to consume 5-8% of US electricity by 2030 and may drive 2-7% annual electricity rate increases. SPP is implementing proactive transmission planning to accommodate this growth while developing new study processes completed within 90 calendar days for HILL requests.

---

## 2. Key Topics

### Load Connection Framework
- **All loads require transmission service** through utilities with load-serving authority
- **Attachment AQ**: For loads with existing sufficient generation (90-day timeline for HILL)
- **Attachment AX**: Provisional process for loads with future planned generation (60-90 day studies)
- Cost allocation varies: Base Plan Funding (BPF) vs. 100% directly assigned upgrade costs

### High Impact Large Load (HILL) Definition
- **Voltage-based thresholds**:
  - ≤69 kV: ≥10 MW
  - >69 kV: ≥50 MW
- New commercial/industrial loads at single sites
- **Excludes**: Electric Storage Resources (must register in market)

### Study Requirements for HILLs
- **90 calendar day timeline**
- **Analyses include**:
  - Transient Stability with SPP HILL ride-through requirements
  - Electromagnetic Transient (EMT) Screening
  - Short-Circuit Ratio and Critical Clearing Time
  - Full EMT analysis if issues occur

### HILL Generation Assessment (HILLGA)
Two pathways for generation:

**Path 1: Behind the Meter (Non-Jurisdictional)**
- Previously required full GI process for >5 MW
- Now: 90-day study for zero-injection configurations
- Generation >10 MW must be market registered
- Separate metering required

**Path 2: Load Limited Resource Interconnection Service (LLRIS) - Attachment BB**
- Generation within 2 substations of each load
- Maximum 5 substations, 2 transmission lines
- Output limited to HILL amounts
- Formula: Total capacity ≤ HILL load × Max(110%+PRM, 125%)
- Interim service for 5 years, then subject to CPP GRID-C fee

### Conditional HILL (CHILL) Service - Attachment BC
- **Phase 2 under development**
- Curtailable, non-conforming load service
- Up to 1-year initial term, potential 7-year long-term
- **All CHILL curtailed during EEA2**

**Two CHILL Options**:
1. Adequate generation but contingent on transmission upgrades (curtailed when limitations realized)
2. Requires accredited equivalent HILLGA generation (curtailed if generation unavailable)

### Load Growth Drivers
**AI Data Centers**:
- Projected $4 trillion US GDP growth by 2030
- 5-8% of US electricity consumption by 2030
- Flat, continuous 24/7 operation with low ramping ability

**Other Large Load Types**:
- Cryptocurrency mining (5-100+ MW, high demand response appetite)
- Manufacturing/heavy industry (20-500+ MW)
- Green hydrogen production (20-300+ MW, high flexibility)
- Battery Energy Storage Systems (10-500+ MW, very high flexibility)
- EV charging hubs, mining operations, oil & gas facilities

### Study Models and Analyses
**Model Years**:
- Steady-State: ITP Years 1, 2, 3, 5, and 10
- Stability: Years 2 and 10
- Short-Circuit: Year 5

**Study Components**:
- Monitored elements: SPP facilities 69 kV+, First-Tier Companies 100 kV+
- Applies SPP Criteria and NERC Reliability Standards
- Contingency analysis for SPP and First-Tier Companies

### Cost Allocation Methods
- **Base Plan Funding (BPF)**: Load Ratio Share (12 CP)
  - 345 kV: 100% Regional
  - 230 kV: 67% Zonal/33% Regional
  - 69 kV: 100% Zonal
- **Direct Assignment**: 100% customer-funded for provisional loads

---

## 3. Decisions or Actions

### Implemented Processes
- HILL definition and thresholds established
- 90-day study timeline for HILL requests approved
- HILLGA pathways (Behind-the-Meter and LLRIS) operational
- New EMT screening requirements for HILLs

### Under Development
- CHILL service (Attachment BC) - Phase 2
- Long-term CHILL service framework (up to 7 years)
- CHILL curtailment protocols and options

### Required Actions for Load Customers
- Execute AQ/AX transmission service agreements through utilities
- Demonstrate sufficient Designated Resources (for AQ)
- Register generation >10 MW in market (Behind-the-Meter path)
- Maintain separate metering for load and generation
- Comply with SPP ride-through requirements

### Planning Response
- Include large load growth in 2025 and 2026 planning models
- Implement proactive transmission investment strategies

---

## 4. Important Dates

### Study Timelines
- **HILL studies**: 90 calendar days
- **Preliminary Assessment**: 10 business days
- **Delivery Point Network Study**: 60-90 calendar days
- **Attachment AX studies**: 60-90 calendar days

### Service Terms
- **HILLGA LLRIS**: 5-year interim service before transitioning to firm with CPP GRID-C fee
- **CHILL initial service**: Up to 1 year
- **CHILL long-term service**: Up to 7 years (path available after initial year)

### Planning Horizons
- **2025-2026**: Planning models include large load growth
- **By 2030**: AI data centers projected to use 5-8% of US electricity
- **Model years**: Years 1, 2, 3, 5, and 10 for various studies

---

## 5. Organizations and People Mentioned

### Organizations
- **SPP (Southwest Power Pool)** - Primary organization
- **FERC (Federal Energy Regulatory Commission)** - Regulatory authority (proforma language reference)
- **NERC (North American Electric Reliability Corporation)** - Reliability standards authority
- **First-Tier Companies** - Interconnected utilities (100 kV+ facilities monitored)
- **Transmission Customers/Utilities** - Load-serving entities
- **US Tech Firms** - Top 5 hold >75% of AI patent share
- **China** - Competitor in AI investment ($70 billion by 2025)

### Universities
- US hosts 7 of top 10 universities for AI (unspecified)

### People
No specific individuals mentioned in this presentation.

---

## 6. Links or References

### Referenced Documents/Processes
- **Attachment AQ** - Current load addition process
- **Attachment AX** - Provisional load connection process
- **Attachment BB** - HILLGA Load Limited Interconnection Service
- **Attachment BC** - CHILL service (under development)
- **DISIS** - Full generation interconnection process
- **CPP GRID-C fee** - Planned site fee structure
- **ITP (Integrated Transmission Planning)** - Model basis
- **Transmission System Planning** - Study framework

### Standards and Criteria
- SPP Criteria
- NERC Reliability Standards
- FERC proforma language

### Study Processes
- Generator Interconnection (GI)
- Transmission Service (TS)
- Operations and Markets HILL Processes

### External References
- AI GDP impact projections ($15 trillion globally, $4 trillion US by 2030)
- US AI defense spending

---

# Chunk 2 Analysis

# REGULATORY MEETING ANALYSIS REPORT
## SPP Large Load Presentation 2026

---

## 1. Executive Summary

This presentation (chunk 2 of 2) details Southwest Power Pool's (SPP) comprehensive framework for managing large load interconnections, particularly addressing concerns around the CHILL (Conditional High Impact Load) service. The document outlines multiple service options for large loads including HILL (High Impact Load), HILLGA (High Impact Load Generation Assessment), and a proposed PAL (Price Adaptive Load) service. Key issues addressed include market pricing impacts, generation resource limitations, and stakeholder desires for more flexible transmission products. The presentation includes detailed technical requirements, financial comparisons, and study processes for different service types, with particular focus on accommodating data centers, crypto mining, and other high-demand industrial customers.

---

## 2. Key Topics

### CHILL Service Concerns and Evolution
- Two primary concerns driving requirement for supporting generation:
  - Impact to market pricing (more load = higher prices)
  - Impact to run hours on limited/permit limited resources
- Inability to take HILLGA outages (future changes anticipated)
- Some stakeholders desire allowance for uncovered CHILL

### Stakeholder Requests for New Products
- Permanent curtailable load transmission product without Designated Resources requirement (CHILL is temporary, 5-7 years)
- Usage-based transmission payment vs. reservation-based (for low load factor, highly flexible loads)
- Ability to use storage for ramp management and ride-through requirements

### Price Adaptive Load (PAL) - New Product Concept
- Only pulls power when excess energy exists on system
- Load studied in LOLE without increasing planning reserve margin
- Could be effectuated through price sensitivity or projected dispatch stack
- Storage not injecting into system may be eligible
- Designed to protect market prices

### Service Type Comparison
**HILL (for Load):**
- AQ Process: For LSEs with sufficient generation; load willing to wait on upgrades
- AX Process: For LSEs acquiring generation; load willing to wait on upgrades
- Typical customers: Heavy industry, mining, refineries, data centers with continuous demand
- Permanent status
- Upgrades are base plan funded
- Eligible for Demand Response

**HILLGA (for Generation):**
- Common Bus: Supporting gen built behind common bus with HILL
- Local Area: Supporting gen built behind common bus with HILL
- Load-owned or partnership arrangements
- Permanent status or grid injection with DISIS/CPP
- Directly assigned transmission costs

**CHILL:**
- For large load willing to take curtailable service without sufficient generation
- Typical customers: Data centers with scalable operation
- 7-year limited status (after study complete), must pursue AX/AQ
- Curtailable for reliability (RA or Tx)
- Not eligible for Demand Response
- Directly assigned transmission costs

**PAL (Proposed):**
- For any load willing to take curtailable service to protect market prices
- Typical customers: Crypto Mining or Battery
- Curtailable for price or reliability
- Not eligible for Demand Response
- Flow-based transmission costs

### Technical Requirements

**Ride-Through Performance for HILL:**
- Voltage Ride-Through (ITIC curves)
- Transient Overvoltage Ride-Through (IEEE 2800)
- Frequency Ride-Through (proposed PRC-001)

**Ride-Through Performance for Resources Paired with HILL:**
- IBRs: Based on IEEE 2800-2022 Clause 7
- Synchronous generators, condensers, Type 1/2 wind: Based on PRC-024-4 requirements

**Study Requirements:**
- All service types: 90-day study timeline
- SCRCCT screening performed for DISIS and HILLGA
- Additional EMT/PSCAD may be required outside 90 days

**Stability Analysis:**
- TPL-001 contingencies: P0, P1, P2.1-2.3, P4, and P5
- Unsuccessful reclosing evaluated for P1 and P6 events
- Evaluates system stability, FERC Order 661-A compliance, SPP Disturbance Performance Requirements

### Load Hosting Capacity Tool
- Provides ATC (Available Transfer Capability) data
- Determines maximum load amount per bus on SPP Transmission System
- Monthly updates
- *Pending FERC approval

### Financial Comparisons

**Study Deposits:**
- AQ: $10,000 study deposit
- AX: Billable after study completion
- HILL: $125,000 ($200,000 for EMT) - Proposed revision to billable after study completion
- HILLGA: $250,000 flat fee (up to 500 MW), $500,000 (>500 MW)

**DISIS vs. HILLGA:**
- DISIS: $10,000 application fee, tiered study deposits ($35K-$250K based on MW)
- HILLGA: $20,000 application fee, flat fee structure
- Security deposits: HILLGA requires $8,000/MW at application vs. DISIS $4,000/MW with tiered additional requirements

---

## 3. Decisions or Actions

### Implemented Decisions
- HILL (for Load): MOPC approved Aug 21, BOD approved Sept. 4
- HILLGA (for Generation): MOPC approved Aug 21, BOD approved Sept. 4

### Planned Actions
- **Phase 1 CHILL**: Implementation January 2026
- **Phase 2 PAL**: Implementation April 2026
- Future changes anticipated for HILLGA outage inability issue
- Proposed revision to HILL study deposit structure (billable after study completion)

### Under Consideration
- Price Adaptive Load (PAL) product development
- Allowing some amount of uncovered CHILL per stakeholder requests
- Permanent curtailable load transmission product

---

## 4. Important Dates

- **August 21**: MOPC approval of HILL and HILLGA policies
- **September 4**: BOD approval of HILL and HILLGA policies
- **January 2026**: Phase 1 (CHILL) implementation
- **April 2026**: Phase 2 (PAL) implementation
- **90 calendar days**: Standard study timeline for all service types
- **5-7 years**: CHILL temporary service duration (7 years after study completion)

---

## 5. Organizations and People Mentioned

### Organizations
- **SPP (Southwest Power Pool)** - Primary regulatory authority
- **MOPC** - Markets and Operations Policy Committee
- **BOD** - Board of Directors
- **FERC** - Federal Energy Regulatory Commission
- **LSEs** - Load Serving Entities
- **Transmission Owners**
- **Transmission Customers**

### Standards/Regulatory Bodies Referenced
- FERC Order 888/890 Pro Forma Tariff
- FERC Order 661-A
- IEEE 2800-2022 Clause 7
- PRC-024-4 (currently on version 3)
- PRC-001 (proposed)
- TPL-001
- ITIC curves

### Customer Types Mentioned
- Heavy industry
- Mining operations
- Refineries
- Data centers
- Crypto mining operations
- Battery storage operators
- Developers

---

## 6. Links or References

### Technical Standards
- FERC Order 888/890 Pro Forma Tariff
- FERC Order 661-A
- IEEE 2800-2022 Clause 7
- PRC-024-4
- PRC-001 (proposed)
- TPL-001
- ITIC curves
- SPP Disturbance Performance Requirements

### SPP Processes
- DISIS (Definitive Interconnection System Impact Study)
- CPP (process not defined in excerpt)
- ITP (Integrated Transmission Planning)
- Attachment BB HILLGA Process

### Study Types
- LOLE (Loss of Load Expectation)
- SCRCCT screening
- EMT/PSCAD analysis
- Steady-State Model
- Stability Model

---

## 7. Suggested Tags

- SPP
- Large Load Interconnection
- HILL
- HILLGA
- CHILL
- Price Adaptive Load
- PAL
- Transmission Service
- Data Centers
- Resource Adequacy
- Demand Response
- Curtailable Load
- FERC Compliance
- Transmission Planning
-